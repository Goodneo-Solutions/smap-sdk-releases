package ca.superroute.smap

import android.annotation.SuppressLint
import android.graphics.PointF
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import com.google.gson.JsonObject
import kotlinx.coroutines.CoroutineScope
import org.maplibre.android.geometry.LatLng
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point
import kotlin.math.sqrt

/**
 * Draws a plan editor's plan on an [SMap] through its points and lines layers — `<id>:legs`, `<id>:starts`,
 * `<id>:stop-borders`, `<id>:stops` (numbered), `<id>:unassigned` — and lets a stop (or an unassigned job) be moved:
 * long-press its pin, drag it (the map does not pan meanwhile) before another stop or onto a route's line, and let go.
 * While it is dragged, the routes the drop would make are priced as a preview 250 ms after the target last changed.
 */
@SuppressLint("ClickableViewAccessibility")
class SMapPlanLayer internal constructor(
    private val map: SMap,
    private val editor: SMapPlanEditor,
    val id: String,
    private val colors: List<String>,
    preview: Boolean,
) {
    private val legs = "$id:legs"
    private val starts = "$id:starts"
    private val borders = "$id:stop-borders"
    private val stops = "$id:stops"
    private val unassigned = "$id:unassigned"
    private val marker = "$id:drag"
    private val handler = Handler(Looper.getMainLooper())
    private val drag = SMapPlanDrag(editor, SMapPlanScheduler { ms, block ->
        val r = Runnable(block)
        handler.postDelayed(r, ms)
        val cancel: () -> Unit = { handler.removeCallbacks(r) }
        cancel
    }, preview)
    private val density = map.resources.displayMetrics.density
    private val slop = ViewConfiguration.get(map.context).scaledTouchSlop
    private var added = false
    private var removed = false
    private var pressed: Triple<String, Float, Float>? = null
    private var armed = false
    private var panWas: Boolean? = null

    private val listener: (SMapPlanEvent) -> Unit = { e ->
        when (e) {
            is SMapPlanEvent.Change -> draw()
            SMapPlanEvent.Destroy -> remove()
            else -> Unit
        }
    }

    private val longPress = Runnable {
        val p = pressed ?: return@Runnable
        pressed = null
        armed = true
        drag.start(p.first, p.second, p.third)
        setPan(false)
        map.engineView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        // The map stops the gesture it began with this finger.
        val now = SystemClock.uptimeMillis()
        val cancel = MotionEvent.obtain(now, now, MotionEvent.ACTION_CANCEL, p.second, p.third, 0)
        map.engineView.onTouchEvent(cancel)
        cancel.recycle()
    }

    private val touch = View.OnTouchListener { _, e -> onTouch(e) }

    init {
        editor.addListener(listener)
        draw()
        map.engineView.setOnTouchListener(touch)
    }

    /** The features drawn now. */
    fun features(): SMapPlanFeatures = SMapPlanDraw.features(editor, id, colors)

    /** The layer ids on the map. */
    val layerIds: List<String> get() = listOf(legs, starts, borders, stops, unassigned, marker)

    /** Takes the plan off the map and stops listening to the editor. */
    fun remove() {
        if (removed) return
        removed = true
        cancelPress()
        drag.cancel()
        armed = false
        setPan(true)
        editor.removeListener(listener)
        map.engineView.setOnTouchListener(null)
        if (added) layerIds.forEach { try { map.removeLayer(it) } catch (e: Exception) { /* already gone */ } }
    }

    private fun draw() {
        if (removed) return
        val f = features()
        val legData = collection(f.legs) { mapOf("stroke" to it.properties["color"]) }
        val startData = collection(f.starts) { mapOf("marker-color" to it.properties["color"], "marker-size" to "large") }
        val borderData = collection(f.stops) { mapOf("marker-color" to it.properties["border"], "marker-size" to "large", "kind" to "stop-border") }
        val stopData = collection(f.stops) { mapOf("marker-color" to it.properties["color"]) }
        val jobData = collection(f.unassigned) { emptyMap() }
        if (!added) {
            map.addLines(legs, legData, SMapLineOptions(width = 4f))
            map.addPoints(starts, startData, SMapPointOptions())
            map.addPoints(unassigned, jobData, SMapPointOptions(color = "#9ca3af", radius = 9f))
            map.addPoints(borders, borderData, SMapPointOptions())
            map.addPoints(stops, stopData, SMapPointOptions(label = "label"))
            map.addPoints(marker, FeatureCollection.fromFeatures(emptyList()), SMapPointOptions(color = SMapPlanDraw.LOCKED, radius = 8f))
            added = true
        } else {
            map.setData(legs, legData)
            map.setData(starts, startData)
            map.setData(unassigned, jobData)
            map.setData(borders, borderData)
            map.setData(stops, stopData)
        }
    }

    // Features with the plan's properties plus the simplestyle values the SDK's layers draw with.
    private fun collection(list: List<SMapPlanFeature>, style: (SMapPlanFeature) -> Map<String, Any?>): FeatureCollection =
        FeatureCollection.fromFeatures(list.map { f ->
            val props: JsonObject = SMapGeoJson.properties(f.properties + style(f))
            val geometry = if (f.kind == "leg") LineString.fromLngLats(f.coordinates.map { Point.fromLngLat(it[0], it[1]) })
            else Point.fromLngLat(f.coordinates[0][0], f.coordinates[0][1])
            Feature.fromGeometry(geometry, props)
        })

    private fun setPan(on: Boolean) {
        val ui = map.mapEngine ?: return
        if (!on) {
            if (panWas == null) panWas = ui.isScrollGesturesEnabled
            ui.isScrollGesturesEnabled = false
        } else {
            panWas?.let { ui.isScrollGesturesEnabled = it }
            panWas = null
        }
    }

    private fun cancelPress() {
        handler.removeCallbacks(longPress)
        pressed = null
    }

    private fun onTouch(e: MotionEvent): Boolean {
        if (removed) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                cancelPress()
                val hit = hitsAt(e.x, e.y).firstOrNull { it["kind"] == "stop" || it["kind"] == "unassigned" }
                val stop = hit?.get("id")?.toString()
                if (stop != null) {
                    pressed = Triple(stop, e.x, e.y)
                    handler.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                }
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                if (armed) {
                    drag.move(hitsAt(e.x, e.y), e.x, e.y)
                    if (drag.moved) {
                        map.mapEngine?.fromScreenLocation(PointF(e.x, e.y))?.let { at ->
                            map.setData(marker, listOf(SMapPoint(at.latitude, at.longitude)))
                        }
                    }
                    return true
                }
                pressed?.let { p -> if (Math.abs(e.x - p.second) + Math.abs(e.y - p.third) > slop) cancelPress() }
                return false
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                cancelPress()
                return armed
            }
            MotionEvent.ACTION_UP -> {
                cancelPress()
                if (!armed) return false
                armed = false
                setPan(true)
                map.setData(marker, emptyList<SMapPoint>())
                drag.end(hitsAt(e.x, e.y))
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelPress()
                if (!armed) return false
                armed = false
                setPan(true)
                map.setData(marker, emptyList<SMapPoint>())
                drag.cancel()
                return true
            }
        }
        return armed
    }

    // The plan's features under a screen point, nearest first (a feature query of the plan's layers at the pointer).
    private fun hitsAt(x: Float, y: Float): List<Map<String, Any?>> {
        val eng = map.mapEngine ?: return emptyList()
        val style = eng.engineStyle ?: return emptyList()
        val layers = listOf(SMapEngineIds.points(stops), SMapEngineIds.points(unassigned), SMapEngineIds.points(starts), SMapEngineIds.lines(legs))
            .filter { style.getLayer(it) != null }
        if (layers.isEmpty()) return emptyList()
        val r = TOUCH_DP * density
        val found = eng.queryRenderedFeatures(RectF(x - r, y - r, x + r, y + r), *layers.toTypedArray())
        val projection = eng
        fun screen(p: Point): PointF = projection.toScreenLocation(LatLng(p.latitude(), p.longitude()))
        val hits = found.mapIndexedNotNull { order, f ->
            val props = SMapGeoJson.propertiesOf(f)
            if (props["smap_plan"] != id) return@mapIndexedNotNull null
            val d = when (val g = f.geometry()) {
                is Point -> screen(g).let { q -> sqrt(((q.x - x) * (q.x - x) + (q.y - y) * (q.y - y)).toDouble()) }
                is LineString -> g.coordinates().map(::screen).zipWithNext { a, b -> segmentDistance(x, y, a, b) }.minOrNull() ?: Double.MAX_VALUE
                else -> Double.MAX_VALUE
            }
            Triple(props, d, order)
        }
        return hits.sortedWith(compareBy({ it.second }, { it.third })).map { it.first }
    }

    private fun segmentDistance(px: Float, py: Float, a: PointF, b: PointF): Double {
        val dx = (b.x - a.x).toDouble()
        val dy = (b.y - a.y).toDouble()
        val l = dx * dx + dy * dy
        val t = if (l > 0) ((px - a.x) * dx + (py - a.y) * dy).div(l).coerceIn(0.0, 1.0) else 0.0
        val x = a.x + t * dx - px
        val y = a.y + t * dy - py
        return sqrt(x * x + y * y)
    }

    private companion object {
        /** Half the side of the square a pointer's features are looked for in. */
        const val TOUCH_DP = 12f
    }
}

/**
 * The plan editor's panel on a map.
 *
 * @param position the corner of the panel
 * @param label the tool's label in the tools control (default the `editor` text)
 * @param labels the app's own texts by key, over the language's
 * @param id the tool id (default `<layer id>-editor`)
 */
data class SMapPlanPanelOptions(
    val position: SMapToolPosition = SMapToolPosition.TOP_LEFT,
    val label: String? = null,
    val labels: Map<String, String>? = null,
    val id: String? = null,
)

/**
 * A plan editor on this map: its layers ([SMapPlanEditor.layer]) and the panel as a map tool ([SMapPlanEditor.panel],
 * unless [panel] is null). [SMapPlanEditor.destroy] takes both away.
 *
 * @param layerId the prefix of the plan's layer ids
 * @param colors the route colours, one per vehicle in plan order
 * @param preview price the drop while a stop is dragged
 * @param language the panel's language (default the map's)
 * @param scope where the editor's calls run (default the main thread)
 */
fun SMap.planEditor(
    options: SMapPlanEditorOptions,
    layerId: String = "plan",
    colors: List<String> = SMapPlanDraw.COLORS,
    preview: Boolean = true,
    panel: SMapPlanPanelOptions? = SMapPlanPanelOptions(),
    language: String? = null,
    scope: CoroutineScope? = null,
): SMapPlanEditor {
    val editor = SMapPlanEditor(options.copy(plan = null, smapUrl = options.smapUrl ?: this.options.baseUrl), context, scope)
    editor.layer = SMapPlanLayer(this, editor, layerId, colors, preview)
    if (panel != null) {
        val view = SMapPlanPanel(context, editor, language ?: this.language, panel.labels, colors)
        editor.panel = view
        val toolId = panel.id ?: "$layerId-editor"
        addTool(toolId, view, panel.label ?: view.texts.getValue("editor"), panel.position)
        editor.addListener { if (it is SMapPlanEvent.Destroy) removeTool(toolId) }
    }
    options.plan?.let { plan -> editor.perform { setPlan(plan) } }
    return editor
}
