package ca.superroute.smap

import android.graphics.Bitmap
import android.graphics.PointF
import android.graphics.RectF
import android.view.View
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.Layer
import org.maplibre.android.style.sources.Source
import org.maplibre.android.style.sources.GeoJsonOptions
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import java.net.URI

/**
 * The map engine under [SMap] (sRender DESIGN §12 N1, §13): the part of the engine the SDK uses — camera,
 * projection, feature queries, events, the style — so either engine can draw the map behind the same SDK calls.
 * MapLibre Native is one ([SMapMapLibreEngine]); sRender is the other. The SDK keeps describing its sources and
 * layers with MapLibre's style objects ([Source], [Layer]); an engine other than MapLibre reads them as the Style
 * Specification (§13 E6). Every call on the main thread.
 */
internal interface SMapEngine {
    /** "maplibre" or "srender". */
    val engineName: String

    /** The view the engine draws into (placed in the SDK's view). */
    val view: View

    /** The style loaded last; null until one has loaded and while the next loads. */
    val engineStyle: SMapEngineStyle?

    /** Loads a style by address; [loaded] once it has (not after a newer one was asked for). */
    fun loadStyle(uri: String, loaded: (SMapEngineStyle) -> Unit)

    // Camera

    val cameraPosition: CameraPosition
    fun moveCamera(camera: CameraPosition)

    /** Animates to [camera] over [durationMillis] (null: the engine's own duration); [ease] straight, else flying. */
    fun animateCamera(camera: CameraPosition, durationMillis: Int?, ease: Boolean = false)

    /** The camera fitting [bounds] inside the view less [padding] (left, top, right, bottom pixels). */
    fun cameraFor(bounds: LatLngBounds, padding: IntArray, bearing: Double, tilt: Double): CameraPosition?

    // Projection

    fun toScreenLocation(position: LatLng): PointF
    fun fromScreenLocation(point: PointF): LatLng

    /** The box around the view (around a turned or tilted view too). */
    val visibleBounds: LatLngBounds
    fun metersPerPixelAtLatitude(latitude: Double): Double

    // Features

    fun queryRenderedFeatures(point: PointF, filter: Expression?, vararg layerIds: String): List<Feature>
    fun queryRenderedFeatures(box: RectF, filter: Expression?, vararg layerIds: String): List<Feature>
    fun queryRenderedFeatures(point: PointF, vararg layerIds: String): List<Feature> = queryRenderedFeatures(point, null, *layerIds)
    fun queryRenderedFeatures(box: RectF, vararg layerIds: String): List<Feature> = queryRenderedFeatures(box, null, *layerIds)

    // Controls and gestures

    var isCompassEnabled: Boolean
    var isScrollGesturesEnabled: Boolean
    fun triggerRepaint()

    // Events

    fun addOnCameraMoveStartedListener(l: MapLibreMap.OnCameraMoveStartedListener)
    fun addOnCameraMoveListener(l: MapLibreMap.OnCameraMoveListener)
    fun removeOnCameraMoveListener(l: MapLibreMap.OnCameraMoveListener)
    fun addOnCameraIdleListener(l: MapLibreMap.OnCameraIdleListener)
    fun removeOnCameraIdleListener(l: MapLibreMap.OnCameraIdleListener)
    fun addOnMapClickListener(l: MapLibreMap.OnMapClickListener)
    fun addOnMapLongClickListener(l: MapLibreMap.OnMapLongClickListener)
    /** A frame was drawn; `fully` when every tile of the view was. */
    fun addOnDidFinishRenderingFrameListener(l: (fully: Boolean) -> Unit)
    fun removeOnDidFinishRenderingFrameListener(l: (fully: Boolean) -> Unit)
    /** Nothing is left to draw (every tile of the view loaded and drawn). */
    fun addOnDidBecomeIdleListener(l: () -> Unit)
    /** The style or the map could not load. */
    fun addOnDidFailLoadingMapListener(l: (String?) -> Unit)

    /** The last frame as a picture. */
    fun snapshot(done: (Bitmap?) -> Unit)

    /** The engine is no longer used: what it holds is freed (MapLibre's map view lives as long as the SDK's view). */
    fun destroy() {}
}

/** The style of an [SMapEngine]: MapLibre's [Style] as it is, or sRender's reading of the same objects. */
internal interface SMapEngineStyle {
    fun getSource(id: String): Source?
    fun getLayer(id: String): Layer?
    val layers: List<Layer>
    /** The layers' ids in order (without making an object of each, which [layers] does on sRender). */
    val layerIds: List<String>
    val sources: List<Source>
    fun addSource(source: Source)
    fun removeSource(id: String): Boolean
    fun removeSource(source: Source): Boolean = removeSource(source.id)
    fun addLayer(layer: Layer)
    fun addLayerBelow(layer: Layer, below: String)
    fun addLayerAbove(layer: Layer, above: String)
    fun addLayerAt(layer: Layer, index: Int)
    fun removeLayer(id: String): Boolean
    fun removeLayer(layer: Layer): Boolean = removeLayer(layer.id)
    fun addImage(name: String, bitmap: Bitmap, sdf: Boolean = false)
    fun getImage(name: String): Bitmap?
    fun removeImage(name: String)
    /** The whole style as JSON. */
    val json: String
    /**
     * Adds a GeoJSON source: [data] a [FeatureCollection], a [Feature], GeoJSON text or a [java.net.URI]. GeoJSON
     * sources are made and changed only here (MapLibre keeps a source's data to itself).
     */
    fun addGeoJsonSource(id: String, data: Any?, options: GeoJsonOptions? = null)
    /** Replaces a GeoJSON source's data (as [addGeoJsonSource] takes it); false when there is no such source. */
    fun setGeoJson(id: String, data: Any?): Boolean
    /** A GeoJSON source's feature state (G21), by feature key: values merged into what the feature has. */
    fun setFeatureState(source: String, key: String, state: com.google.gson.JsonObject)
    /** Removes one value of a feature's state. */
    fun removeFeatureState(source: String, key: String, name: String)
    /** A GeoJSON source's features (`querySourceFeatures`). */
    fun sourceFeatures(source: String, filter: Expression? = null): List<Feature>
    /** The zoom at which a cluster of a clustered GeoJSON source falls apart (−1 when unknown). */
    fun clusterExpansionZoom(source: String, cluster: Feature): Int
    fun clusterLeaves(source: String, cluster: Feature, limit: Long, offset: Long): List<Feature>
}

/** MapLibre Native as the engine: its map view and map, every call as it was. */
internal class SMapMapLibreEngine(val mapView: MapView, val map: MapLibreMap) : SMapEngine {
    override val engineName = "maplibre"
    override val view: View get() = mapView
    private var styleWrapper: SMapMapLibreStyle? = null
    override val engineStyle: SMapEngineStyle?
        get() {
            val s = map.style?.takeIf { it.isFullyLoaded } ?: return null
            return styleWrapper?.takeIf { it.style === s } ?: SMapMapLibreStyle(s).also { styleWrapper = it }
        }

    override fun loadStyle(uri: String, loaded: (SMapEngineStyle) -> Unit) {
        map.setStyle(Style.Builder().fromUri(uri)) { s -> loaded(SMapMapLibreStyle(s).also { styleWrapper = it }) }
    }

    override val cameraPosition: CameraPosition get() = map.cameraPosition
    override fun moveCamera(camera: CameraPosition) = map.moveCamera(CameraUpdateFactory.newCameraPosition(camera))
    override fun animateCamera(camera: CameraPosition, durationMillis: Int?, ease: Boolean) {
        val u = CameraUpdateFactory.newCameraPosition(camera)
        when {
            durationMillis == null -> map.animateCamera(u)
            ease -> map.easeCamera(u, durationMillis)
            else -> map.animateCamera(u, durationMillis)
        }
    }
    override fun cameraFor(bounds: LatLngBounds, padding: IntArray, bearing: Double, tilt: Double) = map.getCameraForLatLngBounds(bounds, padding, bearing, tilt)

    override fun toScreenLocation(position: LatLng): PointF = map.projection.toScreenLocation(position)
    override fun fromScreenLocation(point: PointF): LatLng = map.projection.fromScreenLocation(point)
    override val visibleBounds: LatLngBounds get() = map.projection.visibleRegion.latLngBounds
    override fun metersPerPixelAtLatitude(latitude: Double) = map.projection.getMetersPerPixelAtLatitude(latitude)

    override fun queryRenderedFeatures(point: PointF, filter: Expression?, vararg layerIds: String): List<Feature> =
        map.queryRenderedFeatures(point, filter, *layerIds)
    override fun queryRenderedFeatures(box: RectF, filter: Expression?, vararg layerIds: String): List<Feature> =
        map.queryRenderedFeatures(box, filter, *layerIds)

    override var isCompassEnabled: Boolean
        get() = map.uiSettings.isCompassEnabled
        set(v) { map.uiSettings.isCompassEnabled = v }
    override var isScrollGesturesEnabled: Boolean
        get() = map.uiSettings.isScrollGesturesEnabled
        set(v) { map.uiSettings.isScrollGesturesEnabled = v }
    override fun triggerRepaint() = map.triggerRepaint()

    override fun addOnCameraMoveStartedListener(l: MapLibreMap.OnCameraMoveStartedListener) = map.addOnCameraMoveStartedListener(l)
    override fun addOnCameraMoveListener(l: MapLibreMap.OnCameraMoveListener) = map.addOnCameraMoveListener(l)
    override fun removeOnCameraMoveListener(l: MapLibreMap.OnCameraMoveListener) = map.removeOnCameraMoveListener(l)
    override fun addOnCameraIdleListener(l: MapLibreMap.OnCameraIdleListener) = map.addOnCameraIdleListener(l)
    override fun removeOnCameraIdleListener(l: MapLibreMap.OnCameraIdleListener) = map.removeOnCameraIdleListener(l)
    override fun addOnMapClickListener(l: MapLibreMap.OnMapClickListener) = map.addOnMapClickListener(l)
    override fun addOnMapLongClickListener(l: MapLibreMap.OnMapLongClickListener) = map.addOnMapLongClickListener(l)

    private val frameListeners = HashMap<(Boolean) -> Unit, MapView.OnDidFinishRenderingFrameListener>()
    override fun addOnDidFinishRenderingFrameListener(l: (fully: Boolean) -> Unit) {
        val w = MapView.OnDidFinishRenderingFrameListener { fully, _, _ -> l(fully) }
        frameListeners[l] = w
        mapView.addOnDidFinishRenderingFrameListener(w)
    }
    override fun removeOnDidFinishRenderingFrameListener(l: (fully: Boolean) -> Unit) {
        frameListeners.remove(l)?.let(mapView::removeOnDidFinishRenderingFrameListener)
    }
    override fun addOnDidBecomeIdleListener(l: () -> Unit) = mapView.addOnDidBecomeIdleListener { l() }
    override fun addOnDidFailLoadingMapListener(l: (String?) -> Unit) = mapView.addOnDidFailLoadingMapListener { l(it) }

    override fun snapshot(done: (Bitmap?) -> Unit) = map.snapshot { done(it) }
}

/** MapLibre's [Style] as the engine style: every call as it was. */
internal class SMapMapLibreStyle(val style: Style) : SMapEngineStyle {
    override fun getSource(id: String): Source? = style.getSource(id)
    override fun getLayer(id: String): Layer? = style.getLayer(id)
    override val layers: List<Layer> get() = style.layers
    override val layerIds: List<String> get() = style.layers.map { it.id }
    override val sources: List<Source> get() = style.sources
    override fun addSource(source: Source) = style.addSource(source)
    override fun removeSource(id: String) = style.removeSource(id)
    override fun addLayer(layer: Layer) = style.addLayer(layer)
    override fun addLayerBelow(layer: Layer, below: String) = style.addLayerBelow(layer, below)
    override fun addLayerAbove(layer: Layer, above: String) = style.addLayerAbove(layer, above)
    override fun addLayerAt(layer: Layer, index: Int) = style.addLayerAt(layer, index)
    override fun removeLayer(id: String) = style.removeLayer(id)
    override fun addImage(name: String, bitmap: Bitmap, sdf: Boolean) = style.addImage(name, bitmap, sdf)
    override fun getImage(name: String): Bitmap? = style.getImage(name)
    override fun removeImage(name: String) = style.removeImage(name)
    override val json: String get() = style.json
    override fun addGeoJsonSource(id: String, data: Any?, options: GeoJsonOptions?) {
        val o = options ?: GeoJsonOptions()
        style.addSource(
            when (data) {
                null -> GeoJsonSource(id, o)
                is FeatureCollection -> GeoJsonSource(id, data, o)
                is Feature -> GeoJsonSource(id, data, o)
                is URI -> GeoJsonSource(id, data, o)
                else -> GeoJsonSource(id, data.toString(), o)
            },
        )
    }
    override fun setGeoJson(id: String, data: Any?): Boolean {
        val s = style.getSource(id) as? GeoJsonSource ?: return false
        when (data) {
            is FeatureCollection -> s.setGeoJson(data)
            is Feature -> s.setGeoJson(data)
            is URI -> s.setUri(data)
            null -> s.setGeoJson(FeatureCollection.fromFeatures(emptyList()))
            else -> s.setGeoJson(data.toString())
        }
        return true
    }
    override fun setFeatureState(source: String, key: String, state: com.google.gson.JsonObject) {
        (style.getSource(source) as? GeoJsonSource)?.setFeatureState(key, state)
    }
    override fun removeFeatureState(source: String, key: String, name: String) {
        (style.getSource(source) as? GeoJsonSource)?.removeFeatureState(key, name)
    }
    override fun sourceFeatures(source: String, filter: Expression?): List<Feature> =
        (style.getSource(source) as? GeoJsonSource)?.querySourceFeatures(filter) ?: emptyList()
    override fun clusterExpansionZoom(source: String, cluster: Feature): Int =
        (style.getSource(source) as? GeoJsonSource)?.getClusterExpansionZoom(cluster) ?: -1
    override fun clusterLeaves(source: String, cluster: Feature, limit: Long, offset: Long): List<Feature> =
        (style.getSource(source) as? GeoJsonSource)?.getClusterLeaves(cluster, limit, offset)?.features() ?: emptyList()
}

/** The camera now with what is given changed. */
internal fun SMapEngine.cameraWith(target: LatLng? = null, zoom: Double? = null, bearing: Double? = null, tilt: Double? = null): CameraPosition =
    CameraPosition.Builder(cameraPosition).apply {
        target?.let { target(it) }
        zoom?.let { zoom(it) }
        bearing?.let { bearing(it) }
        tilt?.let { tilt(it) }
    }.build()

/** Which engine draws a map (sRender DESIGN §12 N1): MapLibre Native (the default) or sRender. */
enum class SMapRenderer { MAPLIBRE, SRENDER }

/**
 * A source's Style Specification as the SDK made it (MapLibre keeps a source's options to itself once made), for an
 * engine that reads the SDK's sources as the Style Specification (E6). Recording changes nothing on MapLibre.
 */
internal object SMapSourceSpecs {
    private val recorded = java.util.WeakHashMap<Source, com.google.gson.JsonObject>()

    @Synchronized fun record(source: Source, json: com.google.gson.JsonObject) { recorded[source] = json.deepCopy() }
    @Synchronized fun spec(source: Source): com.google.gson.JsonObject? = recorded[source]?.deepCopy()
}

/** The engines this build carries besides MapLibre. */
internal object SMapEngines {
    /** sRender, when this build has it (the `srender` source set) and the device can run it; null otherwise. */
    /** Whether this build carries sRender and the device can run it. */
    val hasSRender: Boolean by lazy {
        android.os.Build.VERSION.SDK_INT >= 26 && runCatching { Class.forName("ca.superroute.smap.SMapSRenderEngine") }.isSuccess
    }

    fun srender(host: SMap): SMapEngine? {
        if (!hasSRender) return null
        return runCatching {
            Class.forName("ca.superroute.smap.SMapSRenderEngine").getConstructor(SMap::class.java).newInstance(host) as SMapEngine
        }.getOrNull()
    }
}

/**
 * Paint values MapLibre's getters cannot give back (colour ramps: `heatmap-color`, `line-gradient` read as
 * transparent), as the SDK set them, for an engine that reads the SDK's layers as the Style Specification (E6).
 */
internal object SMapPaintRecords {
    val ramps = setOf("heatmap-color", "line-gradient")
    private val recorded = java.util.WeakHashMap<Layer, HashMap<String, Any>>()

    @Synchronized fun record(layer: Layer, name: String, value: Any) { recorded.getOrPut(layer) { HashMap() }[name] = value }
    @Synchronized fun of(layer: Layer): Map<String, Any> = recorded[layer]?.toMap() ?: emptyMap()
}
