package ca.superroute.smap

import ca.superroute.smap.SMapJson.arrOrNull
import ca.superroute.smap.SMapJson.bool
import ca.superroute.smap.SMapJson.num
import ca.superroute.smap.SMapJson.objOrNull
import ca.superroute.smap.SMapJson.str
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngQuad
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.BackgroundLayer
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.ColorReliefLayer
import org.maplibre.android.style.layers.FillExtrusionLayer
import org.maplibre.android.style.layers.FillLayer
import org.maplibre.android.style.layers.HeatmapLayer
import org.maplibre.android.style.layers.HillshadeLayer
import org.maplibre.android.style.layers.Layer
import org.maplibre.android.style.layers.LayoutPropertyValue
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.PaintPropertyValue
import org.maplibre.android.style.layers.PropertyValue
import org.maplibre.android.style.layers.RasterLayer
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonOptions
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.android.style.sources.ImageSource
import org.maplibre.android.style.sources.RasterDemSource
import org.maplibre.android.style.sources.RasterSource
import org.maplibre.android.style.sources.Source
import org.maplibre.android.style.sources.TileSet
import org.maplibre.android.style.sources.VectorSource
import java.net.URI

/**
 * A Style Spec expression handed to the engine exactly as written. The engine's own Java expression converter reads
 * literal arrays as operators, so expressions from JSON go through this instead.
 */
internal class SMapRawExpression(private val raw: kotlin.Array<Any?>) : Expression("literal") {
    override fun toArray(): kotlin.Array<Any?> = raw

    companion object {
        fun of(json: JsonElement): Expression {
            val v = SMapJson.toEngine(json)
            @Suppress("UNCHECKED_CAST")
            return if (v is kotlin.Array<*>) SMapRawExpression(v as kotlin.Array<Any?>) else Expression.literal(v ?: "")
        }
    }
}

/** Turns Style Spec v8 JSON into the engine's layer and source objects. */
internal object SMapStyleBridge {

    /** A paint or layout value for the engine (null = the property's default). */
    fun property(paint: Boolean, name: String, value: JsonElement?): PropertyValue<*> {
        val v = if (value == null || value.isJsonNull) null else SMapJson.toEngine(value)
        return if (paint) PaintPropertyValue(name, v) else LayoutPropertyValue(name, v)
    }

    fun layer(json: JsonObject, hidden: Boolean): Layer {
        SMapStyleSpec.checkLayer(json)
        val id = json.str("id")!!
        val src = json.str("source").orEmpty()
        val layer: Layer = when (val type = json.str("type")) {
            "fill" -> FillLayer(id, src)
            "line" -> LineLayer(id, src)
            "symbol" -> SymbolLayer(id, src)
            "circle" -> CircleLayer(id, src)
            "heatmap" -> HeatmapLayer(id, src)
            "fill-extrusion" -> FillExtrusionLayer(id, src)
            "raster" -> RasterLayer(id, src)
            "hillshade" -> HillshadeLayer(id, src)
            "color-relief" -> ColorReliefLayer(id, src)
            "background" -> BackgroundLayer(id)
            else -> throw IllegalArgumentException("sMap: style layer $id has an unknown type \"$type\"")
        }
        json.str("source-layer")?.let { sourceLayer(layer, it) }
        json.get("filter")?.takeIf { !it.isJsonNull }?.let { filter(layer, it) }
        json.num("minzoom")?.let { layer.minZoom = it.toFloat() }
        json.num("maxzoom")?.let { layer.maxZoom = it.toFloat() }
        val props = ArrayList<PropertyValue<*>>()
        json.objOrNull("layout")?.entrySet()?.forEach { (k, v) -> props += property(false, k, v) }
        json.objOrNull("paint")?.entrySet()?.forEach { (k, v) ->
            props += property(true, k, v)
            if (k in SMapPaintRecords.ramps && !v.isJsonNull) SMapPaintRecords.record(layer, k, v)
        }
        if (hidden) props += LayoutPropertyValue("visibility", "none")
        if (props.isNotEmpty()) layer.setProperties(*props.toTypedArray())
        return layer
    }

    private fun sourceLayer(layer: Layer, name: String) {
        when (layer) {
            is FillLayer -> layer.setSourceLayer(name)
            is LineLayer -> layer.setSourceLayer(name)
            is SymbolLayer -> layer.setSourceLayer(name)
            is CircleLayer -> layer.setSourceLayer(name)
            is HeatmapLayer -> layer.setSourceLayer(name)
            is FillExtrusionLayer -> layer.setSourceLayer(name)
            is RasterLayer -> layer.setSourceLayer(name)
            is HillshadeLayer -> layer.setSourceLayer(name)
            is ColorReliefLayer -> layer.setSourceLayer(name)
            else -> Unit
        }
    }

    /** Sets (or, with a JSON null, clears) a layer's filter; false when the layer type has no filter. */
    fun filter(layer: Layer, filter: JsonElement?): Boolean {
        val e = if (filter == null || filter.isJsonNull) Expression.literal(true) else SMapRawExpression.of(filter)
        when (layer) {
            is FillLayer -> layer.setFilter(e)
            is LineLayer -> layer.setFilter(e)
            is SymbolLayer -> layer.setFilter(e)
            is CircleLayer -> layer.setFilter(e)
            is HeatmapLayer -> layer.setFilter(e)
            is FillExtrusionLayer -> layer.setFilter(e)
            is ColorReliefLayer -> layer.setFilter(e)
            else -> return false
        }
        return true
    }

    private fun tileSet(json: JsonObject): TileSet {
        val tiles = json.arrOrNull("tiles")?.map { it.asString }?.toTypedArray() ?: emptyArray()
        val ts = TileSet("3.0.0", *tiles)
        json.num("minzoom")?.let { ts.setMinZoom(it.toFloat()) }
        json.num("maxzoom")?.let { ts.setMaxZoom(it.toFloat()) }
        json.str("scheme")?.let { ts.scheme = it }
        json.str("attribution")?.let { ts.attribution = it }
        json.str("encoding")?.let { ts.encoding = it }
        json.arrOrNull("bounds")?.takeIf { it.size() == 4 }?.let { b -> ts.setBounds(*FloatArray(4) { b[it].asFloat }) }
        return ts
    }

    fun source(id: String, json: JsonObject): Source = make(id, json).also { SMapSourceSpecs.record(it, json) }

    private fun make(id: String, json: JsonObject): Source {
        SMapStyleSpec.checkSource(id, json)
        val url = json.str("url")
        return when (json.str("type")) {
            "vector" -> if (json.has("tiles")) VectorSource(id, tileSet(json)) else VectorSource(id, url!!)
            "raster" -> {
                val size = json.num("tileSize")?.toInt() ?: 512
                if (json.has("tiles")) RasterSource(id, tileSet(json), size) else RasterSource(id, url!!, size)
            }
            "raster-dem" -> {
                val size = json.num("tileSize")?.toInt() ?: 512
                if (json.has("tiles")) RasterDemSource(id, tileSet(json), size) else RasterDemSource(id, url!!, size)
            }
            "geojson" -> {
                val o = GeoJsonOptions()
                if (json.bool("cluster") == true) o.withCluster(true)
                json.num("clusterRadius")?.let { o.withClusterRadius(it.toInt()) }
                json.num("clusterMaxZoom")?.let { o.withClusterMaxZoom(it.toInt()) }
                json.num("clusterMinPoints")?.let { o.withClusterMinPoints(it.toInt()) }
                json.num("maxzoom")?.let { o.withMaxZoom(it.toInt()) }
                json.num("buffer")?.let { o.withBuffer(it.toInt()) }
                json.num("tolerance")?.let { o.withTolerance(it.toFloat()) }
                json.bool("lineMetrics")?.let { o.withLineMetrics(it) }
                val data = json.get("data")
                if (data.isJsonPrimitive) GeoJsonSource(id, URI(data.asString), o) else GeoJsonSource(id, data.toString(), o)
            }
            "image" -> {
                val c = json.arrOrNull("coordinates")!!.map { p -> p.asJsonArray.let { LatLng(it[1].asDouble, it[0].asDouble) } }
                if (c.size != 4) throw IllegalArgumentException("sMap: source $id needs four image corners")
                ImageSource(id, LatLngQuad(c[0], c[1], c[2], c[3]), URI(url!!))
            }
            else -> throw IllegalArgumentException("sMap: source $id has an unsupported type")
        }
    }
}
