package ca.superroute.smap

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import org.maplibre.android.geometry.LatLng
import org.maplibre.geojson.Feature
import org.maplibre.geojson.Point
import kotlin.math.max
import kotlin.math.min

/** What an area selection found: the features of each layer inside it, and the area drawn. */
data class SMapSelection(val features: Map<String, List<Feature>>, val geometry: JsonObject)

/**
 * Area selection (G4): one finger draws a box or a free shape; the map does not pan meanwhile; *Cancel* at the top
 * of the map ends it with nothing. A point or custom marker counts when inside, a line or area when any vertex is.
 */
@SuppressLint("ViewConstructor")
internal class SMapSelect(
    context: Context,
    private val map: SMap,
    private val lasso: Boolean,
    private val layers: List<String>,
    cancelLabel: String,
    private val done: (SMapSelection?) -> Unit,
) : FrameLayout(context), SMapInteraction.Capture {
    private val points = ArrayList<PointF>()
    private val density = resources.displayMetrics.density
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * density; color = SMapToolStyle.BLUE; pathEffect = DashPathEffect(floatArrayOf(5 * density, 3 * density), 0f) }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = android.graphics.Color.argb(31, 37, 99, 235) }
    private var finished = false

    init {
        setWillNotDraw(false)
        addView(TextView(context).apply {
            text = cancelLabel
            setTextColor(SMapToolStyle.TEXT)
            textSize = 14f
            gravity = Gravity.CENTER
            minHeight = (44 * density).toInt()
            val p = (16 * density).toInt(); setPadding(p, 0, p, 0)
            background = SMapToolStyle.card(context, 22f)
            elevation = 4 * density
            setOnClickListener { end(null) }
        }, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = (12 * density).toInt() })
    }

    override fun onTouch(e: MotionEvent): Boolean {
        if (finished) return false
        // The Cancel button keeps its own taps.
        val cancel = getChildAt(0)
        if (e.actionMasked == MotionEvent.ACTION_DOWN && e.x >= cancel.left && e.x <= cancel.right && e.y >= cancel.top && e.y <= cancel.bottom) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { points.clear(); points += PointF(e.x, e.y) }
            MotionEvent.ACTION_MOVE -> { if (lasso) points += PointF(e.x, e.y) else if (points.isNotEmpty()) { if (points.size == 1) points += PointF(e.x, e.y) else points[1] = PointF(e.x, e.y) } }
            MotionEvent.ACTION_UP -> {
                if (!lasso) { if (points.size == 1) points += PointF(e.x, e.y) else if (points.size == 2) points[1] = PointF(e.x, e.y) }
                if (points.size >= 2) end(select()) else points.clear()
            }
            MotionEvent.ACTION_CANCEL -> points.clear()
        }
        invalidate()
        return true
    }

    private fun ring(): List<PointF> = if (lasso) points.toList() else {
        val a = points[0]; val b = points[points.size - 1]
        listOf(a, PointF(b.x, a.y), b, PointF(a.x, b.y))
    }

    override fun onDraw(canvas: Canvas) {
        if (points.size < 2) return
        val path = Path()
        ring().forEachIndexed { i, p -> if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y) }
        path.close()
        canvas.drawPath(path, fill)
        canvas.drawPath(path, stroke)
    }

    private fun select(): SMapSelection {
        val r = ring()
        val screen = r.map { doubleArrayOf(it.x.toDouble(), it.y.toDouble()) }
        val minX = r.minOf { it.x }; val maxX = r.maxOf { it.x }; val minY = r.minOf { it.y }; val maxY = r.maxOf { it.y }
        val projection = map.mapEngine!!
        fun inside(lng: Double, lat: Double): Boolean {
            val p = projection.toScreenLocation(LatLng(lat, lng))
            return p.x in minX..maxX && p.y in minY..maxY && SMapGeo.pointInPolygon(doubleArrayOf(p.x.toDouble(), p.y.toDouble()), screen)
        }
        val out = LinkedHashMap<String, List<Feature>>()
        for (id in layers) {
            val data = map.layerData(id) ?: continue
            val hits = data.features()?.filter { f -> anyVertex(f.geometry()?.toJson()?.let { com.google.gson.JsonParser.parseString(it).asJsonObject }, ::inside) } ?: emptyList()
            if (hits.isNotEmpty()) out[id] = hits
        }
        val geo = JsonArray()
        (r + r.first()).forEach { p -> val ll = projection.fromScreenLocation(p); geo.add(JsonArray().apply { add(ll.longitude); add(ll.latitude) }) }
        return SMapSelection(out, JsonObject().apply { addProperty("type", "Polygon"); add("coordinates", JsonArray().apply { add(geo) }) })
    }

    private fun anyVertex(g: JsonObject?, inside: (Double, Double) -> Boolean): Boolean {
        var found = false
        fun walk(e: com.google.gson.JsonElement) {
            if (found || !e.isJsonArray) return
            val a = e.asJsonArray
            if (a.size() >= 2 && a[0].isJsonPrimitive) { found = inside(a[0].asDouble, a[1].asDouble); return }
            a.forEach(::walk)
        }
        g?.get("coordinates")?.let(::walk)
        return found
    }

    private fun end(result: SMapSelection?) {
        if (finished) return
        finished = true
        map.endSelect(this)
        done(result)
    }
}
