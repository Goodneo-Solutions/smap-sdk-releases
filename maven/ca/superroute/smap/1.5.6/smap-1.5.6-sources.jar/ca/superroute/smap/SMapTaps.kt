package ca.superroute.smap

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/**
 * (1.5.5) Points piled on top of each other under a tap: on (the default), two or more features drawn under the
 * finger are listed in a small menu at the tap, and choosing one answers its layer's tap as a direct tap would; the
 * camera never moves for it. Off (`SMapOverlap(enabled = false)`, or null), the layer's features are neither counted
 * nor listed: the nearest (top) feature answers.
 *
 * @param label the row of a feature in the list; else the feature's `label` property when the layer has [SMapPointOptions.label],
 *   else its key (the idProperty value or id), else its place in the list (1, 2, …)
 */
data class SMapOverlap(
    val enabled: Boolean = true,
    val label: ((SMapFeature) -> String)? = null,
)

/**
 * The hit maths of taps (1.5.5): a feature counts only where it is drawn, plus the finger tolerance, and the one
 * whose shape holds the tap comes first, then the nearest; ties keep the drawing order (top first). Pure (no views).
 */
internal object SMapTapMath {
    /** At most this many rows in the chooser. */
    const val MAX_ROWS = 50

    /** One feature near a tap: [distance] in pixels from its drawn shape (0 inside), [rank] its drawing order (0 = top). */
    class Candidate<T>(val item: T, val distance: Float, val rank: Int, val piles: Boolean)

    sealed class Answer<out T> {
        object None : Answer<Nothing>()
        data class One<T>(val item: T) : Answer<T>()
        data class Choose<T>(val items: List<T>) : Answer<T>()
    }

    /** The distance from (x, y) to a disc of [r] pixels around (cx, cy); 0 inside. */
    fun toDisc(cx: Float, cy: Float, r: Float, x: Float, y: Float): Float = max(0f, hypot(x - cx, y - cy) - max(r, 0f))

    /** The distance from (x, y) to a box; 0 inside or on its edge. */
    fun toBox(left: Float, top: Float, width: Float, height: Float, x: Float, y: Float): Float {
        val dx = max(max(left - x, 0f), x - (left + width))
        val dy = max(max(top - y, 0f), y - (top + height))
        return hypot(dx, dy)
    }

    /**
     * The box an icon is drawn in (left, top, width, height), all in pixels: [w] × [h] the image's drawn size, placed
     * by its [anchor] on the point (ax, ay) and moved by the offset (already in pixels). Rotation is ignored.
     */
    fun iconBox(ax: Float, ay: Float, w: Float, h: Float, anchor: SMapAnchor, offX: Float, offY: Float): FloatArray =
        floatArrayOf(ax - anchor.x * w + offX, ay - anchor.y * h + offY, w, h)

    /** Contains the tap first, then the nearest, then the drawing order (top first). */
    fun <T> ordered(list: List<Candidate<T>>): List<Candidate<T>> =
        list.sortedWith(compareBy<Candidate<T>>({ if (it.distance <= 0f) 0 else 1 }, { it.distance }, { it.rank }))

    /**
     * What a tap answers: nothing (no feature within [tolerance]), one feature, or a list to choose from when two or
     * more features of piling layers hold the tap point itself and the first of them piles.
     */
    fun <T> answer(list: List<Candidate<T>>, tolerance: Float): Answer<T> {
        val counted = ordered(list.filter { it.distance <= tolerance })
        val first = counted.firstOrNull() ?: return Answer.None
        if (!first.piles || first.distance > 0f) return Answer.One(first.item)
        val pile = counted.filter { it.distance <= 0f && it.piles }
        return if (pile.size >= 2) Answer.Choose(pile.take(MAX_ROWS).map { it.item }) else Answer.One(first.item)
    }

    /**
     * A row of the chooser: the layer's own label, else the feature's label property, else its key unless it is only
     * its place in the data (`#<index>`), else its row number from 1.
     */
    fun label(row: Int, own: String?, labelValue: Any?, key: String?): String =
        own ?: labelValue?.toString()?.takeIf { it.isNotEmpty() } ?: key?.takeIf { it.isNotEmpty() && !it.startsWith("#") } ?: "${row + 1}"

    /** Whether two taps are one (the marker view's tap and the map's own click of the same touch). */
    fun sameTap(x1: Float, y1: Float, x2: Float, y2: Float, slop: Float): Boolean = abs(x1 - x2) <= slop && abs(y1 - y2) <= slop
}
