/**
 * Automatically generated file. DO NOT MODIFY
 */
package ca.superroute.smap;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "ca.superroute.smap";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String SMAP_VERSION = "1.5.15";
}
