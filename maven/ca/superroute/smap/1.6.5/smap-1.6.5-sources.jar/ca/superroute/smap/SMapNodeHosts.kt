package ca.superroute.smap

import android.content.Context
import okhttp3.Dispatcher
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import java.net.URI
import java.util.concurrent.ConcurrentHashMap

/**
 * The hosts of the map service's nodes this app reads from: every map's base URL, its seed nodes and the nodes of the
 * node list. Identity headers go to these hosts only, never to any other.
 */
object SMapNodeHosts {
    private val hosts = ConcurrentHashMap.newKeySet<String>()

    /** Adds the hosts of [urls] (anything that is not an http(s) URL is ignored). */
    fun add(urls: Iterable<String>) {
        for (url in urls) hostOf(url)?.let { hosts.add(it) }
    }

    fun contains(host: String): Boolean = hosts.contains(host.lowercase())

    fun isNode(url: String): Boolean = hostOf(url)?.let { hosts.contains(it) } ?: false

    internal fun clear() = hosts.clear()

    internal fun hostOf(url: String): String? = try {
        val uri = URI(url.trim())
        if (uri.scheme?.lowercase() in setOf("http", "https")) uri.host?.lowercase()?.takeIf { it.isNotEmpty() } else null
    } catch (e: Exception) {
        null
    }
}

/** Adds [headers] to requests for node hosts ([isNode]); every other request goes out unchanged. */
class SMapIdentityInterceptor(
    private val headers: () -> Map<String, String>,
    private val isNode: (String) -> Boolean = SMapNodeHosts::contains,
) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        if (!isNode(request.url.host)) return chain.proceed(request)
        val builder = request.newBuilder()
        for ((name, value) in headers()) builder.header(name, value)
        return chain.proceed(builder.build())
    }
}

/**
 * Hands the rendering engine an HTTP client that adds the app identity to its style, tile, glyph and sprite requests
 * to node hosts. The engine has one HTTP client for the whole app, so this is global: an app that sets its own client
 * on the engine after a map was created replaces this one (and the identity headers with it).
 */
internal object SMapEngineHttp {
    @Volatile
    private var installed = false

    /** Told the URL and status of every engine answer from a node host that is a refusal (401, 403; G32). */
    val statusListeners = java.util.concurrent.CopyOnWriteArraySet<(String, Int) -> Unit>()

    private val refusals = Interceptor { chain ->
        val response = chain.proceed(chain.request())
        val url = chain.request().url
        if (SMapUnavailable.isRefusal(response.code) && SMapNodeHosts.contains(url.host)) {
            for (l in statusListeners) l(url.toString(), response.code)
        }
        response
    }

    @Synchronized
    fun install(context: Context) {
        if (installed) return
        val app = context.applicationContext
        // As the engine's own default client: at most 20 requests per host.
        val dispatcher = Dispatcher().apply { maxRequestsPerHost = 20 }
        val client = OkHttpClient.Builder()
            .dispatcher(dispatcher)
            .addInterceptor(SMapLocalTiles.interceptor)
            .addInterceptor(SMapIdentityInterceptor({ SMapAppIdentity.headers(app) }))
            .addInterceptor(refusals)
            .build()
        org.maplibre.android.module.http.HttpRequestUtil.setOkHttpClient(client)
        this.client = client
        installed = true
    }

    /** The engines' client (MapLibre's, and sRender's fetches through [fetch]). */
    @Volatile
    var client: OkHttpClient? = null
        private set

    /** One GET through the engines' client (its interceptors: app-drawn tiles, app identity, refusals): status and body. */
    fun fetch(url: String, headers: Map<String, String>): Pair<Int, ByteArray?> {
        val c = client ?: OkHttpClient()
        val req = okhttp3.Request.Builder().url(url).apply { headers.forEach { (k, v) -> header(k, v) } }.build()
        c.newCall(req).execute().use { r -> return r.code to r.body?.bytes() }
    }
}
