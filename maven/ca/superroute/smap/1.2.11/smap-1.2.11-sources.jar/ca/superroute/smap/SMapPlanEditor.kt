package ca.superroute.smap

import android.content.Context
import android.util.Log
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch

/**
 * How a plan editor starts.
 *
 * @param credentials a plan editor token provider or a map key with plan editing switched on (§2e)
 * @param baseUrl the Open Platform
 * @param app the app's identity headers; read from the system when the editor is given a context and this is null
 * @param http replaces the HTTP layer (OkHttp by default)
 * @param plan the starting plan
 * @param region / [profile] used when the plan names none
 * @param snapshot open and use a distance snapshot
 * @param geometry ask for each leg's line (for drawing)
 * @param insertLimit positions offered per inserted job (1-10)
 * @param objective what insert ranks by (`duration` or `distance`; the server's default: duration)
 * @param clock wall-clock milliseconds (token renewal and the snapshot's retry wait)
 * @param smapUrl the sMap service a map key's configuration is read from (`GET <smapUrl>/plan/v1/config`); null:
 *   https://tile.srsr.ca, or the map's own sMap address through [SMap.planEditor]
 * @param fastPath take the fast path when the credential names one (OPEN-ROUTE-EDIT E19); false: the standard path only
 * @param fastPathTimeoutMillis how long a fast-path call (every call but refine) may take before it is repeated on the
 *   standard path
 * @param fastPathRefineTimeoutMillis the same for refine, whose search takes longer
 * @param insertWaitTimeoutMillis how long an insert waits at most for its prepared points to be measured
 *   ([SMapPlanEditor.prepareInsert]); it is sent then either way
 */
data class SMapPlanEditorOptions(
    val credentials: SMapPlanCredentials,
    val baseUrl: String = DEFAULT_BASE_URL,
    val app: SMapPlanApp? = null,
    val http: SMapPlanHttp? = null,
    val plan: SMapPlan? = null,
    val region: String? = null,
    val profile: String? = null,
    val snapshot: Boolean = true,
    val geometry: Boolean = true,
    val insertLimit: Int = 3,
    val objective: String? = null,
    val clock: () -> Long = System::currentTimeMillis,
    val smapUrl: String? = null,
    val fastPath: Boolean = true,
    val fastPathTimeoutMillis: Long = SMapPlanTransport.FAST_PATH_TIMEOUT_MS,
    val fastPathRefineTimeoutMillis: Long = SMapPlanTransport.FAST_PATH_REFINE_TIMEOUT_MS,
    val insertWaitTimeoutMillis: Long = SMapPlanEditor.INSERT_WAIT_TIMEOUT_MS,
) {
    companion object {
        const val DEFAULT_BASE_URL = "https://open.superroute.ca"
    }
}

/** What a plan editor reports (MOBILE-SDK-SPEC "Plan editor", Events). */
sealed class SMapPlanEvent {
    /**
     * After every change of what is shown. [kind]: `set`, `recost`, `resequence`, `move`, `remove`, `insert`,
     * `refine`, `undo`, `redo`, `lock`, `choices`, `error`; [pending]: the plan shown is not priced yet. [plan] is the
     * plan to keep.
     */
    data class Change(
        val kind: String,
        val plan: SMapPlan?,
        val result: SMapPlanResult?,
        val answer: JsonElement?,
        val pending: Boolean,
        val canUndo: Boolean,
        val canRedo: Boolean,
        /** Where the last answered call was answered ([SMapPlanPath]); null before the first answer. */
        val path: String? = null,
    ) : SMapPlanEvent()

    /** Once per stretch of calls. */
    data class Busy(val busy: Boolean) : SMapPlanEvent()

    /** A refused or failed call ([kind]: the call, or `preview`). */
    data class Error(val error: SMapPlanException, val kind: String) : SMapPlanEvent()

    /** The distance snapshot: `opened`, `failed`, `used`, `expired`, `unavailable` or `mismatch`. */
    data class Snapshot(
        val status: String,
        val matrix: String?,
        val expiresAt: String? = null,
        val node: String? = null,
        val error: Throwable? = null,
        /** With `opened`: the path that opened it ([SMapPlanPath]); the id is the same on both paths. */
        val path: String? = null,
    ) : SMapPlanEvent()

    /** A priced preview, or null when it was cleared. */
    data class Preview(val preview: SMapPlanPreview?) : SMapPlanEvent()

    /** The editor ended. */
    object Destroy : SMapPlanEvent()
}

/**
 * The plan editor (Superroute OPEN-ROUTE-EDIT E10): a person edits a plan of routes and every edit is one call of the
 * Open Platform's plan editing with the whole plan. The editor keeps no plan on any server: the plan goes back to the
 * app through [SMapPlanEvent.Change].
 *
 * Moves, resequences and removals are drawn at once and sent with the plan before them; the answer replaces them.
 * Inserts and refines are kept when answered. A newer edit, undo, redo, [setPlan] or [recost] cancels the call in
 * flight, whose suspend call then gives null. A refused edit is taken back and its call throws [SMapPlanException].
 *
 * Call it on one thread (the main thread in an app); its calls and events run in [scope].
 *
 * @param context reads the app's identity (`X-SMap-App`, `X-SMap-App-Cert`) from the system; null sends none unless
 *   [SMapPlanEditorOptions.app] gives it
 * @param scope where the calls run (a supervisor child of it); the main thread by default
 */
class SMapPlanEditor(
    val options: SMapPlanEditorOptions,
    context: Context? = null,
    scope: CoroutineScope? = null,
) {
    private val scope: CoroutineScope = if (scope != null) {
        CoroutineScope(scope.coroutineContext + SupervisorJob(scope.coroutineContext[Job]))
    } else {
        CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    }
    private val clock = options.clock
    private val transport = SMapPlanTransport(
        options.baseUrl,
        options.credentials,
        (options.app ?: context?.let { SMapPlanApp.of(it) })?.headers() ?: emptyMap(),
        options.http ?: SMapPlanOkHttp(),
        clock,
        options.smapUrl,
        options.fastPath,
        options.fastPathTimeoutMillis,
        options.fastPathRefineTimeoutMillis,
    )

    private class Entry(val kind: String, var routes: List<SMapPlanRoute>, val jobs: List<JsonObject>) {
        var result: SMapPlanResult? = null
        var answer: JsonElement? = null
    }

    private class Ticket(val kind: String) {
        var job: Job? = null
    }

    private class Search(val base: Entry, val jobs: List<JsonObject>, val wait: (suspend () -> Unit)? = null)

    private val listeners = ArrayList<(SMapPlanEvent) -> Unit>()
    private val history = ArrayList<Entry>()
    private var at = -1
    private var vehicles: List<JsonObject> = emptyList()
    private var region: String? = null
    private var profile: String? = null
    private var departedAt: String? = null
    private val lockedIds = LinkedHashSet<String>()
    private var choiceItems: List<SMapPlanChoices>? = null
    private var last: SMapPlanLast? = null
    private var inflight: Ticket? = null
    private var previewing: Ticket? = null
    private var previewResult: SMapPlanPreview? = null
    private var busy = false
    private var error: SMapPlanError? = null
    private var matrix: String? = null
    private var matrixKey: String? = null
    private var opening: Deferred<String?>? = null
    private var openingKey: String? = null
    private var matrixRetryAt = 0L
    private var destroyed = false
    private var lastPath: String? = null
    // Drop points (E25/E26): the points the open snapshot's opening sent, and those sent to it since ("sent" / "ready").
    private var openedMatrix: String? = null
    private var openedPoints: List<String> = emptyList()
    private var preparedMatrix: String? = null
    private val prepared = HashMap<String, String>()

    /** The map layer drawing this editor, when made by [SMap.planEditor]. */
    var layer: SMapPlanLayer? = null
        internal set

    /** The ready-made panel of this editor, when made by [SMap.planEditor]. */
    var panel: SMapPlanPanel? = null
        internal set

    init {
        options.plan?.let { plan ->
            val call = startSetPlan(plan)
            this.scope.launch { try { call.await() } catch (e: Exception) { /* reported as an error event */ } }
        }
    }

    // ------------------------------------------------------------------ events

    fun addListener(listener: (SMapPlanEvent) -> Unit) { listeners.add(listener) }
    fun removeListener(listener: (SMapPlanEvent) -> Unit) { listeners.remove(listener) }

    private fun emit(event: SMapPlanEvent) {
        listeners.toList().forEach {
            try {
                it(event)
            } catch (e: Exception) {
                Log.w(TAG, "a plan editor listener failed", e)
            }
        }
    }

    // ------------------------------------------------------------------ reading

    private fun current(): Entry? = history.getOrNull(at)

    /** The plan as it is sent: vehicles, jobs, routes (stops in driving order), unassigned and its context. */
    fun plan(): SMapPlan? {
        val e = current() ?: return null
        return SMapPlan(
            vehicles.map { it.deepCopy() }, e.jobs.map { it.deepCopy() }, e.routes.toList(),
            SMapPlanOps.unassignedOf(e.jobs.map(SMapPlanIds::ofJob), e.routes), region, profile, departedAt,
        )
    }

    /** The plan's prices and judgement as the last answer gave them, or null before one. */
    fun result(): SMapPlanResult? = current()?.result?.copy()

    /** Everything a panel shows, in one object. */
    fun state(): SMapPlanState = SMapPlanState(
        plan(), result(), busy, error, canUndo, canRedo, choices(), locked(), last?.let { SMapPlanLast(it.kind, it.answer?.deepCopy()) },
        previewResult?.let { SMapPlanPreview(it.routes, it.result.copy()) },
        lastPath,
    )

    val canUndo: Boolean get() = at > 0
    val canRedo: Boolean get() = at >= 0 && at < history.size - 1
    val isBusy: Boolean get() = busy

    /** The vehicle ids in plan order (route colours follow it). */
    fun vehicleIds(): List<String> = vehicles.map(SMapPlanIds::ofJob)

    /** The vehicles as the plan gave them. */
    fun vehicles(): List<JsonObject> = vehicles.map { it.deepCopy() }

    /** The positions the last insert answered; null when none. */
    fun choices(): List<SMapPlanChoices>? = choiceItems?.toList()

    fun clearChoices() {
        choiceItems = null
        changed("choices")
    }

    /** Clears the error the panel shows. */
    fun clearError() {
        error = null
        changed("error")
    }

    // ------------------------------------------------------------------ edits

    /** Replaces the plan: the history starts again from it, and it is priced (plan.recost). */
    suspend fun setPlan(plan: SMapPlan): SMapPlanEdit? = awaitEdit(startSetPlan(plan))

    private fun startSetPlan(plan: SMapPlan): Deferred<SMapPlanEdit?> {
        supersede()
        clearPreview()
        vehicles = plan.vehicles.map { it.deepCopy() }
        region = plan.region ?: options.region
        profile = plan.profile ?: options.profile
        departedAt = plan.departedAt
        val routes = SMapPlanOps.withAllVehicles(SMapPlanOps.routesOf(plan.routes), vehicleIds())
        val jobs = plan.jobs.map { it.deepCopy() }
        val known = jobs.map(SMapPlanIds::ofJob).toHashSet()
        lockedIds.retainAll(known)
        history.clear()
        history.add(Entry("set", routes, jobs))
        at = 0
        choiceItems = null
        last = null
        error = null
        changed("set")
        return price(history[0])
    }

    /** Gives [vehicleId]'s route the stops in a new driving order (plan.resequence). */
    suspend fun resequence(vehicleId: String, stops: List<String>): SMapPlanEdit? {
        val order = stops.toList()
        val extra = JsonObject().apply { addProperty("vehicle_id", vehicleId); add("stops", ids(order)) }
        return awaitEdit(run("resequence", extra, { SMapPlanOps.applyResequence(it, vehicleId, order) }, null))
    }

    /** Moves [stops] to [vehicleId]'s route at [position] (from 1, counted without them; null: last) (plan.move). */
    suspend fun move(stops: List<String>, vehicleId: String, position: Int? = null): SMapPlanEdit? =
        awaitEdit(startMove(stops, vehicleId, position))

    private fun startMove(stops: List<String>, vehicleId: String, position: Int?): Deferred<SMapPlanEdit?> {
        val list = stops.toList()
        val extra = JsonObject().apply {
            addProperty("vehicle_id", vehicleId)
            add("stops", ids(list))
            position?.let { addProperty("position", it) }
        }
        return run("move", extra, { SMapPlanOps.applyMove(it, list, vehicleId, position) }, null)
    }

    /** Takes [stops] off their routes; they become unassigned (plan.remove). */
    suspend fun remove(stops: List<String>): SMapPlanEdit? {
        val list = stops.toList()
        return awaitEdit(run("remove", JsonObject().apply { add("stops", ids(list)) }, { SMapPlanOps.applyRemove(it, list) }, null))
    }

    /**
     * Places a stop where it was dropped: before the stop at [position] of [vehicleId]'s route as drawn (past the last
     * stop: after it). Within its route a resequence, otherwise a move. Null when nothing changes (nothing is sent).
     */
    suspend fun dropStop(stopId: String, vehicleId: String, position: Int): SMapPlanEdit? {
        val e = current() ?: return null
        val d = SMapPlanOps.dropEdit(e.routes, stopId, vehicleId, position) ?: return null
        // A job of no route dropped on one: its point goes to the snapshot at once (E25), unless it is there already.
        if (SMapPlanOps.findStop(e.routes, stopId) == null) prepareInsert(stopId)
        return when (d) {
            is SMapPlanOps.Drop.Resequence -> resequence(d.vehicleId, d.stops)
            is SMapPlanOps.Drop.Move -> move(listOf(stopId), d.vehicleId, d.position)
        }
    }

    /**
     * Inserts new jobs (JSON objects like the plan's jobs, with ids the plan does not have) at their cheapest positions,
     * or places jobs of the plan that are on no route (given by id, as JSON strings or numbers) (plan.insert). The
     * ranked positions answered are kept in [choices]; [choose] takes another one.
     *
     * @param limit positions per job (1-10; default [SMapPlanEditorOptions.insertLimit])
     * @param objective `duration` or `distance`
     * @param nearest the candidate routes looked at (1-50)
     */
    suspend fun insert(jobs: List<JsonElement>, limit: Int? = null, objective: String? = null, nearest: Int? = null): SMapPlanEdit? {
        val e = current() ?: throw SMapPlanException("sMap plan editor: no plan; call setPlan first")
        val byId = e.jobs.associateBy(SMapPlanIds::ofJob)
        val placing = jobs.map { j ->
            if (j.isJsonPrimitive) {
                val id = SMapPlanIds.of(j)
                val known = byId[id] ?: throw SMapPlanException("sMap plan editor: no job $id")
                if (SMapPlanOps.findStop(e.routes, id) != null) throw SMapPlanException("sMap plan editor: $id is already on a route")
                known.deepCopy()
            } else if (j.isJsonObject) {
                j.asJsonObject.deepCopy()
            } else {
                throw SMapPlanException("sMap plan editor: a job is an object or an id")
            }
        }
        val placingIds = placing.map(SMapPlanIds::ofJob)
        val rest = e.jobs.filter { SMapPlanIds.ofJob(it) !in placingIds }
        val extra = JsonObject().apply {
            add("insert", JsonArray().also { a -> placing.forEach(a::add) })
            addProperty("limit", limit ?: options.insertLimit)
            (objective ?: options.objective)?.let { addProperty("objective", it) }
            nearest?.let { addProperty("nearest", it) }
        }
        return awaitEdit(run("insert", extra, null, rest to rest + placing, waitFor(placing)))
    }

    /**
     * Sends points about to be inserted to the open snapshot at once (`POST /v1/plan/matrix/<id>/points` on the
     * standard path, OPEN-ROUTE-EDIT E25), so their legs are measured before the insert is confirmed. Call it when a
     * new stop is dropped on the map (on release, not while dragging) or an address is picked for an insert; the editor
     * calls it itself when a job of no route is dropped on one. Each element is a point (`{lat, lng}` or `[lng, lat]`),
     * a job (its `location`) or the id of a job of the plan. Never waits and never fails: returns how many points were
     * sent (0 without an open snapshot, or when every point was sent to this snapshot before).
     */
    fun prepareInsert(points: List<JsonElement>): Int {
        val id = matrix
        if (destroyed || id == null) return 0
        val known = knownPoints(id)
        val send = ArrayList<DoubleArray>()
        pointsOf(points).forEach { p ->
            val k = pointKey(p)
            if (known.containsKey(k)) return@forEach
            known[k] = SENT
            send.add(p)
        }
        if (send.isNotEmpty()) scope.launch { sendPoints(id, send) }
        return send.size
    }

    /** [prepareInsert] for one point. */
    fun prepareInsert(lat: Double, lng: Double): Int =
        prepareInsert(listOf(JsonObject().apply { addProperty("lat", lat); addProperty("lng", lng) }))

    /** [prepareInsert] for a job of the plan, by id. */
    fun prepareInsert(jobId: String): Int = prepareInsert(listOf(com.google.gson.JsonPrimitive(jobId)))

    // The points call. A network failure is repeated once, quietly; nothing else is repeated or reported. Points the
    // server did not take count as never sent.
    private suspend fun sendPoints(id: String, points: List<DoubleArray>) {
        val path = PATH_MATRIX + "/" + encode(id) + "/points"
        val body = JsonObject().apply { add("points", pointsJson(points)) }
        var r = transport.sendQuiet(path, body, PREPARE_TIMEOUT_MS)
        if (r.network && !destroyed) r = transport.sendQuiet(path, body, PREPARE_TIMEOUT_MS)
        when {
            r.ready -> markPoints(id, points, READY, SENT)
            r.status !in 200..299 -> markPoints(id, points, null, SENT)
        }
    }

    // Before an insert: the points of [jobs] sent to this snapshot and not yet answered ready are waited for (wait_ms,
    // E26), at most [SMapPlanEditorOptions.insertWaitTimeoutMillis]; null when there is nothing to wait for.
    private fun waitFor(jobs: List<JsonObject>): (suspend () -> Unit)? {
        val id = matrix ?: return null
        if (preparedMatrix != id) return null
        val seen = HashSet<String>()
        val waiting = ArrayList<DoubleArray>()
        jobs.forEach { j ->
            val ll = SMapPlanOps.lngLat(j.get("location")) ?: return@forEach
            if (!ll[0].isFinite() || !ll[1].isFinite()) return@forEach
            val k = pointKey(ll)
            if (prepared[k] != SENT || !seen.add(k)) return@forEach
            waiting.add(ll)
        }
        if (waiting.isEmpty()) return null
        val path = PATH_MATRIX + "/" + encode(id) + "/points"
        val body = JsonObject().apply { add("points", pointsJson(waiting)); addProperty("wait_ms", WAIT_MS) }
        val limit = options.insertWaitTimeoutMillis.takeIf { it > 0 } ?: INSERT_WAIT_TIMEOUT_MS
        return {
            val r = transport.sendQuiet(path, body, limit)
            if (r.ready) markPoints(id, waiting, READY, SENT)
        }
    }

    // The points known to snapshot [id]: those its opening sent, and those sent to it since.
    private fun knownPoints(id: String): HashMap<String, String> {
        if (preparedMatrix != id) {
            prepared.clear()
            preparedMatrix = id
            if (openedMatrix == id) openedPoints.forEach { prepared[it] = OPENED }
        }
        return prepared
    }

    private fun markPoints(id: String, points: List<DoubleArray>, to: String?, from: String) {
        if (preparedMatrix != id) return
        points.forEach { p ->
            val k = pointKey(p)
            if (prepared[k] != from) return@forEach
            if (to != null) prepared[k] = to else prepared.remove(k)
        }
    }

    // [lng, lat] of each point given to prepareInsert: a point, a job (its location) or an id of the plan's jobs.
    private fun pointsOf(input: List<JsonElement>): List<DoubleArray> {
        val byId = current()?.jobs?.associateBy(SMapPlanIds::ofJob) ?: emptyMap()
        return input.mapNotNull { v ->
            val at: JsonElement? = when {
                v.isJsonPrimitive -> byId[SMapPlanIds.of(v)]?.get("location")
                v.isJsonObject && v.asJsonObject.has("location") -> v.asJsonObject.get("location")
                else -> v
            }
            SMapPlanOps.lngLat(at)?.takeIf { it[0].isFinite() && it[1].isFinite() }
        }
    }

    private fun pointKey(p: DoubleArray): String = "${p[1]},${p[0]}"

    private fun pointsJson(points: List<DoubleArray>): JsonArray = JsonArray().also { a ->
        points.forEach { p -> a.add(JsonObject().apply { addProperty("lat", p[1]); addProperty("lng", p[0]) }) }
    }

    /** Places the unassigned job [jobId] (plan.insert). */
    suspend fun insert(jobId: String, limit: Int? = null): SMapPlanEdit? =
        insert(listOf(com.google.gson.JsonPrimitive(jobId)), limit)

    /** Puts an inserted job at another of its answered positions (plan.move). */
    suspend fun choose(jobId: String, index: Int): SMapPlanEdit? {
        val kept = choiceItems ?: emptyList()
        val item = kept.firstOrNull { it.job == jobId }
        val choice = item?.choices?.getOrNull(index) ?: throw SMapPlanException("sMap plan editor: no such position for $jobId")
        val vehicle = SMapPlanIds.of(choice.get("vehicle_id"))
        val position = choice.get("position")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asInt
        val moving = startMove(listOf(jobId), vehicle, position)
        val chosen = kept.map { if (it === item) it.copy(chosen = index) else it }
        choiceItems = chosen
        changed("choices")
        return try {
            val answer = awaitEdit(moving)
            if (answer != null) { choiceItems = chosen; changed("choices") }
            answer
        } catch (e: SMapPlanException) {
            choiceItems = kept
            changed("choices")
            throw e
        }
    }

    /**
     * Re-orders the stops of chosen routes around the locked stops (plan.refine). The new order is kept only when the
     * service finds it better; otherwise the plan stays and the answer's `changed` is false.
     *
     * @param vehicleIds the routes refined (default every route)
     * @param freeze the stops kept in place (default the locked stops on those routes)
     */
    suspend fun refine(vehicleIds: List<String>? = null, freeze: List<String>? = null): SMapPlanEdit? {
        val e = current() ?: throw SMapPlanException("sMap plan editor: no plan; call setPlan first")
        val extra = JsonObject()
        vehicleIds?.let { extra.add("vehicle_ids", ids(it)) }
        val frozen = freeze ?: locked().filter { id ->
            val where = SMapPlanOps.findStop(e.routes, id)
            where != null && (vehicleIds == null || where.second in vehicleIds)
        }
        if (frozen.isNotEmpty()) extra.add("freeze", ids(frozen))
        return awaitEdit(run("refine", extra, null, null to null))
    }

    /** Prices the plan again as it is (plan.recost). */
    suspend fun recost(): SMapPlanEdit? {
        val e = current() ?: return null
        supersede()
        return awaitEdit(price(e))
    }

    /** Locks stops so that refine keeps them on their route, in their order. Sends nothing. */
    fun lock(stops: List<String>) {
        lockedIds.addAll(stops)
        changed("lock")
    }

    fun unlock(stops: List<String>) {
        lockedIds.removeAll(stops.toSet())
        changed("lock")
    }

    fun locked(): List<String> = lockedIds.toList()
    fun isLocked(id: String): Boolean = id in lockedIds

    /** Goes back one edit. The plan drawn is the one answered then; a plan never priced is priced again. */
    suspend fun undo(): SMapPlanEdit? = if (!canUndo) null else step(-1)

    suspend fun redo(): SMapPlanEdit? = if (!canRedo) null else step(1)

    private suspend fun step(by: Int): SMapPlanEdit? {
        supersede()
        clearPreview()
        at += by
        choiceItems = null
        last = null
        error = null
        val e = history[at]
        val kind = if (by < 0) "undo" else "redo"
        changed(kind)
        return if (e.result != null) SMapPlanEdit(kind, plan(), result(), null) else awaitEdit(price(e))
    }

    /**
     * Prices other routes for the current jobs without changing the plan (plan.recost, no geometry), e.g. while a stop
     * is dragged; a newer preview cancels the one before. Reported as [SMapPlanEvent.Preview].
     */
    suspend fun preview(routes: List<SMapPlanRoute>): SMapPlanPreview? {
        val d = startPreview(routes) ?: return null
        return try {
            d.await()
        } catch (e: CancellationException) {
            currentCoroutineContext().ensureActive()
            null
        }
    }

    internal fun startPreview(routes: List<SMapPlanRoute>): Deferred<SMapPlanPreview?>? {
        val e = current() ?: return null
        if (destroyed) return null
        cancelPreview()
        val ticket = Ticket("preview")
        previewing = ticket
        val held = SMapPlanOps.routesOf(routes)
        val body = body(held, e.jobs, JsonObject(), false)
        val d = scope.async(start = CoroutineStart.LAZY) {
            val res = try {
                call(PATH_RECOST, body, 0)
            } catch (x: CancellationException) {
                throw x
            } catch (x: SMapPlanException) {
                if (previewing === ticket) previewing = null
                if (previewing == null && !destroyed) emit(SMapPlanEvent.Error(x, "preview"))
                return@async null
            }
            if (previewing !== ticket) return@async null
            previewing = null
            val data = res.data ?: JsonObject()
            val p = SMapPlanPreview(held, SMapPlanResult(data.arrayOr("routes"), data.objectOrNull("summary")))
            previewResult = p
            emit(SMapPlanEvent.Preview(p))
            p
        }
        ticket.job = d
        d.start()
        return d
    }

    fun clearPreview() {
        val had = previewing != null || previewResult != null
        cancelPreview()
        previewResult = null
        if (had) emit(SMapPlanEvent.Preview(null))
    }

    private fun cancelPreview() {
        previewing?.job?.cancel()
        previewing = null
    }

    /** Ends the editor: cancels its calls, closes its snapshot, and tells its map layer and panel to leave. */
    fun destroy() {
        if (destroyed) return
        supersede()
        cancelPreview()
        destroyed = true
        val id = matrix
        matrix = null
        if (id != null) closeMatrix(id)
        emit(SMapPlanEvent.Destroy)
        listeners.clear()
    }

    val isDestroyed: Boolean get() = destroyed

    /**
     * Runs an edit in the editor's scope without waiting for it (buttons, drops). A refusal is not thrown here: it is
     * reported as [SMapPlanEvent.Error].
     */
    fun perform(block: suspend SMapPlanEditor.() -> Unit) {
        scope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Reported through the error event (or a programming error of the caller's own block).
                if (e !is SMapPlanException) Log.w(TAG, "a plan edit failed", e)
            }
        }
    }

    // ------------------------------------------------------------------ internals

    private fun changed(kind: String) {
        val e = current()
        emit(SMapPlanEvent.Change(kind, plan(), result(), last?.answer?.deepCopy(), e?.result == null, canUndo, canRedo, lastPath))
    }

    private fun setBusy(on: Boolean) {
        if (busy == on) return
        busy = on
        emit(SMapPlanEvent.Busy(on))
    }

    // Cancels the call in flight. An edit drawn ahead of its answer stays in the history unpriced and is priced when it
    // is shown again; a search (insert, refine) that was cancelled never happened.
    private fun supersede() {
        val t = inflight ?: return
        inflight = null
        t.job?.cancel()
        setBusy(false)
    }

    private suspend fun awaitEdit(d: Deferred<SMapPlanEdit?>): SMapPlanEdit? = try {
        d.await()
    } catch (e: CancellationException) {
        // The call was superseded (its answer is ignored); a cancelled caller goes on cancelled.
        currentCoroutineContext().ensureActive()
        null
    }

    private fun ids(list: List<String>): JsonArray = JsonArray().also { a -> list.forEach(a::add) }

    private fun body(routes: List<SMapPlanRoute>, jobs: List<JsonObject>, extra: JsonObject, geometry: Boolean = options.geometry): JsonObject {
        // Routes without stops are kept as drop targets and not sent (an empty route would be priced start to end).
        var sent = routes.filter { it.stops.isNotEmpty() }
        if (sent.isEmpty()) sent = routes.take(1)
        val body = JsonObject()
        body.add("vehicles", JsonArray().also { a -> vehicles.forEach { a.add(it.deepCopy()) } })
        body.add("jobs", JsonArray().also { a -> jobs.forEach { a.add(it.deepCopy()) } })
        body.add("routes", JsonArray().also { a -> sent.forEach { a.add(it.toJson()) } })
        region?.let { body.addProperty("region", it) }
        profile?.let { body.addProperty("profile", it) }
        departedAt?.let { body.addProperty("departed_at", it) }
        body.add("options", JsonObject().apply { addProperty("geometry", geometry) })
        extra.entrySet().forEach { (k, v) -> body.add(k, v) }
        return body
    }

    // One edit: drawn at once when its outcome is known here (`local`), sent with the plan it changes, and replaced by
    // the answer. A search (insert, refine; `search` = jobs sent, jobs after) is pushed to the history only when answered.
    private fun run(
        kind: String,
        extra: JsonObject,
        local: ((List<SMapPlanRoute>) -> List<SMapPlanRoute>)?,
        search: Pair<List<JsonObject>?, List<JsonObject>?>?,
        wait: (suspend () -> Unit)? = null,
    ): Deferred<SMapPlanEdit?> {
        if (destroyed) throw SMapPlanException("sMap plan editor: destroyed")
        val base = current() ?: throw SMapPlanException("sMap plan editor: no plan; call setPlan first")
        supersede()
        clearPreview()
        var entry: Entry? = null
        if (local != null) {
            val routes = local(base.routes)
            entry = Entry(kind, routes, base.jobs)
            while (history.size > at + 1) history.removeAt(history.size - 1)
            history.add(entry)
            at = history.size - 1
            choiceItems = null
            last = null
            error = null
            changed(kind)
        }
        val body = body(base.routes, search?.first ?: base.jobs, extra)
        return request(kind, PATHS.getValue(kind), body, entry, search?.let { Search(base, it.second ?: base.jobs, wait) })
    }

    private fun price(entry: Entry): Deferred<SMapPlanEdit?> =
        request("recost", PATH_RECOST, body(entry.routes, entry.jobs, JsonObject()), entry, null)

    private fun request(kind: String, path: String, body: JsonObject, entry: Entry?, search: Search?): Deferred<SMapPlanEdit?> {
        val ticket = Ticket(kind)
        inflight = ticket
        setBusy(true)
        val d = scope.async(start = CoroutineStart.LAZY) {
            // An insert of prepared points waits for them first (at most the wait's time limit); it is sent either way.
            search?.wait?.let { w ->
                w()
                if (inflight !== ticket) return@async null
            }
            val res = try {
                call(path, body, 0)
            } catch (e: CancellationException) {
                throw e
            } catch (e: SMapPlanException) {
                return@async failed(ticket, kind, entry, e)
            }
            answered(ticket, kind, res, entry, search)
        }
        ticket.job = d
        d.start()
        return d
    }

    private fun answered(ticket: Ticket, kind: String, res: SMapPlanAnswer, entry: Entry?, search: Search?): SMapPlanEdit? {
        if (inflight !== ticket) return null
        inflight = null
        val data = res.data ?: JsonObject()
        val answer = ANSWERS[kind]?.let { data.get(it)?.takeIf { v -> !v.isJsonNull } }
        var target = entry
        if (search != null) {
            if (current() !== search.base) {
                setBusy(false)
                return null
            }
            val unchanged = kind == "refine" && answer != null && answer.isJsonObject &&
                answer.asJsonObject.get("changed")?.let { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean && !it.asBoolean } == true
            if (unchanged) {
                // The plan as sent stays; its prices are the ones answered.
                target = search.base
            } else {
                target = Entry(kind, search.base.routes, search.jobs.map { it.deepCopy() })
                while (history.size > at + 1) history.removeAt(history.size - 1)
                history.add(target)
                at = history.size - 1
            }
        }
        val t = target ?: return null
        val planRoutes = data.objectOrNull("plan")?.get("routes")?.takeIf { it.isJsonArray }?.asJsonArray
        if (planRoutes != null) {
            t.routes = SMapPlanOps.withAllVehicles(
                SMapPlanOps.routesOf(planRoutes.filter { it.isJsonObject }.map { SMapPlanRoute.fromJson(it.asJsonObject) }),
                vehicleIds(),
            )
        }
        t.result = SMapPlanResult(data.arrayOr("routes"), data.objectOrNull("summary"))
        if (kind != "recost") {
            t.answer = answer
            last = SMapPlanLast(kind, answer)
        }
        if (kind == "insert") {
            choiceItems = (answer?.takeIf { it.isJsonArray }?.asJsonArray ?: JsonArray()).filter { it.isJsonObject }.map { item ->
                val o = item.asJsonObject
                val placed = o.get("placed")?.let { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean && it.asBoolean } ?: false
                SMapPlanChoices(
                    SMapPlanIds.of(o.get("job")),
                    placed,
                    o.get("reason")?.takeIf { it.isJsonPrimitive }?.asString,
                    o.get("choices")?.takeIf { it.isJsonArray }?.asJsonArray?.filter { it.isJsonObject }?.map { it.asJsonObject.deepCopy() } ?: emptyList(),
                    if (placed) 0 else null,
                )
            }
        }
        error = null
        setBusy(false)
        if (current() === t || kind != "recost") changed(kind)
        return SMapPlanEdit(kind, plan(), result(), answer?.deepCopy(), lastPath)
    }

    private fun failed(ticket: Ticket, kind: String, entry: Entry?, e: SMapPlanException): SMapPlanEdit? {
        val now = inflight === ticket
        if (now) {
            inflight = null
            setBusy(false)
        }
        if (!now || destroyed) return null
        // A failed edit drawn ahead of its answer is taken back.
        if (entry != null && kind != "recost") {
            val i = history.indexOfFirst { it === entry }
            if (i > 0) {
                history.removeAt(i)
                if (at >= i) at -= 1
            }
        }
        error = SMapPlanError(kind, e.status, e.code, e.message ?: "", e.reason)
        changed("error")
        emit(SMapPlanEvent.Error(e, kind))
        throw e
    }

    // A call with the snapshot: opened first when needed, named as `matrix`, and opened again after it expired. A
    // snapshot never makes a call fail (E2): a 410 is repeated with a new snapshot, then without one.
    private suspend fun call(path: String, body: JsonObject, attempt: Int): SMapPlanAnswer {
        val id = if (attempt >= 2) null else ensureMatrix().await()
        if (id != null) body.addProperty("matrix", id) else body.remove("matrix")
        val res = try {
            transport.send("POST", path, body)
        } catch (e: SMapPlanException) {
            val sent = body.get("matrix")?.asString
            if (e.status == 410 && sent != null && attempt < 2) {
                dropMatrix(sent, "expired")
                return call(path, body, attempt + 1)
            }
            throw e
        }
        if (!destroyed) lastPath = res.path
        body.get("matrix")?.asString?.let { snapshotSeen(res.matrix, it) }
        return res
    }

    private fun snapshotSeen(header: String?, sent: String) {
        val status = header ?: "used"
        emit(SMapPlanEvent.Snapshot(status, sent))
        if (status == "expired" || status == "mismatch") {
            dropMatrix(sent, null)
            // Opened now, for the next call; this call was already answered without it.
            ensureMatrix()
        }
    }

    private fun dropMatrix(id: String, status: String?) {
        if (matrix == id) {
            matrix = null
            matrixKey = null
        }
        if (status != null) emit(SMapPlanEvent.Snapshot(status, id))
    }

    private fun closeMatrix(id: String) {
        scope.launch {
            try {
                transport.send("DELETE", PATH_MATRIX + "/" + encode(id))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // A snapshot left open ends by itself.
            }
        }
    }

    private fun ensureMatrix(): Deferred<String?> {
        if (!options.snapshot || destroyed) return done(null)
        val key = (region ?: "") + "|" + (profile ?: "")
        matrix?.let { if (matrixKey == key) return done(it) }
        opening?.let { if (openingKey == key) return it }
        if (matrixRetryAt != 0L && clock() < matrixRetryAt) return done(null)
        matrix?.let { old ->
            matrix = null
            closeMatrix(old)
        }
        val body = JsonObject()
        region?.let { body.addProperty("region", it) }
        profile?.let { body.addProperty("profile", it) }
        // The plan's points, so the server can measure their legs into the snapshot ahead of the edits (E24).
        val points = points()
        if (points.size() > 0) body.add("points", points)
        openingKey = key
        var self: Deferred<String?>? = null
        val d = scope.async(start = CoroutineStart.LAZY) {
            val id: String? = try {
                val res = transport.send("POST", PATH_MATRIX, body)
                val id = res.data?.get("matrix")?.takeIf { it.isJsonPrimitive }?.asString?.takeIf { it.isNotEmpty() }
                    ?: throw SMapPlanException("sMap plan editor: the snapshot answer has no id")
                if (destroyed) {
                    closeMatrix(id)
                    null
                } else {
                    matrixRetryAt = 0
                    if (openingKey == key) {
                        matrix = id
                        matrixKey = key
                        openedMatrix = id
                        openedPoints = points.map { p -> p.asJsonObject.let { "${it.get("lat").asDouble},${it.get("lng").asDouble}" } }
                    }
                    val data = res.data
                    emit(SMapPlanEvent.Snapshot("opened", id, data.get("expires_at")?.takeIf { it.isJsonPrimitive }?.asString,
                        data.get("node")?.takeIf { it.isJsonPrimitive }?.asString, path = res.path))
                    id
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                matrixRetryAt = clock() + SNAPSHOT_RETRY_MS
                if (!destroyed) emit(SMapPlanEvent.Snapshot("failed", null, error = e))
                null
            }
            if (opening === self) {
                opening = null
                openingKey = null
            }
            id
        }
        self = d
        opening = d
        d.start()
        return d
    }

    // The plan's points as a snapshot opening sends them: every job location, then every vehicle's start and end, exactly
    // as the plan holds them (the numbers the plan calls send, since legs are matched exactly), each sent once, first
    // seen first.
    private fun points(): JsonArray {
        val out = JsonArray()
        val seen = HashSet<String>()
        fun add(v: JsonElement?) {
            val ll = SMapPlanOps.lngLat(v) ?: return
            if (!ll[0].isFinite() || !ll[1].isFinite()) return
            val lat = ll[1]
            val lng = ll[0]
            if (!seen.add("$lat,$lng")) return
            out.add(JsonObject().apply { addProperty("lat", lat); addProperty("lng", lng) })
        }
        current()?.jobs?.forEach { add(it.get("location")) }
        vehicles.forEach { add(it.get("start")); add(it.get("end")) }
        return out
    }

    private fun done(value: String?): Deferred<String?> = CompletableDeferred<String?>().also { it.complete(value) }

    private fun JsonObject.arrayOr(key: String): JsonArray = get(key)?.takeIf { it.isJsonArray }?.asJsonArray?.deepCopy() ?: JsonArray()
    private fun JsonObject.objectOrNull(key: String): JsonObject? = get(key)?.takeIf { it.isJsonObject }?.asJsonObject?.deepCopy()

    companion object {
        private const val TAG = "SMapPlan"
        internal const val PATH_RECOST = "/v1/plan/recost"
        internal const val PATH_MATRIX = "/v1/plan/matrix"
        private val PATHS = mapOf(
            "recost" to PATH_RECOST, "resequence" to "/v1/plan/resequence", "move" to "/v1/plan/move",
            "remove" to "/v1/plan/remove", "insert" to "/v1/plan/insert", "refine" to "/v1/plan/refine",
        )

        // Answer fields that describe the edit itself, beside routes, summary and plan.
        private val ANSWERS = mapOf("resequence" to "resequence", "move" to "move", "remove" to "removed", "insert" to "insert", "refine" to "refine")

        /** A snapshot that could not be opened is asked for again after this long; calls go on without one meanwhile. */
        const val SNAPSHOT_RETRY_MS = 60_000L

        /** How long the server is asked to wait for an insert's prepared points (`wait_ms`, E26). */
        const val WAIT_MS = 1000

        /** How long an insert waits at most for that answer before it is sent anyway. */
        const val INSERT_WAIT_TIMEOUT_MS = 1200L

        /** A points call without a wait is given up after this long. */
        const val PREPARE_TIMEOUT_MS = 10_000L

        private const val OPENED = "plan"
        private const val SENT = "sent"
        private const val READY = "ready"

        /** `encodeURIComponent`. */
        internal fun encode(s: String): String {
            val sb = StringBuilder()
            for (b in s.toByteArray(Charsets.UTF_8)) {
                val c = b.toInt() and 0xff
                if (c.toChar().isLetterOrDigit() && c < 128 || c.toChar() in "-_.!~*'()") sb.append(c.toChar())
                else sb.append('%').append("%02X".format(c))
            }
            return sb.toString()
        }
    }
}
