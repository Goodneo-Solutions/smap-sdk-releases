package ca.superroute.smap

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.JsonPrimitive

/**
 * The indoor calls of the Flutter and React Native SDKs, by name with JSON arguments (MOBILE-SDK-SPEC, the indoor
 * layer): one reading for both. Answers JSON text, or null for a method that is not an indoor call.
 *
 * Events go to [emit]: `indoorLevelChange` `{id, level}` and `indoorClick` `{id, feature, lat, lng}`.
 */
object SMapIndoorCalls {
    val METHODS = setOf("addIndoor", "setIndoorLevel", "getIndoorLevel", "indoorLevels", "indoors", "indoorToLngLat", "lngLatToIndoor", "removeIndoor")

    fun handles(method: String) = method in METHODS

    /** Sends every level change of [map]'s indoor layers to [emit]. */
    fun listen(map: SMap, emit: (String, JsonObject) -> Unit) {
        map.on(SMapEventType.INDOOR_LEVEL_CHANGE) { e ->
            emit("indoorLevelChange", JsonObject().apply { addProperty("id", e.indoorId); addProperty("level", e.level) })
        }
    }

    /** One call; [args] the call's JSON array as text. */
    suspend fun call(map: SMap, method: String, args: String, emit: (String, JsonObject) -> Unit): String? {
        if (!handles(method)) return null
        val a = JsonParser.parseString(args.ifEmpty { "[]" }).takeIf { it.isJsonArray }?.asJsonArray ?: JsonArray()
        fun s(i: Int): String = a.get(i).asString
        fun d(i: Int): Double = a.get(i).asDouble
        return when (method) {
            "addIndoor" -> {
                val id = s(0)
                val source = SMapIndoor.sourceOf(a.get(1).asJsonObject)
                val o = a.takeIf { it.size() > 2 }?.get(2)?.takeIf { it.isJsonObject }?.asJsonObject
                val onClick = o?.get("onClick")?.takeIf { it.isJsonPrimitive && it.asBoolean }?.let {
                    { f: JsonObject, at: org.maplibre.android.geometry.LatLng ->
                        emit("indoorClick", JsonObject().apply { addProperty("id", id); add("feature", f); addProperty("lat", at.latitude); addProperty("lng", at.longitude) })
                    }
                }
                map.addIndoor(id, source, SMapIndoor.optionsOf(o, onClick))
                "null"
            }
            "setIndoorLevel" -> { map.setIndoorLevel(s(0), s(1)); "null" }
            "getIndoorLevel" -> map.getIndoorLevel(s(0))?.let { JsonPrimitive(it).toString() } ?: "null"
            "indoorLevels" -> JsonArray().also { out -> map.indoorLevels(s(0)).forEach { out.add(SMapIndoor.levelJson(it)) } }.toString()
            "indoors" -> JsonArray().also { out -> map.indoors().forEach { out.add(it) } }.toString()
            "indoorToLngLat" -> map.indoorToLngLat(s(0), s(1), d(2), d(3)).let { JsonArray().apply { add(it.longitude); add(it.latitude) } }.toString()
            "lngLatToIndoor" -> map.lngLatToIndoor(s(0), s(1), d(2), d(3)).let { JsonArray().apply { add(it.first); add(it.second) } }.toString()
            "removeIndoor" -> { map.removeIndoor(s(0)); "null" }
            else -> null
        }
    }

    /** A JSON value as plain Kotlin values (maps, lists, strings, numbers, booleans, null), for a host channel. */
    fun plain(e: JsonElement?): Any? = when {
        e == null || e is JsonNull -> null
        e.isJsonObject -> e.asJsonObject.entrySet().associate { it.key to plain(it.value) }
        e.isJsonArray -> e.asJsonArray.map { plain(it) }
        e.asJsonPrimitive.isBoolean -> e.asBoolean
        e.asJsonPrimitive.isNumber -> e.asDouble
        else -> e.asString
    }
}
