package ca.superroute.smap

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser

/**
 * The traffic calls of the Flutter and React Native SDKs (MOBILE-SDK-SPEC "Traffic"): the view's option, its calls by
 * name with JSON arguments and its events, one reading for both. Their wrapper draws the button and panel itself, so
 * the native view never draws one; the card is drawn by the native view unless the option's `info` is false.
 *
 * Events go to `emit`: `trafficAvailable` `{available}` each time it changes, `trafficChange` `{shown, groups, open}`
 * after every change, `trafficClick` `{id, group, lngLat, point}` after a tap on a feature and, for a wrapper drawing
 * the panel from pictures (React Native, `legendImages`), `trafficLegend` `{scale, symbols}` once the map is ready.
 */
object SMapTrafficCalls {
    val METHODS = setOf("setTraffic", "traffic", "trafficFeature")

    fun handles(method: String) = method in METHODS

    /**
     * The view's `traffic` option as the wrapper sends it: an object `{shown, groups, info}` (the token is asked of
     * [getToken]), always without the native button; null (no traffic layer) for anything else or without [getToken].
     */
    fun options(value: JsonElement?, getToken: (suspend () -> String)?): SMapTrafficOptions? {
        val o = value?.takeIf { it.isJsonObject }?.asJsonObject ?: return null
        if (getToken == null) return null
        return SMapTrafficOptions(
            getToken = getToken,
            shown = flag(o["shown"]) == true,
            groups = o["groups"]?.let(::strings),
            control = false,
            info = flag(o["info"]) != false,
        )
    }

    /** [options] from the option's JSON text (null / empty: no traffic layer). */
    fun options(json: String?, getToken: (suspend () -> String)?): SMapTrafficOptions? =
        options(json?.takeIf { it.isNotBlank() }?.let { try { JsonParser.parseString(it) } catch (e: Exception) { null } }, getToken)

    /** Sends [map]'s traffic availability, changes and clicks to [emit]; with [legendImages] also the groups' pictures. */
    fun listen(map: SMap, emit: (String, JsonObject) -> Unit, legendImages: Boolean = false) {
        if (map.traffic() == null) return
        map.onTrafficAvailable { ok -> emit("trafficAvailable", JsonObject().apply { addProperty("available", ok) }) }
        map.addOnTrafficChangeListener { e -> emit("trafficChange", SMapTraffic.changeJson(e)) }
        map.addOnTrafficClickListener { e -> emit("trafficClick", SMapTraffic.clickJson(e)) }
        if (legendImages) map.ready {
            try { emit("trafficLegend", SMapTraffic.legendImagesJson(map.resources.displayMetrics.density)) } catch (e: Exception) { /* a picture the device cannot make */ }
        }
    }

    /**
     * One call, answered as JSON text (null for a method that is not a traffic call); [args] the call's JSON array as
     * text: `setTraffic` `[shown | null, groups | null, open | null]`, `traffic` `[]`, `trafficFeature` `[id]`.
     */
    suspend fun call(map: SMap, method: String, args: String): String? {
        if (!handles(method)) return null
        val a = JsonParser.parseString(args.ifEmpty { "[]" }).takeIf { it.isJsonArray }?.asJsonArray ?: JsonArray()
        fun at(i: Int): JsonElement? = if (i < a.size() && !a[i].isJsonNull) a[i] else null
        return when (method) {
            "setTraffic" -> {
                map.setTraffic(shown = flag(at(0)), groups = at(1)?.let(::strings), open = flag(at(2)))
                "null"
            }
            "traffic" -> SMapTraffic.stateJson(map.traffic()).toString()
            "trafficFeature" -> {
                val id = SMapTraffic.id(at(0)?.takeIf { it.isJsonPrimitive }?.asString) ?: throw IllegalArgumentException("sMap: a traffic feature's id is a whole number")
                SMapTraffic.featureJson(map.trafficFeature(id)).toString()
            }
            else -> null
        }
    }

    private fun flag(e: JsonElement?): Boolean? = e?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean }?.asBoolean

    private fun strings(e: JsonElement): List<String>? = e.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { if (it.isJsonPrimitive) it.asString else null }
}
