package ca.superroute.smap

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.maplibre.android.geometry.LatLng
import org.maplibre.geojson.Point

/**
 * The traffic layer of one map (MOBILE-SDK-SPEC "Traffic"): hidden until the person turns it on and nothing asked
 * before; then the TileJSON with the traffic token, the source and layers above the road attributes and under the
 * caller's layers, the button and panel as the tool `traffic`, the tap, its card and the listeners. Its layers and
 * source are the SDK's own: never among the caller's layers, sources or the layer description.
 */
internal class SMapTrafficLayer(private val map: SMap, private val options: SMapTrafficOptions?, http: SMapHttp?) {
    private val start = SMapTraffic.start(options)
    val enabled: Boolean get() = start != null
    private val wantsCard = options?.info != false

    private var now = SMapTrafficChange(start?.first ?: false, start?.second ?: emptyList(), false)
    val shown: Boolean get() = now.shown
    val groups: List<String> get() = now.groups
    val open: Boolean get() = now.open
    var available: Boolean? = null
        private set

    // Its own requests carry the traffic token only and stay at the node they were sent to.
    private val client = options?.let { SMapTrafficClient(SMapTrafficClient.tokens(it.getToken), http ?: SMapUrlConnectionHttp(followRedirects = false)) }
    private var number: String? = null
    private var tiles: List<String>? = null
    private var credit: List<SMapTrafficCredit> = emptyList()
    private var seconds = SMapTraffic.refreshSeconds
    private var begun = false
    private var loading = false
    private var destroyed = false
    private var pressed = false
    private var timer: Job? = null
    private var askedAt = 0L
    private var blinking = false
    private var blinks = 0
    private var control: SMapTrafficControl? = null
    private val listeners = ArrayList<(SMapTrafficChange) -> Unit>()
    private val clickListeners = ArrayList<(SMapTrafficClick) -> Unit>()

    /** Called with the availability each time it changes (the Flutter and React Native views tell their wrapper). */
    var onAvailable: ((Boolean) -> Unit)? = null

    /** The credit of the data drawn now, as plain text. */
    var creditText: String? = null
        private set

    fun state(): SMapTrafficState? = if (!enabled) null else SMapTrafficState(available, shown, groups, open)

    fun addListener(l: (SMapTrafficChange) -> Unit) { listeners += l }
    fun removeListener(l: (SMapTrafficChange) -> Unit) { listeners -= l }
    fun addClickListener(l: (SMapTrafficClick) -> Unit) { clickListeners += l }
    fun removeClickListener(l: (SMapTrafficClick) -> Unit) { clickListeners -= l }

    /** The map has its first style: the button, and the layer when it starts shown. */
    fun begin() {
        if (!enabled || begun || destroyed) return
        begun = true
        val o = options!!
        if (o.control) {
            val c = SMapTrafficControl(map.context, o.position, this, { map.raiseCorner(o.position, it) }) { map.language }
            control = c
            map.addTool(SMapTraffic.toolId, c, SMapTraffic.text(map.language, "button"), o.position)
            c.render()
        }
        if (shown) load()
    }

    /** The button: the first press shows the layer and opens the panel, later presses open and close the panel (M114). */
    fun press() {
        if (!open && !pressed && !shown) {
            pressed = true
            set(true, null, true)
        } else {
            set(null, null, !open)
        }
    }

    // ------------------------------------------------------------------ the service

    /** The TileJSON, then the layer: when the layer is first shown, and again every refresh while it is not offered. */
    private fun load() {
        if (!begun || loading || destroyed) return
        val c = client ?: return
        loading = true
        askedAt = SystemClock.elapsedRealtime()
        map.scope.launch {
            val json = try {
                c.get(SMapTraffic.tileJsonUrl(map.nodeUrl())).let { SMapTraffic.parse(it.status, it.body) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            loading = false
            // Only tiles the token may go to are drawn.
            val t = SMapTraffic.tiles(json)?.filter(::mayAsk)?.takeIf { it.isNotEmpty() }
            val was = available
            available = t != null
            if (t != null) {
                tiles = t
                credit = SMapTraffic.credit(json!!["attribution"]?.takeIf { it.isJsonPrimitive }?.asString)
                seconds = SMapTraffic.refreshSeconds(json)
            }
            map.currentStyle()?.let { apply(it) }
            if (was != available) {
                control?.render()
                onAvailable?.invoke(available == true)
            }
            restart()
        }
    }

    // The template's {z}/{x}/{y} are not part of an address.
    private fun mayAsk(tile: String): Boolean =
        SMapTraffic.webUrl(tile.replace(Regex("\\{[zxy]\\}"), "0"))?.let { SMapTraffic.mayCarryToken(it, map.nodeUrls()) } == true

    /** This map's number in the tile URLs, made when its tiles are first asked for. */
    private fun number(): String = number ?: SMapTrafficHttp.add(
        SMapTrafficHttp.Access({ SMapTraffic.mayCarryToken(it, map.nodeUrls()) }, ::tokenNow),
    ).also { number = it }

    /** The token for a tile, on a network thread: the app's getToken is asked on the main thread, as for the map's own. */
    private fun tokenNow(refused: String?): String {
        val tokens = client!!.tokens
        if (refused == null) tokens.fresh?.let { return it }
        return runBlocking {
            withTimeout(TOKEN_TIMEOUT_MILLIS) {
                map.scope.async { if (refused == null) tokens.token() else tokens.replace(refused) }.await()
            }
        } ?: throw SMapException("sMap: no traffic token")
    }

    /** A feature's details. */
    suspend fun feature(id: Long): SMapTrafficFeature {
        val c = client ?: throw SMapException("sMap: the map has no traffic layer")
        if (destroyed) throw SMapException("sMap: the map is gone")
        val url = SMapTraffic.featureUrl(map.nodeUrl(), id)
        val answer = c.get(url)
        val json = SMapTraffic.parse(answer.status, answer.body)
            ?: throw SMapException("sMap: the traffic details could not be read (HTTP ${answer.status})", answer.status, url)
        return SMapTraffic.feature(id, json)
    }

    // ------------------------------------------------------------------ the layer

    /** Puts the source and layers on [style] as the state says (after a style load, a change of groups, on and off). */
    fun apply(style: SMapEngineStyle) {
        if (!enabled || destroyed) return
        val t = tiles
        try {
            if (!shown || available != true || t == null) remove(style) else put(style, t)
        } catch (e: Exception) {
            map.reportError(e)
        }
        val text = if (shown && available == true) SMapAttribution.text(listOf(credit.joinToString("") { it.text })).ifEmpty { null } else null
        if (text != creditText) {
            creditText = text
            map.updateAttribution()
        }
    }

    private fun put(style: SMapEngineStyle, t: List<String>) {
        if (style.getSource(SMapTraffic.source) == null) {
            val source = SMapStyleBridge.source(SMapTraffic.source, sourceJson(t))
            // Asked for with the person's token: not kept on the device.
            source.setVolatile(true)
            style.addSource(source)
            blinking = false
        }
        val scale = map.resources.displayMetrics.density
        for (id in SMapTraffic.imageIds()) {
            if (style.getImage(id) == null) style.addImage(id, SMapTraffic.image(id, scale).apply { density = map.resources.displayMetrics.densityDpi })
        }
        val basemap = map.basemapLayerIds()
        for (l in SMapTraffic.layers(groups)) {
            val id = l["id"].asString
            val drawn = style.getLayer(id)
            if (drawn != null) {
                SMapStyleBridge.filter(drawn, l["filter"])
                continue
            }
            val layer = SMapStyleBridge.layer(l, hidden = false)
            val before = SMapTraffic.beforeId(id, style.layerIds, basemap)
            if (before != null) style.addLayerBelow(layer, before) else style.addLayer(layer)
        }
    }

    private fun remove(style: SMapEngineStyle) {
        for (id in SMapTraffic.layerIds()) if (style.getLayer(id) != null) style.removeLayer(id)
        if (style.getSource(SMapTraffic.source) != null) style.removeSource(SMapTraffic.source)
    }

    private fun sourceJson(t: List<String>) = JsonObject().apply {
        val zoom = SMapTraffic.spec.getAsJsonObject("zoom")
        addProperty("type", "vector")
        add("tiles", JsonArray().also { a -> t.forEach { a.add(SMapTrafficHttp.tileUrl(it, number())) } })
        addProperty("minzoom", zoom["min"].asInt)
        addProperty("maxzoom", zoom["max"].asInt)
        if (credit.isNotEmpty()) addProperty("attribution", SMapTraffic.creditHtml(credit))
    }

    /** Changes the state; keys left null keep their value. Tells the listeners when something changed. */
    fun set(shown: Boolean?, groups: List<String>?, open: Boolean?) {
        if (!enabled || destroyed) return
        val before = now
        now = SMapTraffic.next(before, shown, groups, open, control != null)
        if (now == before) return
        if (now.shown && !before.shown && available != true) load()
        if (!now.shown) closeCard()
        map.currentStyle()?.let { apply(it) }
        if (now.shown != before.shown) restart()
        val e = now
        listeners.toList().forEach { try { it(e) } catch (x: Exception) { map.reportError(x) } }
        control?.render()
    }

    fun close() { if (open) set(null, null, false) }

    // ------------------------------------------------------------------ the refresh

    /** The map came to the front (onStart) or left it (onStop): nothing is asked in the background. */
    fun front(front: Boolean) {
        if (!enabled || destroyed) return
        if (front && begun && shown && SystemClock.elapsedRealtime() - askedAt >= seconds * 1000L) tick()
        restart()
    }

    private fun restart() {
        timer?.cancel()
        timer = null
        if (!begun || !shown || destroyed || !map.inFront) return
        timer = map.scope.launch {
            while (isActive) {
                delay(seconds * 1000L)
                tick()
            }
        }
    }

    // Not offered: asked again. Offered: the tiles drawn are asked for again (neither engine does so by itself).
    private fun tick() {
        if (available != true) { load(); return }
        val engine = map.mapEngine ?: return
        val style = map.currentStyle() ?: return
        if (style.getSource(SMapTraffic.source) == null) return
        askedAt = SystemClock.elapsedRealtime()
        try {
            if (engine.asksShownTilesAgain) blink(engine, style)
            else {
                remove(style)
                apply(style)
            }
        } catch (e: Exception) {
            map.reportError(e)
        }
    }

    // MapLibre (13.6) does not ask for a drawn tile again by itself. It does for the tiles of a source drawn again after
    // a frame without it: with the tile's ETag, once the tile has expired, what it has staying drawn meanwhile. A zoom
    // range the map is not in leaves the source out of a frame (hiding the layers would throw the tiles away). Two
    // frames, as one may have been under way.
    private fun blink(engine: SMapEngine, style: SMapEngineStyle) {
        if (blinking) return
        blinking = true
        val round = ++blinks
        inRange(style, false)
        var frames = 0
        var listener: ((Boolean) -> Unit)? = null
        listener = {
            if (++frames < 2) {
                engine.triggerRepaint()
            } else {
                listener?.let(engine::removeOnDidFinishRenderingFrameListener)
                if (blinking && round == blinks && !destroyed) {
                    blinking = false
                    try { map.currentStyle()?.let { inRange(it, true) } } catch (e: Exception) { map.reportError(e) }
                }
            }
        }
        engine.addOnDidFinishRenderingFrameListener(listener)
        engine.triggerRepaint()
    }

    private fun inRange(style: SMapEngineStyle, on: Boolean) {
        for (id in SMapTraffic.layerIds()) style.getLayer(id)?.minZoom = if (on) 0f else OUT_OF_RANGE
    }

    fun destroy() {
        destroyed = true
        timer?.cancel()
        number?.let(SMapTrafficHttp::remove)
        closeCard()
    }

    // ------------------------------------------------------------------ the tap and its card

    private var card: SMapTrafficCard? = null
    private var cardJob: Job? = null

    fun closeCard() {
        cardJob?.cancel()
        cardJob = null
        card?.let { map.removeView(it) }
        card = null
    }

    /**
     * A tap the caller's layers did not answer: when no layer that is neither the basemap's, the road attributes' nor
     * the traffic's is drawn at [point], the nearest traffic point within the tolerance is read, else a line. True when
     * a feature was read.
     */
    fun click(point: PointF, latLng: LatLng): Boolean {
        if (!enabled || !shown || available != true) return false
        val style = map.currentStyle() ?: return false
        val basemap = map.basemapLayerIds()
        val own = style.layerIds.filter { it !in basemap && !SMapTraffic.isOverlay(it) }
        if (own.isNotEmpty() && map.engineFeatures(RectF(point.x - 0.5f, point.y - 0.5f, point.x + 0.5f, point.y + 0.5f), own).isNotEmpty()) return false
        val r = SMapTraffic.tolerance * map.resources.displayMetrics.density
        val box = RectF(point.x - r, point.y - r, point.x + r, point.y + r)
        val points = SMapTraffic.pointLayers()
        val hits = ArrayList<SMapTrafficHit>()
        // MapLibre does not tell a feature's layer: asked layer by layer, the top one first.
        for (id in SMapTraffic.layerIds().reversed()) {
            for (f in map.engineFeatures(box, listOf(id))) {
                val at = (f.geometry() as? Point)?.let { map.mapEngine?.toScreenLocation(LatLng(it.latitude(), it.longitude())) }
                val distance = if (at == null) Float.MAX_VALUE else kotlin.math.hypot(at.x - point.x, at.y - point.y)
                hits += SMapTrafficHit(SMapTraffic.id(f.id()), SMapTraffic.groupOf(f.properties()), id in points, distance)
            }
        }
        val picked = SMapTraffic.pick(hits) ?: return false
        val id = picked.id ?: return false
        val click = SMapTrafficClick(id, picked.group, latLng, point.x to point.y)
        clickListeners.toList().forEach { try { it(click) } catch (e: Exception) { map.reportError(e) } }
        if (wantsCard && !destroyed) showCard(id, picked.group, point)
        return true
    }

    private fun showCard(id: Long, group: String?, at: PointF) {
        closeCard()
        val c = SMapTrafficCard(map.context, group, map.language, map.scope) { closeCard() }
        card = c
        map.addView(c, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        // Placed again as it grows (the details, the picture).
        c.addOnLayoutChangeListener { _, l, t, right, b, ol, ot, or, ob -> if (right - l != or - ol || b - t != ob - ot) place(c, at) }
        c.measure(View.MeasureSpec.makeMeasureSpec(map.width, View.MeasureSpec.AT_MOST), View.MeasureSpec.makeMeasureSpec(map.height, View.MeasureSpec.AT_MOST))
        place(c, at)
        cardJob = map.scope.launch {
            val f = try {
                feature(id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (card === c) c.fill(f)
        }
    }

    // Above the tap when it fits, else below it; always wholly inside the map.
    private fun place(c: View, at: PointF) {
        val d = map.resources.displayMetrics.density
        val margin = 8 * d
        val w = c.measuredWidth.toFloat()
        val h = c.measuredHeight.toFloat()
        var y = at.y - h - 12 * d
        if (y < margin) y = at.y + 12 * d
        c.translationX = (at.x - w / 2).coerceIn(margin, maxOf(margin, map.width - w - margin))
        c.translationY = y.coerceIn(margin, maxOf(margin, map.height - h - margin))
    }

    private companion object {
        /** A tile waits this long for the app's token at most. */
        const val TOKEN_TIMEOUT_MILLIS = 15_000L

        /** A minimum zoom no map is at. */
        const val OUT_OF_RANGE = 25.5f
    }
}

/**
 * The traffic tool: a round button with a traffic light (blue while the layer is shown) that opens a panel beside it
 * (towards the map's middle): the title, the switch, the note while sMap does not offer the layer, All and None, and one
 * row per group with its image.
 */
@SuppressLint("ViewConstructor")
internal class SMapTrafficControl(
    context: Context,
    private val corner: SMapToolPosition,
    private val layer: SMapTrafficLayer,
    private val onOpen: (Boolean) -> Unit,
    private val languageOf: () -> String?,
) : LinearLayout(context) {
    private val button = SMapToolStyle.roundButton(context)
    private val icon = LightIcon(context)
    private val scroll = ScrollView(context)
    private val panel = LinearLayout(context)
    private fun dp(v: Float) = SMapToolStyle.dp(context, v)

    // The panel's parts, made once per language; a change of the layer only updates them (a screen reader keeps its place).
    private var madeFor: String? = null
    private lateinit var showBox: CheckBox
    private lateinit var note: TextView
    private val presets = ArrayList<Pair<TextView, List<String>>>()
    private val boxes = LinkedHashMap<String, CheckBox>()
    private var updating = false
    private var raised = false

    init {
        orientation = HORIZONTAL
        clipChildren = false
        button.addView(icon, FrameLayout.LayoutParams(dp(20f), dp(20f), Gravity.CENTER))
        button.setOnClickListener { layer.press() }
        panel.orientation = VERTICAL
        val pad = dp(10f)
        panel.setPadding(pad, dp(8f), pad, dp(8f))
        scroll.background = SMapToolStyle.card(context, 8f)
        // The corners of the map do not clip (shadows): the rows scrolled away are cut at the panel's own edge.
        scroll.clipToOutline = true
        scroll.elevation = dp(4f).toFloat()
        scroll.addView(panel, ViewGroup.LayoutParams(dp(250f), ViewGroup.LayoutParams.WRAP_CONTENT))
        scroll.visibility = View.GONE
        val right = corner == SMapToolPosition.TOP_RIGHT || corner == SMapToolPosition.BOTTOM_RIGHT
        val bottom = corner == SMapToolPosition.BOTTOM_LEFT || corner == SMapToolPosition.BOTTOM_RIGHT
        gravity = if (bottom) Gravity.BOTTOM else Gravity.TOP
        val size = dp(SMapToolStyle.BUTTON_DP)
        val panelParams = LayoutParams(dp(250f), ViewGroup.LayoutParams.WRAP_CONTENT)
        if (right) { addView(scroll, panelParams.apply { marginEnd = dp(6f) }); addView(button, LayoutParams(size, size)) }
        else { addView(button, LayoutParams(size, size)); addView(scroll, panelParams.apply { marginStart = dp(6f) }) }
    }

    /** Draws the panel again from the layer's state, in the map's language. */
    fun render() {
        val lang = SMapTraffic.language(languageOf())
        if (madeFor != lang) make(lang)
        button.isSelected = layer.shown
        icon.tint(if (layer.shown) SMapToolStyle.BLUE else SMapToolStyle.TEXT)
        scroll.visibility = if (layer.open) View.VISIBLE else View.GONE
        if (raised != layer.open) {
            raised = layer.open
            onOpen(raised)
        }
        updating = true
        showBox.isChecked = layer.shown
        boxes.forEach { (key, box) -> box.isChecked = key in layer.groups }
        updating = false
        note.visibility = if (layer.shown && layer.available == false) View.VISIBLE else View.GONE
        presets.forEach { (view, groups) ->
            val on = layer.groups == groups
            view.setTextColor(if (on) Color.WHITE else SMapToolStyle.TEXT)
            view.background = SMapToolStyle.card(context, 5f).apply { if (on) { setColor(SMapToolStyle.BLUE); setStroke(0, 0) } }
            view.isSelected = on
        }
    }

    private fun make(lang: String) {
        madeFor = lang
        presets.clear()
        boxes.clear()
        panel.removeAllViews()
        val t = { k: String -> SMapTraffic.text(lang, k) }
        button.contentDescription = t("button")
        panel.addView(text(t("button"), 13f, bold = true), LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(4f) })
        showBox = row("shown", t("show"), null) { layer.set(it, null, null) }
        note = text(t("unavailable"), 12f).apply {
            tag = "unavailable"
            setTextColor(Color.rgb(194, 65, 12))
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        panel.addView(note)
        val line = LinearLayout(context).apply { orientation = HORIZONTAL }
        listOf("presetAll" to SMapTraffic.groupKeys(), "presetNone" to emptyList<String>()).forEach { (key, groups) ->
            val v = text(t(key), 12f).apply {
                tag = key
                setPadding(dp(8f), dp(3f), dp(8f), dp(3f))
                isClickable = true
                isFocusable = true
                setOnClickListener { layer.set(null, groups, null) }
            }
            presets += v to groups
            line.addView(v, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(4f) })
        }
        panel.addView(line, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4f); bottomMargin = dp(4f) })
        SMapTraffic.groupKeys().forEach { key ->
            boxes[key] = row("group:$key", t(key), key) { on -> layer.set(null, layer.groups.filter { it != key } + (if (on) listOf(key) else emptyList()), null) }
        }
    }

    private fun row(name: String, label: String, group: String?, change: (Boolean) -> Unit): CheckBox {
        val row = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; tag = name }
        val box = CheckBox(context).apply {
            contentDescription = label
            setOnCheckedChangeListener { _, checked -> if (!updating) change(checked) }
        }
        row.addView(box, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        if (group != null) row.addView(ImageView(context).apply {
            tag = "symbol:$group"
            setImageBitmap(SMapTraffic.sign(group, SMapTraffic.SIGN_SIZE, resources.displayMetrics.density))
        }, LayoutParams(dp(SMapTraffic.SIGN_SIZE), dp(SMapTraffic.SIGN_SIZE)).apply { marginEnd = dp(7f) })
        // The switch carries the label for a screen reader.
        row.addView(text(label, 12f).apply { importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO; setOnClickListener { box.toggle() } },
            LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        panel.addView(row)
        return box
    }

    private fun text(s: String, sp: Float, bold: Boolean = false) = TextView(context).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(SMapToolStyle.TEXT)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    /** The traffic light icon: its body and three lights. */
    private class LightIcon(context: Context) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = SMapToolStyle.TEXT; style = Paint.Style.STROKE }
        private val body = RectF()

        fun tint(color: Int) {
            if (p.color == color) return
            p.color = color
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            val k = width / 24f
            p.strokeWidth = 2 * k
            body.set(8 * k, 2.5f * k, 16 * k, 21.5f * k)
            canvas.drawRoundRect(body, 3 * k, 3 * k, p)
            for (y in floatArrayOf(7f, 12f, 17f)) canvas.drawCircle(12 * k, y * k, 1.4f * k, p)
        }
    }
}
