package ca.superroute.smap

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import org.maplibre.android.geometry.LatLng
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

// The indoor layer (sIndoor P6, IK5 / IK8): a site of sIndoor drawn one level at a time. The rules that need no
// screen are here (the same answers as every SDK, shared/indoor-vectors.json); the map's part is in SMapIndoorLayers.

/** A level's place on the earth (sIndoor's geo anchor): x east and y south of it at rotation 0, in millimetres. */
data class SMapIndoorAnchor(val lat: Double, val lon: Double, val rotationDeg: Double = 0.0, val scale: Double = 1.0)

/** One level of an indoor layer as its GeoJSON lists it. */
data class SMapIndoorLevel(
    val id: String,
    val ordinal: Int,
    /** `indoor` or `outdoor`. */
    val kind: String = "indoor",
    val building: String? = null,
    val anchor: SMapIndoorAnchor = SMapIndoor.LOCAL_ANCHOR,
)

/** A layer's tie to one level of an indoor layer (the layer option `indoor`). */
data class SMapIndoorRef(val id: String, val level: String)

/** Where an indoor layer's data comes from. */
sealed class SMapIndoorSource {
    /** sIndoor's layer GeoJSON: a [JsonObject], its text, or a map of plain values. */
    data class GeoJson(val geojson: Any) : SMapIndoorSource()

    /** A URL answering the layer GeoJSON, fetched with [headers] only (never the map's key). */
    data class Url(val url: String, val headers: Map<String, String> = emptyMap()) : SMapIndoorSource()

    /** A site read from `{indoorUrl}/sites/{site}/layer` with the map's key and token. */
    data class Site(val site: String) : SMapIndoorSource()
}

/** A colour pair: the fill and the outline (CSS `#rrggbb` colours). */
data class SMapIndoorLook(val fill: String? = null, val outline: String? = null)

/** Colours over the defaults: the levels' outlines, the obstacles, and the obstacles by their `type`. */
data class SMapIndoorStyle(
    val level: SMapIndoorLook? = null,
    val obstacle: SMapIndoorLook? = null,
    val types: Map<String, SMapIndoorLook> = emptyMap(),
)

/** Whether the basemap stays while an indoor layer is shown. */
enum class SMapIndoorBasemap {
    /** Hidden while a layer in its own frame (`frame: "local"`, no place on the earth) is shown. */
    AUTO,
    /** Always kept. */
    SHOW,
    /** Hidden while this layer is on the map. */
    HIDE,
}

/**
 * How an indoor layer is drawn.
 *
 * @param level the level shown first (default the first level of ordinal 0, else the lowest)
 * @param control the level control (levels by ordinal, highest on top) in the corner [controlPosition]
 * @param onClick a tap on an obstacle (else the level's outline) of the shown level: the feature as GeoJSON and where
 */
data class SMapIndoorOptions(
    val level: String? = null,
    val control: Boolean = true,
    val controlPosition: SMapToolPosition = SMapToolPosition.TOP_RIGHT,
    val style: SMapIndoorStyle? = null,
    val minZoom: Double? = null,
    val basemap: SMapIndoorBasemap = SMapIndoorBasemap.AUTO,
    val onClick: ((feature: JsonObject, position: LatLng) -> Unit)? = null,
)

/** The look of an indoor layer after the defaults: every colour set. */
data class SMapIndoorResolvedStyle(
    val level: Pair<String, String>,
    val obstacle: Pair<String, String>,
    val types: LinkedHashMap<String, Pair<String, String>>,
)

/** An indoor layer's GeoJSON, read. */
class SMapIndoorLayer internal constructor(val geojson: JsonObject, val frame: String, val site: String?, val levels: List<SMapIndoorLevel>)

/** A public site in view (`{indoorUrl}/public-sites?bbox=`). */
data class SMapIndoorPublicSite(val site: String, val name: String? = null, val bbox: List<Double>, val levels: Int? = null)

/** The indoor layer's rules that need no map (the same numbers as sIndoor). */
object SMapIndoor {
    const val DEFAULT_URL = "https://open.superroute.ca/v1/indoor"
    const val PUBLIC_MIN_ZOOM = 16.0
    const val PUBLIC_DEBOUNCE_MILLIS = 300L
    const val LEVEL_FILL = "#cbd5e1"
    const val LEVEL_OUTLINE = "#64748b"
    const val OBSTACLE_FILL = "#94a3b8"
    const val OBSTACLE_OUTLINE = "#475569"
    const val LEVEL_FILL_OPACITY = 0.35
    const val OBSTACLE_FILL_OPACITY = 0.8
    const val LEVEL_OUTLINE_WIDTH = 1.5
    const val OBSTACLE_OUTLINE_WIDTH = 1.0
    /** The colour of the shown level's button in the level control. */
    const val CONTROL_ACTIVE = "#2563eb"
    /** The types with a look of their own by default. */
    val DEFAULT_TYPES: Map<String, SMapIndoorLook> = mapOf("wall" to SMapIndoorLook("#475569", "#334155"))
    val LOCAL_ANCHOR = SMapIndoorAnchor(0.0, 0.0, 0.0, 1.0)
    /** The prefix of public sites' indoor layer ids. */
    const val PUBLIC_PREFIX = "public:"

    /** Millimetres per degree of latitude and of longitude at [lat] (sIndoor sindoor_model::outdoor::mm_per_degree). */
    fun mmPerDegree(lat: Double): Pair<Double, Double> {
        val r = Math.toRadians(lat)
        val latM = 111132.92 - 559.82 * cos(2 * r) + 1.175 * cos(4 * r)
        val lonM = 111412.84 * cos(r) - 93.5 * cos(3 * r)
        return Pair(latM * 1000, lonM * 1000)
    }

    /** A level point in millimetres → the position, through [anchor] (sIndoor level_to_geo). */
    fun levelToLatLng(anchor: SMapIndoorAnchor, x: Double, y: Double): LatLng {
        val (kLat, kLon) = mmPerDegree(anchor.lat)
        val t = Math.toRadians(anchor.rotationDeg)
        val s = sin(t)
        val c = cos(t)
        val xs = x * anchor.scale
        val ys = y * anchor.scale
        val e = xs * c - ys * s
        val south = xs * s + ys * c
        return LatLng(anchor.lat - south / kLat, anchor.lon + e / kLon)
    }

    /** A position → a level point (x, y) in millimetres, the inverse of [levelToLatLng] (sIndoor geo_to_level). */
    fun latLngToLevel(anchor: SMapIndoorAnchor, lat: Double, lng: Double): Pair<Double, Double> {
        val (kLat, kLon) = mmPerDegree(anchor.lat)
        val e = (lng - anchor.lon) * kLon
        val south = -(lat - anchor.lat) * kLat
        val t = Math.toRadians(anchor.rotationDeg)
        val s = sin(t)
        val c = cos(t)
        val x = e * c + south * s
        val y = -e * s + south * c
        val k = if (abs(anchor.scale) > 1e-12) anchor.scale else 1.0
        return Pair(x / k, y / k)
    }

    private fun num(o: JsonObject, key: String): Double? =
        o.get(key)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble

    /** An anchor as the layer GeoJSON writes it (`{lat, lon, rotation_deg, scale}`); the local anchor when absent. */
    fun anchor(e: JsonElement?): SMapIndoorAnchor {
        val o = e?.takeIf { it.isJsonObject }?.asJsonObject ?: return LOCAL_ANCHOR
        return SMapIndoorAnchor(num(o, "lat") ?: 0.0, num(o, "lon") ?: 0.0, num(o, "rotation_deg") ?: 0.0, num(o, "scale") ?: 1.0)
    }

    fun anchorJson(a: SMapIndoorAnchor): JsonObject = JsonObject().apply {
        addProperty("lat", a.lat); addProperty("lon", a.lon); addProperty("rotation_deg", a.rotationDeg); addProperty("scale", a.scale)
    }

    fun levelJson(l: SMapIndoorLevel): JsonObject = JsonObject().apply {
        addProperty("id", l.id); addProperty("ordinal", l.ordinal); addProperty("kind", l.kind)
        if (l.building == null) add("building", com.google.gson.JsonNull.INSTANCE) else addProperty("building", l.building)
        add("anchor", anchorJson(l.anchor))
    }

    /**
     * Reads sIndoor's layer GeoJSON (a [JsonObject], its text or a map of plain values).
     *
     * @throws IllegalArgumentException when it is not a FeatureCollection with levels, or a level has no id or ordinal
     */
    fun read(input: Any): SMapIndoorLayer {
        val g = when (input) {
            is JsonObject -> input.deepCopy()
            is String -> SMapJson.parseObject(input)
            else -> SMapJson.of(input).takeIf { it.isJsonObject }?.asJsonObject ?: throw IllegalArgumentException("sMap: an indoor layer is a FeatureCollection")
        }
        if (g.get("type")?.takeIf { it.isJsonPrimitive }?.asString != "FeatureCollection" || g.get("features")?.isJsonArray != true) {
            throw IllegalArgumentException("sMap: an indoor layer is a FeatureCollection")
        }
        val list = g.get("levels")?.takeIf { it.isJsonArray }?.asJsonArray
        if (list == null || list.size() == 0) throw IllegalArgumentException("sMap: an indoor layer needs its levels")
        val levels = list.map { e ->
            val l = e.takeIf { it.isJsonObject }?.asJsonObject ?: throw IllegalArgumentException("sMap: an indoor level needs an id")
            val id = l.get("id")?.takeIf { !it.isJsonNull && it.isJsonPrimitive }?.asString?.takeIf { it.isNotEmpty() }
                ?: throw IllegalArgumentException("sMap: an indoor level needs an id")
            val ordinal = num(l, "ordinal") ?: throw IllegalArgumentException("sMap: indoor level $id needs an ordinal")
            SMapIndoorLevel(id, ordinal.toInt(), l.get("kind")?.takeIf { it.isJsonPrimitive }?.asString ?: "indoor",
                l.get("building")?.takeIf { it.isJsonPrimitive }?.asString, anchor(l.get("anchor")))
        }
        val frame = g.get("frame")?.takeIf { it.isJsonPrimitive }?.asString ?: "wgs84"
        return SMapIndoorLayer(g, frame, g.get("site")?.takeIf { it.isJsonPrimitive }?.asString, levels)
    }

    /** The level shown first: the first of ordinal 0 in the list, else the one of the lowest ordinal. */
    fun defaultLevel(levels: List<SMapIndoorLevel>): String? {
        levels.firstOrNull { it.ordinal == 0 }?.let { return it.id }
        return levels.minByOrNull { it.ordinal }?.id
    }

    /** The level control's order: highest ordinal on top, levels of one ordinal in the list's order. */
    fun controlOrder(levels: List<SMapIndoorLevel>): List<String> =
        levels.withIndex().sortedWith(compareBy({ -it.value.ordinal }, { it.index })).map { it.value.id }

    /** The look after the defaults: the caller's colours over them, key by key. */
    fun styleOf(given: SMapIndoorStyle?): SMapIndoorResolvedStyle {
        fun pick(base: Pair<String, String>, over: SMapIndoorLook?) = Pair(over?.fill ?: base.first, over?.outline ?: base.second)
        val level = pick(Pair(LEVEL_FILL, LEVEL_OUTLINE), given?.level)
        val obstacle = pick(Pair(OBSTACLE_FILL, OBSTACLE_OUTLINE), given?.obstacle)
        val types = LinkedHashMap<String, Pair<String, String>>()
        val names = LinkedHashSet<String>().apply { addAll(DEFAULT_TYPES.keys); addAll(given?.types?.keys ?: emptySet()) }
        for (t in names) types[t] = pick(pick(obstacle, DEFAULT_TYPES[t]), given?.types?.get(t))
        return SMapIndoorResolvedStyle(level, obstacle, types)
    }

    private fun trim(url: String?) = (url ?: DEFAULT_URL).trimEnd('/')

    private fun encode(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20").replace("%7E", "~")

    /** `{indoorUrl}/sites/{site}/layer`. */
    fun layerUrl(indoorUrl: String?, site: String): String = trim(indoorUrl) + "/sites/" + encode(site) + "/layer"

    /** `{indoorUrl}/public-sites?bbox=w,s,e,n` (six decimals). */
    fun publicUrl(indoorUrl: String?, bbox: List<Double>): String =
        trim(indoorUrl) + "/public-sites?bbox=" + bbox.joinToString(",") { String.format(Locale.ROOT, "%.6f", it) }

    fun bboxMeets(a: List<Double>?, b: List<Double>?): Boolean =
        a != null && b != null && a.size >= 4 && b.size >= 4 && a[0] <= b[2] && a[2] >= b[0] && a[1] <= b[3] && a[3] >= b[1]

    /** Which public sites to add and to remove for a view: those of the answer meeting it, against those shown. */
    fun publicDiff(shown: List<String>, answer: List<SMapIndoorPublicSite>, bbox: List<Double>): Pair<List<String>, List<String>> {
        val want = LinkedHashSet<String>()
        for (s in answer) if (bboxMeets(s.bbox, bbox)) want += s.site
        val have = LinkedHashSet(shown)
        return Pair(want.filter { it !in have }, have.filter { it !in want })
    }

    /** The public sites of an answer of `/public-sites` (entries without a site or a box are left out). */
    fun publicSites(answer: JsonElement?): List<SMapIndoorPublicSite> {
        val a = answer?.takeIf { it.isJsonArray }?.asJsonArray ?: return emptyList()
        return a.mapNotNull { e ->
            val o = e.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
            val site = o.get("site")?.takeIf { it.isJsonPrimitive }?.asString ?: return@mapNotNull null
            val box = o.get("bbox")?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { v -> v.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble }
                ?: return@mapNotNull null
            SMapIndoorPublicSite(site, o.get("name")?.takeIf { it.isJsonPrimitive }?.asString, box, o.get("levels")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asInt)
        }
    }

    /** The filter of one part (`level` or `obstacle`) on the shown level (nothing while none is). */
    fun filter(kind: String, level: String?): JsonArray =
        SMapJson.arr("all", SMapJson.arr("==", SMapJson.arr("get", "layer"), kind), SMapJson.arr("==", SMapJson.arr("to-string", SMapJson.arr("get", "level")), level ?: ""))

    /** An obstacle's colour by its `type` (fill or outline), else the obstacles' own. */
    fun typeColor(style: SMapIndoorResolvedStyle, outline: Boolean): JsonElement {
        val base = if (outline) style.obstacle.second else style.obstacle.first
        if (style.types.isEmpty()) return SMapJson.of(base)
        val expr = SMapJson.arr("match", SMapJson.arr("to-string", SMapJson.arr("coalesce", SMapJson.arr("get", "type"), "")))
        for ((t, c) in style.types) { expr.add(t); expr.add(if (outline) c.second else c.first) }
        expr.add(base)
        return expr
    }

    /** The four style layers of an indoor layer: level fill and outline, obstacle fill and outline. */
    fun styleLayers(id: String, style: SMapIndoorResolvedStyle, level: String?, minZoom: Double?): List<JsonObject> {
        val src = sourceId(id)
        fun layer(part: String, type: String, kind: String, paint: JsonObject) = JsonObject().apply {
            addProperty("id", "$src-$part"); addProperty("type", type); addProperty("source", src)
            add("filter", filter(kind, level)); add("paint", paint)
            minZoom?.let { addProperty("minzoom", it) }
        }
        return listOf(
            layer("level-fill", "fill", "level", SMapJson.obj("fill-color" to style.level.first, "fill-opacity" to LEVEL_FILL_OPACITY)),
            layer("level-line", "line", "level", SMapJson.obj("line-color" to style.level.second, "line-width" to LEVEL_OUTLINE_WIDTH)),
            layer("obstacle-fill", "fill", "obstacle", JsonObject().apply { add("fill-color", typeColor(style, false)); addProperty("fill-opacity", OBSTACLE_FILL_OPACITY) }),
            layer("obstacle-line", "line", "obstacle", JsonObject().apply { add("line-color", typeColor(style, true)); addProperty("line-width", OBSTACLE_OUTLINE_WIDTH) }),
        )
    }

    /** The engine source of an indoor layer. */
    fun sourceId(id: String) = "smap-indoor-$id"

    /** The engine layers of an indoor layer, in draw order. */
    fun layerIds(id: String): List<String> = listOf("level-fill", "level-line", "obstacle-fill", "obstacle-line").map { "${sourceId(id)}-$it" }

    /** Whether an indoor layer hides the basemap while it is on the map. */
    fun hidesBasemap(frame: String, basemap: SMapIndoorBasemap): Boolean =
        basemap == SMapIndoorBasemap.HIDE || (basemap == SMapIndoorBasemap.AUTO && frame == "local")

    /** The [SMapToolPosition] of a corner name (`top-left`, `top-right`, `bottom-left`, `bottom-right`). */
    fun position(name: String?): SMapToolPosition = when (name) {
        null, "top-right" -> SMapToolPosition.TOP_RIGHT
        "top-left" -> SMapToolPosition.TOP_LEFT
        "bottom-left" -> SMapToolPosition.BOTTOM_LEFT
        "bottom-right" -> SMapToolPosition.BOTTOM_RIGHT
        else -> throw IllegalArgumentException("sMap: unknown control position \"$name\"")
    }

    // ---- the call protocol of the Flutter and React Native SDKs (JSON in, JSON out)

    /** A source as JSON: `{"geojson": …}`, `{"url", "headers"}` or `{"site"}`. */
    fun sourceOf(o: JsonObject): SMapIndoorSource {
        o.get("geojson")?.takeIf { !it.isJsonNull }?.let { g -> return SMapIndoorSource.GeoJson(if (g.isJsonPrimitive) g.asString else g) }
        o.get("url")?.takeIf { it.isJsonPrimitive }?.asString?.takeIf { it.isNotEmpty() }?.let { url ->
            val h = o.get("headers")?.takeIf { it.isJsonObject }?.asJsonObject
            return SMapIndoorSource.Url(url, h?.entrySet()?.associate { it.key to it.value.asString } ?: emptyMap())
        }
        o.get("site")?.takeIf { it.isJsonPrimitive }?.asString?.takeIf { it.isNotEmpty() }?.let { return SMapIndoorSource.Site(it) }
        throw IllegalArgumentException("sMap: addIndoor needs {geojson}, {url} or {site}")
    }

    private fun look(e: JsonElement?): SMapIndoorLook? = e?.takeIf { it.isJsonObject }?.asJsonObject?.let {
        SMapIndoorLook(it.get("fill")?.takeIf { v -> v.isJsonPrimitive }?.asString, it.get("outline")?.takeIf { v -> v.isJsonPrimitive }?.asString)
    }

    /** A style as JSON: `{"level": {fill, outline}, "obstacle": {…}, "types": {type: {…}}}`. */
    fun styleOf(o: JsonObject?): SMapIndoorStyle? = o?.let {
        SMapIndoorStyle(look(it.get("level")), look(it.get("obstacle")),
            it.get("types")?.takeIf { t -> t.isJsonObject }?.asJsonObject?.entrySet()?.mapNotNull { (k, v) -> look(v)?.let { l -> k to l } }?.toMap() ?: emptyMap())
    }

    /** Options as JSON (`level`, `control` true / false / {position}, `style`, `minzoom`, `basemap` "auto" / true / false). */
    fun optionsOf(o: JsonObject?, onClick: ((JsonObject, LatLng) -> Unit)? = null): SMapIndoorOptions {
        val j = o ?: JsonObject()
        val control = j.get("control")
        val basemap = j.get("basemap")
        return SMapIndoorOptions(
            level = j.get("level")?.takeIf { it.isJsonPrimitive }?.asString,
            control = control == null || control.isJsonNull || control.isJsonObject || (control.isJsonPrimitive && control.asJsonPrimitive.isBoolean && control.asBoolean),
            controlPosition = position(control?.takeIf { it.isJsonObject }?.asJsonObject?.get("position")?.takeIf { it.isJsonPrimitive }?.asString),
            style = styleOf(j.get("style")?.takeIf { it.isJsonObject }?.asJsonObject),
            minZoom = num(j, "minzoom") ?: num(j, "minZoom"),
            basemap = when {
                basemap == null || basemap.isJsonNull -> SMapIndoorBasemap.AUTO
                basemap.isJsonPrimitive && basemap.asJsonPrimitive.isBoolean -> if (basemap.asBoolean) SMapIndoorBasemap.SHOW else SMapIndoorBasemap.HIDE
                basemap.isJsonPrimitive && basemap.asString == "auto" -> SMapIndoorBasemap.AUTO
                else -> throw IllegalArgumentException("sMap: indoor basemap is \"auto\", true or false")
            },
            onClick = onClick,
        )
    }

    /** A layer option `indoor` as JSON (`{"id", "level"}`), or null. */
    fun refOf(e: JsonElement?): SMapIndoorRef? {
        val o = e?.takeIf { it.isJsonObject }?.asJsonObject ?: return null
        val id = o.get("id")?.takeIf { it.isJsonPrimitive }?.asString
        val level = o.get("level")?.takeIf { it.isJsonPrimitive }?.asString
        if (id == null || level == null) throw IllegalArgumentException("sMap: the layer option indoor is {id, level}")
        return SMapIndoorRef(id, level)
    }
}
