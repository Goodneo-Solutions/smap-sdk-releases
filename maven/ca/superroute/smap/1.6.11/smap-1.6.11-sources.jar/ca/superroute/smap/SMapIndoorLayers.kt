package ca.superroute.smap

import android.content.Context
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import org.maplibre.android.geometry.LatLng

/** The indoor layers of one map (addIndoor): their data, shown level, level control and taps. */
internal class SMapIndoorLayers(private val map: SMap) {

    class State(val id: String, val source: SMapIndoorSource, val options: SMapIndoorOptions, val isPublic: Boolean) {
        var layer: SMapIndoorLayer? = null
        var level: String? = null
        var want: String? = options.level
        val style = SMapIndoor.styleOf(options.style)
        var control: SMapIndoorControl? = null
        var click: ((SMapEvent) -> Unit)? = null
    }

    val states = LinkedHashMap<String, State>()
    /** The engine source and layer ids of every indoor layer (left out of layers(), sources() and toJSON()). */
    val internal = HashSet<String>()
    private val handler = Handler(Looper.getMainLooper())
    private var publicSeq = 0
    private var publicStarted = false

    fun state(id: String): State = states[id] ?: throw IllegalArgumentException("sMap: no indoor layer $id")

    fun level(st: State, level: String): SMapIndoorLevel =
        st.layer?.levels?.firstOrNull { it.id == level } ?: throw IllegalArgumentException("sMap: indoor layer ${st.id} has no level $level")

    fun shows(ref: SMapIndoorRef?): Boolean {
        val st = ref?.let { states[it.id] } ?: return false
        return st.level != null && st.level == ref.level
    }

    suspend fun add(id: String, source: SMapIndoorSource, options: SMapIndoorOptions, isPublic: Boolean = false) {
        if (id.isEmpty()) throw IllegalArgumentException("sMap: addIndoor needs an id")
        if (options.controlPosition == SMapToolPosition.NONE || options.controlPosition == SMapToolPosition.TOOLBAR) {
            throw IllegalArgumentException("sMap: the level control sits in a corner")
        }
        if (states.containsKey(id)) remove(id)
        val st = State(id, source, options, isPublic)
        states[id] = st
        try {
            val geojson: Any = when (source) {
                is SMapIndoorSource.GeoJson -> source.geojson
                is SMapIndoorSource.Url -> fetch(source.url, source.headers)
                is SMapIndoorSource.Site -> fetch(SMapIndoor.layerUrl(map.indoorUrl, source.site), map.indoorHeaders())
            }
            if (states[id] !== st) return
            take(st, SMapIndoor.read(geojson))
        } catch (e: CancellationException) {
            if (states[id] === st) remove(id)
            throw e
        } catch (e: Exception) {
            if (states[id] === st) remove(id)
            throw e
        }
    }

    private suspend fun fetch(url: String, headers: Map<String, String>): JsonObject {
        val res = map.indoorHttp.get(url, headers, FETCH_TIMEOUT_MILLIS)
        if (!res.ok) throw SMapException("sMap: the indoor layer $url answered ${res.status}", url = url)
        return JsonParser.parseString(res.body).asJsonObject
    }

    private fun take(st: State, layer: SMapIndoorLayer) {
        st.layer = layer
        val want = st.want
        val known = want != null && layer.levels.any { it.id == want }
        if (want != null && !known) map.reportIndoor(SMapException("sMap: indoor layer ${st.id} has no level $want; its first level is shown"))
        st.level = if (known) want else SMapIndoor.defaultLevel(layer.levels)
        val src = SMapIndoor.sourceId(st.id)
        val source = JsonObject().apply { addProperty("type", "geojson"); add("data", layer.geojson) }
        internal += src
        internal.addAll(SMapIndoor.layerIds(st.id))
        map.addSource(src, source)
        for (l in SMapIndoor.styleLayers(st.id, st.style, st.level, st.options.minZoom)) {
            map.addStyleLayer(l, SMapStyleLayerOptions(slot = SMapSlot.TOP, zIndex = Z_INDEX))
        }
        st.options.onClick?.let { onClick ->
            val l: (SMapEvent) -> Unit = l@{ e ->
                val p = e.point ?: return@l
                val ids = SMapIndoor.layerIds(st.id)
                val r = 4 * map.resources.displayMetrics.density
                val hits = map.engineFeatures(RectF(p.x - r, p.y - r, p.x + r, p.y + r), listOf(ids[2], ids[0]))
                val f = hits.firstOrNull { it.getStringProperty("layer") == "obstacle" } ?: hits.firstOrNull() ?: return@l
                val json = JsonParser.parseString(f.toJson()).asJsonObject
                json.remove("id")
                onClick(json, e.position ?: map.unproject(p) ?: LatLng(0.0, 0.0))
            }
            st.click = l
            map.on(SMapEventType.CLICK, l)
        }
        if (st.options.control) {
            val c = SMapIndoorControl(map.context) { lid -> if (states[st.id] === st) map.setIndoorLevel(st.id, lid) }
            st.control = c
            c.render(SMapIndoor.controlOrder(layer.levels), st.level)
            map.addControl(c, st.options.controlPosition)
        }
        basemap()
        map.refreshIndoorLayers(st.id)
    }

    fun setLevel(id: String, level: String) {
        val st = state(id)
        val layer = st.layer
        if (layer == null) { st.want = level; return }
        level(st, level)
        if (st.level == level) return
        st.level = level
        filters(st)
        st.control?.render(SMapIndoor.controlOrder(layer.levels), level)
        map.refreshIndoorLayers(id)
        map.fireIndoor(SMapEvent(SMapEventType.INDOOR_LEVEL_CHANGE.webName, indoorId = id, level = level))
    }

    private fun filters(st: State) {
        SMapIndoor.layerIds(st.id).forEachIndexed { i, lid -> map.setFilter(lid, SMapIndoor.filter(if (i < 2) "level" else "obstacle", st.level)) }
    }

    fun remove(id: String) {
        val st = states.remove(id) ?: return
        st.click?.let { map.off(SMapEventType.CLICK, it) }
        st.control?.let { map.removeControl(it) }
        val src = SMapIndoor.sourceId(id)
        if (st.layer != null) map.removeSource(src)
        internal -= src
        SMapIndoor.layerIds(id).forEach { internal -= it }
        basemap()
        map.refreshIndoorLayers(id)
    }

    /** Whether any indoor layer on the map asks for the basemap to be hidden now. */
    fun hidesBasemap(): Boolean = states.values.any { s -> s.layer?.let { SMapIndoor.hidesBasemap(it.frame, s.options.basemap) } == true }

    private fun basemap() = map.setIndoorBasemapHidden(hidesBasemap())

    // ---- public sites (map option indoor = "public")

    fun startPublic() {
        if (publicStarted) return
        publicStarted = true
        map.on(SMapEventType.MOVE_END) {
            handler.removeCallbacksAndMessages(PUBLIC_TOKEN)
            handler.postAtTime({ runPublic() }, PUBLIC_TOKEN, android.os.SystemClock.uptimeMillis() + SMapIndoor.PUBLIC_DEBOUNCE_MILLIS)
        }
        runPublic()
    }

    fun runPublic() {
        val seq = ++publicSeq
        val shown = states.values.filter { it.isPublic }.map { it.id }
        if (map.getZoom() < SMapIndoor.PUBLIC_MIN_ZOOM) { shown.forEach { remove(it) }; return }
        val b = map.getBounds() ?: return
        val bbox = listOf(b.longitudeWest, b.latitudeSouth, b.longitudeEast, b.latitudeNorth)
        val own = states.values.filter { !it.isPublic }.mapNotNull { (it.source as? SMapIndoorSource.Site)?.site }.toSet()
        map.scope.launch {
            try {
                val res = map.indoorHttp.get(SMapIndoor.publicUrl(map.indoorUrl, bbox), map.indoorHeaders(), FETCH_TIMEOUT_MILLIS)
                if (seq != publicSeq || !res.ok) return@launch
                val sites = SMapIndoor.publicSites(JsonParser.parseString(res.body)).filter { it.site !in own }
                val now = states.values.filter { it.isPublic }.map { it.id.removePrefix(SMapIndoor.PUBLIC_PREFIX) }
                val (add, gone) = SMapIndoor.publicDiff(now, sites, bbox)
                gone.forEach { remove(SMapIndoor.PUBLIC_PREFIX + it) }
                for (site in add) {
                    map.scope.launch {
                        // A site that cannot be read is left out.
                        try { add(SMapIndoor.PUBLIC_PREFIX + site, SMapIndoorSource.Site(site), SMapIndoorOptions(), isPublic = true) } catch (e: Exception) { if (e is CancellationException) throw e }
                    }
                }
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                // Public sites are a nicety: a failure shows none.
            }
        }
    }

    companion object {
        /** Under every layer of the caller's in the top slot, so a blue dot and a route stay above. */
        const val Z_INDEX = Int.MIN_VALUE / 2
        const val FETCH_TIMEOUT_MILLIS = 15_000L
        private val PUBLIC_TOKEN = Any()
    }
}

/** The level control: one button per level, highest on top; the shown level filled blue. */
internal class SMapIndoorControl(context: Context, private val onPick: (String) -> Unit) : LinearLayout(context) {
    private val density = resources.displayMetrics.density

    init {
        orientation = VERTICAL
        background = GradientDrawable().apply { cornerRadius = 8 * density; setColor(Color.WHITE); setStroke((1 * density).toInt(), Color.argb(38, 15, 23, 42)) }
        elevation = 2 * density
        clipToOutline = true
    }

    /** The levels in control order and the one shown. */
    var levels: List<String> = emptyList()
        private set
    var shown: String? = null
        private set

    fun render(order: List<String>, level: String?) {
        levels = order
        shown = level
        removeAllViews()
        for (id in order) {
            val active = id == level
            addView(TextView(context).apply {
                text = id
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f)
                typeface = Typeface.DEFAULT_BOLD
                minWidth = (36 * density).toInt()
                minHeight = (32 * density).toInt()
                setPadding((8 * density).toInt(), 0, (8 * density).toInt(), 0)
                setTextColor(if (active) Color.WHITE else Color.parseColor("#1e293b"))
                setBackgroundColor(if (active) Color.parseColor(SMapIndoor.CONTROL_ACTIVE) else Color.TRANSPARENT)
                isSelected = active
                contentDescription = id
                setOnClickListener { onPick(id) }
            }, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        }
    }
}
