package ca.superroute.smap

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.Paint
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.JsonPrimitive

/**
 * How the road attributes layer starts (MOBILE-SDK-SPEC "Road attributes"; Superroute MAP-SDK-DESIGN M86–M100).
 *
 * @param groups the categories shown first (null: General); unknown ones are dropped
 * @param detail `standard`, or `full`: every road at every zoom (the tile URLs carry `?detail=full`)
 * @param position the corner of its button
 * @param control false: no button (change the layer with [SMap.setRoadAttributes])
 * @param enabled false ([OFF]): no button, no layer, no request
 * @param info false: a tap on a road opens no card (M110); [SMap.onRoadAttributeClick] is told either way
 */
data class SMapRoadAttributesOptions(
    val groups: List<String>? = null,
    val detail: String = SMapRoadAttributes.STANDARD,
    val position: SMapToolPosition = SMapToolPosition.TOP_RIGHT,
    val control: Boolean = true,
    val enabled: Boolean = true,
    val info: Boolean = true,
) {
    companion object {
        /** The map without the road attributes layer (the Web SDK's `roadAttributes: false`). */
        val OFF = SMapRoadAttributesOptions(enabled = false)
    }
}

/** The road attributes layer now: [available] is null until sMap answered, then whether it serves the layer here. */
data class SMapRoadAttributesState(
    val available: Boolean?,
    val groups: List<String>,
    val detail: String,
    val open: Boolean,
    /** A forced tile came at reduced detail (`X-Road-Attributes-Detail: reduced`). */
    val reduced: Boolean,
)

/** Told after every change of the road attributes layer (the SDK stores nothing). */
data class SMapRoadAttributesChange(val groups: List<String>, val detail: String, val open: Boolean)

/**
 * What the map learnt from the tiles it drew, for wrappers that draw the panel themselves (Flutter, React Native):
 * whether a forced tile came at reduced detail and the routing speed legend's unit (`km/h` or `mph`, by the country of
 * the roads in view, M100). Not a change of the layer.
 */
data class SMapRoadAttributesInfo(val reduced: Boolean, val speedUnit: String)

/** One fact of a road (M110): its label and, unless the label says it all, its value ("" then). */
data class SMapRoadAttributeFact(val id: String, val label: String, val value: String)

/**
 * A tap on a road of the road attributes layer (M110): where ([lngLat], [point] in the map view's pixels), the card's [title]
 * and [rows] in the map's language and units (M100), and the tile features' properties read — the road (its line or
 * label point), the junction and the routing speed line — null for one not read.
 */
data class SMapRoadAttributeClick(
    val lngLat: org.maplibre.android.geometry.LatLng?,
    val point: Pair<Float, Float>,
    val title: String,
    val rows: List<SMapRoadAttributeFact>,
    val road: Map<String, Any?>?,
    val turn: Map<String, Any?>?,
    val speeds: Map<String, Any?>?,
)

/** A tile feature a tap hit: its tile layer, feature id and properties. */
data class SMapRoadAttributeHit(val sourceLayer: String?, val id: String?, val properties: JsonObject)

/** The features a tap read ([SMapRoadAttributes.pick]); null for one not read. */
data class SMapRoadAttributesPicked(val road: SMapRoadAttributeHit?, val turn: SMapRoadAttributeHit?, val speeds: SMapRoadAttributeHit?)

/** A category's symbol as the map draws it (M111): parts in a box of [width] x [height] logical pixels. */
data class SMapRoadAttributesLegend(val width: Float, val height: Float, val parts: List<JsonObject>, val kinds: List<Pair<String, String>>?)

/**
 * The road attributes layer's rules that need no map: everything comes from the SDK's copy of
 * shared/road-attributes.json (`road-attributes.json`, written by tools/road-attributes.mjs), the only place tile
 * property names, categories, presets, colours, images, layers and texts are written.
 */
object SMapRoadAttributes {
    const val STANDARD = "standard"
    const val FULL = "full"
    const val LAYER_PREFIX = "smap-ra-"

    /** The contract as the SDK carries it. */
    val spec: JsonObject by lazy {
        val stream = SMapRoadAttributes::class.java.getResourceAsStream("road-attributes.json")
            ?: throw IllegalStateException("sMap: road-attributes.json is missing from the library")
        stream.reader(Charsets.UTF_8).use { JsonParser.parseReader(it).asJsonObject }
    }

    val toolId: String get() = spec["toolId"].asString
    val attributesSource: String get() = spec.getAsJsonObject("sources")["attributes"].asString
    val speedsSource: String get() = spec.getAsJsonObject("sources")["speeds"].asString
    val reducedHeader: String get() = spec.getAsJsonObject("services")["reducedHeader"].asString
    val reducedValue: String get() = spec.getAsJsonObject("services")["reducedValue"].asString
    private val groupList: JsonArray get() = spec.getAsJsonArray("groups")

    /** The ten categories in the panel's order. */
    fun groupKeys(): List<String> = groupList.map { it.asJsonObject["key"].asString }

    /** The categories of [list] that exist, once each, in the panel's order. */
    fun groups(list: List<String>?): List<String> {
        val want = (list ?: emptyList()).toSet()
        return groupKeys().filter { it in want }
    }

    fun defaultGroups(): List<String> = spec.getAsJsonArray("defaultGroups").map { it.asString }

    /** The presets in order: key → its categories. */
    fun presets(): List<Pair<String, List<String>>> =
        spec.getAsJsonArray("presets").map { p -> p.asJsonObject["key"].asString to p.asJsonObject.getAsJsonArray("groups").map { it.asString } }

    /** The start: null when the layer is off, else (groups, detail). */
    fun start(options: SMapRoadAttributesOptions?): Pair<List<String>, String>? {
        if (options == null || !options.enabled) return null
        return (options.groups?.let { groups(it) } ?: defaultGroups()) to detail(options.detail)
    }

    fun detail(value: String?): String = if (value == FULL) FULL else STANDARD

    /** The preset whose categories are exactly [groups], or null. */
    fun presetOf(groups: List<String>): String? {
        val key = groups(groups)
        return presets().firstOrNull { it.second == key }?.first
    }

    /** Whether [groups] need the road speeds tile set. */
    fun needsSpeeds(groups: List<String>): Boolean {
        val on = groups.toSet()
        return groupList.any { g -> g.asJsonObject["key"].asString in on && g.asJsonObject["source"]?.asString == "speeds" }
    }

    /** The spec's language for a BCP-47 tag: one of the 14, English when none fits. */
    fun language(tag: String?): String {
        val t = (tag ?: "en").lowercase().replace('_', '-')
        if (Regex("^zh-(hant|tw|hk|mo)").containsMatchIn(t)) return "zh-Hant"
        if (t.startsWith("zh")) return "zh-Hans"
        val base = t.split('-')[0]
        return if (spec.getAsJsonObject("texts").has(base)) base else "en"
    }

    fun texts(tag: String?): JsonObject = spec.getAsJsonObject("texts").getAsJsonObject(language(tag))
    fun text(tag: String?, key: String): String = texts(tag)[key]?.asString ?: spec.getAsJsonObject("texts").getAsJsonObject("en")[key].asString

    /** The layers in drawing order: `@text:<key>` replaced by the language's text, `text-font` by [font] when given. */
    fun layers(tag: String?, font: JsonArray? = null): List<JsonObject> {
        val tx = texts(tag)
        fun walk(e: JsonElement): JsonElement = when {
            e.isJsonPrimitive && e.asJsonPrimitive.isString && e.asString.startsWith("@text:") ->
                JsonPrimitive(tx[e.asString.substring(6)]?.asString ?: "")
            e.isJsonArray -> JsonArray().also { out -> e.asJsonArray.forEach { out.add(walk(it)) } }
            e.isJsonObject -> JsonObject().also { out -> e.asJsonObject.entrySet().forEach { (k, v) -> out.add(k, walk(v)) } }
            else -> e
        }
        return spec.getAsJsonArray("layers").map { l ->
            val out = walk(l).asJsonObject
            val layout = out.getAsJsonObject("layout")
            if (font != null && font.size() > 0 && layout != null && layout.has("text-font")) layout.add("text-font", font.deepCopy())
            out
        }
    }

    /**
     * layer id → shown, for the categories [groups]. [labelsSeen]: the tiles have shown a `road_attribute_labels`
     * point (sPath RA8), so the labels drawn along the lines in its place (`labels.fallback`) are hidden.
     */
    fun visibility(groups: List<String>, labelsSeen: Boolean = false): Map<String, Boolean> {
        val on = groups.toSet()
        val hidden = if (labelsSeen) labelFallback().toSet() else emptySet()
        val out = LinkedHashMap<String, Boolean>()
        groupList.forEach { g -> val o = g.asJsonObject; o.getAsJsonArray("layers").forEach { out[it.asString] = o["key"].asString in on && it.asString !in hidden } }
        return out
    }

    /** The layers drawn along the lines while the server has not shown `road_attribute_labels`. */
    fun labelFallback(): List<String> = spec.getAsJsonObject("labels").getAsJsonArray("fallback").map { it.asString }

    /** The tile layer of the labels (`road_attribute_labels`). */
    val labelsSourceLayer: String get() = spec.getAsJsonObject("labels")["sourceLayer"].asString

    /** The layers drawn from `road_attribute_labels` (their features tell the SDK that the server writes it). */
    fun labelLayers(): List<String> {
        val layer = spec.getAsJsonObject("labels")["sourceLayer"].asString
        return spec.getAsJsonArray("layers").map { it.asJsonObject }.filter { it["source-layer"]?.asString == layer }.map { it["id"].asString }
    }

    /** The country most of these features' properties carry (`props.country`), or null when none has one. */
    fun countryOf(properties: List<JsonObject?>): String? {
        val key = spec.getAsJsonObject("props")["country"].asString
        val n = HashMap<String, Int>()
        var best: String? = null
        for (p in properties) {
            val c = p?.get(key)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString?.takeIf { it.isNotEmpty() } ?: continue
            n[c] = (n[c] ?: 0) + 1
            if (best == null || n[c]!! > n[best]!!) best = c
        }
        return best
    }

    /** The routing speed legend's unit by the road's country, as its signs show speeds (M100): `mph` or `km/h`. */
    fun speedUnit(country: String?): String =
        if (spec.getAsJsonObject("units").getAsJsonArray("mph").any { it.asString == country?.uppercase() }) "mph" else "km/h"

    /** The routing speed legend in a unit: its title's text key and the bins (lower bound in that unit, colour). */
    fun legend(unit: String): Pair<String, List<Pair<Int, String>>> {
        val bins = spec.getAsJsonArray(if (unit == "mph") "speedBinsMph" else "speedBins").map { it.asJsonArray[0].asInt to it.asJsonArray[1].asString }
        return (if (unit == "mph") "speedLegendMph" else "speedLegend") to bins
    }

    /** The chips' texts of the bins: `a–b`, the last `a+`. */
    fun chips(bins: List<Pair<Int, String>>): List<String> =
        bins.mapIndexed { i, b -> if (i + 1 < bins.size) "${b.first}–${bins[i + 1].first}" else "${b.first}+" }

    /** The TileJSON address of a set (`attributes` | `speeds`), with the token and key as the style URL carries them. */
    fun tileJsonUrl(node: String, set: String, token: String? = null, apiKey: String? = null): String {
        val path = spec.getAsJsonObject("services")[if (set == "speeds") "speeds" else "attributes"].asString
        val q = ArrayList<String>()
        if (!token.isNullOrEmpty()) q += "token=" + SMapStyleUrl.encode(token)
        if (!apiKey.isNullOrEmpty()) q += "key=" + SMapStyleUrl.encode(apiKey)
        return node.trimEnd('/') + path + (if (q.isEmpty()) "" else "?" + q.joinToString("&"))
    }

    /** The tile URLs of a TileJSON answer, null without the service; `detail=full` added while [detail] is full. */
    fun tiles(tilejson: JsonObject?, detail: String = STANDARD): List<String>? {
        if (tilejson == null) return null
        if (tilejson["available"]?.let { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean && !it.asBoolean } == true) return null
        val list = tilejson.getAsJsonArray("tiles")?.mapNotNull { if (it.isJsonPrimitive) it.asString else null } ?: return null
        if (list.isEmpty()) return null
        val q = spec.getAsJsonObject("services")["detailQuery"].asString
        return list.map { u -> if (detail != FULL || Regex("[?&]detail=full\\b").containsMatchIn(u)) u else u + (if ('?' in u) "&" else "?") + q }
    }

    /** The TileJSON answer as JSON, or null for anything else (a refusal's body, text that is not JSON). */
    fun parseTileJson(status: Int, body: String): JsonObject? {
        if (status !in 200..299) return null
        return try { JsonParser.parseString(body).takeIf { it.isJsonObject }?.asJsonObject } catch (e: Exception) { null }
    }

    /**
     * The layer a road attributes layer goes under: the next road attributes layer already in [styleIds] after it in
     * the spec's order, else the first layer that is neither the basemap's nor a road attributes layer (the caller's
     * first); null = on top.
     */
    fun beforeId(layerId: String, styleIds: List<String>, basemapIds: Set<String>): String? {
        val order = spec.getAsJsonArray("layers").map { it.asJsonObject["id"].asString }
        val present = styleIds.toSet()
        val at = order.indexOf(layerId)
        for (i in at + 1 until order.size) if (order[i] in present) return order[i]
        return styleIds.firstOrNull { it !in basemapIds && !it.startsWith(LAYER_PREFIX) }
    }

    // ------------------------------------------------------------------ the road card (M110), as smap-interop.js

    val infoTolerance: Float get() = spec.getAsJsonObject("info")["tolerance"].asFloat

    /** The tile layer each layer of the contract draws from (MapLibre does not tell a hit feature's layer). */
    fun sourceLayerOf(): Map<String, String> =
        spec.getAsJsonArray("layers").associate { it.asJsonObject["id"].asString to it.asJsonObject["source-layer"].asString }

    /**
     * The features a tap read from the features hit (top first): the top road line, else the top label point; the top
     * junction; the routing speed line of the road's id, else the top one when the road has no id or none was read.
     * Null when nothing was read.
     */
    fun pick(hits: List<SMapRoadAttributeHit>): SMapRoadAttributesPicked? {
        val sl = spec.getAsJsonObject("sourceLayers")
        val roads = ArrayList<SMapRoadAttributeHit>()
        var label: SMapRoadAttributeHit? = null
        var turn: SMapRoadAttributeHit? = null
        val speeds = ArrayList<SMapRoadAttributeHit>()
        for (h in hits) {
            when (h.sourceLayer) {
                sl["attributes"].asString -> roads += h
                sl["labels"].asString -> if (label == null) label = h
                sl["turns"].asString -> if (turn == null) turn = h
                sl["speeds"].asString -> speeds += h
            }
        }
        // A sign tapped is its own road's: the line with the sign's id, else the sign; without an id the top line.
        val sign = label
        val r = (if (sign?.id != null) roads.firstOrNull { it.id == sign.id } ?: sign else null) ?: roads.firstOrNull() ?: sign
        var sp: SMapRoadAttributeHit? = null
        if (speeds.isNotEmpty()) {
            if (r?.id != null) sp = speeds.firstOrNull { it.id == r.id }
            if (sp == null && (r == null || r.id == null)) sp = speeds[0]
        }
        if (r == null && turn == null && sp == null) return null
        return SMapRoadAttributesPicked(r, turn, sp)
    }

    private fun units(k: String) = spec.getAsJsonObject("units").getAsJsonArray(k).map { it.asString }

    // JavaScript's Math.round for the numbers the tiles carry.
    private fun jsRound(x: Double): Long = kotlin.math.floor(x + 0.5).toLong()

    /** A number as the map's labels write it: one decimal at most, '.' as the separator ("4", "4.1"). */
    fun number(x: Double): String {
        val tenths = jsRound(x * 10)
        return if (tenths % 10 == 0L) (tenths / 10).toString() else String.format(java.util.Locale.ROOT, "%.1f", tenths / 10.0)
    }

    /** A length in metres as the signs of the country show it (M100): feet and inches (metres beside), or metres. */
    fun formatLength(metres: Double, country: String?): String {
        val c = country?.uppercase() ?: ""
        if (c !in units("feetInches")) return number(metres) + " m"
        val inches = jsRound(metres / 0.0254)
        val fi = "${inches / 12}'${inches % 12}\""
        return if (c in units("metresBeside")) fi + " (" + number(metres) + " m)" else fi
    }

    /** A weight in tonnes: short tons in the United States, else tonnes. */
    fun formatWeight(tonnes: Double, country: String?): String =
        if ((country?.uppercase() ?: "") in units("shortTons")) number(tonnes * 1.102311) + " tn" else number(tonnes) + " t"

    /** A speed in km/h: mph where the signs are in mph, else km/h, whole. */
    fun formatSpeed(kph: Double, country: String?): String =
        if ((country?.uppercase() ?: "") in units("mph")) jsRound(kph / 1.609344).toString() + " mph" else jsRound(kph).toString() + " km/h"

    private fun numberOf(e: JsonElement?): Double? {
        if (e == null || !e.isJsonPrimitive) return null
        val p = e.asJsonPrimitive
        return when {
            p.isNumber -> p.asDouble
            p.isString -> p.asString.takeIf { it.isNotEmpty() }?.toDoubleOrNull()
            else -> null
        }?.takeIf { it.isFinite() }
    }

    private fun stringOf(e: JsonElement): String = if (e.isJsonPrimitive) e.asJsonPrimitive.let { p ->
        if (p.isNumber) { val d = p.asDouble; if (d == kotlin.math.floor(d) && kotlin.math.abs(d) < 1e15) d.toLong().toString() else d.toString() } else p.asString
    } else e.toString()

    /** One fact of the card (a row of `info.facts`) for a feature's properties, or null. */
    private fun fact(f: JsonObject, p: JsonObject?, tx: (String) -> String): SMapRoadAttributeFact? {
        if (p == null) return null
        val prop = f["prop"].asString
        val v = p[prop]?.takeIf { !it.isJsonNull } ?: return null
        f["unless"]?.asString?.let { u -> if (p[u] != null && !p[u].isJsonNull) return null }
        val id = f["id"].asString
        val text = f["text"]?.takeIf { !it.isJsonNull }?.asString
        val country = p[spec.getAsJsonObject("props")["country"].asString]?.takeIf { it.isJsonPrimitive }?.asString
        fun row(label: String, value: String) = SMapRoadAttributeFact(id, label, value)
        return when (f["kind"].asString) {
            "flag" -> {
                val eq = f["eq"]
                val on = if (eq == null || (eq.isJsonPrimitive && eq.asJsonPrimitive.isBoolean && eq.asBoolean)) {
                    val q = v.asJsonPrimitive
                    (q.isBoolean && q.asBoolean) || (q.isNumber && q.asDouble == 1.0) || (q.isString && q.asString == "true")
                } else v.isJsonPrimitive && stringOf(v) == stringOf(eq)
                if (on) row(tx(text!!), "") else null
            }
            "enum" -> {
                val key = f.getAsJsonObject("values")[stringOf(v)]?.asString ?: return null
                if (text != null) row(tx(text), tx(key)) else row(tx(key), "")
            }
            "list" -> {
                val values = f.getAsJsonObject("values")
                val keys = stringOf(v).split(';').mapNotNull { values[it.trim()]?.asString }.distinct()
                if (keys.isEmpty()) null else row(tx(text!!), keys.joinToString(", ") { tx(it) })
            }
            "length" -> numberOf(v)?.let { row(tx(text!!), formatLength(it, country)) }
            "weight" -> numberOf(v)?.let { row(tx(text!!), formatWeight(it, country)) }
            "speed" -> {
                val n = numberOf(v) ?: return null
                val none = f.getAsJsonArray("none")
                if (none != null && none[0].asDouble == n) row(tx(text!!), tx(none[1].asString)) else row(tx(text!!), formatSpeed(n, country))
            }
            "count" -> numberOf(v)?.let { row(tx(text!!), jsRound(it).toString()) }
            "bits" -> {
                val n = numberOf(v)?.toLong() ?: return null
                val names = f.getAsJsonArray("values").filter { n and it.asJsonArray[0].asLong != 0L }.map { tx(it.asJsonArray[1].asString) }
                if (names.isEmpty()) null else row(tx(text!!), names.joinToString(", "))
            }
            "conditional" -> {
                val list = try {
                    (if (v.isJsonPrimitive) JsonParser.parseString(v.asString) else v).takeIf { it.isJsonArray }?.asJsonArray
                } catch (e: Exception) { null } ?: return null
                val out = list.mapNotNull { c ->
                    val o = c.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
                    val kph = numberOf(o["speed_kph"]) ?: return@mapNotNull null
                    val s = formatSpeed(kph, country)
                    val w = o["when"]?.takeIf { it.isJsonPrimitive }?.asString
                    if (w.isNullOrEmpty()) s else "$s ($w)"
                }
                if (out.isEmpty()) null else row(tx(text!!), out.joinToString("; "))
            }
            else -> null
        }
    }

    /** The card of the features read, in a language: its title and rows in the order of `info.facts`. */
    fun facts(road: JsonObject?, turn: JsonObject?, speeds: JsonObject?, tag: String?): Pair<String, List<SMapRoadAttributeFact>> {
        val tx = { k: String -> text(tag, k) }
        val from = mapOf("road" to road, "turn" to turn, "speeds" to speeds)
        val rows = spec.getAsJsonObject("info").getAsJsonArray("facts").mapNotNull { fe ->
            val f = fe.asJsonObject
            fact(f, from[f["from"].asString], tx)
        }
        return tx("infoTitle") to rows
    }

    fun facts(picked: SMapRoadAttributesPicked?, tag: String?) = facts(picked?.road?.properties, picked?.turn?.properties, picked?.speeds?.properties, tag)

    /**
     * The legend of a category (M111): its symbol's parts (badge texts in the language, the ramp's `colors`) and for
     * turn restrictions the signs (image id, text); null for an unknown category.
     */
    fun legendOf(key: String, tag: String?): SMapRoadAttributesLegend? {
        val g = groupList.map { it.asJsonObject }.firstOrNull { it["key"].asString == key } ?: return null
        val lg = spec.getAsJsonObject("legend")
        val parts = (g.getAsJsonArray("legend") ?: JsonArray()).map { e ->
            val p = e.asJsonObject.deepCopy()
            p["text"]?.takeIf { it.isJsonPrimitive && it.asString.startsWith("@text:") }?.let { p.addProperty("text", text(tag, it.asString.substring(6))) }
            if (p["type"].asString == "ramp") p.add("colors", JsonArray().also { a -> spec.getAsJsonArray("speedBins").forEach { a.add(it.asJsonArray[1]) } })
            p
        }
        val kinds = if (key == "turn_restrictions") lg.getAsJsonArray("turnKinds").map { it.asJsonArray[0].asString to text(tag, it.asJsonArray[1].asString) } else null
        return SMapRoadAttributesLegend(lg["width"].asFloat, lg["height"].asFloat, parts, kinds)
    }

    /** A JSON value of the tiles as a plain Kotlin value (strings, numbers, booleans, maps, lists). */
    fun plain(e: JsonElement?): Any? = when {
        e == null || e.isJsonNull -> null
        e.isJsonPrimitive -> e.asJsonPrimitive.let { p -> when { p.isBoolean -> p.asBoolean; p.isNumber -> p.asNumber.toDouble().let { d -> if (d == kotlin.math.floor(d) && kotlin.math.abs(d) < 1e15) d.toLong() else d }; else -> p.asString } }
        e.isJsonArray -> e.asJsonArray.map { plain(it) }
        else -> e.asJsonObject.entrySet().associate { it.key to plain(it.value) }
    }

    /** The click as JSON (the Flutter and React Native views' `roadAttributeClick`). */
    fun clickJson(c: SMapRoadAttributeClick, road: JsonObject?, turn: JsonObject?, speeds: JsonObject?): JsonObject = JsonObject().apply {
        if (c.lngLat == null) add("lngLat", com.google.gson.JsonNull.INSTANCE)
        else add("lngLat", JsonArray().apply { add(c.lngLat.longitude); add(c.lngLat.latitude) })
        add("point", JsonArray().apply { add(c.point.first); add(c.point.second) })
        addProperty("title", c.title)
        add("rows", JsonArray().also { a -> c.rows.forEach { r -> a.add(JsonObject().apply { addProperty("id", r.id); addProperty("label", r.label); addProperty("value", r.value) }) } })
        add("road", road?.deepCopy() ?: com.google.gson.JsonNull.INSTANCE)
        add("turn", turn?.deepCopy() ?: com.google.gson.JsonNull.INSTANCE)
        add("speeds", speeds?.deepCopy() ?: com.google.gson.JsonNull.INSTANCE)
    }

    /** The images by id: logical width, height and shapes (shared/road-attributes.json `images`). */
    fun imageIds(): List<String> = spec.getAsJsonObject("images").keySet().toList()

    /** Draws image [id] at [scale] device pixels per logical pixel. */
    fun image(id: String, scale: Float): Bitmap = SMapSpecImages.image(spec.getAsJsonObject("images").getAsJsonObject(id), scale)

    // ------------------------------------------------------------------ the legend's pictures (M111)

    /** Draws image [id] into [c] at its top left ([x], [y]) at [scale] (stroke then fill, as [image]). */
    private fun drawImage(c: Canvas, id: String, x: Float, y: Float, scale: Float) {
        val b = image(id, scale)
        c.drawBitmap(b, x, y, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        b.recycle()
    }

    private fun imageSize(id: String): Pair<Float, Float> {
        val o = spec.getAsJsonObject("images").getAsJsonObject(id)
        return o["width"].asFloat to o["height"].asFloat
    }

    /**
     * The symbol of category [key] as the map draws it (M111), [scale] device pixels per logical pixel: the legend's
     * parts in order — the line (dash in line widths, opacity), the image centred and scaled to the box's height (the
     * speed sign's number on it), the badge (white text on its colour), the ramp of routing speed colours.
     */
    fun symbol(key: String, tag: String?, scale: Float): Bitmap {
        val lg = legendOf(key, tag) ?: legendOf("toll", tag)!!
        val box = spec.getAsJsonObject("legend")
        val w = lg.width
        val h = lg.height
        val bitmap = Bitmap.createBitmap(Math.ceil(w * scale.toDouble()).toInt(), Math.ceil(h * scale.toDouble()).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bitmap)
        val cy = h / 2 * scale
        for (p in lg.parts) {
            when (p["type"].asString) {
                "line" -> {
                    val width = p["width"].asFloat
                    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        style = Paint.Style.STROKE
                        color = Color.parseColor(p["color"].asString)
                        strokeWidth = width * scale
                        p["opacity"]?.let { alpha = (it.asFloat * 255).toInt() }
                        p.getAsJsonArray("dash")?.let { d -> pathEffect = DashPathEffect(d.map { it.asFloat * width * scale }.toFloatArray(), 0f) }
                    }
                    c.drawLine(1 * scale, cy, (w - 1) * scale, cy, paint)
                }
                "image" -> {
                    val id = p["image"].asString
                    val (iw, ih) = imageSize(id)
                    val k = minOf(1f, h / ih) * scale
                    drawImage(c, id, (w * scale - iw * k) / 2, (h * scale - ih * k) / 2, k)
                    p["text"]?.asString?.let { t ->
                        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = Color.parseColor(p["textColor"]?.asString ?: "#111111")
                            textSize = box["signTextSize"].asFloat * scale
                            typeface = Typeface.DEFAULT_BOLD
                            textAlign = Paint.Align.CENTER
                        }
                        c.drawText(t, w * scale / 2, cy - (paint.descent() + paint.ascent()) / 2, paint)
                    }
                }
                "badge" -> {
                    val size = box["badgeTextSize"].asFloat
                    val t = p["text"]?.asString ?: ""
                    val bw = minOf(w - 2, maxOf(12f, t.length * size * 0.62f + 6))
                    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor(p["color"].asString) }
                    c.drawRoundRect(RectF((w - bw) / 2 * scale, cy - size * 0.75f * scale, (w + bw) / 2 * scale, cy + size * 0.75f * scale), 2.5f * scale, 2.5f * scale, fill)
                    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = size * scale; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
                    c.drawText(t, w * scale / 2, cy - (paint.descent() + paint.ascent()) / 2, paint)
                }
                "ramp" -> {
                    val colors = p.getAsJsonArray("colors").map { it.asString }
                    val step = (w - 2) / colors.size
                    val half = p["height"].asFloat / 2
                    colors.forEachIndexed { i, col ->
                        c.drawRect((1 + i * step) * scale, cy - half * scale, (1 + (i + 1) * step + 0.2f) * scale, cy + half * scale, Paint().apply { color = Color.parseColor(col) })
                    }
                }
            }
        }
        return bitmap
    }

    /** Sign [id] alone in a square of [size] logical pixels (the turn restrictions' list). */
    fun sign(id: String, size: Float, scale: Float): Bitmap = SMapSpecImages.sign(spec.getAsJsonObject("images").getAsJsonObject(id), size, scale)

    /** The size of the turn signs listed under the turn restrictions (logical pixels). */
    const val SIGN_SIZE = 14f

    /**
     * The legend's pictures for a wrapper that draws the panel itself (React Native, `roadAttributesLegend`):
     * `{scale, symbols: {category: base64 PNG}, kinds: [{image, text, png}]}` at [scale] device pixels per logical pixel.
     */
    fun legendImagesJson(tag: String?, scale: Float): JsonObject {
        val png = SMapSpecImages::png
        return JsonObject().apply {
            addProperty("scale", scale)
            add("symbols", JsonObject().also { o -> groupKeys().forEach { k -> o.addProperty(k, png(symbol(k, tag, scale))) } })
            add("kinds", JsonArray().also { a ->
                legendOf("turn_restrictions", tag)!!.kinds!!.forEach { (id, t) ->
                    a.add(JsonObject().apply { addProperty("image", id); addProperty("text", t); addProperty("png", png(sign(id, SIGN_SIZE, scale))) })
                }
            })
        }
    }
}
