package ca.superroute.smap

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import com.google.gson.JsonObject

/**
 * Draws the images of the shared contracts (`images` of shared/road-attributes.json and shared/traffic.json): circles,
 * rects, polygons and open lines on a logical pixel grid, each shape's stroke, then its fill.
 */
internal object SMapSpecImages {
    /** Draws image [o] at [scale] device pixels per logical pixel. */
    fun image(o: JsonObject, scale: Float): Bitmap {
        val w = Math.ceil(o["width"].asDouble * scale).toInt()
        val h = Math.ceil(o["height"].asDouble * scale).toInt()
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bitmap)
        c.scale(scale, scale)
        o.getAsJsonArray("shapes").forEach { s ->
            val sh = s.asJsonObject
            val path = Path()
            when (sh["type"].asString) {
                "circle" -> path.addCircle(sh["cx"].asFloat, sh["cy"].asFloat, sh["r"].asFloat, Path.Direction.CW)
                "rect" -> path.addRect(sh["x"].asFloat, sh["y"].asFloat, sh["x"].asFloat + sh["w"].asFloat, sh["y"].asFloat + sh["h"].asFloat, Path.Direction.CW)
                else -> {
                    sh.getAsJsonArray("points").forEachIndexed { i, p ->
                        val x = p.asJsonArray[0].asFloat
                        val y = p.asJsonArray[1].asFloat
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    if (sh["type"].asString == "polygon") path.close()
                }
            }
            val line = sh["type"].asString == "line"
            sh["stroke"]?.asString?.let { color ->
                c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    this.color = Color.parseColor(color)
                    strokeWidth = sh["strokeWidth"]?.asFloat ?: 1f
                    strokeCap = if (line) Paint.Cap.ROUND else Paint.Cap.BUTT
                    strokeJoin = Paint.Join.ROUND
                })
            }
            if (!line) sh["fill"]?.asString?.let { color ->
                c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; this.color = Color.parseColor(color) })
            }
        }
        return bitmap
    }

    /** Image [o] centred in a square of [size] logical pixels. */
    fun sign(o: JsonObject, size: Float, scale: Float): Bitmap {
        val iw = o["width"].asFloat
        val ih = o["height"].asFloat
        val px = Math.ceil(size * scale.toDouble()).toInt()
        val bitmap = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val k = size / maxOf(iw, ih) * scale
        val b = image(o, k)
        Canvas(bitmap).drawBitmap(b, (px - iw * k) / 2, (px - ih * k) / 2, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        b.recycle()
        return bitmap
    }

    /** [b] as a base64 PNG; [b] is recycled. */
    fun png(b: Bitmap): String {
        val out = java.io.ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.PNG, 100, out)
        b.recycle()
        return android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP)
    }
}
