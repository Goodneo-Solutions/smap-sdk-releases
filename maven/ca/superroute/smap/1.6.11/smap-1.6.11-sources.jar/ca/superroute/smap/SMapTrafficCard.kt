package ca.superroute.smap

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.text.SpannableString
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.URLSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

/**
 * The card of a traffic feature: its group and a close button at once, the details once they came. All of it is other
 * people's data: plain texts, a picture only over https and without the map's credentials, links only to web addresses.
 */
@SuppressLint("ViewConstructor")
internal class SMapTrafficCard(
    context: Context,
    group: String?,
    private val language: String?,
    private val scope: CoroutineScope,
    onClose: () -> Unit,
) : LinearLayout(context) {
    private val name = SMapTraffic.groupText(language, group)
    private val body = LinearLayout(context).apply { orientation = VERTICAL }
    private var picture: Job? = null
    private fun dp(v: Float) = SMapToolStyle.dp(context, v)
    private fun t(key: String) = SMapTraffic.text(language, key)

    init {
        orientation = VERTICAL
        tag = "smap-tr-card"
        background = SMapToolStyle.card(context, 8f)
        elevation = dp(6f).toFloat()
        setPadding(dp(10f), dp(6f), dp(6f), dp(8f))
        isClickable = true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) accessibilityPaneTitle = name
        val head = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(View(context).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(SMapTraffic.color(group) ?: SMapTraffic.color("other")!!)) }
        }, LayoutParams(dp(10f), dp(10f)).apply { marginEnd = dp(6f) })
        head.addView(text(name, 13f, bold = true).apply { tag = "smap-tr-card-group" }, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(text("×", 18f).apply {
            tag = "smap-tr-card-close"
            contentDescription = SMapRoadAttributes.text(language, "infoClose")
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            setOnClickListener { onClose() }
        }, LayoutParams(dp(28f), dp(28f)))
        addView(head)
        addView(ScrollView(context).apply { addView(body, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)) },
            LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        note(t("loading"))
    }

    /** At most 280 wide and never larger than the map less its margins (the details scroll). */
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val edge = dp(16f)
        fun limit(spec: Int) = if (MeasureSpec.getMode(spec) == MeasureSpec.UNSPECIFIED) Int.MAX_VALUE / 2 else maxOf(1, MeasureSpec.getSize(spec) - edge)
        super.onMeasure(
            MeasureSpec.makeMeasureSpec(minOf(dp(280f), limit(widthMeasureSpec)), MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(limit(heightMeasureSpec), MeasureSpec.AT_MOST),
        )
    }

    /** The details, or null when they could not be read. */
    fun fill(f: SMapTrafficFeature?) {
        body.removeAllViews()
        if (f == null) { note(t("failed")); return }
        f.title?.let { add(text(SMapTraffic.short(it), 13f, bold = true), "smap-tr-card-title") }
        f.description?.let { add(text(SMapTraffic.short(it), 12f), "smap-tr-card-text") }
        val pictureUrl = SMapTraffic.pictureUrl(f)
        val link = SMapTraffic.webUrl(f.image)
        if (pictureUrl != null) showPicture(pictureUrl, f.title?.let { SMapTraffic.short(it) } ?: name)
        else if (link != null) add(link(link), "smap-tr-card-link")
        f.source?.name?.takeIf { it.isNotEmpty() }?.let { add(text(t("source") + ": " + SMapTraffic.short(it), 11f), "smap-tr-card-source") }
        val credit = SMapTraffic.credit(f.attribution)
        if (credit.isNotEmpty()) add(creditText(credit), "smap-tr-card-credit")
    }

    override fun onDetachedFromWindow() {
        picture?.cancel()
        super.onDetachedFromWindow()
    }

    private fun add(v: View, name: String, at: Int = -1) {
        v.tag = name
        body.addView(v, at, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4f); marginEnd = dp(4f) })
    }

    private fun note(s: String) = add(text(s, 12f).apply { accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE }, "smap-tr-card-note")

    /** The picture; one that does not load becomes its link. */
    private fun showPicture(url: String, description: String) {
        val v = ImageView(context).apply {
            contentDescription = description
            adjustViewBounds = true
            maxHeight = dp(200f)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        add(v, "smap-tr-card-image")
        picture = scope.launch {
            val b = SMapTrafficPictures.load(url, dp(264f))
            val at = body.indexOfChild(v)
            if (at < 0) return@launch
            if (b != null) {
                v.setImageBitmap(b)
            } else {
                body.removeViewAt(at)
                add(link(url), "smap-tr-card-link", at)
            }
        }
    }

    private fun link(url: String) = text(t("openCamera"), 12f).apply {
        setTextColor(SMapToolStyle.BLUE)
        paint.isUnderlineText = true
        minHeight = dp(32f)
        gravity = Gravity.CENTER_VERTICAL
        isClickable = true
        isFocusable = true
        setOnClickListener { open(context, url) }
    }

    private fun creditText(parts: List<SMapTrafficCredit>): TextView = text("", 10f).apply {
        val s = SpannableString(parts.joinToString("") { it.text })
        var at = 0
        for (p in parts) {
            p.url?.let { url ->
                s.setSpan(object : URLSpan(url) { override fun onClick(widget: View) = open(widget.context, url) }, at, at + p.text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            at += p.text.length
        }
        setText(s, TextView.BufferType.SPANNABLE)
        setTextColor(Color.rgb(71, 85, 105))
        setLinkTextColor(SMapToolStyle.BLUE)
        if (parts.any { it.url != null }) movementMethod = LinkMovementMethod.getInstance()
    }

    private fun text(s: String, sp: Float, bold: Boolean = false) = TextView(context).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(SMapToolStyle.TEXT)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private companion object {
        /** Opens a web address outside the app; anything else is not opened. */
        fun open(context: Context, url: String) {
            val web = SMapTraffic.webUrl(url) ?: return
            try {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(web)).addCategory(Intent.CATEGORY_BROWSABLE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: ActivityNotFoundException) {
                // No app opens web addresses.
            } catch (e: SecurityException) {
                // The app that would is not open to others.
            }
        }
    }
}

/**
 * The pictures of the feeds: over https only, with a client of their own (no token, key, app identity or cookie), up to
 * [MAX_BYTES] and drawn no larger than they are shown.
 */
internal object SMapTrafficPictures {
    const val MAX_BYTES = 8 * 1024 * 1024
    const val MAX_PIXELS = 100_000_000L
    private const val DRAWN_PIXELS = 4_000_000L

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followSslRedirects(false)
            .connectTimeout(10, TimeUnit.SECONDS)
            .callTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    /** The picture at [url], about [width] pixels wide; null when it is not one, too large or does not load. */
    suspend fun load(url: String, width: Int): Bitmap? {
        if (!url.startsWith("https://")) return null
        val bytes = fetch(url) ?: return null
        return withContext(Dispatchers.Default) { try { decode(bytes, width) } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null } }
    }

    private suspend fun fetch(url: String): ByteArray? = suspendCancellableCoroutine { done ->
        val call = try { client.newCall(Request.Builder().url(url).build()) } catch (e: IllegalArgumentException) { done.resume(null); return@suspendCancellableCoroutine }
        done.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) { if (done.isActive) done.resume(null) }
            override fun onResponse(call: Call, response: Response) {
                val bytes = try {
                    response.use { r ->
                        val b = r.body
                        if (!r.isSuccessful || !r.request.isHttps || b == null || b.contentLength() > MAX_BYTES) null else read(b.byteStream(), MAX_BYTES)
                    }
                } catch (e: Exception) {
                    null
                }
                if (done.isActive) done.resume(bytes)
            }
        })
    }

    /** All of [stream], null when it holds more than [max] bytes. */
    fun read(stream: InputStream, max: Int): ByteArray? {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        while (true) {
            val n = stream.read(buffer)
            if (n < 0) return out.toByteArray()
            if (out.size() + n > max) return null
            out.write(buffer, 0, n)
        }
    }

    private fun decode(bytes: ByteArray, width: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        val sample = sample(o.outWidth, o.outHeight, width) ?: return null
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    /** How much a picture of [w] x [h] is scaled down (a power of two) to be drawn [width] wide; null for one that is not drawn. */
    fun sample(w: Int, h: Int, width: Int): Int? {
        if (w <= 0 || h <= 0 || w.toLong() * h > MAX_PIXELS) return null
        var s = 1
        while (w / (s * 2) >= maxOf(1, width) || (w / s).toLong() * (h / s) > DRAWN_PIXELS) s *= 2
        return s
    }
}
