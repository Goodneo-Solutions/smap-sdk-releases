package ca.superroute.smap

import android.graphics.Bitmap
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.JsonPrimitive
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.maplibre.android.geometry.LatLng

/**
 * The traffic layer (MOBILE-SDK-SPEC "Traffic"; Superroute MAP-SDK-DESIGN M113–M123): closures, incidents, works, road
 * conditions, message signs, cameras and facilities of the official traveller feeds. A map without this option has
 * none of it.
 *
 * @param getToken asked for a token whose claims carry the capability `traffic`, when the layer is first shown, before
 *   the token expires and when sMap refuses it; called on the main thread. It goes to sMap's traffic tiles and traffic
 *   details only, and takes the place of the map's own token and key there.
 * @param shown true: drawn from the start (it starts hidden, and nothing is asked before it is first shown, M114)
 * @param groups the groups shown first (null: the contract's); unknown ones are dropped
 * @param position the corner of its button
 * @param control false: no button (change the layer with [SMap.setTraffic])
 * @param info false: a tap on a feature opens no card; the click listeners are told either way
 */
data class SMapTrafficOptions(
    val getToken: suspend () -> String,
    val shown: Boolean = false,
    val groups: List<String>? = null,
    val position: SMapToolPosition = SMapToolPosition.TOP_RIGHT,
    val control: Boolean = true,
    val info: Boolean = true,
)

/** The traffic layer now: [available] is null until sMap was asked, then whether it serves the layer here. */
data class SMapTrafficState(val available: Boolean?, val shown: Boolean, val groups: List<String>, val open: Boolean)

/** Told after every change of the traffic layer (the SDK stores nothing). */
data class SMapTrafficChange(val shown: Boolean, val groups: List<String>, val open: Boolean)

/** A tap on a traffic feature: its [id] and [group], where ([lngLat], [point] in the map view's pixels). */
data class SMapTrafficClick(val id: Long, val group: String?, val lngLat: LatLng?, val point: Pair<Float, Float>)

/** Where a traffic feature's data comes from. */
data class SMapTrafficSource(val code: String?, val name: String?)

/**
 * One traffic feature's details ([SMap.trafficFeature]). Everything in it is other people's data: the texts are plain
 * text, [attribution] may hold links as HTML (see [SMapTraffic.credit]) and [image] any address (see [SMapTraffic.webUrl]).
 */
data class SMapTrafficFeature(
    val id: Long,
    val feed: String?,
    val group: String?,
    val subtype: String?,
    val title: String?,
    val description: String?,
    val image: String?,
    val media: String?,
    val source: SMapTrafficSource?,
    val attribution: String?,
)

/** A part of a credit: its text and, for a link, its web address (http or https only). */
data class SMapTrafficCredit(val text: String, val url: String?)

/** A tile feature a tap hit; [distance] from the tap in pixels, for points. */
data class SMapTrafficHit(val id: Long?, val group: String?, val point: Boolean, val distance: Float = 0f)

/**
 * The traffic layer's rules that need no map: everything comes from the SDK's copy of shared/traffic.json
 * (`traffic.json`, written by tools/traffic.mjs), the only place tile property names, groups, colours, images, layers
 * and texts are written.
 */
object SMapTraffic {
    const val LAYER_PREFIX = "smap-tr-"

    /** The largest feature id (2^53 − 1). */
    const val MAX_ID = 9007199254740991L

    /** A title or description is shown up to this many characters. */
    internal const val MAX_TEXT = 4000

    /** The contract as the SDK carries it. */
    val spec: JsonObject by lazy {
        val stream = SMapTraffic::class.java.getResourceAsStream("traffic.json")
            ?: throw IllegalStateException("sMap: traffic.json is missing from the library")
        stream.reader(Charsets.UTF_8).use { JsonParser.parseReader(it).asJsonObject }
    }

    val toolId: String get() = spec["toolId"].asString
    val source: String get() = spec["source"].asString
    val tolerance: Float get() = spec["tolerance"].asFloat
    val refreshSeconds: Int get() = spec["refreshSeconds"].asInt
    private val groupList: List<JsonObject> get() = spec.getAsJsonArray("groups").map { it.asJsonObject }

    /** The thirteen groups, most important first. */
    fun groupKeys(): List<String> = groupList.map { it["key"].asString }

    /** The groups of [list] that exist, once each, in the contract's order. */
    fun groups(list: List<String>?): List<String> {
        val want = (list ?: emptyList()).toSet()
        return groupKeys().filter { it in want }
    }

    fun defaultGroups(): List<String> = spec.getAsJsonArray("defaultGroups").map { it.asString }

    /** A group's colour (`#rrggbb`), null for an unknown one. */
    fun color(group: String?): String? = groupList.firstOrNull { it["key"].asString == group }?.get("color")?.asString

    /** The image of a group the map draws, null for an unknown one. */
    fun imageOf(group: String?): String? = groupList.firstOrNull { it["key"].asString == group }?.get("image")?.asString

    /** The start: null without the option, else shown and the groups. */
    fun start(options: SMapTrafficOptions?): Pair<Boolean, List<String>>? =
        options?.let { it.shown to (it.groups?.let(::groups) ?: defaultGroups()) }

    /** [now] changed; keys left null keep their value, unknown groups are dropped, and only a map with a panel opens it. */
    fun next(now: SMapTrafficChange, shown: Boolean?, groups: List<String>?, open: Boolean?, hasPanel: Boolean) = SMapTrafficChange(
        shown ?: now.shown,
        groups?.let(::groups) ?: now.groups,
        if (open == null) now.open else open && hasPanel,
    )

    /** The contract's language for a BCP-47 tag: one of the 14, English when none fits. */
    fun language(tag: String?): String {
        val t = (tag ?: "en").lowercase().replace('_', '-')
        if (Regex("^zh-(hant|tw|hk|mo)").containsMatchIn(t)) return "zh-Hant"
        if (t.startsWith("zh")) return "zh-Hans"
        val base = t.split('-')[0]
        return if (spec.getAsJsonObject("texts").has(base)) base else "en"
    }

    fun texts(tag: String?): JsonObject = spec.getAsJsonObject("texts").getAsJsonObject(language(tag))
    fun text(tag: String?, key: String): String = texts(tag)[key]?.asString ?: spec.getAsJsonObject("texts").getAsJsonObject("en")[key].asString

    /** A group's name; another event's for a group this contract does not know. */
    fun groupText(tag: String?, group: String?): String = text(tag, if (group != null && group in groupKeys()) group else "other")

    /** The layers in drawing order, for the groups shown (`"@groups"` in a filter). */
    fun layers(groups: List<String>): List<JsonObject> {
        val list = groups(groups)
        fun walk(e: JsonElement): JsonElement = when {
            e.isJsonPrimitive && e.asJsonPrimitive.isString && e.asString == "@groups" -> JsonArray().also { a -> list.forEach { a.add(it) } }
            e.isJsonArray -> JsonArray().also { out -> e.asJsonArray.forEach { out.add(walk(it)) } }
            e.isJsonObject -> JsonObject().also { out -> e.asJsonObject.entrySet().forEach { (k, v) -> out.add(k, walk(v)) } }
            else -> e
        }
        return spec.getAsJsonArray("layers").map { walk(it).asJsonObject }
    }

    fun layerIds(): List<String> = spec.getAsJsonArray("layers").map { it.asJsonObject["id"].asString }

    /** The layers drawn from the tiles' points. */
    internal fun pointLayers(): Set<String> {
        val points = spec.getAsJsonObject("sourceLayers")["points"].asString
        return spec.getAsJsonArray("layers").map { it.asJsonObject }.filter { it["source-layer"].asString == points }.map { it["id"].asString }.toSet()
    }

    /**
     * The layer a traffic layer goes under: the next traffic layer already in [styleIds] after it in the contract's
     * order, else the first layer that is neither the basemap's, the road attributes' nor the traffic's (the caller's
     * first); null = on top.
     */
    fun beforeId(layerId: String, styleIds: List<String>, basemapIds: Set<String>): String? {
        val order = layerIds()
        val present = styleIds.toSet()
        for (i in order.indexOf(layerId) + 1 until order.size) if (order[i] in present) return order[i]
        return styleIds.firstOrNull { it !in basemapIds && !isOverlay(it) }
    }

    /** A layer of the road attributes or the traffic (the SDK's own, under the caller's). */
    internal fun isOverlay(id: String): Boolean = id.startsWith(SMapRoadAttributes.LAYER_PREFIX) || id.startsWith(LAYER_PREFIX)

    // ------------------------------------------------------------------ the service

    /** The TileJSON address at a node. No token: it goes in a header. */
    fun tileJsonUrl(node: String): String = node.trimEnd('/') + tilePath

    /** The address of a feature's details at a node. */
    fun featureUrl(node: String, id: Long): String = node.trimEnd('/') + spec.getAsJsonObject("services")["feature"].asString + id

    /** The tile URLs of a TileJSON answer without their query (no token in the engine's URLs); null without the service. */
    fun tiles(tilejson: JsonObject?): List<String>? {
        if (tilejson == null) return null
        if (tilejson["available"]?.let { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean && !it.asBoolean } == true) return null
        val list = tilejson["tiles"]?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { textOf(it)?.substringBefore('?') }
        return list?.takeIf { it.isNotEmpty() }
    }

    /** How often the tiles are asked for again, in seconds (15–3600). */
    fun refreshSeconds(tilejson: JsonObject?): Int {
        val n = tilejson?.get("refresh_seconds")?.takeIf { it.isJsonPrimitive }?.asString?.toDoubleOrNull()?.takeIf { it.isFinite() && it != 0.0 }
        return (n ?: refreshSeconds.toDouble()).coerceIn(15.0, 3600.0).toInt()
    }

    /** An answer's JSON object, or null for anything else (a refusal's body, text that is not JSON). */
    fun parse(status: Int, body: String): JsonObject? {
        if (status !in 200..299) return null
        return try { JsonParser.parseString(body).takeIf { it.isJsonObject }?.asJsonObject } catch (e: Exception) { null }
    }

    /**
     * Whether the traffic token may go to [url]: a traffic address (`/v1/tiles/traffic…`, `/v1/traffic/…`) of one of
     * [nodes], at the same scheme, host and port.
     */
    internal fun mayCarryToken(url: okhttp3.HttpUrl, nodes: Collection<String>): Boolean = nodes.any { n ->
        val node = n.toHttpUrlOrNull() ?: return@any false
        if (node.scheme != url.scheme || node.host != url.host || node.port != url.port) return@any false
        val base = node.encodedPath.trimEnd('/')
        url.encodedPath.startsWith("$base/") && isTrafficPath(url.encodedPath.substring(base.length))
    }

    internal fun mayCarryToken(url: String, nodes: Collection<String>): Boolean = url.toHttpUrlOrNull()?.let { mayCarryToken(it, nodes) } == true

    internal val tilePath: String get() = spec.getAsJsonObject("services")["tiles"].asString

    private fun isTrafficPath(path: String): Boolean = path == tilePath || path.startsWith("$tilePath/") || path.startsWith("/v1/traffic/")

    // ------------------------------------------------------------------ the features

    /**
     * A feature id as the engines give it (text of a number), exactly: a whole number from 1 to 2^53 − 1, else null.
     * Never read through a floating point number.
     */
    fun id(text: String?): Long? = try {
        text?.trim()?.takeIf { it.length in 1..32 }?.let { java.math.BigDecimal(it).longValueExact() }?.takeIf { it in 1..MAX_ID }
    } catch (e: ArithmeticException) {
        null
    } catch (e: NumberFormatException) {
        null
    }

    /** The group a tile feature carries. */
    fun groupOf(properties: JsonObject?): String? = textOf(properties?.get(spec.getAsJsonObject("props")["group"].asString))

    /** The feature a tap read ([hits] top first): the nearest point, else the top line; null without one. */
    fun pick(hits: List<SMapTrafficHit>): SMapTrafficHit? {
        val known = hits.filter { it.id != null }
        return known.filter { it.point }.minByOrNull { it.distance } ?: known.firstOrNull()
    }

    private fun textOf(e: JsonElement?): String? = e?.takeIf { it.isJsonPrimitive }?.asString

    /** A feature's details from sMap's answer ([id] the one asked for). */
    fun feature(id: Long, o: JsonObject): SMapTrafficFeature {
        fun s(k: String): String? = textOf(o[k])?.takeIf { it.isNotEmpty() }
        val src = o["source"]?.takeIf { it.isJsonObject }?.asJsonObject
        return SMapTrafficFeature(
            id(textOf(o["id"])) ?: id, s("feed"), s("group"), s("subtype"), s("title"), s("description"), s("image"), s("media"),
            src?.let { SMapTrafficSource(textOf(it["code"]), textOf(it["name"])) }, s("attribution"),
        )
    }

    // ------------------------------------------------------------------ what of a feed is shown (other people's data)

    /** A web address (http or https) in its normal form, or null: nothing else of a feed is opened. */
    fun webUrl(u: String?): String? {
        val s = u?.trim() ?: return null
        if (!s.startsWith("http://", true) && !s.startsWith("https://", true)) return null
        return s.toHttpUrlOrNull()?.toString()
    }

    /** The picture a card shows: an https address that is not a video's; null otherwise (its link is shown, if any). */
    fun pictureUrl(f: SMapTrafficFeature): String? = if (f.media == "video") null else webUrl(f.image)?.takeIf { it.startsWith("https://") }

    /** [s] up to [MAX_TEXT] characters. */
    internal fun short(s: String): String = if (s.length <= MAX_TEXT) s else s.take(MAX_TEXT) + "…"

    /**
     * A credit (the TileJSON's or a feature's `attribution`, text that may hold HTML) as its texts and its links: never
     * markup, scripts and styles left out, links only where they are web addresses.
     */
    fun credit(html: String?): List<SMapTrafficCredit> {
        val s = html?.take(MAX_TEXT) ?: return emptyList()
        val out = ArrayList<SMapTrafficCredit>()
        var link: String? = null
        val text = StringBuilder()
        fun flush() {
            val t = text.toString().replace(Regex("\\s+"), " ")
            text.setLength(0)
            if (t.isEmpty() || (t == " " && out.isEmpty())) return
            val last = out.lastOrNull()
            if (last != null && last.url == link) out[out.size - 1] = last.copy(text = (last.text + t).replace(Regex("\\s+"), " "))
            else out += SMapTrafficCredit(if (out.isEmpty()) t.trimStart() else t, link)
        }
        var i = 0
        while (i < s.length) {
            val c = s[i]
            val n = s.getOrNull(i + 1)
            if (c != '<' || n == null || !(n.isLetter() || n == '/' || n == '!' || n == '?')) { text.append(c); i++; continue }
            if (s.startsWith("<!--", i)) { i = s.indexOf("-->", i + 4).let { if (it < 0) s.length else it + 3 }; continue }
            val end = tagEnd(s, i)
            val tag = s.substring(i + 1, minOf(end, s.length))
            i = minOf(end + 1, s.length)
            val closing = tag.startsWith("/")
            val name = tag.trimStart('/').takeWhile { it.isLetterOrDigit() }.lowercase()
            when {
                name in HIDDEN_TAGS && !closing -> i = afterClosing(s, i, name)
                name == "a" -> { decodeInto(text); flush(); link = if (closing) null else webUrl(decode(attribute(tag, "href") ?: "")) }
                name in BREAKING_TAGS -> text.append(' ')
            }
        }
        decodeInto(text)
        flush()
        if (out.isNotEmpty()) out[out.size - 1] = out.last().let { it.copy(text = it.text.trimEnd()) }
        return out.filter { it.text.isNotEmpty() }
    }

    /** A credit's links and texts as HTML of nothing else, for an engine that shows its sources' attribution itself. */
    internal fun creditHtml(parts: List<SMapTrafficCredit>): String = parts.joinToString("") { p ->
        if (p.url == null) escape(p.text) else "<a href=\"" + escape(p.url) + "\">" + escape(p.text) + "</a>"
    }

    private val HIDDEN_TAGS = setOf("script", "style", "template", "title", "iframe", "noscript")
    private val BREAKING_TAGS = setOf("br", "p", "div", "li", "ul", "ol", "tr", "td", "hr")

    /** Where the tag opened at [at] ends (its `>`), quotes respected; the text's length when it never does. */
    private fun tagEnd(s: String, at: Int): Int {
        var quote = 0.toChar()
        for (k in at + 1 until s.length) {
            val c = s[k]
            if (quote != 0.toChar()) { if (c == quote) quote = 0.toChar() }
            else if (c == '"' || c == '\'') quote = c
            else if (c == '>') return k
        }
        return s.length
    }

    private fun afterClosing(s: String, from: Int, name: String): Int {
        val at = s.indexOf("</$name", from, ignoreCase = true)
        return if (at < 0) s.length else minOf(tagEnd(s, at) + 1, s.length)
    }

    /** An attribute's value in a tag's text (quoted or not), null without it. */
    private fun attribute(tag: String, name: String): String? {
        var k = tag.indexOfFirst { it.isWhitespace() || it == '/' }.takeIf { it >= 0 } ?: return null
        while (k < tag.length) {
            while (k < tag.length && (tag[k].isWhitespace() || tag[k] == '/')) k++
            val start = k
            while (k < tag.length && !tag[k].isWhitespace() && tag[k] != '=' && tag[k] != '/') k++
            val key = tag.substring(start, k)
            while (k < tag.length && tag[k].isWhitespace()) k++
            var value: String? = null
            if (k < tag.length && tag[k] == '=') {
                k++
                while (k < tag.length && tag[k].isWhitespace()) k++
                val q = tag.getOrNull(k)
                if (q == '"' || q == '\'') {
                    val close = tag.indexOf(q, k + 1).let { if (it < 0) tag.length else it }
                    value = tag.substring(k + 1, close)
                    k = minOf(close + 1, tag.length)
                } else {
                    val from = k
                    while (k < tag.length && !tag[k].isWhitespace()) k++
                    value = tag.substring(from, k)
                }
            }
            if (key.equals(name, true)) return value
            if (key.isEmpty() && value == null) k++
        }
        return null
    }

    private val ENTITIES = mapOf("amp" to "&", "lt" to "<", "gt" to ">", "quot" to "\"", "apos" to "'", "nbsp" to " ", "copy" to "©", "reg" to "®", "ndash" to "–", "mdash" to "—")
    private val ENTITY = Regex("&(#[0-9]{1,7}|#[xX][0-9a-fA-F]{1,6}|[a-zA-Z]{2,8});")

    private fun decode(s: String): String = ENTITY.replace(s) { m ->
        val e = m.groupValues[1]
        val code = when {
            e.startsWith("#x", true) -> e.substring(2).toInt(16)
            e.startsWith("#") -> e.substring(1).toInt()
            else -> return@replace ENTITIES[e] ?: ENTITIES[e.lowercase()] ?: m.value
        }
        if (Character.isValidCodePoint(code) && code !in 0xD800..0xDFFF && !Character.isISOControl(code)) String(Character.toChars(code)) else " "
    }

    private fun decodeInto(b: StringBuilder) { val t = decode(b.toString()); b.setLength(0); b.append(t) }

    private fun escape(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    // ------------------------------------------------------------------ JSON (the Flutter and React Native views)

    /** The click as JSON (`trafficClick`). */
    fun clickJson(c: SMapTrafficClick): JsonObject = JsonObject().apply {
        addProperty("id", c.id)
        addProperty("group", c.group)
        if (c.lngLat == null) add("lngLat", com.google.gson.JsonNull.INSTANCE)
        else add("lngLat", JsonArray().apply { add(c.lngLat.longitude); add(c.lngLat.latitude) })
        add("point", JsonArray().apply { add(c.point.first); add(c.point.second) })
    }

    /** A feature's details as JSON (`trafficFeature`). */
    fun featureJson(f: SMapTrafficFeature): JsonObject = JsonObject().apply {
        addProperty("id", f.id)
        addProperty("feed", f.feed)
        addProperty("group", f.group)
        addProperty("subtype", f.subtype)
        addProperty("title", f.title)
        addProperty("description", f.description)
        addProperty("image", f.image)
        addProperty("media", f.media)
        if (f.source == null) add("source", com.google.gson.JsonNull.INSTANCE)
        else add("source", JsonObject().apply { addProperty("code", f.source.code); addProperty("name", f.source.name) })
        addProperty("attribution", f.attribution)
    }

    fun changeJson(e: SMapTrafficChange): JsonObject = JsonObject().apply {
        addProperty("shown", e.shown)
        add("groups", JsonArray().also { a -> e.groups.forEach { a.add(it) } })
        addProperty("open", e.open)
    }

    fun stateJson(s: SMapTrafficState?): JsonElement {
        if (s == null) return com.google.gson.JsonNull.INSTANCE
        return JsonObject().apply {
            add("available", if (s.available == null) com.google.gson.JsonNull.INSTANCE else JsonPrimitive(s.available))
            changeJson(SMapTrafficChange(s.shown, s.groups, s.open)).entrySet().forEach { (k, v) -> add(k, v) }
        }
    }

    // ------------------------------------------------------------------ images

    /** The images by id: logical width, height and shapes (shared/traffic.json `images`). */
    fun imageIds(): List<String> = spec.getAsJsonObject("images").keySet().toList()

    /** Draws image [id] at [scale] device pixels per logical pixel. */
    fun image(id: String, scale: Float): Bitmap = SMapSpecImages.image(spec.getAsJsonObject("images").getAsJsonObject(id), scale)

    /** The size of a group's image in the panel (logical pixels). */
    const val SIGN_SIZE = 16f

    /** The image of [group] in a square of [size] logical pixels (the panel's rows). */
    fun sign(group: String, size: Float, scale: Float): Bitmap =
        SMapSpecImages.sign(spec.getAsJsonObject("images").getAsJsonObject(imageOf(group) ?: imageOf("other")!!), size, scale)

    /** The groups' images for a wrapper that draws the panel itself (`trafficLegend`): `{scale, symbols: {group: base64 PNG}}`. */
    fun legendImagesJson(scale: Float): JsonObject = JsonObject().apply {
        addProperty("scale", scale)
        add("symbols", JsonObject().also { o -> groupKeys().forEach { k -> o.addProperty(k, SMapSpecImages.png(sign(k, SIGN_SIZE, scale))) } })
    }
}
