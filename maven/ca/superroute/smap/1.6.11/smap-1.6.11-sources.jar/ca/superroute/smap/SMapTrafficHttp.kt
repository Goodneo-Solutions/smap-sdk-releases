package ca.superroute.smap

import okhttp3.HttpUrl
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * The requests of one map's traffic layer that the SDK makes itself (the TileJSON and the features' details), each with
 * the traffic token and nothing of the map's own; a refused token (401) is replaced once.
 */
internal class SMapTrafficClient(val tokens: SMapTokenManager, private val http: SMapHttp) {

    /** @throws SMapException when there is no token; a network failure throws */
    suspend fun get(url: String): SMapHttpResponse {
        val token = tokens.token() ?: throw SMapException("sMap: no traffic token")
        val answer = ask(url, token)
        if (answer.status != 401) return answer
        return ask(url, tokens.replace(token) ?: throw SMapException("sMap: no traffic token"))
    }

    private suspend fun ask(url: String, token: String): SMapHttpResponse =
        http.get(url, mapOf("Authorization" to "Bearer $token"), FETCH_TIMEOUT_MILLIS)

    companion object {
        const val FETCH_TIMEOUT_MILLIS = 10_000L

        /** A new token is asked for this long before the current one expires. */
        const val REFRESH_BEFORE_SECONDS = 60L

        fun tokens(getToken: suspend () -> String, clock: () -> Long = System::currentTimeMillis) =
            SMapTokenManager(null, getToken, clock, REFRESH_BEFORE_SECONDS)
    }
}

/**
 * The traffic token on the engines' traffic tile requests. The engines share one HTTP client for the whole app and ask
 * for a tile by its URL alone, so the tile URLs they are given name their map by a number (`smap-traffic=<number>`, no
 * secret, never sent: it is taken off here). A request that names a map, for a traffic address of that map's nodes,
 * goes out with that map's traffic token and without the map's own credentials; every other request is left as it is.
 */
internal object SMapTrafficHttp {
    const val MAP_QUERY = "smap-traffic"

    /**
     * One map's traffic tiles.
     *
     * @param owns the addresses its token may go to
     * @param token the token to send, on a network thread: the current one, or a new one in place of the refused one
     */
    class Access(val owns: (HttpUrl) -> Boolean, val token: (refused: String?) -> String)

    private val maps = ConcurrentHashMap<String, Access>()
    private val numbers = AtomicLong()

    /** Adds a map; its number. */
    fun add(access: Access): String = numbers.incrementAndGet().toString().also { maps[it] = access }

    fun remove(map: String) { maps.remove(map) }

    /** A tile URL as the engine is given it. */
    fun tileUrl(url: String, map: String): String = url + (if ('?' in url) "&" else "?") + MAP_QUERY + "=" + map

    /** Whether a request names a map's traffic layer. */
    fun names(url: HttpUrl): Boolean = url.queryParameter(MAP_QUERY) != null

    val interceptor = Interceptor { chain ->
        val request = chain.request()
        val map = request.url.queryParameter(MAP_QUERY) ?: return@Interceptor chain.proceed(request)
        val access = maps[map]
        if (access == null) {
            // A tile of a map that is gone: not asked for without its token.
            if (SMapNodeHosts.contains(request.url.host) && SMapTraffic.tilePath in request.url.encodedPath) throw IOException("sMap: the map is gone")
            return@Interceptor chain.proceed(request)
        }
        if (!access.owns(request.url)) return@Interceptor chain.proceed(request)
        val token = token(access, null)
        val response = chain.proceed(signed(request, token, access))
        if (response.code != 401) return@Interceptor response
        response.close()
        chain.proceed(signed(request, token(access, token), access))
    }

    /** A redirect away from the map's traffic addresses goes on without the token (a network interceptor). */
    val redirects = Interceptor { chain ->
        val request = chain.request()
        val access = request.tag(Access::class.java)
        if (access == null || access.owns(request.url)) chain.proceed(request)
        else chain.proceed(request.newBuilder().removeHeader("Authorization").build())
    }

    // Anything but an IOException would end the app from the client's threads.
    private fun token(access: Access, refused: String?): String = try {
        access.token(refused)
    } catch (e: InterruptedException) {
        Thread.currentThread().interrupt()
        throw IOException("sMap: no traffic token", e)
    } catch (e: Exception) {
        throw IOException("sMap: no traffic token", e)
    }

    private fun signed(request: Request, token: String, access: Access): Request = try {
        request.newBuilder()
            .url(request.url.newBuilder().removeAllQueryParameters(MAP_QUERY).removeAllQueryParameters("token").removeAllQueryParameters("key").build())
            .apply { OWN_HEADERS.forEach(::removeHeader) }
            .header("Authorization", "Bearer $token")
            .tag(Access::class.java, access)
            .build()
    } catch (e: IllegalArgumentException) {
        // The message would hold the token.
        throw IOException("sMap: the traffic token cannot be sent")
    }

    private val OWN_HEADERS = listOf("Authorization", "Cookie", SMapAppIdentity.APP_HEADER, SMapAppIdentity.CERT_HEADER, SMapAppIdentity.KEY_HEADER)
}
