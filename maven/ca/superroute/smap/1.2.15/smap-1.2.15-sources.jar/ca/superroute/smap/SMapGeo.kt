package ca.superroute.smap

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import org.maplibre.android.geometry.LatLng
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Geometry helpers (MOBILE-SDK-SPEC G14), the same answers as the Web SDK's `sMap.geo` (shared/geo-vectors.json).
 * Positions are `[lng, lat]`.
 */
object SMapGeo {
    private const val EARTH_RADIUS = 6371008.8

    /** The point of a line nearest to a position: [distance] in metres from it, [index] of the segment's first vertex, [along] metres from the start. */
    data class Nearest(val point: DoubleArray, val distance: Double, val index: Int, val along: Double)

    private fun rad(d: Double) = d * Math.PI / 180

    /** Great-circle distance in metres. */
    fun distance(a: DoubleArray, b: DoubleArray): Double {
        val dLat = rad(b[1] - a[1])
        val dLng = rad(b[0] - a[0])
        val h = sin(dLat / 2) * sin(dLat / 2) + cos(rad(a[1])) * cos(rad(b[1])) * sin(dLng / 2) * sin(dLng / 2)
        return 2 * EARTH_RADIUS * asin(min(1.0, sqrt(h)))
    }

    fun distance(a: LatLng, b: LatLng): Double = distance(doubleArrayOf(a.longitude, a.latitude), doubleArrayOf(b.longitude, b.latitude))

    /** Length in metres of a line. */
    fun length(line: List<DoubleArray>): Double {
        var total = 0.0
        for (i in 1 until line.size) total += distance(line[i - 1], line[i])
        return total
    }

    /** Length of a LineString geometry or its Feature. */
    fun length(geometry: JsonObject): Double = length(lineOf(geometry))

    /** `[west, south, east, north]` of any GeoJSON, or null when it holds no position. */
    fun bounds(geojson: JsonElement): DoubleArray? {
        var b: DoubleArray? = null
        fun walk(v: JsonElement?) {
            if (v == null || v.isJsonNull) return
            if (v.isJsonArray) {
                val arr = v.asJsonArray
                if (arr.size() >= 2 && arr[0].isJsonPrimitive) {
                    val x = arr[0].asDouble
                    val y = arr[1].asDouble
                    val cur = b
                    b = if (cur == null) doubleArrayOf(x, y, x, y) else doubleArrayOf(min(cur[0], x), min(cur[1], y), max(cur[2], x), max(cur[3], y))
                    return
                }
                arr.forEach { walk(it) }
                return
            }
            if (!v.isJsonObject) return
            val o = v.asJsonObject
            when (o.get("type")?.asString) {
                "FeatureCollection" -> o.getAsJsonArray("features")?.forEach { walk(it) }
                "Feature" -> walk(o.get("geometry"))
                "GeometryCollection" -> o.getAsJsonArray("geometries")?.forEach { walk(it) }
                else -> walk(o.get("coordinates"))
            }
        }
        walk(geojson)
        return b
    }

    private fun inRing(x: Double, y: Double, ring: List<DoubleArray>): Boolean {
        var inside = false
        var j = ring.size - 1
        for (i in ring.indices) {
            val xi = ring[i][0]; val yi = ring[i][1]; val xj = ring[j][0]; val yj = ring[j][1]
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside
            j = i
        }
        return inside
    }

    /** Whether a position is inside a ring of positions. */
    fun pointInPolygon(point: DoubleArray, ring: List<DoubleArray>): Boolean = inRing(point[0], point[1], ring)

    /** Whether a position is inside a Polygon or MultiPolygon (holes excluded), or a Feature of one. */
    fun pointInPolygon(point: DoubleArray, polygon: JsonObject): Boolean {
        val g = geometryOf(polygon)
        val polys: List<List<List<DoubleArray>>> = when (g.get("type")?.asString) {
            "Polygon" -> listOf(rings(g.getAsJsonArray("coordinates")))
            "MultiPolygon" -> g.getAsJsonArray("coordinates").map { rings(it.asJsonArray) }
            else -> throw IllegalArgumentException("sMap: not a polygon")
        }
        return polys.any { rs ->
            rs.isNotEmpty() && inRing(point[0], point[1], rs[0]) && rs.drop(1).none { inRing(point[0], point[1], it) }
        }
    }

    /** The point of a line nearest to a position, measured in a local flat projection around the position. */
    fun nearestPointOnLine(line: List<DoubleArray>, point: DoubleArray): Nearest? {
        if (line.isEmpty()) return null
        val kx = cos(rad(point[1])) * rad(1.0) * EARTH_RADIUS
        val ky = rad(1.0) * EARTH_RADIUS
        var best: Nearest? = null
        var walked = 0.0
        for (i in 0 until max(1, line.size - 1)) {
            val a = line[i]
            val b = line[min(i + 1, line.size - 1)]
            val ax = (a[0] - point[0]) * kx; val ay = (a[1] - point[1]) * ky
            val bx = (b[0] - point[0]) * kx; val by = (b[1] - point[1]) * ky
            val dx = bx - ax; val dy = by - ay
            val len2 = dx * dx + dy * dy
            val t = if (len2 > 0) max(0.0, min(1.0, -(ax * dx + ay * dy) / len2)) else 0.0
            val x = ax + t * dx; val y = ay + t * dy
            val d = sqrt(x * x + y * y)
            val seg = distance(a, b)
            if (best == null || d < best.distance) best = Nearest(doubleArrayOf(point[0] + x / kx, point[1] + y / ky), d, i, walked + seg * t)
            walked += seg
        }
        return best
    }

    fun nearestPointOnLine(line: JsonObject, point: DoubleArray): Nearest? = nearestPointOnLine(lineOf(line), point)

    /** Metres from a position to the nearest point of a line. */
    fun distanceToLine(line: List<DoubleArray>, point: DoubleArray): Double = nearestPointOnLine(line, point)?.distance ?: Double.POSITIVE_INFINITY

    fun decodePolyline(encoded: String, precision: Int = 5): List<DoubleArray> = SMapFormats.decodePolyline(encoded, precision)
    fun encodePolyline(coordinates: List<DoubleArray>, precision: Int = 5): String = SMapFormats.encodePolyline(coordinates, precision)

    private fun geometryOf(o: JsonObject): JsonObject = if (o.get("type")?.asString == "Feature") o.getAsJsonObject("geometry") else o
    private fun position(e: JsonElement): DoubleArray = e.asJsonArray.let { doubleArrayOf(it[0].asDouble, it[1].asDouble) }
    private fun rings(a: JsonArray): List<List<DoubleArray>> = a.map { r -> r.asJsonArray.map(::position) }
    private fun lineOf(o: JsonObject): List<DoubleArray> {
        val g = geometryOf(o)
        if (g.get("type")?.asString != "LineString") throw IllegalArgumentException("sMap: not a line")
        return g.getAsJsonArray("coordinates").map(::position)
    }
}
