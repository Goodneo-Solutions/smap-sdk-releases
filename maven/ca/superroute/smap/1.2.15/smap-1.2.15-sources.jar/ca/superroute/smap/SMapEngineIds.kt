package ca.superroute.smap

/** Names of what the SDK adds to the map engine: source `smap-{id}`, layers `smap-{id}-…`. */
object SMapEngineIds {
    const val BASEMAP_SOURCE = "basemap"
    const val BUILDINGS_SOURCE_LAYER = "buildings"
    const val BUILDINGS_LAYER = "smap-buildings-3d"

    fun source(id: String): String = "smap-$id"

    fun clusters(id: String): String = "smap-$id-clusters"
    fun clusterCount(id: String): String = "smap-$id-count"
    /** Never seen: the clusters drawn this frame of a point layer whose clusters are views (ring or render). */
    fun clusterHits(id: String): String = "smap-$id-cluster-hits"
    fun points(id: String): String = "smap-$id-points"
    fun labels(id: String): String = "smap-$id-labels"
    fun lines(id: String): String = "smap-$id-lines"
    fun fill(id: String): String = "smap-$id-fill"
    fun outline(id: String): String = "smap-$id-outline"
    fun extrusion(id: String): String = "smap-$id-extrusion"
    fun lineLabels(id: String): String = "smap-$id-labels"
    fun heat(id: String): String = "smap-$id-heat"

    /** The engine layers of a point layer, bottom first. */
    fun pointLayers(id: String, o: SMapPointOptions): List<String> = buildList {
        if (o.cluster != null && o.cluster.ring == null && o.cluster.render == null) { add(clusters(id)); add(clusterCount(id)) }
        if (o.cluster != null && (o.cluster.ring != null || o.cluster.render != null)) add(clusterHits(id))
        add(points(id))
        if (o.label != null) add(labels(id))
    }

    fun lineLayers(id: String, o: SMapLineOptions? = null): List<String> = if (o?.label != null) listOf(lines(id), lineLabels(id)) else listOf(lines(id))

    fun polygonLayers(id: String, o: SMapPolygonOptions): List<String> =
        if (o.extrude != null) listOf(extrusion(id)) else listOf(fill(id), outline(id))

    /** The engine layer a tap on a caller layer is matched against. */
    fun tapLayer(id: String, kind: Kind, extruded: Boolean): String = when (kind) {
        Kind.POINTS -> points(id)
        Kind.LINES -> lines(id)
        Kind.POLYGONS -> if (extruded) extrusion(id) else fill(id)
        Kind.STYLE -> id
        Kind.HEATMAP -> heat(id)
        Kind.CUSTOM, Kind.MODELS -> id
    }

    /**
     * POINTS, LINES, POLYGONS and HEATMAP are the SDK's own drawn layers; STYLE a Style Spec layer, whose engine id is
     * its own id; CUSTOM custom markers (views over the map, no engine layer).
     */
    enum class Kind { POINTS, LINES, POLYGONS, STYLE, HEATMAP, CUSTOM, MODELS }
}
