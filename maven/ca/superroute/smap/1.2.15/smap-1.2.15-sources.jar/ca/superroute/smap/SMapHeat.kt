package ca.superroute.smap

import org.maplibre.android.style.expressions.Expression

/** The heat map colour ramp (G7), as the Web SDK writes it. */
internal object SMapHeat {
    /** The Web SDK's default: transparent, then five colours from blue to red. */
    val DEFAULT = listOf(
        0.0 to "rgba(33, 102, 172, 0)", 0.2 to "rgb(103, 169, 207)", 0.4 to "rgb(209, 229, 240)",
        0.6 to "rgb(253, 219, 199)", 0.8 to "rgb(239, 138, 98)", 1.0 to "rgb(178, 24, 43)",
    )

    /** Colours from low to high: transparent at no density, then evenly spaced (or the default ramp). */
    fun stops(colors: List<String>?): List<Pair<Double, String>> =
        if (colors.isNullOrEmpty()) DEFAULT
        else listOf(0.0 to "rgba(0, 0, 0, 0)") + colors.mapIndexed { i, c -> (i + 1).toDouble() / colors.size to c }

    fun ramp(colors: List<String>?): Expression = Expression.interpolate(
        Expression.linear(), Expression.heatmapDensity(),
        *stops(colors).map { (d, c) -> Expression.stop(d, Expression.toColor(Expression.literal(c))) }.toTypedArray(),
    )
}
