package ca.superroute.smap

import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.ViewConfiguration
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.Point
import kotlin.math.abs

/**
 * Touches on the drawn layers (MOBILE-SDK-SPEC "Touch rules"): a long press (500 ms) on a draggable point drags it
 * (G2), on a feature with a tooltip shows it until the finger lifts (G5). Until then the map gets every touch; once
 * one of them starts, the map gets a cancel and the gesture is the SDK's. Tools that take every touch while they
 * work (drawing, area selection) claim them with [capture].
 */
internal class SMapInteraction(private val host: SMap) {
    /** A tool taking the touches (G3, G4): every event goes to it while it returns true. */
    interface Capture { fun onTouch(e: MotionEvent): Boolean }

    var capture: Capture? = null
    private val handler = Handler(Looper.getMainLooper())
    private val slop = ViewConfiguration.get(host.context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var active: Active? = null

    private sealed class Active {
        class Tooltip : Active()
        class Drag(val layer: SMap.Interactive, val index: Int, val original: Feature, val ghostSource: String, val ghostId: String) : Active()
    }

    private val longPress = Runnable { if (!moved) start() }

    fun cameraMoved() { if (active is Active.Tooltip) { host.overlay().hideTooltip(); active = null } }

    // A touch that began on a tool or control is the control's: the SDK takes no part in it.
    private var onControl = false

    fun intercept(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) onControl = host.onControl(e.x, e.y)
        if (onControl) return false
        capture?.let { if (it.onTouch(e)) return true }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; moved = false; active = null
                if (host.interactiveLayers().isNotEmpty()) handler.postDelayed(longPress, SMapMarkerOverlay.LONG_PRESS_MS)
            }
            MotionEvent.ACTION_MOVE -> if (!moved && (abs(e.x - downX) > slop || abs(e.y - downY) > slop)) { moved = true; handler.removeCallbacks(longPress) }
            MotionEvent.ACTION_POINTER_DOWN -> { moved = true; handler.removeCallbacks(longPress) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { handler.removeCallbacks(longPress); if (active != null) return true }
        }
        return active != null
    }

    fun touch(e: MotionEvent): Boolean {
        if (onControl) return false
        capture?.let { if (it.onTouch(e)) return true }
        val a = active ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> if (a is Active.Drag) dragTo(a, e.x, e.y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (a is Active.Drag) finish(a, e.x, e.y) else host.overlay().hideTooltip()
                active = null
            }
        }
        return true
    }

    // The long press: the top feature under the finger of a layer that may be dragged or shows a tooltip.
    private fun start() {
        val map = host.engine ?: return
        val point = PointF(downX, downY)
        for (layer in host.interactiveLayers()) {
            val f = host.featureAt(map, layer.id, layer.engineLayer, point) ?: continue
            val props = SMapGeoJson.propertiesOf(f)
            if (props.containsKey("point_count")) continue
            val drag = layer.drag
            if (drag != null && drag.draggable.read(props, false)) {
                val data = host.layerData(layer.id) ?: return
                val index = indexOf(data, f)
                if (index < 0) return
                beginDrag(layer, index, data)
                return
            }
            val tip = layer.tooltip ?: continue
            val g = f.geometry()
            if (g is Point) {
                val p = map.projection.toScreenLocation(LatLng(g.latitude(), g.longitude()))
                host.overlay().showTooltip(tip, props, p.x, p.y, (layer.points?.radius ?: 6f) * 2 * host.resources.displayMetrics.density)
            } else {
                host.overlay().showTooltip(tip, props, downX, downY, 0f)
            }
            active = Active.Tooltip()
            cancelMap()
            return
        }
    }

    private fun cancelMap() {
        val cancel = MotionEvent.obtain(0, 0, MotionEvent.ACTION_CANCEL, downX, downY, 0)
        host.mapView.dispatchTouchEvent(cancel)
        cancel.recycle()
    }

    private fun beginDrag(layer: SMap.Interactive, index: Int, data: FeatureCollection) {
        val style = host.currentStyle() ?: return
        val original = data.features()!![index]
        val ghostId = layer.id + "-drag"
        val ghostSource = "smap-$ghostId"
        style.getSource(ghostSource)?.let { style.removeSource(it) }
        style.addSource(GeoJsonSource(ghostSource, FeatureCollection.fromFeatures(listOf(original))))
        host.addGhost(style, ghostId, ghostSource, layer.points ?: SMapPointOptions())
        val without = ArrayList(data.features()!!).apply { removeAt(index) }
        host.showData(layer.id, FeatureCollection.fromFeatures(without))
        val a = Active.Drag(layer, index, original, ghostSource, ghostId)
        active = a
        cancelMap()
        val g = original.geometry() as Point
        val p = host.engine!!.projection.toScreenLocation(LatLng(g.latitude(), g.longitude()))
        layer.drag?.onDragStart?.invoke(feature(layer, original, index), SMapDragEvent(LatLng(g.latitude(), g.longitude()), p.x, p.y))
    }

    private fun dragTo(a: Active.Drag, x: Float, y: Float) {
        val ll = host.engine?.projection?.fromScreenLocation(PointF(x, y)) ?: return
        val moved = Feature.fromGeometry(Point.fromLngLat(ll.longitude, ll.latitude), a.original.properties(), a.original.id())
        host.currentStyle()?.getSourceAs<GeoJsonSource>(a.ghostSource)?.setGeoJson(moved)
        a.layer.drag?.onDrag?.invoke(feature(a.layer, moved, a.index), SMapDragEvent(ll, x, y))
    }

    private fun finish(a: Active.Drag, x: Float, y: Float) {
        val style = host.currentStyle()
        val ll = host.engine?.projection?.fromScreenLocation(PointF(x, y))
        style?.let { s ->
            SMapEngineIds.pointLayers(a.ghostId, SMapPointOptions()).forEach { id -> s.getLayer(id)?.let(s::removeLayer) }
            s.getSource(a.ghostSource)?.let(s::removeSource)
        }
        val data = host.layerData(a.layer.id) ?: return
        if (ll == null) { host.showData(a.layer.id, data); return }
        val next = SMapMarkerOverlay.moveFeature(data, a.index, doubleArrayOf(ll.longitude, ll.latitude))
        host.replaceData(a.layer.id, next)
        a.layer.drag?.onDragEnd?.invoke(feature(a.layer, next.features()!![a.index], a.index), SMapDragEvent(ll, x, y))
    }

    private fun feature(layer: SMap.Interactive, f: Feature, index: Int): SMapFeature {
        val g = f.geometry() as Point
        return SMapFeature(f.id() ?: "#$index", SMapGeoJson.propertiesOf(f), LatLng(g.latitude(), g.longitude()))
    }

    companion object {
        // The engine answers numbers as doubles: compare every number as one.
        private fun normal(p: Map<String, Any?>): Map<String, Any?> = p.mapValues { (_, v) -> if (v is Number) v.toDouble() else v }

        /** The feature of the layer's data the engine answered: the same properties at (nearly) the same point. */
        fun indexOf(data: FeatureCollection, hit: Feature): Int {
            val g = hit.geometry() as? Point ?: return -1
            val props = normal(SMapGeoJson.propertiesOf(hit))
            var best = -1
            var bestD = Double.MAX_VALUE
            data.features()?.forEachIndexed { i, f ->
                val p = f.geometry() as? Point ?: return@forEachIndexed
                if (normal(SMapGeoJson.propertiesOf(f)) != props) return@forEachIndexed
                val d = abs(p.longitude() - g.longitude()) + abs(p.latitude() - g.latitude())
                if (d < bestD && d < 1e-6) { bestD = d; best = i }
            }
            return best
        }
    }
}
