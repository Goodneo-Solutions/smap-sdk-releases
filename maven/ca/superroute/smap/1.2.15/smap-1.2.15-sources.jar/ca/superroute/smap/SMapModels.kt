package ca.superroute.smap

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import android.view.Surface
import android.view.TextureView
import com.google.android.filament.Camera
import com.google.android.filament.Engine
import com.google.android.filament.EntityManager
import com.google.android.filament.IndirectLight
import com.google.android.filament.LightManager
import com.google.android.filament.Renderer
import com.google.android.filament.Scene
import com.google.android.filament.SwapChain
import com.google.android.filament.SwapChainFlags
import com.google.android.filament.View
import com.google.android.filament.Viewport
import com.google.android.filament.android.UiHelper
import com.google.android.filament.gltfio.AssetLoader
import com.google.android.filament.gltfio.FilamentAsset
import com.google.android.filament.gltfio.ResourceLoader
import com.google.android.filament.gltfio.UbershaderProvider
import com.google.android.filament.utils.Utils
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.Point
import java.net.URL
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tan

/**
 * glTF models at points (G12). [model] a .glb URL; [size] metres per model unit; [heading] degrees clockwise from
 * north; [altitude] metres; [rotate] the x / y / z degrees turning the model upright and to face north (default for
 * up +Y, front +Z).
 */
data class SMapModelOptions(
    val model: String,
    val size: SMapFeatureValue<Double>? = null,
    val heading: SMapFeatureValue<Double>? = null,
    val altitude: SMapFeatureValue<Double>? = null,
    val rotate: List<Double> = listOf(90.0, 0.0, 180.0),
    val idProperty: String? = null,
    val minZoom: Double? = null,
)

/**
 * The 3D models of one map (G12): a transparent view over the map in which Filament draws every model layer, its
 * camera set from the map's on every camera change (MapLibre's own geometry: a 36.87° vertical field of view, the
 * centre at the middle of the view, tilt and bearing), so a model stands where its point is.
 */
@SuppressLint("ViewConstructor")
internal class SMapModels(context: Context) : TextureView(context) {
    class Layer(val id: String, val options: SMapModelOptions, var data: FeatureCollection) {
        var hidden = false
        var buffer: ByteBuffer? = null
        val assets = LinkedHashMap<String, FilamentAsset>()
    }

    val layers = LinkedHashMap<String, Layer>()
    var map: MapLibreMap? = null
    private val ui = UiHelper(UiHelper.ContextErrorPolicy.DONT_CHECK)
    private var engine: Engine? = null
    private var renderer: Renderer? = null
    private var scene: Scene? = null
    private var view: View? = null
    private var camera: Camera? = null
    private var swapChain: SwapChain? = null
    private var loader: AssetLoader? = null
    private var resources: ResourceLoader? = null
    private var materials: UbershaderProvider? = null
    private var dirty = true
    private var scheduled = false
    private val main = Handler(Looper.getMainLooper())
    private val density = context.resources.displayMetrics.density

    private val frame = Choreographer.FrameCallback { nanos -> scheduled = false; draw(nanos) }

    init {
        isOpaque = false
        ui.isOpaque = false
        ui.renderCallback = object : UiHelper.RendererCallback {
            override fun onNativeWindowChanged(surface: Surface) {
                val e = engine ?: return
                swapChain?.let(e::destroySwapChain)
                swapChain = e.createSwapChain(surface, SwapChainFlags.CONFIG_TRANSPARENT)
                invalidateModels()
            }
            override fun onDetachedFromSurface() {
                val e = engine ?: return
                swapChain?.let { e.destroySwapChain(it); e.flushAndWait() }
                swapChain = null
            }
            override fun onResized(width: Int, height: Int) { view?.viewport = Viewport(0, 0, width, height); invalidateModels() }
        }
    }

    private fun start() {
        if (engine != null) return
        Utils.init()
        val e = Engine.create()
        engine = e
        renderer = e.createRenderer().apply { clearOptions = Renderer.ClearOptions().apply { clear = true; clearColor = doubleArrayOf(0.0, 0.0, 0.0, 0.0) } }
        scene = e.createScene()
        camera = e.createCamera(EntityManager.get().create())
        view = e.createView().apply {
            scene = this@SMapModels.scene
            camera = this@SMapModels.camera
            blendMode = View.BlendMode.TRANSLUCENT
            setPostProcessingEnabled(false)
        }
        materials = UbershaderProvider(e)
        loader = AssetLoader(e, materials!!, EntityManager.get())
        resources = ResourceLoader(e)
        // A sun from the south-east above, and an even light all round, so unlit sides are never black.
        val sun = EntityManager.get().create()
        LightManager.Builder(LightManager.Type.SUN).color(1f, 1f, 1f).intensity(90_000f).direction(-0.3f, 0.5f, -1f).castShadows(false).build(e, sun)
        scene!!.addEntity(sun)
        scene!!.indirectLight = IndirectLight.Builder().irradiance(1, floatArrayOf(1f, 1f, 1f)).intensity(30_000f).build(e)
        ui.attachTo(this)
    }

    fun put(id: String, options: SMapModelOptions, data: FeatureCollection) {
        remove(id)
        start()
        val layer = Layer(id, options, data)
        layers[id] = layer
        LOADS.execute {
            val bytes = try { URL(options.model).openStream().use { it.readBytes() } } catch (e: Exception) { null }
            main.post {
                if (layers[id] !== layer || bytes == null) return@post
                layer.buffer = ByteBuffer.allocateDirect(bytes.size).put(bytes).also { it.flip() }
                sync(layer)
            }
        }
    }

    fun setData(id: String, data: FeatureCollection) { layers[id]?.let { it.data = data; sync(it) } }
    fun setHidden(id: String, hidden: Boolean) { layers[id]?.let { it.hidden = hidden; sync(it) } }

    fun remove(id: String) {
        val layer = layers.remove(id) ?: return
        layer.assets.values.forEach(::destroyAsset)
        layer.assets.clear()
        invalidateModels()
    }

    fun destroy() {
        layers.keys.toList().forEach(::remove)
        ui.detach()
        val e = engine ?: return
        resources?.destroy(); loader?.destroy(); materials?.destroy()
        view?.let(e::destroyView); scene?.let(e::destroyScene); renderer?.let(e::destroyRenderer)
        camera?.let { e.destroyCameraComponent(it.entity) }
        e.destroy()
        engine = null
    }

    private fun destroyAsset(a: FilamentAsset) { scene?.removeEntities(a.entities); loader?.destroyAsset(a) }

    // One asset per feature: kept by key across new data.
    private fun sync(layer: Layer) {
        val buffer = layer.buffer ?: return
        val set = SMapMarkerSet<Unit>(layer.options.idProperty)
        set.update(layer.data)
        val keys = set.items.map { it.key }.toSet()
        layer.assets.keys.filter { it !in keys }.forEach { k -> layer.assets.remove(k)?.let(::destroyAsset) }
        if (!layer.hidden) {
            for (item in set.items) {
                if (item.key in layer.assets) continue
                val asset = loader?.createAsset(buffer.duplicate()) ?: continue
                resources?.loadResources(asset)
                asset.releaseSourceData()
                scene?.addEntities(asset.entities)
                layer.assets[item.key] = asset
            }
        } else {
            layer.assets.values.forEach(::destroyAsset); layer.assets.clear()
        }
        invalidateModels()
    }

    fun invalidateModels() {
        dirty = true
        if (!scheduled) { scheduled = true; Choreographer.getInstance().postFrameCallback(frame) }
    }

    private fun draw(nanos: Long) {
        val m = map ?: return
        val r = renderer ?: return
        val sc = swapChain ?: return
        val v = view ?: return
        if (!dirty || width == 0 || height == 0) return
        dirty = false
        val cam = m.cameraPosition
        val geometry = SMapModelCamera(width.toDouble(), height.toDouble(), cam.target!!.longitude, cam.target!!.latitude, cam.zoom, cam.bearing, cam.tilt, density.toDouble())
        val c = camera!!
        c.setProjection(SMapModelCamera.FOV_DEGREES, geometry.aspect, geometry.near, geometry.far, Camera.Fov.VERTICAL)
        val eye = geometry.eye(); val up = geometry.up()
        c.lookAt(eye[0], eye[1], eye[2], 0.0, 0.0, 0.0, up[0], up[1], up[2])
        val tm = engine!!.transformManager
        for (layer in layers.values) {
            val o = layer.options
            val visible = !layer.hidden && (o.minZoom == null || cam.zoom >= o.minZoom)
            val set = SMapMarkerSet<Unit>(o.idProperty)
            set.update(layer.data)
            for (item in set.items) {
                val asset = layer.assets[item.key] ?: continue
                val props = SMapGeoJson.propertiesOf(item.feature)
                val g = item.feature.geometry() as Point
                val matrix = if (visible) geometry.modelMatrix(g.longitude(), g.latitude(), o.altitude.read(props, 0.0), o.size.read(props, 1.0), o.heading.read(props, 0.0), o.rotate) else FloatArray(16)
                tm.setTransform(tm.getInstance(asset.root), matrix)
            }
        }
        if (r.beginFrame(sc, nanos)) { r.render(v); r.endFrame() }
    }

    companion object {
        private val LOADS = Executors.newSingleThreadExecutor()
    }
}

/**
 * The map's camera as Filament needs it (MOBILE-SDK-SPEC G12), in screen pixels: the ground point at the centre of
 * the view is the origin, x east, y north, z up. MapLibre's geometry: a vertical field of view of 2·atan(0.75), the
 * camera at half the view's height / tan(fov / 2) from the centre, tilted by [tilt] and turned by [bearing]; a world
 * of 512·2^zoom points of [ratio] pixels.
 */
internal class SMapModelCamera(val w: Double, val h: Double, val lng: Double, val lat: Double, val zoom: Double, val bearing: Double, val tilt: Double, val ratio: Double) {
    val aspect = w / h
    val distance = (h / 2) / tan(Math.toRadians(FOV_DEGREES) / 2)
    val near = distance / 50
    val far = distance * 50
    private val world = 512.0 * 2.0.pow(zoom) * ratio

    fun mercator(lng: Double, lat: Double): DoubleArray {
        val x = (lng + 180) / 360 * world
        val s = sin(Math.toRadians(lat.coerceIn(-85.051129, 85.051129)))
        val y = (0.5 - ln((1 + s) / (1 - s)) / (4 * PI)) * world
        return doubleArrayOf(x, y)
    }

    /** Pixels per metre at a latitude. */
    fun pixelsPerMetre(lat: Double): Double = world / (2 * PI * 6378137.0 * cos(Math.toRadians(lat)))

    fun eye(): DoubleArray {
        val t = Math.toRadians(tilt); val b = Math.toRadians(bearing)
        val back = distance * sin(t)
        return doubleArrayOf(-back * sin(b), -back * cos(b), distance * cos(t))
    }

    fun up(): DoubleArray {
        val t = Math.toRadians(tilt); val b = Math.toRadians(bearing)
        return doubleArrayOf(sin(b) * cos(t), cos(b) * cos(t), sin(t))
    }

    /** Where a ground point is, relative to the centre (x east, y north). */
    fun offset(lng: Double, lat: Double): DoubleArray {
        val c = mercator(this.lng, this.lat); val p = mercator(lng, lat)
        return doubleArrayOf(p[0] - c[0], -(p[1] - c[1]))
    }

    /** A model's column-major transform: at its point and altitude, [size] metres per unit, turned to [heading]. */
    fun modelMatrix(lng: Double, lat: Double, altitude: Double, size: Double, heading: Double, rotate: List<Double>): FloatArray {
        val o = offset(lng, lat)
        val k = pixelsPerMetre(lat) * size
        // R = Rz(-heading) · Rz(rz) · Ry(ry) · Rx(rx), then scaled by k and moved to the point.
        val r = mul(rotZ(-heading), mul(rotZ(rotate[2]), mul(rotY(rotate[1]), rotX(rotate[0]))))
        val out = FloatArray(16)
        for (col in 0 until 3) for (row in 0 until 3) out[col * 4 + row] = (r[row][col] * k).toFloat()
        out[12] = o[0].toFloat(); out[13] = o[1].toFloat(); out[14] = (altitude * pixelsPerMetre(lat)).toFloat(); out[15] = 1f
        return out
    }

    companion object {
        /** MapLibre's vertical field of view, 2·atan(0.75) ≈ 36.87°. */
        val FOV_DEGREES = Math.toDegrees(2 * kotlin.math.atan(0.75))

        private fun rotX(d: Double): Array<DoubleArray> { val a = Math.toRadians(d); return arrayOf(doubleArrayOf(1.0, 0.0, 0.0), doubleArrayOf(0.0, cos(a), -sin(a)), doubleArrayOf(0.0, sin(a), cos(a))) }
        private fun rotY(d: Double): Array<DoubleArray> { val a = Math.toRadians(d); return arrayOf(doubleArrayOf(cos(a), 0.0, sin(a)), doubleArrayOf(0.0, 1.0, 0.0), doubleArrayOf(-sin(a), 0.0, cos(a))) }
        private fun rotZ(d: Double): Array<DoubleArray> { val a = Math.toRadians(d); return arrayOf(doubleArrayOf(cos(a), -sin(a), 0.0), doubleArrayOf(sin(a), cos(a), 0.0), doubleArrayOf(0.0, 0.0, 1.0)) }
        private fun mul(a: Array<DoubleArray>, b: Array<DoubleArray>): Array<DoubleArray> =
            Array(3) { i -> DoubleArray(3) { j -> (0 until 3).sumOf { k -> a[i][k] * b[k][j] } } }

        /** Where a point of the ground falls on the screen through this camera (for tests and checks). */
        fun project(cam: SMapModelCamera, lng: Double, lat: Double): DoubleArray {
            val p = cam.offset(lng, lat)
            val eye = cam.eye(); val up = cam.up()
            // camera basis: forward = -eye (towards the origin), right = forward × up
            val f = doubleArrayOf(-eye[0], -eye[1], -eye[2]).let { v -> val n = Math.sqrt(v.sumOf { it * it }); DoubleArray(3) { v[it] / n } }
            val rt = doubleArrayOf(f[1] * up[2] - f[2] * up[1], f[2] * up[0] - f[0] * up[2], f[0] * up[1] - f[1] * up[0])
            val d = doubleArrayOf(p[0] - eye[0], p[1] - eye[1], 0 - eye[2])
            val zc = d[0] * f[0] + d[1] * f[1] + d[2] * f[2]
            val xc = d[0] * rt[0] + d[1] * rt[1] + d[2] * rt[2]
            val yc = d[0] * up[0] + d[1] * up[1] + d[2] * up[2]
            val s = (cam.h / 2) / tan(Math.toRadians(FOV_DEGREES) / 2)
            return doubleArrayOf(cam.w / 2 + xc / zc * s, cam.h / 2 - yc / zc * s)
        }
    }
}
