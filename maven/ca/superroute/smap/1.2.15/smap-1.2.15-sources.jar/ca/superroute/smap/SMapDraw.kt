package ca.superroute.smap

import android.graphics.PointF
import android.graphics.RectF
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.LinearLayout
import android.widget.TextView
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.FillLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.FeatureCollection
import kotlin.math.abs
import kotlin.math.hypot

/** The shapes a drawing tool offers. */
enum class SMapDrawShape { POLYGON, RECTANGLE, CIRCLE, LINE, POINT }

/** A change of the drawing tool's shapes: [type] created, edited or deleted, every shape after it as GeoJSON. */
data class SMapDrawEvent(val type: String, val feature: JsonObject?, val features: JsonObject)

/**
 * Options of [SMap.drawTool] (G3). [labels] translate the toolbar: polygon, rectangle, circle, line, point, hole,
 * delete, undo, redo, finish, cancel.
 */
data class SMapDrawOptions(
    val features: JsonObject? = null,
    val modes: List<SMapDrawShape> = SMapDrawShape.entries,
    val snap: Boolean = true,
    val toolbar: SMapToolPosition? = SMapToolPosition.TOP_LEFT,
    val labels: Map<String, String> = emptyMap(),
    val color: String = "#2563eb",
    val onChange: ((SMapDrawEvent) -> Unit)? = null,
)

/**
 * Drawing and editing shapes (G3, MOBILE-SDK-SPEC touch rules): a tap adds a vertex (a tap on the first closes a
 * polygon, *Finish* ends a polygon, line or hole); rectangles and circles are dragged with one finger; a selected
 * shape's vertex, midpoint or body is dragged to edit it. The map pans as usual everywhere else.
 */
class SMapDrawTool internal constructor(private val map: SMap, private val o: SMapDrawOptions) : SMapInteraction.Capture {
    private val state = SMapDrawState()
    private val id = "smap-draw-" + (++seq)
    private val density = map.resources.displayMetrics.density
    private val slop = ViewConfiguration.get(map.context).scaledTouchSlop
    private val labelText = DEFAULTS + o.labels
    private var selected: String? = null
    private var vertex: Pair<Int, Int>? = null
    private var mode: String? = null
    private var sketch: MutableList<DoubleArray>? = null
    private var toolbar: LinearLayout? = null
    private var destroyed = false
    private val listeners = ArrayList<(SMapDrawEvent) -> Unit>()

    // the touch in progress
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var claimed = false
    private var drag: Drag? = null

    private sealed class Drag {
        class Shape(val kind: String, val start: DoubleArray) : Drag() { var end: DoubleArray? = null }
        class Vertex : Drag()
        class Radius : Drag()
        class Body(var last: DoubleArray) : Drag()
    }

    init {
        o.features?.getAsJsonArray("features")?.let { a -> state.set(a.map { it.asJsonObject }) }
        map.ready { if (!destroyed) mount() }
    }

    fun on(listener: (SMapDrawEvent) -> Unit) { listeners += listener }
    fun off(listener: (SMapDrawEvent) -> Unit) { listeners -= listener }

    /** Every shape as a FeatureCollection (a copy). */
    fun getAll(): JsonObject = state.collection()
    fun get(id: String): JsonObject? = state.find(id)?.deepCopy()
    /** Replaces every shape (clears undo). */
    fun set(data: JsonObject) { state.set(data.getAsJsonArray("features")?.map { it.asJsonObject } ?: emptyList()); selected = null; vertex = null; render() }
    fun selection(): String? = selected
    fun select(id: String?) {
        val next = id?.takeIf { state.find(it) != null }
        if (next == selected && vertex == null) return
        selected = next; vertex = null; render(); renderToolbar()
    }

    /** Starts a shape: "polygon", "rectangle", "circle", "line", "point", or "hole" (in the selected polygon). */
    fun start(shape: String) {
        if (shape == "hole") {
            require(state.find(selected)?.getAsJsonObject("geometry")?.get("type")?.asString == "Polygon") { "sMap: select a polygon to draw a hole in" }
        } else require(SMapDrawShape.entries.any { it.name.lowercase() == shape }) { "sMap: unknown shape \"$shape\"" }
        mode = shape; sketch = ArrayList(); vertex = null
        if (shape != "hole") selected = null
        render(); renderToolbar()
    }

    fun cancel() { mode = null; sketch = null; render(); renderToolbar() }

    /** Ends a polygon, line or hole being drawn (touch has no double click). */
    fun finish() {
        val m = mode; val pts = sketch?.toList() ?: emptyList()
        mode = null; sketch = null
        when {
            m == "line" && pts.size >= 2 -> add(feature("LineString", SMapDrawState.line(pts)))
            m == "polygon" && pts.size >= 3 -> add(feature("Polygon", JsonArray().apply { add(SMapDrawState.closed(pts)) }))
            m == "hole" && pts.size >= 3 -> {
                val f = state.find(selected)
                if (f != null) { state.record(); f.getAsJsonObject("geometry").getAsJsonArray("coordinates").add(SMapDrawState.closed(pts)); emit("edited", f) }
                render(); renderToolbar()
            }
            else -> { render(); renderToolbar() }
        }
    }

    /** Deletes a shape (default the selected one); with a vertex selected, that vertex. */
    fun delete(id: String? = null) {
        val v = vertex
        if (id == null && v != null && selected != null) {
            val f = state.find(selected) ?: return
            val g = f.getAsJsonObject("geometry")
            val r = SMapDrawState.rings(g).getOrNull(v.first) ?: return
            if (r.coords.size <= (if (r.closed) 3 else 2)) return
            state.record()
            SMapDrawState.setRing(g, r, r.coords.toMutableList().also { it.removeAt(v.second) })
            vertex = null; render(); emit("edited", f); return
        }
        val target = id ?: selected ?: return
        val f = state.remove(target) ?: return
        if (selected == target) { selected = null; vertex = null }
        render(); renderToolbar(); emit("deleted", f)
    }

    fun undo() { if (state.undo()) { if (state.find(selected) == null) selected = null; vertex = null; render(); renderToolbar(); emit("edited", state.find(selected)) } }
    fun redo() { if (state.redo()) { if (state.find(selected) == null) selected = null; vertex = null; render(); renderToolbar(); emit("edited", state.find(selected)) } }

    fun destroy() {
        destroyed = true
        map.detachDraw(this)
        map.currentStyle()?.let { s -> LAYERS.forEach { s.getLayer(id + it)?.let(s::removeLayer) }; s.getSource(id)?.let(s::removeSource) }
        toolbar?.let { map.removeControl(it) }
    }

    // ---- engine layers

    internal fun addLayers(s: Style) {
        if (s.getSource(id) != null) return
        s.addSource(GeoJsonSource(id))
        val c = o.color
        fun role(r: String) = Expression.eq(Expression.get("_role"), Expression.literal(r))
        val sel = Expression.eq(Expression.get("_selected"), Expression.literal(true))
        s.addLayer(FillLayer(id + "-fill", id).withFilter(Expression.all(Expression.eq(Expression.geometryType(), Expression.literal("Polygon")), Expression.not(role("sketch"))))
            .withProperties(PropertyFactory.fillColor(Expression.switchCase(Expression.has("_fill"), Expression.toColor(Expression.get("_fill")), Expression.color(android.graphics.Color.parseColor(c)))),
                PropertyFactory.fillOpacity(Expression.switchCase(sel, Expression.literal(0.3), Expression.literal(0.18)))))
        s.addLayer(LineLayer(id + "-line", id).withFilter(Expression.all(Expression.neq(Expression.geometryType(), Expression.literal("Point")), Expression.not(role("sketch"))))
            .withProperties(PropertyFactory.lineColor(c), PropertyFactory.lineWidth(Expression.switchCase(sel, Expression.literal(3f), Expression.literal(2f))),
                PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND), PropertyFactory.lineCap(Property.LINE_CAP_ROUND)))
        s.addLayer(LineLayer(id + "-sketch", id).withFilter(role("sketch"))
            .withProperties(PropertyFactory.lineColor(c), PropertyFactory.lineWidth(2f), PropertyFactory.lineDasharray(arrayOf(2f, 1.5f))))
        s.addLayer(CircleLayer(id + "-mid", id).withFilter(role("mid"))
            .withProperties(PropertyFactory.circleRadius(6f), PropertyFactory.circleColor("#ffffff"), PropertyFactory.circleOpacity(0.9f), PropertyFactory.circleStrokeWidth(1.5f), PropertyFactory.circleStrokeColor(c)))
        val active = Expression.eq(Expression.get("_active"), Expression.literal(true))
        s.addLayer(CircleLayer(id + "-vertex", id).withFilter(Expression.any(role("vertex"), role("point"), role("sketch-vertex")))
            .withProperties(PropertyFactory.circleRadius(Expression.switchCase(active, Expression.literal(9f), Expression.literal(7f))),
                PropertyFactory.circleColor(Expression.switchCase(active, Expression.color(android.graphics.Color.parseColor(c)), Expression.color(android.graphics.Color.WHITE))),
                PropertyFactory.circleStrokeWidth(2.5f), PropertyFactory.circleStrokeColor(c)))
        render()
    }

    private fun mount() {
        map.attachDraw(this)
        map.currentStyle()?.let(::addLayers)
        o.toolbar?.let { pos -> toolbar = LinearLayout(map.context).apply { orientation = LinearLayout.HORIZONTAL; background = SMapToolStyle.card(map.context, 8f); elevation = 4 * density }.also { map.addControl(it, pos) } }
        renderToolbar()
    }

    private fun pt(props: JsonObject, coords: DoubleArray) = JsonObject().apply {
        addProperty("type", "Feature"); add("properties", props)
        add("geometry", JsonObject().apply { addProperty("type", "Point"); add("coordinates", JsonArray().apply { add(coords[0]); add(coords[1]) }) })
    }

    private fun render() {
        val s = map.currentStyle() ?: return
        val out = JsonArray()
        for (f in state.features) {
            val fid = state.idOf(f)
            val isSel = fid == selected
            val g = f.getAsJsonObject("geometry")
            val props = JsonObject().apply {
                addProperty("_id", fid); addProperty("_selected", isSel)
                f.getAsJsonObject("properties")?.get("fill")?.takeIf { it.isJsonPrimitive }?.let { add("_fill", it) }
                if (g["type"].asString == "Point") { addProperty("_role", "point"); addProperty("_active", isSel) }
            }
            out.add(JsonObject().apply { addProperty("type", "Feature"); add("properties", props); add("geometry", g) })
            if (!isSel || g["type"].asString == "Point") continue
            val fp = f.getAsJsonObject("properties")
            if (fp?.get("shape")?.asString == "circle" && fp.has("center")) {
                val center = fp.getAsJsonArray("center").let { doubleArrayOf(it[0].asDouble, it[1].asDouble) }
                out.add(pt(JsonObject().apply { addProperty("_role", "vertex"); addProperty("_id", fid); addProperty("_radius", true) }, SMapDrawState.circleRing(center, fp["radius"].asDouble)[16]))
                continue
            }
            val rect = fp?.get("shape")?.asString == "rectangle"
            SMapDrawState.rings(g).forEachIndexed { ri, r ->
                r.coords.forEachIndexed { i, c ->
                    out.add(pt(JsonObject().apply { addProperty("_role", "vertex"); addProperty("_id", fid); addProperty("_ring", ri); addProperty("_index", i); addProperty("_active", vertex == ri to i) }, c))
                    val next = r.coords.getOrNull(i + 1) ?: if (r.closed) r.coords[0] else null
                    if (next != null && !rect) out.add(pt(JsonObject().apply { addProperty("_role", "mid"); addProperty("_id", fid); addProperty("_ring", ri); addProperty("_index", i + 1) }, doubleArrayOf((c[0] + next[0]) / 2, (c[1] + next[1]) / 2)))
                }
            }
        }
        val sk = sketch
        if (mode != null && sk != null) {
            if (sk.size >= 2) {
                val closedSketch = mode != "line" && sk.size >= 3
                out.add(JsonObject().apply { addProperty("type", "Feature"); add("properties", JsonObject().apply { addProperty("_role", "sketch") })
                    add("geometry", JsonObject().apply { addProperty("type", "LineString"); add("coordinates", SMapDrawState.line(if (closedSketch) sk + listOf(sk[0]) else sk)) }) })
            }
            sk.forEach { out.add(pt(JsonObject().apply { addProperty("_role", "sketch-vertex") }, it)) }
        }
        s.getSourceAs<GeoJsonSource>(id)?.setGeoJson(FeatureCollection.fromJson(JsonObject().apply { addProperty("type", "FeatureCollection"); add("features", out) }.toString()))
    }

    // ---- touches

    private fun lngLat(x: Float, y: Float): DoubleArray = map.engine!!.projection.fromScreenLocation(PointF(x, y)).let { doubleArrayOf(it.longitude, it.latitude) }

    private fun snapped(x: Float, y: Float, except: String? = null): DoubleArray {
        if (!o.snap) return lngLat(x, y)
        val p = map.engine!!.projection
        var best: DoubleArray? = null
        var bestD = SNAP_DP * density
        for (f in state.features) {
            if (state.idOf(f) == except) continue
            val g = f.getAsJsonObject("geometry")
            val pts = if (g["type"].asString == "Point") listOf(g.getAsJsonArray("coordinates").let { doubleArrayOf(it[0].asDouble, it[1].asDouble) }) else SMapDrawState.rings(g).flatMap { it.coords }
            for (c in pts) {
                val s = p.toScreenLocation(LatLng(c[1], c[0]))
                val d = hypot(s.x - x, s.y - y)
                if (d <= bestD) { bestD = d; best = c }
            }
        }
        return best?.copyOf() ?: lngLat(x, y)
    }

    private fun hit(x: Float, y: Float, vararg layers: String): org.maplibre.geojson.Feature? {
        val r = TOUCH_DP * density / 2
        return map.engine!!.queryRenderedFeatures(RectF(x - r, y - r, x + r, y + r), *layers.map { id + it }.toTypedArray()).firstOrNull()
    }

    override fun onTouch(e: MotionEvent): Boolean {
        if (destroyed || map.engine == null) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; moved = false; claimed = false; drag = null
                claimed = down(e.x, e.y)
                return claimed
            }
            MotionEvent.ACTION_POINTER_DOWN -> { moved = true; if (drag != null) { drag = null; render() }; return false }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && (abs(e.x - downX) > slop || abs(e.y - downY) > slop)) moved = true
                if (claimed) { move(e.x, e.y); return true }
                return false
            }
            MotionEvent.ACTION_UP -> {
                if (claimed) { up(e.x, e.y); claimed = false; return true }
                if (!moved) return tap(e.x, e.y)
                return false
            }
            MotionEvent.ACTION_CANCEL -> { if (claimed) { drag = null; render() }; claimed = false; return false }
        }
        return claimed
    }

    // A press: a rectangle or circle starts, or a handle or the body of the selected shape is taken.
    private fun down(x: Float, y: Float): Boolean {
        if (mode == "rectangle" || mode == "circle") { drag = Drag.Shape(mode!!, snapped(x, y)); return true }
        if (mode != null) return false
        val f = state.find(selected) ?: return false
        val h = hit(x, y, "-vertex", "-mid")
        if (h != null && h.getStringProperty("_id") == selected) {
            if (h.hasProperty("_radius")) { state.record(); drag = Drag.Radius(); return true }
            val ri = h.getNumberProperty("_ring").toInt(); val idx = h.getNumberProperty("_index").toInt()
            state.record()
            if (h.getStringProperty("_role") == "mid") {
                val g = f.getAsJsonObject("geometry"); val r = SMapDrawState.rings(g)[ri]
                val at = (h.geometry() as org.maplibre.geojson.Point).let { doubleArrayOf(it.longitude(), it.latitude()) }
                SMapDrawState.setRing(g, r, r.coords.toMutableList().also { it.add(idx, at) })
            }
            vertex = ri to idx; drag = Drag.Vertex(); render(); return true
        }
        val body = hit(x, y, "-fill", "-line")
        if (body != null && body.getStringProperty("_id") == selected) { state.record(); vertex = null; drag = Drag.Body(lngLat(x, y)); return true }
        return false
    }

    private fun move(x: Float, y: Float) {
        val d = drag ?: return
        if (d is Drag.Shape) { d.end = lngLat(x, y); sketch = shapeRing(d)?.dropLast(1)?.toMutableList() ?: ArrayList(); render(); return }
        val f = state.find(selected) ?: return
        val g = f.getAsJsonObject("geometry")
        val props = f.getAsJsonObject("properties")
        when (d) {
            is Drag.Radius -> {
                val center = props.getAsJsonArray("center").let { doubleArrayOf(it[0].asDouble, it[1].asDouble) }
                val radius = SMapGeo.distance(center, lngLat(x, y))
                props.addProperty("radius", radius)
                g.add("coordinates", JsonArray().apply { add(SMapDrawState.closed(SMapDrawState.circleRing(center, radius).dropLast(1))) })
            }
            is Drag.Vertex -> {
                val v = vertex ?: return
                val r = SMapDrawState.rings(g)[v.first]
                val at = snapped(x, y, state.idOf(f))
                if (props?.get("shape")?.asString == "rectangle") SMapDrawState.setRing(g, r, SMapDrawState.rectangleWithCorner(r.coords, v.second, at))
                else SMapDrawState.setRing(g, r, r.coords.toMutableList().also { it[v.second] = at })
            }
            is Drag.Body -> {
                val now = lngLat(x, y)
                val dx = now[0] - d.last[0]; val dy = now[1] - d.last[1]
                props?.getAsJsonArray("center")?.let { c -> props.add("center", JsonArray().apply { add(c[0].asDouble + dx); add(c[1].asDouble + dy) }) }
                SMapDrawState.move(g, dx, dy)
                d.last = now
            }
            else -> Unit
        }
        render()
    }

    private fun up(x: Float, y: Float) {
        val d = drag ?: return
        drag = null
        if (d is Drag.Shape) {
            d.end = lngLat(x, y)
            val ring = shapeRing(d)
            mode = null; sketch = null
            if (ring != null && moved) {
                val props = JsonObject()
                if (d.kind == "circle") {
                    props.addProperty("shape", "circle")
                    props.add("center", JsonArray().apply { add(d.start[0]); add(d.start[1]) })
                    props.addProperty("radius", SMapGeo.distance(d.start, d.end!!))
                } else props.addProperty("shape", "rectangle")
                add(SMapDrawState.polygon(ring.dropLast(1), props))
            } else { render(); renderToolbar() }
            return
        }
        if (moved) emit("edited", state.find(selected)) else state.dropRecord()
        render()
    }

    private fun shapeRing(d: Drag.Shape): List<DoubleArray>? {
        val end = d.end ?: return null
        if (d.kind == "rectangle") { val a = d.start; return listOf(a, doubleArrayOf(end[0], a[1]), end, doubleArrayOf(a[0], end[1]), a) }
        val radius = SMapGeo.distance(d.start, end)
        return if (radius > 0) SMapDrawState.circleRing(d.start, radius) else null
    }

    // A tap: a vertex added (closing on the first), a point placed, or a shape (or a vertex of the selected one) selected.
    private fun tap(x: Float, y: Float): Boolean {
        when (mode) {
            "point" -> { mode = null; sketch = null; add(feature("Point", JsonArray().apply { val c = snapped(x, y); add(c[0]); add(c[1]) })); return true }
            "polygon", "line", "hole" -> {
                val sk = sketch ?: return true
                if (mode != "line" && sk.size >= 3) {
                    val first = map.engine!!.projection.toScreenLocation(LatLng(sk[0][1], sk[0][0]))
                    if (hypot(first.x - x, first.y - y) <= TOUCH_DP * density / 2) { finish(); return true }
                }
                val at = snapped(x, y)
                val last = sk.lastOrNull()
                if (last == null || last[0] != at[0] || last[1] != at[1]) sk += at
                render(); return true
            }
            null -> {
                val v = if (selected != null) hit(x, y, "-vertex") else null
                if (v != null && v.getStringProperty("_id") == selected && !v.hasProperty("_radius")) {
                    vertex = v.getNumberProperty("_ring").toInt() to v.getNumberProperty("_index").toInt(); render(); return true
                }
                val h = hit(x, y, "-vertex", "-line", "-fill")
                val was = selected
                select(h?.getStringProperty("_id"))
                return h != null || was != null
            }
        }
        return false
    }

    private fun feature(type: String, coords: JsonArray) = JsonObject().apply {
        addProperty("type", "Feature"); add("properties", JsonObject())
        add("geometry", JsonObject().apply { addProperty("type", type); add("coordinates", coords) })
    }

    private fun add(f: JsonObject) {
        val own = state.add(f)
        selected = if (own.getAsJsonObject("geometry")["type"].asString == "Point") null else state.idOf(own)
        vertex = null; render(); renderToolbar(); emit("created", own)
    }

    private fun emit(type: String, f: JsonObject?) {
        val e = SMapDrawEvent(type, f?.deepCopy(), state.collection())
        listeners.toList().forEach { it(e) }
        o.onChange?.invoke(e)
    }

    // ---- the toolbar

    private fun renderToolbar() {
        val bar = toolbar ?: return
        bar.removeAllViews()
        val drawingLong = mode == "polygon" || mode == "line" || mode == "hole"
        val names = ArrayList<String>()
        if (drawingLong) { names += "finish"; names += "cancel" } else {
            o.modes.forEach { names += it.name.lowercase() }
            val sel = state.find(selected)
            if (sel != null && sel.getAsJsonObject("geometry")["type"].asString == "Polygon" && !sel.getAsJsonObject("properties").has("shape")) names += "hole"
            names += listOf("delete", "undo", "redo")
        }
        for (n in names) {
            val enabled = when (n) { "delete" -> selected != null; "undo" -> state.canUndo; "redo" -> state.canRedo; else -> true }
            val pressed = mode == n
            bar.addView(TextView(map.context).apply {
                this.text = labelText[n]
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                gravity = Gravity.CENTER
                minHeight = (44 * density).toInt(); minWidth = (44 * density).toInt()
                val p = (10 * density).toInt(); setPadding(p, 0, p, 0)
                setTextColor(if (pressed) android.graphics.Color.WHITE else SMapToolStyle.TEXT)
                if (pressed) setBackgroundColor(SMapToolStyle.BLUE)
                alpha = if (enabled) 1f else 0.4f
                isEnabled = enabled
                contentDescription = labelText[n]
                setOnClickListener {
                    when (n) {
                        "finish" -> finish(); "cancel" -> cancel(); "delete" -> delete(); "undo" -> undo(); "redo" -> redo()
                        else -> if (mode == n) cancel() else start(n)
                    }
                }
            })
        }
        bar.visibility = if (names.isEmpty()) View.GONE else View.VISIBLE
    }

    companion object {
        private var seq = 0
        private const val SNAP_DP = 10f
        private const val TOUCH_DP = 44f
        private val LAYERS = listOf("-fill", "-line", "-sketch", "-mid", "-vertex")
        private val DEFAULTS = mapOf(
            "polygon" to "Polygon", "rectangle" to "Rectangle", "circle" to "Circle", "line" to "Line", "point" to "Point", "hole" to "Hole",
            "delete" to "Delete", "undo" to "Undo", "redo" to "Redo", "finish" to "Finish", "cancel" to "Cancel",
        )
    }
}
