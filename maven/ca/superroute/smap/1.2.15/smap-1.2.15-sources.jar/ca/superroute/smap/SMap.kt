package ca.superroute.smap

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.PointF
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.location.LocationManager
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import ca.superroute.smap.SMapJson.objOrNull
import ca.superroute.smap.SMapJson.str
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapLibreMapOptions
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.FillExtrusionLayer
import org.maplibre.android.style.layers.FillLayer
import org.maplibre.android.style.layers.HeatmapLayer
import org.maplibre.android.style.layers.Layer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonOptions
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.Point
import java.util.Locale
import kotlin.math.min

/**
 * A map view showing the map service's basemap with the caller's points, lines and areas on top.
 *
 * Forward the host's lifecycle to it ([onCreate], [onStart], [onResume], [onPause], [onStop], [onLowMemory],
 * [onSaveInstanceState], [onDestroy]). Every method must be called on the main thread.
 *
 * Layers, sources and basemap options set before the map is ready are drawn once it is; style, language and token
 * changes keep them.
 */
@SuppressLint("ViewConstructor")
class SMap(context: Context, val options: SMapOptions = SMapOptions()) : FrameLayout(context) {

    /** The underlying map view, for anything the SDK does not wrap. */
    val mapView: MapView

    /** The underlying map controller; null until the map exists (see [ready]). */
    var engine: MapLibreMap? = null
        private set

    /** The colour scheme in use (the last scheme set while a custom style is shown). */
    var flavor: SMapFlavor = options.styleName?.takeIf { !SMapStyleUrl.isCustom(it) }?.let(SMapStyleUrl::checkFlavor) ?: options.style
        private set

    /** The style in use by name: a flavor id (`light`, …) or a saved custom style `custom:<id>`. */
    var styleName: String = options.styleName?.let(SMapStyleUrl::checkStyle) ?: options.style.id
        private set

    /** The label language in use. */
    var language: String = options.language ?: Locale.getDefault().toLanguageTag()
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val tokens = SMapTokenManager(options.token, options.getToken)
    private val http: SMapHttp = options.http ?: SMapUrlConnectionHttp(ownHeaders(context, options.apiKey))
    private val nodes = SMapNodePicker(
        options.baseUrl,
        http,
        options.store ?: SMapPreferencesStore(context),
        options.nearest,
        seeds = options.nodes,
    )
    private val readyDeferred = CompletableDeferred<SMap>()

    /** The offline regions on this device (download, list, remove; see [SMapOffline]). */
    val offline: SMapOffline by lazy { SMapOffline(context, options) }

    /** The offline region shown now; null while the map reads the map service. */
    var offlineRegionInUse: String? = null
        private set
    private var refreshedOffline = false
    private val order = SMapLayerOrder()
    private val defs = HashMap<String, LayerDef>()
    private val sources = LinkedHashMap<String, JsonObject>()
    private val tapHandlers = HashMap<String, (Map<String, Any?>, LatLng) -> Unit>()
    private val images = LinkedHashMap<String, Pair<Bitmap, Boolean>>()
    private var style: Style? = null
    private var styleGeneration = 0
    private var styleFailures = 0
    private var node: String = nodes.baseUrl
    private var refreshJob: Job? = null
    private var buildings = false
    private var buildingColor: String? = null
    private var buildingOpacity = 0.85f

    // Basemap class overrides (setBasemap), the style as it came, the overrides last applied, the slot anchors, and
    // setPaint / setLayout / setFilter on basemap layers (applied again after every style change).
    private var basemapOverrides: JsonObject = SMapBasemap.toJson(options.basemap).also { SMapBasemap.refuse(it) }
    private var basemapOriginal: JsonObject? = null
    private var basemapApplied: JsonObject? = null
    private var anchors: Map<SMapSlot, String?> = emptyMap()
    private val basemapEdits = LinkedHashMap<String, JsonObject>()
    private val attributionView: TextView

    // Map tools (MOBILE-SDK-SPEC "Map tools"): the registry holds every rule, the views are kept beside it.
    private val tools = SMapToolRegistry<View?>(options.tools.hidden).also { r -> options.tools.onChange?.let(r::addListener) }
    private var toolCorners: SMapToolCorners? = null
    private var toolsControl: SMapToolsControl? = null

    // Custom markers, clusters drawn as views and the tooltip (G1, G5, G6), over the map and under the controls.
    private val markers: SMapMarkerOverlay
    private val interaction: SMapInteraction
    // 3D models (G12), made with the first model layer, between the map and the marker views.
    private var models: SMapModels? = null

    private fun models(): SMapModels = models ?: SMapModels(context).also { m ->
        models = m
        addView(m, indexOfChild(mapView) + 1, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        m.map = engine
    }

    private class LayerDef(
        val id: String,
        val kind: SMapEngineIds.Kind,
        var data: FeatureCollection,
        val points: SMapPointOptions? = null,
        val lines: SMapLineOptions? = null,
        val polygons: SMapPolygonOptions? = null,
        var layer: JsonObject? = null,
        val styleOptions: SMapStyleLayerOptions? = null,
        val custom: SMapCustomMarkerOptions? = null,
        val heatmap: SMapHeatmapOptions? = null,
        val model: SMapModelOptions? = null,
    ) {
        var hidden = false
        var group: String? = null
        var ownsSource: String? = null

        val zIndex: Int get() = points?.zIndex ?: lines?.zIndex ?: polygons?.zIndex ?: heatmap?.zIndex ?: styleOptions?.zIndex ?: 0
        val slot: SMapSlot? get() = points?.slot ?: lines?.slot ?: polygons?.slot ?: heatmap?.slot ?: styleOptions?.slot
        val before: String? get() = points?.before ?: lines?.before ?: polygons?.before ?: heatmap?.before ?: styleOptions?.before

        /** Clusters of this point layer drawn as views (ring or render). */
        val viewClusters: Boolean get() = points?.cluster?.let { it.ring != null || it.render != null } == true

        /** The engine source of a style layer whose source is given inline. */
        val inlineSource: String? get() = if (layer?.get("source")?.isJsonObject == true) "smap-inline-$id" else null

        val engineLayers: List<String>
            get() = when (kind) {
                SMapEngineIds.Kind.POINTS -> SMapEngineIds.pointLayers(id, points!!)
                SMapEngineIds.Kind.LINES -> SMapEngineIds.lineLayers(id, lines)
                SMapEngineIds.Kind.POLYGONS -> SMapEngineIds.polygonLayers(id, polygons!!)
                SMapEngineIds.Kind.STYLE -> listOf(id)
                SMapEngineIds.Kind.HEATMAP -> listOf(SMapEngineIds.heat(id))
                SMapEngineIds.Kind.CUSTOM, SMapEngineIds.Kind.MODELS -> emptyList()
            }
    }

    init {
        MapLibre.getInstance(context.applicationContext)
        SMapEngineHttp.install(context)
        val camera = CameraPosition.Builder().apply {
            options.center?.let { target(it) }
            options.zoom?.let { zoom(it) }
            options.bearing?.let { bearing(it) }
            options.pitch?.let { tilt(it) }
        }.build()
        // The engine's logo stays off. The sMap badge sits bottom-right; the attribution keeps its place bottom-left.
        val mapOptions = MapLibreMapOptions.createFromAttributes(context)
            .attributionEnabled(true)
            .logoEnabled(false)
            .camera(camera)
        mapView = MapView(context, mapOptions)
        addView(mapView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        markers = SMapMarkerOverlay(context, mapView, ::markerOrder) { id, data -> defs[id]?.data = data }
        addView(markers, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        interaction = SMapInteraction(this)
        val density = resources.displayMetrics.density
        val badgeMargin = (SMapBadge.MARGIN_DP * density).toInt()
        // Bottom-right: the external sources' credit (when there is one), then the badge.
        val corner = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            isClickable = false
        }
        attributionView = TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
            setTextColor(SMapBadge.TEXT)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            maxWidth = (220 * density).toInt()
            includeFontPadding = false
            setPadding((6 * density).toInt(), (2 * density).toInt(), (6 * density).toInt(), (2 * density).toInt())
            background = GradientDrawable().apply { cornerRadius = 10 * density; setColor(Color.argb(209, 255, 255, 255)) }
            visibility = View.GONE
        }
        corner.addView(attributionView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { marginEnd = badgeMargin })
        corner.addView(SMapBadge(context), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(corner, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.END).apply { marginEnd = badgeMargin; bottomMargin = badgeMargin })
        mapView.addOnDidFailLoadingMapListener { message -> onStyleFailed(message) }
        start()
    }

    // ------------------------------------------------------------------ lifecycle

    fun onCreate(savedInstanceState: Bundle?) = mapView.onCreate(savedInstanceState)
    fun onStart() = mapView.onStart()
    fun onResume() = mapView.onResume()
    fun onPause() = mapView.onPause()
    fun onStop() = mapView.onStop()
    fun onLowMemory() = mapView.onLowMemory()
    fun onSaveInstanceState(outState: Bundle) = mapView.onSaveInstanceState(outState)

    fun onDestroy() {
        scope.cancel()
        models?.destroy()
        mapView.onDestroy()
    }

    // ------------------------------------------------------------------ readiness

    /** Suspends until the first style has loaded. */
    suspend fun ready(): SMap = readyDeferred.await()

    /** Calls [callback] once the first style has loaded (at once when it already has). */
    fun ready(callback: (SMap) -> Unit) {
        if (readyDeferred.isCompleted) {
            callback(this)
        } else {
            scope.launch { callback(readyDeferred.await()) }
        }
    }

    /** True once the first style has loaded. */
    val isReady: Boolean get() = readyDeferred.isCompleted

    /** The token in use now, if any. */
    val token: String? get() = tokens.current

    private fun start() {
        // A region asked for at start is shown at once, without waiting for the network.
        options.offlineRegion?.let { id ->
            if (offline.styleFile(id) != null) {
                offlineRegionInUse = id
                scope.launch(Dispatchers.Main) {
                    mapView.getMapAsync { map ->
                        engine = map
                        map.addOnMapClickListener { latLng -> handleTap(map, latLng) }
                        attachTools(map)
                        loadStyle()
                    }
                }
                return
            }
            report(SMapException("sMap: the offline region \"$id\" is not on this device or has expired"))
        }
        // Posted (not immediate), so the host's onCreate has reached the map view before the map is asked for.
        scope.launch(Dispatchers.Main) {
            val tokenJob = async {
                if (options.getToken != null && options.token == null) {
                    try {
                        tokens.refresh()
                    } catch (e: Exception) {
                        report(e)
                    }
                }
            }
            val nodeJob = async { nodes.nodes() }
            tokenJob.await()
            node = nodeJob.await().first()
            mapView.getMapAsync { map ->
                engine = map
                map.addOnMapClickListener { latLng -> handleTap(map, latLng) }
                attachTools(map)
                loadStyle()
            }
            scheduleRefresh()
        }
    }

    private fun report(e: Throwable) {
        options.onError?.invoke(e)
    }

    // ------------------------------------------------------------------ tokens

    private fun scheduleRefresh() {
        refreshJob?.cancel()
        val wait = tokens.refreshDelayMillis() ?: return
        refreshJob = scope.launch {
            delay(wait)
            try {
                tokens.refresh()
                if (offlineRegionInUse == null) loadStyle()
                scheduleRefresh()
            } catch (e: Exception) {
                report(e)
                delay(RETRY_MILLIS)
                scheduleRefresh()
            }
        }
    }

    // ------------------------------------------------------------------ style

    /** The address of the style in use. */
    val styleUrl: String get() = SMapStyleUrl.build(node, styleName, language, tokens.current, options.apiKey)

    private fun loadStyle() {
        val map = engine ?: return
        style = null
        val generation = ++styleGeneration
        val offlineStyle = offlineRegionInUse?.let { offline.styleFile(it) }
        if (offlineRegionInUse != null && offlineStyle == null) offlineRegionInUse = null
        val uri = offlineStyle?.let { "file://" + it.absolutePath } ?: styleUrl
        map.setStyle(Style.Builder().fromUri(uri)) { loaded ->
            if (generation != styleGeneration) return@setStyle
            styleFailures = 0
            style = loaded
            snapshotBasemap(loaded)
            restore(loaded)
            if (!readyDeferred.isCompleted) readyDeferred.complete(this)
            onStyleLoaded?.invoke(this)
            if (offlineStyle == null) refreshOfflineOnce()
        }
    }

    private fun onStyleFailed(message: String?) {
        if (offlineRegionInUse != null) {
            report(SMapException("sMap: the offline region \"$offlineRegionInUse\" could not load: ${message ?: "unknown error"}"))
            return
        }
        report(SMapException("sMap: the map style could not load: ${message ?: "unknown error"}", url = styleUrl))
        scope.launch {
            val list = nodes.nodes()
            if (list.size < 2 || styleFailures >= list.size - 1) {
                fallBackOffline()
                return@launch
            }
            styleFailures++
            nodes.demote(node)
            node = nodes.nodes().first()
            loadStyle()
        }
    }

    /** Every node failed: a downloaded region containing the view's centre, when the app allows it. */
    private suspend fun fallBackOffline() {
        if (!options.offlineFallback) return
        val center = engine?.cameraPosition?.target ?: options.center ?: return
        val pick = withContext(Dispatchers.IO) { SMapOfflineFiles.pick(offline.ready(), center.latitude, center.longitude) } ?: return
        offlineRegionInUse = pick.id
        loadStyle()
    }

    /** Once a map has loaded from the map service, the regions in their last days are refreshed in the background. */
    private fun refreshOfflineOnce() {
        if (refreshedOffline || !options.offlineAutoRefresh) return
        refreshedOffline = true
        scope.launch(Dispatchers.IO) {
            try {
                offline.refreshDue()
            } catch (e: Exception) {
                report(e)
            }
        }
    }

    /**
     * Shows the downloaded offline region [id] instead of the map service (no network needed). The caller's layers
     * are kept.
     *
     * @return false when the region is not on this device or has expired
     */
    fun useOfflineRegion(id: String): Boolean {
        if (offline.styleFile(id) == null) return false
        offlineRegionInUse = id
        loadStyle()
        return true
    }

    /** Reads the map service again after [useOfflineRegion] (or a fallback to a region). */
    fun useOnline() {
        offlineRegionInUse = null
        styleFailures = 0
        loadStyle()
    }

    /** Switches the colour scheme; the caller's layers are kept. */
    fun setStyle(flavor: SMapFlavor) = setStyle(flavor.id)

    /**
     * Switches the style: a flavor id (`light`, `white`, `grayscale`, `dark`, `black`) or a saved custom style
     * `custom:<id>`. The caller's layers, sources and basemap options are kept.
     *
     * @throws IllegalArgumentException for an unknown style name
     */
    fun setStyle(style: String) {
        styleName = SMapStyleUrl.checkStyle(style)
        if (!SMapStyleUrl.isCustom(style)) flavor = SMapStyleUrl.checkFlavor(style)
        offlineRegionInUse = null
        loadStyle()
    }

    /** Switches the label language (a BCP-47 tag); the caller's layers are kept. */
    fun setLanguage(tag: String) {
        language = tag
        offlineRegionInUse = null
        loadStyle()
    }

    private fun restore(style: Style) {
        for ((name, image) in images) {
            if (style.getImage(name) == null) style.addImage(name, image.first, image.second)
        }
        for (id in sources.keys) addEngineSource(style, id)
        for (id in order.ids()) defs[id]?.let { addToStyle(style, it) }
        applyBuildings(style)
        applyBasemap(style)
        for ((id, edit) in basemapEdits) applyEdit(style, id, edit)
        imageryHid.clear()
        if (baseImagery != null) applyImagery(style)
        drawTools.forEach { it.addLayers(style) }
        if (terrain != null) applyTerrain(style)
        hideLayerTools(style)
        updateAttribution()
    }

    // ------------------------------------------------------------------ basemap options

    // The style as it came: its layer ids (for the slots) and its layers (for the overrides and getStyleLayer).
    private fun snapshotBasemap(style: Style) {
        basemapApplied = null
        basemapOriginal = try { SMapJson.parseObject(style.json) } catch (e: Exception) { null }
        val ids = basemapOriginal?.getAsJsonArray("layers")?.mapNotNull { it.asJsonObject.str("id") }
            ?: style.layers.map { it.id }
        anchors = SMapSlots.anchors(ids)
    }

    private fun applyBasemap(style: Style) {
        val original = basemapOriginal ?: return
        val next = SMapBasemap.apply(original, basemapOverrides)
        for (c in SMapBasemap.changes(basemapApplied ?: original, next)) {
            try {
                style.getLayer(c.layer)?.setProperties(SMapEngineStyle.property(c.paint, c.name, c.value))
            } catch (e: Exception) {
                report(e)
            }
        }
        basemapApplied = next
    }

    /**
     * Shows, hides and recolours the basemap by class (`water`, `land`, `parks`, `roads` and `roads.highway` …,
     * `labels` and `labels.places` …, `pois`, …). Replaces the overrides set before (an empty map clears them); kept
     * across style and language changes.
     *
     * @throws IllegalArgumentException naming an unknown class or field, or a value out of range
     */
    fun setBasemap(overrides: Map<String, SMapBasemapOverride>) = setBasemap(SMapBasemap.toJson(overrides))

    /** [setBasemap] with the overrides as their JSON object (`{"water":{"color":"#9cc0e6"}}`). */
    fun setBasemap(overrides: JsonObject) {
        SMapBasemap.refuse(overrides)
        basemapOverrides = overrides.deepCopy()
        style?.let { applyBasemap(it) }
    }

    /** [setBasemap] with the overrides as JSON text. */
    fun setBasemap(json: String) = setBasemap(SMapJson.parseObject(json))

    /** The basemap overrides in force. */
    fun basemap(): Map<String, SMapBasemapOverride> = SMapBasemap.fromJson(basemapOverrides)

    /** The basemap overrides in force, as their JSON object (a copy). */
    fun basemapJson(): JsonObject = basemapOverrides.deepCopy()

    // ------------------------------------------------------------------ images

    /** Registers an image for point icons; it is kept across style changes. */
    fun addImage(name: String, bitmap: Bitmap, sdf: Boolean = false) {
        images[name] = bitmap to sdf
        style?.addImage(name, bitmap, sdf)
    }

    // ------------------------------------------------------------------ 3D buildings

    /**
     * Shows the basemap's buildings in 3D under the caller's layers, and tilts the map to 55° when it is flat.
     *
     * @param color `#d9dee7` by default (`#3b4252` on dark and black)
     */
    fun setBuildings3D(on: Boolean, color: String? = null, opacity: Float? = null) {
        buildings = on
        buildingColor = color
        if (opacity != null) buildingOpacity = opacity
        style?.let { applyBuildings(it) }
        val map = engine
        if (on && map != null && map.cameraPosition.tilt < FLAT_TILT) {
            map.animateCamera(CameraUpdateFactory.tiltTo(BUILDINGS_TILT), TILT_MILLIS)
        }
    }

    private fun applyBuildings(style: Style) {
        style.getLayer(SMapEngineIds.BUILDINGS_LAYER)?.let { style.removeLayer(it) }
        if (!buildings || style.getSource(SMapEngineIds.BASEMAP_SOURCE) == null) return
        val layer = FillExtrusionLayer(SMapEngineIds.BUILDINGS_LAYER, SMapEngineIds.BASEMAP_SOURCE)
            .withSourceLayer(SMapEngineIds.BUILDINGS_SOURCE_LAYER)
            .withProperties(
                PropertyFactory.fillExtrusionColor(buildingColor ?: if (flavor.isDark) "#3b4252" else "#d9dee7"),
                PropertyFactory.fillExtrusionHeight(Expression.coalesce(Expression.get("height"), Expression.literal(8))),
                PropertyFactory.fillExtrusionBase(Expression.coalesce(Expression.get("min_height"), Expression.literal(0))),
                PropertyFactory.fillExtrusionOpacity(buildingOpacity),
            )
        layer.minZoom = BUILDINGS_MIN_ZOOM
        // Under the caller's layers that draw on top (no slot, or the top slot); slotted layers keep their places.
        val below = order.ids().firstNotNullOfOrNull { id ->
            val onTop = order.beforeOf(id) == null && (order.slotOf(id) ?: SMapSlot.TOP) == SMapSlot.TOP
            if (onTop) firstEngineLayer(style, id) else null
        }
        if (below != null) style.addLayerBelow(layer, below) else style.addLayer(layer)
    }

    // ------------------------------------------------------------------ the SDK's own layers

    /** Adds (or replaces) a point layer. */
    fun addPoints(id: String, points: List<SMapPoint>, options: SMapPointOptions = SMapPointOptions()) =
        addPoints(id, SMapGeoJson.points(points), options)

    /** Adds (or replaces) a point layer from GeoJSON. */
    fun addPoints(id: String, data: FeatureCollection, options: SMapPointOptions = SMapPointOptions()) =
        define(LayerDef(id, SMapEngineIds.Kind.POINTS, data, points = options))

    /** Adds (or replaces) a line layer. */
    fun addLines(id: String, lines: List<SMapLine>, options: SMapLineOptions = SMapLineOptions()) =
        addLines(id, SMapGeoJson.lines(lines), options)

    /** Adds (or replaces) a line layer from GeoJSON. */
    fun addLines(id: String, data: FeatureCollection, options: SMapLineOptions = SMapLineOptions()) =
        define(LayerDef(id, SMapEngineIds.Kind.LINES, data, lines = options))

    /** Adds (or replaces) an area layer. */
    fun addPolygons(id: String, polygons: List<SMapPolygon>, options: SMapPolygonOptions = SMapPolygonOptions()) =
        addPolygons(id, SMapGeoJson.polygons(polygons), options)

    /** Adds (or replaces) an area layer from GeoJSON. */
    fun addPolygons(id: String, data: FeatureCollection, options: SMapPolygonOptions = SMapPolygonOptions()) =
        define(LayerDef(id, SMapEngineIds.Kind.POLYGONS, data, polygons = options))

    /**
     * Custom markers (G1): the app's own view at each point, over the map's drawn layers. A view is made the first
     * time its point comes into view and is detached while out of view, so thousands stay smooth. [data] as setData.
     */
    fun addCustomMarkers(id: String, data: Any, options: SMapCustomMarkerOptions) {
        if (options.snapshot) return addSnapshotMarkers(id, SMapGeoJson.toFeatureCollection(data), options)
        define(LayerDef(id, SMapEngineIds.Kind.CUSTOM, SMapGeoJson.toFeatureCollection(data), custom = options))
    }

    // Custom markers drawn by the map (snapshot): each look is drawn once from the app's view into an image and the
    // layer is a point layer of those images, so tens of thousands pan as smoothly as points.
    private class SnapshotLayer(val options: SMapCustomMarkerOptions) {
        /** Look → image name. */
        val images = HashMap<String, String>()
        /** Image name → its size in density-independent pixels. */
        val sizes = HashMap<String, Pair<Float, Float>>()
    }

    /**
     * The top feature of a layer under a screen point. A snapshot layer is hit by each image's own box: the engine
     * finds an icon that ignores placement only near its anchor point, not over the picture.
     */
    internal fun featureAt(map: MapLibreMap, id: String, engineLayer: String, point: PointF): Feature? {
        val layer = snapshots[id] ?: return map.queryRenderedFeatures(point, engineLayer).firstOrNull()
        val features = defs[id]?.data?.features() ?: return null
        val o = layer.options
        val d = resources.displayMetrics.density
        // Later features draw on top (symbol-z-order source).
        for (f in features.asReversed()) {
            val g = f.geometry() as? Point ?: continue
            val name = f.getStringProperty(SMapSnapshots.IMAGE) ?: continue
            val (w, h) = layer.sizes[name] ?: continue
            val at = map.projection.toScreenLocation(LatLng(g.latitude(), g.longitude()))
            val left = at.x - o.anchor.x * w * d + o.offsetDp.first * d
            val top = at.y - o.anchor.y * h * d + o.offsetDp.second * d
            if (point.x >= left && point.x <= left + w * d && point.y >= top && point.y <= top + h * d) return f
        }
        return null
    }

    private val snapshots = HashMap<String, SnapshotLayer>()
    private var snapshotImages = 0

    private fun addSnapshotMarkers(id: String, data: FeatureCollection, options: SMapCustomMarkerOptions) {
        removeLayer(id)
        val layer = SnapshotLayer(options)
        val plain = { f: SMapFeature -> SMapSnapshots.plain(f) }
        val d = options.drag
        addPoints(
            id, snapshotCollection(id, layer, data),
            SMapPointOptions(
                minZoom = options.minZoom?.toFloat(), maxZoom = options.maxZoom?.toFloat(), tooltip = options.tooltip,
                drag = SMapDragOptions(
                    draggable = d.draggable,
                    onDragStart = d.onDragStart?.let { cb -> { f, e -> cb(plain(f), e) } },
                    onDrag = d.onDrag?.let { cb -> { f, e -> cb(plain(f), e) } },
                    onDragEnd = d.onDragEnd?.let { cb -> { f, e -> cb(plain(f), e) } },
                ),
                iconProperty = SMapSnapshots.IMAGE, iconAnchor = options.anchor, iconOffsetDp = options.offsetDp,
                iconOpacityProperty = if (options.opacity != null) SMapSnapshots.OPACITY else null,
                sortProperty = if (options.zIndex != null) SMapSnapshots.ORDER else null,
            ),
        )
        snapshots[id] = layer
        options.onTap?.let { tap ->
            onTap(id) { props, at -> tap(SMapFeature(props[SMapSnapshots.KEY]?.toString() ?: "", SMapSnapshots.stripped(props), at)) }
        }
    }

    // The layer's features with the image, key, opacity and order of each; a look not seen before is drawn now.
    private fun snapshotCollection(id: String, layer: SnapshotLayer, data: FeatureCollection): FeatureCollection {
        val o = layer.options
        val keys = SMapMarkerSet<View>(o.idProperty)
        val out = ArrayList<Feature>()
        data.features()?.forEachIndexed { index, f ->
            if (f.geometry() !is Point) return@forEachIndexed
            val props = SMapSnapshots.stripped(SMapGeoJson.propertiesOf(f)).toMutableMap()
            val look = o.snapshotKey?.invoke(props) ?: SMapSnapshots.look(props) ?: "#$index"
            val name = layer.images.getOrPut(look) {
                "smap-snapshot|$id|${snapshotImages++}".also { name ->
                    val bitmap = SMapSnapshots.draw(o.render(props), resources.displayMetrics)
                    layer.sizes[name] = bitmap.width / resources.displayMetrics.density to bitmap.height / resources.displayMetrics.density
                    addImage(name, bitmap)
                }
            }
            val key = keys.keyOf(f, index)
            o.opacity?.let { props[SMapSnapshots.OPACITY] = it.read(props, 1f).toDouble() }
            o.zIndex?.let { props[SMapSnapshots.ORDER] = it.read(props, 0).toDouble() }
            props[SMapSnapshots.IMAGE] = name
            props[SMapSnapshots.KEY] = key
            out.add(Feature.fromGeometry(f.geometry(), SMapGeoJson.properties(props), f.id()))
        }
        return FeatureCollection.fromFeatures(out)
    }

    /** Forgets an image of [addImage]. */
    fun removeImage(name: String) {
        if (images.remove(name) != null) style?.removeImage(name)
    }

    /** The view of one custom marker by its key (made now if it was not in view yet), or null. */
    fun getMarker(id: String, key: String): View? = markers.marker(id, key)

    /**
     * glTF models at points (G12), drawn in 3D over the map and turned to each feature's heading. [data] as setData;
     * the model is read once from its URL.
     */
    fun addModels(id: String, data: Any, options: SMapModelOptions) {
        define(LayerDef(id, SMapEngineIds.Kind.MODELS, SMapGeoJson.toFeatureCollection(data), model = options))
    }

    /** A heat map of points (G7). [data] as setData. */
    fun addHeatmap(id: String, data: Any, options: SMapHeatmapOptions = SMapHeatmapOptions()) {
        define(LayerDef(id, SMapEngineIds.Kind.HEATMAP, SMapGeoJson.toFeatureCollection(data), heatmap = options))
    }

    /**
     * Replaces a layer's data and keeps its look. [data]: a FeatureCollection, a Feature, a GeoJSON string, or a list
     * of [SMapPoint], [SMapLine] or [SMapPolygon].
     *
     * @throws IllegalArgumentException when there is no layer [id] of addPoints / addLines / addPolygons, or the data
     *   cannot be read
     */
    fun setData(id: String, data: Any) {
        val def = defs[id]?.takeIf { it.kind != SMapEngineIds.Kind.STYLE } ?: throw IllegalArgumentException("sMap: no layer $id")
        val snapshot = snapshots[id]
        def.data = if (snapshot != null) snapshotCollection(id, snapshot, SMapGeoJson.toFeatureCollection(data)) else SMapGeoJson.toFeatureCollection(data)
        if (def.kind == SMapEngineIds.Kind.CUSTOM) return markers.setData(id, def.data)
        if (def.kind == SMapEngineIds.Kind.MODELS) return models().setData(id, def.data)
        style?.getSourceAs<GeoJsonSource>(SMapEngineIds.source(id))?.setGeoJson(def.data)
        if (def.viewClusters) clustersDirty = true
    }

    /** Shows or hides a layer. */
    fun setVisible(id: String, visible: Boolean) {
        val def = defs[id] ?: return
        def.hidden = !visible
        if (def.kind == SMapEngineIds.Kind.CUSTOM) return markers.setHidden(id, !visible)
        if (def.kind == SMapEngineIds.Kind.MODELS) return models().setHidden(id, !visible)
        if (def.viewClusters) markers.setHidden(clusterLayer(id), !visible)
        val s = style ?: return
        val value = PropertyFactory.visibility(if (visible) Property.VISIBLE else Property.NONE)
        def.engineLayers.forEach { s.getLayer(it)?.setProperties(value) }
    }

    /**
     * Removes a layer: one of the SDK's own (addPoints, addLines, addPolygons; addData's whole group), a style layer
     * (addStyleLayer and the external-layer calls, with the source such a call made for it), or a source of
     * addSource with the style layers that read it.
     */
    fun removeLayer(id: String) {
        val ids = order.ids().filter { it == id || defs[it]?.group == id }
        if (ids.isEmpty()) {
            if (id in sources) removeSource(id)
            return
        }
        for (x in ids) {
            val def = defs.remove(x) ?: continue
            style?.let { drop(it, def) }
            snapshots.remove(x)?.images?.values?.forEach { removeImage(it) }
            if (def.kind == SMapEngineIds.Kind.CUSTOM) markers.remove(x)
            if (def.kind == SMapEngineIds.Kind.MODELS) models?.remove(x)
            if (def.viewClusters) markers.remove(clusterLayer(x))
            order.remove(x)
            tapHandlers.remove(x)
            val owned = def.ownsSource
            if (owned != null && owned in sources && !sourceInUse(owned)) removeSource(owned)
        }
        updateAttribution()
    }

    /** The caller's layer ids in draw order, bottom first. */
    fun layers(): List<String> = order.ids()

    /** Moves the camera to show all of a layer's data. [padding] in density-independent pixels. */
    fun fitLayer(id: String, padding: Int = 40, maxZoom: Double = 15.0) {
        val map = engine ?: return
        val def = defs[id]?.takeIf { it.kind != SMapEngineIds.Kind.STYLE } ?: return
        val b = SMapGeoJson.bounds(def.data) ?: return
        if (b[0] == b[2] && b[1] == b[3]) {
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(b[1], b[0]), maxZoom))
            return
        }
        val bounds = LatLngBounds.from(b[3], b[2], b[1], b[0])
        val px = (padding * resources.displayMetrics.density).toInt()
        val camera = map.getCameraForLatLngBounds(bounds, intArrayOf(px, px, px, px)) ?: return
        map.animateCamera(
            CameraUpdateFactory.newCameraPosition(CameraPosition.Builder(camera).zoom(min(camera.zoom, maxZoom)).build()),
        )
    }

    /** Calls [handler] with the tapped feature's properties and position when a feature of layer [id] is tapped. */
    fun onTap(id: String, handler: (properties: Map<String, Any?>, latLng: LatLng) -> Unit) {
        tapHandlers[id] = handler
    }

    /** Flies the camera to [center], at [zoom] when given. */
    fun flyTo(center: LatLng, zoom: Double? = null) {
        val map = engine ?: return
        val update = if (zoom != null) CameraUpdateFactory.newLatLngZoom(center, zoom) else CameraUpdateFactory.newLatLng(center)
        map.animateCamera(update, FLY_MILLIS)
    }

    // ------------------------------------------------------------------ sources and style layers

    /**
     * Adds a Style Spec v8 source (geojson, vector, raster, raster-dem, image), passed to the engine as it is and kept
     * across style and language changes. Its `attribution` is shown beside the map data credit. `pmtiles://<url>`
     * reads a PMTiles archive. A source with the same id is replaced (with the style layers that read it).
     *
     * @param source the source as JSON text, a [JsonObject] or a map of plain values
     * @throws IllegalArgumentException for a source that cannot be drawn, the id `basemap`, or Google / Bing tiles
     */
    fun addSource(id: String, source: Any) {
        val json = (if (source is JsonObject) source else SMapStyleSpec.layerObject(source)).deepCopy()
        if (id == SMapEngineIds.BASEMAP_SOURCE) throw IllegalArgumentException("sMap: the source id \"basemap\" belongs to the map")
        SMapStyleSpec.checkSource(id, json)
        SMapExternalLayers.refuseForbidden(SMapExternalLayers.sourceUrls(json))
        if (id in sources) removeSource(id)
        sources[id] = json
        style?.let { addEngineSource(it, id) }
        updateAttribution()
    }

    /** Removes a source of addSource and the style layers that read it. */
    fun removeSource(id: String) {
        if (id !in sources) return
        order.ids().filter { defs[it]?.layer?.str("source") == id }.forEach { x ->
            defs[x]?.ownsSource = null
            removeLayer(x)
        }
        sources.remove(id)
        style?.let { s -> s.getSource(id)?.let { s.removeSource(it) } }
        updateAttribution()
    }

    /** The sources added with addSource (and by the external-layer calls): id → source (copies). */
    fun sources(): Map<String, JsonObject> = sources.mapValues { it.value.deepCopy() }

    private fun sourceInUse(id: String): Boolean = defs.values.any { it.layer?.str("source") == id }

    private fun addEngineSource(style: Style, id: String) {
        val json = sources[id] ?: return
        try {
            style.getSource(id)?.let { style.removeSource(it) }
            style.addSource(SMapEngineStyle.source(id, json))
        } catch (e: Exception) {
            report(e)
        }
    }

    /**
     * Adds a Style Spec v8 layer, passed to the engine as it is: a layer copied from a style editor or another map
     * page works unchanged. Its `source` is a source of addSource, an inline source object, `basemap`, or an SDK
     * layer's source (`smap-<id>`). Without [SMapStyleLayerOptions.slot] or [SMapStyleLayerOptions.before] it draws on
     * top, in the order added.
     *
     * @param layer the layer as JSON text, a [JsonObject] or a map of plain values
     * @throws IllegalArgumentException for a layer the engine cannot draw
     */
    fun addStyleLayer(layer: Any, options: SMapStyleLayerOptions = SMapStyleLayerOptions()) {
        val json = SMapStyleSpec.checkLayer(SMapStyleSpec.layerObject(layer).deepCopy())
        json.objOrNull("source")?.let { SMapExternalLayers.refuseForbidden(SMapExternalLayers.sourceUrls(it)) }
        val def = LayerDef(json.str("id")!!, SMapEngineIds.Kind.STYLE, EMPTY, layer = json, styleOptions = options)
        if (json.objOrNull("layout")?.str("visibility") == "none") def.hidden = true
        define(def)
        updateAttribution()
    }

    private fun edit(layerId: String, apply: (JsonObject) -> Unit) {
        val def = defs[layerId]
        if (def != null && def.kind != SMapEngineIds.Kind.STYLE) {
            throw IllegalArgumentException("sMap: $layerId is a layer of addPoints / addLines / addPolygons; set its look with its options")
        }
        if (def != null) apply(def.layer!!) else apply(basemapEdits.getOrPut(layerId) { JsonObject() })
    }

    private fun setKey(layer: JsonObject, paint: Boolean, name: String, value: JsonElement?) {
        val group = SMapStyleSpec.section(layer, paint)
        if (value == null || value.isJsonNull) group.remove(name) else group.add(name, value.deepCopy())
    }

    /**
     * Sets a paint property of a style layer (yours or the basemap's); kept across style changes. [value] is a
     * Style Spec value as a [JsonElement] or plain values (strings, numbers, booleans, lists, maps); null puts the
     * style's default back.
     *
     * @throws IllegalArgumentException for a layer of addPoints / addLines / addPolygons (set its look with its options)
     */
    fun setPaint(layerId: String, name: String, value: Any?) {
        val v = value?.let { SMapJson.of(it) }
        edit(layerId) { setKey(it, true, name, v) }
        try { style?.getLayer(layerId)?.setProperties(SMapEngineStyle.property(true, name, v)) } catch (e: Exception) { report(e) }
    }

    /** Sets a layout property of a style layer (yours or the basemap's); kept across style changes. */
    fun setLayout(layerId: String, name: String, value: Any?) {
        val v = value?.let { SMapJson.of(it) }
        edit(layerId) { setKey(it, false, name, v) }
        val def = defs[layerId]
        if (def != null && name == "visibility") def.hidden = v?.takeIf { it.isJsonPrimitive }?.asString == "none"
        try { style?.getLayer(layerId)?.setProperties(SMapEngineStyle.property(false, name, v)) } catch (e: Exception) { report(e) }
    }

    /** Sets (or with null clears) the filter of a style layer (yours or the basemap's); kept across style changes. */
    fun setFilter(layerId: String, filter: Any?) {
        val f = filter?.let { SMapJson.of(it) }
        edit(layerId) { l -> if (f == null || f.isJsonNull) l.remove("filter") else l.add("filter", f.deepCopy()) }
        try { style?.getLayer(layerId)?.let { SMapEngineStyle.filter(it, f) } } catch (e: Exception) { report(e) }
    }

    private fun applyEdit(style: Style, id: String, edit: JsonObject) {
        val layer = style.getLayer(id) ?: return
        try {
            edit.objOrNull("paint")?.entrySet()?.forEach { (k, v) -> layer.setProperties(SMapEngineStyle.property(true, k, v)) }
            edit.objOrNull("layout")?.entrySet()?.forEach { (k, v) -> layer.setProperties(SMapEngineStyle.property(false, k, v)) }
            edit.get("filter")?.let { SMapEngineStyle.filter(layer, it) }
        } catch (e: Exception) {
            report(e)
        }
    }

    /** Called after each style has loaded and your layers are back on it (scheme, language, token or offline change). */
    var onStyleLoaded: ((SMap) -> Unit)? = null

    /** The style as it was loaded (before your layers and the basemap overrides), as JSON text; null before the first. */
    fun styleJson(): String? = basemapOriginal?.toString()

    /** A style layer as a Style Spec object (a copy): yours, or the basemap's; null when there is none. */
    fun getStyleLayer(layerId: String): JsonObject? {
        val def = defs[layerId]
        if (def != null) return if (def.kind == SMapEngineIds.Kind.STYLE) def.layer!!.deepCopy() else null
        val base = (basemapApplied ?: basemapOriginal)?.getAsJsonArray("layers")
            ?.firstOrNull { it.isJsonObject && it.asJsonObject.str("id") == layerId }?.asJsonObject?.deepCopy() ?: return null
        basemapEdits[layerId]?.let { e ->
            for (paint in listOf(true, false)) {
                e.objOrNull(if (paint) "paint" else "layout")?.entrySet()?.forEach { (k, v) -> SMapStyleSpec.section(base, paint).add(k, v.deepCopy()) }
            }
            e.get("filter")?.let { base.add("filter", it.deepCopy()) }
        }
        return base
    }

    // ------------------------------------------------------------------ files

    /**
     * Reads a file (KML, KMZ, GPX, encoded polyline, WKT, WKB, CSV, TopoJSON, GeoJSON) on the device and draws it:
     * its points as the layer [id], its lines as `<id>:lines`, its areas as `<id>:areas` (only those it has), with
     * simplestyle properties drawn when no colour is given. [removeLayer] with [id] removes all of them, [toGeoJSON]
     * gives them back together.
     *
     * @return the layer ids added
     * @throws IllegalArgumentException when the file cannot be read
     */
    fun addData(id: String, input: ByteArray, options: SMapDataOptions = SMapDataOptions()): List<String> =
        addFeatures(id, SMapFormats.readJson(input, options.format, options.lat, options.lng, options.fileName), options)

    /** [addData] for text input. */
    fun addData(id: String, input: String, options: SMapDataOptions = SMapDataOptions()): List<String> =
        addFeatures(id, SMapFormats.readJson(input, options.format, options.lat, options.lng, options.fileName), options)

    /** [addData] for parsed GeoJSON or TopoJSON. */
    fun addData(id: String, input: JsonObject, options: SMapDataOptions = SMapDataOptions()): List<String> =
        addFeatures(id, SMapFormats.readJson(input, options.format), options)

    private fun addFeatures(id: String, data: JsonObject, o: SMapDataOptions): List<String> {
        val (points, lines, areas) = SMapFormats.split(data)
        removeLayer(id)
        val added = ArrayList<String>()
        fun fc(j: JsonObject) = FeatureCollection.fromJson(j.toString())
        fun count(j: JsonObject) = j.getAsJsonArray("features").size()
        if (count(areas) > 0) { addPolygons("$id:areas", fc(areas), o.polygons); defs["$id:areas"]?.group = id; added += "$id:areas" }
        if (count(lines) > 0) { addLines("$id:lines", fc(lines), o.lines); defs["$id:lines"]?.group = id; added += "$id:lines" }
        if (count(points) > 0) { addPoints(id, fc(points), o.points); defs[id]?.group = id; added += id }
        return added
    }

    private fun geoJsonOf(layerId: String): JsonObject {
        val members = order.ids().filter { defs[it]?.group == layerId }
        if (members.isNotEmpty()) {
            val features = JsonArray()
            for (x in listOf("$layerId:areas", "$layerId:lines", layerId)) {
                if (x in members) SMapJson.parseObject(defs[x]!!.data.toJson()).getAsJsonArray("features").forEach(features::add)
            }
            return JsonObject().apply { addProperty("type", "FeatureCollection"); add("features", features) }
        }
        val def = defs[layerId]
        if (def != null && def.kind != SMapEngineIds.Kind.STYLE) return SMapJson.parseObject(def.data.toJson())
        val source = if (def != null) def.layer!!.objOrNull("source") ?: sources[def.layer!!.str("source")] else sources[layerId]
        val data = source?.takeIf { it.str("type") == "geojson" }?.get("data")
        if (data != null && data.isJsonObject) return SMapFormats.readGeojson(data.asJsonObject)
        throw IllegalArgumentException("sMap: $layerId has no GeoJSON features to give")
    }

    /** A layer's features as GeoJSON: an SDK layer, an addData group, or a style layer of a GeoJSON source. */
    fun toGeoJSON(layerId: String): FeatureCollection = FeatureCollection.fromJson(geoJsonOf(layerId).toString())

    /** [toGeoJSON] as JSON. */
    fun toGeoJSONObject(layerId: String): JsonObject = geoJsonOf(layerId)

    /** A layer's features as a KML document. */
    fun toKML(layerId: String): String = SMapFormats.toKml(geoJsonOf(layerId), layerId)

    /**
     * Converts a file on the map service (`POST /v1/convert`), for large files or formats the device should not
     * parse; this map's node, key and token are used.
     *
     * @param format one of [SMapFormats.FORMATS]; from [fileName]'s extension, else guessed from the content
     * @throws SMapException when the service refuses the file
     */
    suspend fun convert(input: ByteArray, format: String? = null, lat: String? = null, lng: String? = null, fileName: String? = null): FeatureCollection =
        FeatureCollection.fromJson(convertJson(input, format, lat, lng, fileName).toString())

    /** [convert] as JSON. */
    suspend fun convertJson(input: ByteArray, format: String? = null, lat: String? = null, lng: String? = null, fileName: String? = null): JsonObject {
        if (input.size > CONVERT_LIMIT) throw IllegalArgumentException("sMap: convert takes files of at most 20 MB")
        val f = format?.lowercase() ?: SMapFormats.formatOfName(fileName) ?: SMapFormats.guess(input)
        if (f == null || f !in SMapFormats.FORMATS) throw IllegalArgumentException("sMap: the file format could not be recognised; name the format")
        val url = SMapStyleUrl.convert(node, f, lat, lng)
        val headers = LinkedHashMap<String, String>()
        headers["Content-Type"] = "application/octet-stream"
        tokens.current?.let { headers["Authorization"] = "Bearer $it" }
        options.apiKey?.takeIf { it.isNotEmpty() }?.let { headers[SMapAppIdentity.KEY_HEADER] = it }
        val res = http.post(url, input, headers, CONVERT_TIMEOUT_MILLIS)
        if (!res.ok) {
            val msg = try {
                SMapJson.parseObject(res.body).let { it.str("message") ?: it.str("error") } ?: res.body
            } catch (e: Exception) { res.body }
            throw SMapException("sMap: convert failed (HTTP ${res.status})" + if (msg.isNotEmpty()) ": $msg" else "", url = url)
        }
        return SMapJson.parseObject(res.body)
    }

    // ------------------------------------------------------------------ external layers

    private fun addExternal(ext: SMapExternalLayer, place: SMapStyleLayerOptions) {
        addSource(ext.sourceId, ext.source)
        for (layer in ext.layers) {
            addStyleLayer(layer, place)
            if (ext.ownsSource) defs[layer.str("id")!!]?.ownsSource = ext.sourceId
        }
    }

    /** Raster tiles from any XYZ template or a TileJSON address. */
    fun addRasterLayer(id: String, options: SMapRasterOptions) =
        addExternal(SMapExternalLayers.raster(id, options), SMapStyleLayerOptions(options.before, options.slot, options.zIndex))

    /** An OGC WMS layer, one GetMap image per tile in Web Mercator. */
    fun addWmsLayer(id: String, options: SMapWmsOptions) =
        addExternal(SMapExternalLayers.wms(id, options), SMapStyleLayerOptions(options.before, options.slot, options.zIndex))

    /**
     * An OGC WMTS layer (Web Mercator matrix sets): from a REST template, from the capabilities' text, or from a
     * capabilities address (read now).
     */
    suspend fun addWmtsLayer(id: String, options: SMapWmtsOptions) {
        val place = SMapStyleLayerOptions(options.before, options.slot, options.zIndex)
        val url = options.url.orEmpty()
        if (SMapExternalLayers.isWmtsTemplate(url)) return addExternal(SMapExternalLayers.wmtsTemplate(id, options), place)
        options.capabilities?.let { return addExternal(SMapExternalLayers.wmtsFromCapabilities(id, it, options), place) }
        if (url.isEmpty()) throw IllegalArgumentException("sMap: addWmtsLayer needs url or capabilities")
        val capsUrl = SMapExternalLayers.wmtsCapabilitiesUrl(url)
        SMapExternalLayers.refuseForbidden(listOf(capsUrl))
        val res = http.get(capsUrl, FETCH_TIMEOUT_MILLIS)
        if (!res.ok) throw SMapException("sMap: WMTS capabilities: HTTP ${res.status}", url = capsUrl)
        addExternal(SMapExternalLayers.wmtsFromCapabilities(id, res.body, options), place)
    }

    /** Vector tiles from any address (templates, TileJSON, PMTiles), drawn by the given style layers. */
    fun addVectorTiles(id: String, options: SMapVectorTilesOptions) =
        addExternal(SMapExternalLayers.vectorTiles(id, options), SMapStyleLayerOptions(options.before, options.slot, options.zIndex))

    /** An ArcGIS REST MapServer / ImageServer (raster tiles) or VectorTileServer (vector tiles); its description is read now. */
    suspend fun addArcGisLayer(id: String, options: SMapArcGisOptions) {
        val base = SMapExternalLayers.arcGisBase(options.url)
        suspend fun json(u: String): JsonObject = try {
            val r = http.get(u, FETCH_TIMEOUT_MILLIS)
            if (r.ok) SMapJson.parseObject(r.body) else JsonObject()
        } catch (e: Exception) { JsonObject() }
        val info = json("$base?f=json")
        val styleLayers = if (SMapExternalLayers.isArcGisVector(base) && options.layers == null) {
            json(SMapExternalLayers.arcGisStyleUrl(base, info)).get("layers")?.takeIf { it.isJsonArray }?.asJsonArray?.toList() ?: emptyList()
        } else null
        addExternal(SMapExternalLayers.arcGis(id, options, info, styleLayers), SMapStyleLayerOptions(options.before, options.slot, options.zIndex))
    }

    /**
     * sMap's raster tiles of a style as an XYZ template, for tools without vector tiles:
     * `{node}/v1/raster/<style>/{z}/{x}/{y}[@2x].png?lang=…&key=…`.
     */
    fun rasterUrl(style: String = styleName, lang: String? = language, retina: Boolean = false): String =
        SMapStyleUrl.raster(node, style, lang, retina, options.apiKey)

    private fun updateAttribution() {
        val text = SMapAttribution.text(sources.values.map { it.str("attribution") } +
            defs.values.mapNotNull { it.layer?.objOrNull("source")?.str("attribution") })
        attributionView.text = text
        attributionView.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
    }

    // ------------------------------------------------------------------ layer description

    /** The map's layers as the shared layer description (`smap.layers` version 1): basemap, sources, layers. */
    fun toJSON(): JsonObject {
        val basemap = JsonObject().apply {
            addProperty("style", styleName)
            addProperty("language", language)
            add("overrides", basemapOverrides.deepCopy())
        }
        val entries = order.ids().mapNotNull { id ->
            val def = defs[id] ?: return@mapNotNull null
            // The shared description has points, lines, areas and style layers; custom markers and heat maps are left out.
            if (def.kind == SMapEngineIds.Kind.CUSTOM || def.kind == SMapEngineIds.Kind.HEATMAP || def.kind == SMapEngineIds.Kind.MODELS || id in snapshots) return@mapNotNull null
            val base = SMapLayerEntry(id = id, kind = "style", slot = def.slot, before = def.before, zIndex = def.zIndex,
                visible = !def.hidden, group = def.group)
            when (def.kind) {
                SMapEngineIds.Kind.STYLE -> base.copy(layer = def.layer!!.deepCopy())
                SMapEngineIds.Kind.POINTS -> base.copy(kind = "points", data = SMapJson.parseObject(def.data.toJson()), options = SMapLayerJson.pointOptions(def.points!!))
                SMapEngineIds.Kind.LINES -> base.copy(kind = "lines", data = SMapJson.parseObject(def.data.toJson()), options = SMapLayerJson.lineOptions(def.lines!!))
                SMapEngineIds.Kind.POLYGONS -> base.copy(kind = "polygons", data = SMapJson.parseObject(def.data.toJson()), options = SMapLayerJson.polygonOptions(def.polygons!!))
                SMapEngineIds.Kind.HEATMAP, SMapEngineIds.Kind.CUSTOM, SMapEngineIds.Kind.MODELS -> null
            }
        }
        return SMapLayerJson.write(basemap, sources, entries)
    }

    /** [toJSON] as text. */
    fun toJSONString(): String = SMapJson.stringify(toJSON())

    /**
     * Loads a layer description (a [JsonObject] or its text): its basemap, sources and layers, each through the call
     * that made it; an id already on the map is replaced, nothing else changes. A layer this map cannot draw is left
     * out (told through `onError`), never the whole description.
     *
     * @throws IllegalArgumentException when it is not a layer description, or a newer version
     */
    fun loadLayers(json: Any) {
        val desc = SMapLayerJson.read(if (json is JsonObject) json else SMapJson.parseObject(json.toString()))
        desc.basemap?.let { b ->
            val lang = b.str("language")
            val s = b.str("style")
            if (lang != null) language = lang
            if (s != null && s != styleName) setStyle(s) else if (lang != null) loadStyle()
            b.objOrNull("overrides")?.let { setBasemap(it) }
        }
        for ((id, src) in desc.sources) {
            try { addSource(id, src) } catch (e: Exception) { report(e) }
        }
        for (e in desc.layers) {
            try {
                when (e.kind) {
                    "style" -> addStyleLayer(e.layer ?: throw IllegalArgumentException("sMap: layer ${e.id} has no layer object"),
                        SMapStyleLayerOptions(e.before, e.slot, e.zIndex))
                    "points" -> addPoints(e.id, entryData(e), SMapLayerJson.pointOptions(e.options, e))
                    "lines" -> addLines(e.id, entryData(e), SMapLayerJson.lineOptions(e.options, e))
                    else -> addPolygons(e.id, entryData(e), SMapLayerJson.polygonOptions(e.options, e))
                }
                if (e.group != null) defs[e.id]?.group = e.group
                if (!e.visible) setVisible(e.id, false)
            } catch (x: Exception) {
                report(x)
            }
        }
    }

    private fun entryData(e: SMapLayerEntry): FeatureCollection =
        FeatureCollection.fromJson(SMapFormats.readGeojson(e.data ?: SMapFormats.collection(emptyList())).toString())

    // ------------------------------------------------------------------ engine layers

    private fun define(def: LayerDef) {
        if (def.slot != null && def.before != null) throw IllegalArgumentException("sMap: give a layer either slot or before")
        defs[def.id]?.let { old -> style?.let { drop(it, old) } }
        snapshots.remove(def.id)?.images?.values?.forEach { removeImage(it) }
        if (defs[def.id]?.kind == SMapEngineIds.Kind.CUSTOM) markers.remove(def.id)
        if (defs[def.id]?.kind == SMapEngineIds.Kind.MODELS) models?.remove(def.id)
        // A layer added under the id of a hidden data-layer tool starts hidden.
        if (tools.hidesLayer(def.id)) def.hidden = true
        defs[def.id] = def
        order.put(def.id, def.zIndex, def.slot, def.before)
        if (def.kind == SMapEngineIds.Kind.CUSTOM) { markers.put(def.id, def.custom!!, def.data); return }
        if (def.kind == SMapEngineIds.Kind.MODELS) { models().put(def.id, def.model!!, def.data); return }
        style?.let { addToStyle(it, def) }
    }

    private fun firstEngineLayer(style: Style, id: String): String? =
        defs[id]?.engineLayers?.firstOrNull { style.getLayer(it) != null }

    private fun drop(style: Style, def: LayerDef) {
        def.engineLayers.forEach { name -> style.getLayer(name)?.let { style.removeLayer(it) } }
        if (def.kind == SMapEngineIds.Kind.STYLE) {
            def.inlineSource?.let { s -> style.getSource(s)?.let { style.removeSource(it) } }
        } else {
            style.getSource(SMapEngineIds.source(def.id))?.let { style.removeSource(it) }
        }
    }

    private fun insertBelow(style: Style, id: String): String? =
        order.insertBefore(id, { anchors[it] }, { firstEngineLayer(style, it) })?.takeIf { style.getLayer(it) != null }

    private fun addToStyle(style: Style, def: LayerDef) {
        if (def.kind == SMapEngineIds.Kind.STYLE) return addStyleToStyle(style, def)
        if (def.kind == SMapEngineIds.Kind.CUSTOM || def.kind == SMapEngineIds.Kind.MODELS) return
        val src = SMapEngineIds.source(def.id)
        if (style.getSource(src) != null) drop(style, def)
        val sourceOptions = GeoJsonOptions()
        def.points?.cluster?.let {
            sourceOptions.withCluster(true).withClusterRadius(it.radius).withClusterMaxZoom(it.maxZoom)
        }
        if (def.viewClusters) { markers.put(clusterLayer(def.id), clusterMarkerOptions(def.id, def.points!!.cluster!!), EMPTY); clustersDirty = true }
        style.addSource(GeoJsonSource(src, def.data, sourceOptions))
        val before = insertBelow(style, def.id)
        val visibility = PropertyFactory.visibility(if (def.hidden) Property.NONE else Property.VISIBLE)
        val add = { layer: Layer, minZoom: Float?, maxZoom: Float? ->
            layer.setProperties(visibility)
            minZoom?.let { layer.minZoom = it }
            maxZoom?.let { layer.maxZoom = it }
            if (before != null) style.addLayerBelow(layer, before) else style.addLayer(layer)
        }
        when (def.kind) {
            SMapEngineIds.Kind.POINTS -> addPointLayers(def.id, src, def.points!!) { l -> add(l, def.points.minZoom, def.points.maxZoom) }
            SMapEngineIds.Kind.LINES -> {
                val o = def.lines!!
                // simplestyle (stroke, stroke-width, stroke-opacity) when the layer gives no colour of its own
                val simple = o.color == null
                val layer = LineLayer(SMapEngineIds.lines(def.id), src).withProperties(
                    if (simple) PropertyFactory.lineColor(raw(SMapSimpleStyle.color("stroke", DEFAULT_COLOR))) else PropertyFactory.lineColor(o.color!!),
                    if (simple && o.width == DEFAULT_LINE_WIDTH) PropertyFactory.lineWidth(raw(SMapSimpleStyle.number("stroke-width", DEFAULT_LINE_WIDTH)))
                    else PropertyFactory.lineWidth(o.width),
                    if (simple && o.opacity == 1f) PropertyFactory.lineOpacity(raw(SMapSimpleStyle.number("stroke-opacity", 1)))
                    else PropertyFactory.lineOpacity(o.opacity),
                    PropertyFactory.lineCap(Property.LINE_CAP_ROUND),
                    PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
                )
                o.dash?.let { layer.setProperties(PropertyFactory.lineDasharray(it.toTypedArray())) }
                add(layer, o.minZoom, o.maxZoom)
                if (o.label != null) {
                    // A permanent label along each line (a route's name), repeated along long lines.
                    add(
                        SymbolLayer(SMapEngineIds.lineLabels(def.id), src).withProperties(
                            PropertyFactory.symbolPlacement(Property.SYMBOL_PLACEMENT_LINE),
                            PropertyFactory.symbolSpacing(o.labelSpacing),
                            PropertyFactory.textField(Expression.toString(Expression.get(o.label))),
                            PropertyFactory.textFont(arrayOf(LABEL_FONT)),
                            PropertyFactory.textSize(12f),
                            PropertyFactory.textKeepUpright(true),
                            PropertyFactory.textColor(o.labelColor),
                            PropertyFactory.textHaloColor("#ffffff"),
                            PropertyFactory.textHaloWidth(1.6f),
                        ),
                        o.minZoom, o.maxZoom,
                    )
                }
            }
            SMapEngineIds.Kind.HEATMAP -> {
                val o = def.heatmap!!
                add(HeatmapLayer(SMapEngineIds.heat(def.id), src).withProperties(
                    PropertyFactory.heatmapWeight(o.weight?.let { w -> if (w is SMapValue.Fixed) Expression.literal(w.value) else Expression.coalesce(Expression.toNumber(Expression.get((w as SMapValue.Property).name)), Expression.literal(1)) } ?: Expression.literal(1)),
                    PropertyFactory.heatmapRadius(o.radius),
                    PropertyFactory.heatmapIntensity(o.intensity),
                    PropertyFactory.heatmapOpacity(o.opacity),
                    PropertyFactory.heatmapColor(SMapHeat.ramp(o.colors)),
                ), o.minZoom, o.maxZoom)
            }
            SMapEngineIds.Kind.CUSTOM, SMapEngineIds.Kind.MODELS -> Unit
            SMapEngineIds.Kind.POLYGONS -> {
                val o = def.polygons!!
                val extrude = o.extrude
                if (extrude != null) {
                    add(
                        FillExtrusionLayer(SMapEngineIds.extrusion(def.id), src).withProperties(
                            PropertyFactory.fillExtrusionColor(o.fill ?: DEFAULT_COLOR),
                            PropertyFactory.fillExtrusionHeight(valueExpression(extrude.height)),
                            PropertyFactory.fillExtrusionBase(valueExpression(extrude.base)),
                            PropertyFactory.fillExtrusionOpacity(o.opacity),
                        ),
                        o.minZoom, o.maxZoom,
                    )
                } else if (o.fill == null) {
                    // simplestyle (fill, fill-opacity, stroke, stroke-width, stroke-opacity) of each feature
                    add(
                        FillLayer(SMapEngineIds.fill(def.id), src).withProperties(
                            PropertyFactory.fillColor(raw(SMapSimpleStyle.color("fill", DEFAULT_COLOR))),
                            if (o.opacity == DEFAULT_FILL_OPACITY) PropertyFactory.fillOpacity(raw(SMapSimpleStyle.number("fill-opacity", DEFAULT_FILL_OPACITY)))
                            else PropertyFactory.fillOpacity(o.opacity),
                        ),
                        o.minZoom, o.maxZoom,
                    )
                    add(
                        LineLayer(SMapEngineIds.outline(def.id), src).withProperties(
                            if (o.outline != null) PropertyFactory.lineColor(o.outline) else PropertyFactory.lineColor(raw(SMapSimpleStyle.outlineColor(DEFAULT_COLOR))),
                            if (o.outlineWidth == DEFAULT_OUTLINE_WIDTH) PropertyFactory.lineWidth(raw(SMapSimpleStyle.number("stroke-width", DEFAULT_OUTLINE_WIDTH)))
                            else PropertyFactory.lineWidth(o.outlineWidth),
                            PropertyFactory.lineOpacity(raw(SMapSimpleStyle.number("stroke-opacity", 1))),
                        ),
                        o.minZoom, o.maxZoom,
                    )
                } else {
                    add(
                        FillLayer(SMapEngineIds.fill(def.id), src).withProperties(
                            PropertyFactory.fillColor(o.fill),
                            PropertyFactory.fillOpacity(o.opacity),
                        ),
                        o.minZoom, o.maxZoom,
                    )
                    add(
                        LineLayer(SMapEngineIds.outline(def.id), src).withProperties(
                            PropertyFactory.lineColor(o.outline ?: o.fill),
                            PropertyFactory.lineWidth(o.outlineWidth),
                        ),
                        o.minZoom, o.maxZoom,
                    )
                }
            }
            SMapEngineIds.Kind.STYLE -> Unit
        }
    }

    private fun raw(json: JsonElement): Expression = SMapRawExpression.of(json)

    private fun addStyleToStyle(style: Style, def: LayerDef) {
        drop(style, def)
        var json = def.layer!!
        try {
            val inline = def.inlineSource
            if (inline != null) {
                style.addSource(SMapEngineStyle.source(inline, json.getAsJsonObject("source")))
                json = json.deepCopy().apply { addProperty("source", inline) }
            }
            val layer = SMapEngineStyle.layer(json, def.hidden)
            val before = insertBelow(style, def.id)
            if (before != null) style.addLayerBelow(layer, before) else style.addLayer(layer)
        } catch (e: Exception) {
            report(e)
        }
    }

    private fun addPointLayers(id: String, src: String, o: SMapPointOptions, add: (Layer) -> Unit) {
        val unclustered = Expression.not(Expression.has("point_count"))
        // Clusters drawn as views (ring or render) have no circles of their own.
        if (o.cluster != null && o.cluster.ring == null && o.cluster.render == null) {
            add(
                CircleLayer(SMapEngineIds.clusters(id), src).withFilter(Expression.has("point_count")).withProperties(
                    PropertyFactory.circleColor(o.color ?: DEFAULT_COLOR),
                    PropertyFactory.circleOpacity(0.85f),
                    PropertyFactory.circleRadius(
                        Expression.step(
                            Expression.get("point_count"), Expression.literal(14),
                            Expression.stop(50, 18), Expression.stop(500, 24), Expression.stop(5000, 30),
                        ),
                    ),
                    PropertyFactory.circleStrokeWidth(3f),
                    PropertyFactory.circleStrokeColor("rgba(255,255,255,0.75)"),
                ),
            )
            add(
                SymbolLayer(SMapEngineIds.clusterCount(id), src).withFilter(Expression.has("point_count")).withProperties(
                    PropertyFactory.textField(Expression.toString(Expression.get("point_count_abbreviated"))),
                    PropertyFactory.textFont(arrayOf(LABEL_FONT)),
                    PropertyFactory.textSize(12f),
                    PropertyFactory.textAllowOverlap(true),
                    PropertyFactory.textIgnorePlacement(true),
                    PropertyFactory.textColor("#ffffff"),
                ),
            )
        }
        if (o.cluster != null && (o.cluster.ring != null || o.cluster.render != null)) {
            // The view clusters are read from this layer: the clusters drawn this frame, so they match the points drawn
            // beside them (the source also holds tiles kept from another zoom while new ones load). An opacity of 0
            // would leave it out of the engine's queries; 0.004 changes no pixel.
            add(
                CircleLayer(SMapEngineIds.clusterHits(id), src).withFilter(Expression.has("point_count")).withProperties(
                    PropertyFactory.circleColor("#ffffff"),
                    PropertyFactory.circleOpacity(0.004f),
                    PropertyFactory.circleRadius(24f),
                ),
            )
        }
        val main = if (o.icon != null || o.iconProperty != null) {
            SymbolLayer(SMapEngineIds.points(id), src).withProperties(
                if (o.iconProperty != null) PropertyFactory.iconImage(Expression.get(o.iconProperty)) else PropertyFactory.iconImage(o.icon),
                PropertyFactory.iconSize(o.iconSize),
                PropertyFactory.iconAllowOverlap(true),
                PropertyFactory.iconIgnorePlacement(o.iconProperty != null),
                // Own images per point stack in data order (later on top), as live markers do.
                PropertyFactory.symbolZOrder(if (o.iconProperty != null) Property.SYMBOL_Z_ORDER_SOURCE else Property.SYMBOL_Z_ORDER_AUTO),
                PropertyFactory.iconAnchor(o.iconAnchor.engineName),
            ).apply {
                if (o.iconOffsetDp != 0f to 0f) setProperties(PropertyFactory.iconOffset(arrayOf(o.iconOffsetDp.first, o.iconOffsetDp.second)))
                o.iconOpacityProperty?.let { setProperties(PropertyFactory.iconOpacity(Expression.toNumber(Expression.coalesce(Expression.get(it), Expression.literal(1))))) }
                o.sortProperty?.let { setProperties(PropertyFactory.symbolSortKey(Expression.toNumber(Expression.coalesce(Expression.get(it), Expression.literal(0))))) }
            }
        } else {
            CircleLayer(SMapEngineIds.points(id), src).withProperties(
                // simplestyle (marker-color, marker-size) when the layer gives no colour of its own
                if (o.color != null) PropertyFactory.circleColor(o.color) else PropertyFactory.circleColor(raw(SMapSimpleStyle.color("marker-color", DEFAULT_COLOR))),
                if (o.color == null && o.radius == DEFAULT_RADIUS) PropertyFactory.circleRadius(raw(SMapSimpleStyle.markerRadius()))
                else PropertyFactory.circleRadius(o.radius),
                PropertyFactory.circleStrokeWidth(1.5f),
                PropertyFactory.circleStrokeColor(o.strokeColor),
            ).apply { o.sortProperty?.let { setProperties(PropertyFactory.circleSortKey(Expression.toNumber(Expression.coalesce(Expression.get(it), Expression.literal(0))))) } }
        }
        if (o.cluster != null) {
            if (main is SymbolLayer) main.setFilter(unclustered) else (main as CircleLayer).setFilter(unclustered)
        }
        add(main)
        if (o.label != null) {
            val labels = SymbolLayer(SMapEngineIds.labels(id), src).withProperties(
                PropertyFactory.textField(Expression.toString(Expression.get(o.label))),
                PropertyFactory.textFont(arrayOf(LABEL_FONT)),
                PropertyFactory.textSize(12f),
                PropertyFactory.textOffset(arrayOf(0f, 1.2f)),
                PropertyFactory.textAnchor(Property.TEXT_ANCHOR_TOP),
                PropertyFactory.textOptional(true),
                PropertyFactory.textColor("#1f2937"),
                PropertyFactory.textHaloColor("#ffffff"),
                PropertyFactory.textHaloWidth(1.4f),
            )
            if (o.cluster != null) labels.setFilter(unclustered)
            add(labels)
        }
    }

    private fun valueExpression(v: SMapValue): Expression = when (v) {
        is SMapValue.Fixed -> Expression.literal(v.value)
        is SMapValue.Property -> Expression.coalesce(Expression.toNumber(Expression.get(v.name)), Expression.literal(0))
    }

    // ------------------------------------------------------------------ map tools

    /**
     * Lays the app's [view] over the map as a tool, shown or hidden by the tools control, [setToolVisible] and
     * [setToolsVisible]. In a corner the view must not have a parent; with [SMapToolPosition.NONE] it stays where the
     * app put it and is only shown and hidden. Adding an id again replaces the first.
     *
     * @param id 1-64 letters, digits, `-`, `_` or `.`
     * @param label shown on the tool's row in the tools control and read by screen readers
     */
    fun addTool(id: String, view: View, label: String = id, position: SMapToolPosition = SMapToolPosition.TOP_LEFT) {
        SMapToolRegistry.checkId(id)
        SMapToolRegistry.checkPosition(position)
        require(position == SMapToolPosition.NONE || view.parent == null) { "sMap: a tool laid in a corner must not have a parent" }
        placeTool(SMapToolRegistry.Entry(id, label, position, null, view))
    }

    /**
     * Registers data layers as a tool: hiding it hides every layer in [layers] (layout visibility), showing it shows
     * them. The layers are the SDK's own (addPoints, addLines, addPolygons, addData groups, style and external layers)
     * or the basemap's. A layer that is not on the map is left alone; one added later under the id of a hidden tool
     * starts hidden. The tool has no view and no corner. Adding an id again replaces the first.
     *
     * @param layers one or more layer ids (a layer and its labels, …); a repeated id counts once
     */
    fun addTool(id: String, layers: List<String>, label: String = id) {
        SMapToolRegistry.checkId(id)
        val ids = SMapToolRegistry.checkLayers(layers)
        tools.add(SMapToolRegistry.Entry<View?>(id, label, SMapToolPosition.NONE, null, null, ids))?.let(::takeOff)
        joinControl()
        // A tool hidden from the start hides its layers now; a shown one leaves them as they are.
        if (!tools.isVisible(id)) applyLayers(ids, false)
        placeControl()
        renderTools()
    }

    /** Registers one data layer as a tool (see the list form). */
    fun addTool(id: String, layer: String, label: String = id) = addTool(id, listOf(layer), label)

    /** Adds a tool the SDK makes ([SMapToolKind]); its English label and corner unless given. */
    fun addTool(id: String, kind: SMapToolKind, label: String? = null, position: SMapToolPosition? = null) {
        SMapToolRegistry.checkId(id)
        val at = position ?: kind.position
        SMapToolRegistry.checkPosition(at)
        require(at != SMapToolPosition.NONE) { "sMap: a tool the SDK makes sits in a corner" }
        val name = label ?: kind.label
        val view: View = when (kind) {
            SMapToolKind.ZOOM -> SMapZoomTool(context, name) { step ->
                engine?.animateCamera(if (step > 0) CameraUpdateFactory.zoomIn() else CameraUpdateFactory.zoomOut())
            }
            SMapToolKind.COMPASS -> SMapCompassTool(context, name) {
                engine?.animateCamera(CameraUpdateFactory.bearingTo(0.0))
            }
            SMapToolKind.SCALE -> SMapScaleTool(context, name, SMapToolRegistry.usesMiles(Locale.getDefault().country))
            SMapToolKind.LOCATE -> SMapLocateTool(context, name) { locate() }
        }
        placeTool(SMapToolRegistry.Entry(id, name, at, kind, view))
    }

    /** Removes a tool: a corner view leaves the map, a view the app placed is shown again. */
    fun removeTool(id: String) {
        val entry = tools.remove(id) ?: return
        takeOff(entry)
        placeControl()
        renderTools()
    }

    /** Shows or hides one tool. A hidden tool keeps its state and comes back as it was. */
    fun setToolVisible(id: String, visible: Boolean) {
        tools.setVisible(id, visible).forEach { tools[it]?.let(::showTool) }
        renderTools()
    }

    /** Shows or hides every tool. The attribution and the sMap badge always stay. */
    fun setToolsVisible(visible: Boolean) {
        tools.setAllVisible(visible).forEach { tools[it]?.let(::showTool) }
        renderTools()
    }

    /** The tools in the order added. */
    fun tools(): List<SMapToolState> = tools.states()

    /** Called after every change of the tools' visibility; the SDK keeps no state itself. */
    fun addToolsChangeListener(listener: (SMapToolsChange) -> Unit) = tools.addListener(listener)
    fun removeToolsChangeListener(listener: (SMapToolsChange) -> Unit) = tools.removeListener(listener)

    private fun placeTool(entry: SMapToolRegistry.Entry<View?>) {
        tools.add(entry)?.let(::takeOff)
        joinControl()
        val view = entry.payload
        if (view != null && entry.position != SMapToolPosition.NONE) corners().add(entry.position, view)
        if (entry.kind == SMapToolKind.COMPASS) engine?.uiSettings?.isCompassEnabled = false
        showTool(entry)
        placeControl()
        updateToolViews()
        renderTools()
    }

    // The tools control joins the map with its first tool, so a map without tools is as before.
    private fun joinControl() {
        val control = options.tools.control
        if (toolsControl != null || control == null) return
        val at = controlCorner(control)
        toolsControl = SMapToolsControl(context, at, options.tools.labels,
            onToggle = { id -> setToolVisible(id, !tools.isVisible(id)) },
            onAll = { on -> setToolsVisible(on) },
            onOpen = { open -> toolsControl?.let { corners().raise(it.position, open) } },
        ).also { corners().add(at, it, last = true) }
    }

    private fun controlCorner(control: SMapToolPosition): SMapToolPosition =
        if (control == SMapToolPosition.TOOLBAR) tools.toolbarCorner() else control

    // The tools control is the last of its corner's tools: by default the toolbar's (the corner of the zoom tool, which
    // may change as tools come and go), kept last when tools join the corner later. Its corner is drawn above the others.
    private fun placeControl() {
        val control = toolsControl ?: return
        val at = controlCorner(options.tools.control ?: return)
        val corners = corners()
        if (control.position == at && corners.isLast(at, control)) return
        val open = control.isOpen
        if (open) corners.raise(control.position, false)
        corners.remove(control)
        if (control.position != at) control.layOut(at)
        corners.add(at, control, last = true)
        corners.raise(at, open)
    }

    private fun corners(): SMapToolCorners = toolCorners ?: SMapToolCorners(this).also { toolCorners = it }

    private fun takeOff(entry: SMapToolRegistry.Entry<View?>) {
        val layers = entry.layers
        if (layers != null) {
            // A removed data-layer tool leaves its layers shown, as a removed view is shown again.
            if (!tools.isVisible(entry.id)) applyLayers(layers, true)
            return
        }
        val view = entry.payload ?: return
        if (entry.position == SMapToolPosition.NONE) {
            view.visibility = View.VISIBLE
        } else {
            toolCorners?.remove(view)
        }
    }

    private fun showTool(entry: SMapToolRegistry.Entry<View?>) {
        entry.layers?.let { applyLayers(it, tools.isVisible(entry.id)); return }
        val view = entry.payload ?: return
        // The compass shows only while the map is rotated, like the engine's own.
        val rotated = entry.kind != SMapToolKind.COMPASS || (engine?.cameraPosition?.bearing ?: 0.0) != 0.0
        view.visibility = if (tools.isVisible(entry.id) && rotated) View.VISIBLE else View.GONE
    }

    // A data-layer tool's layers: the SDK's own through setVisible (kept across style changes), the basemap's through
    // their layout visibility; a layer that is not on the map is left alone (nothing is recorded for it).
    private fun applyLayers(layers: List<String>, visible: Boolean, s: Style? = style) {
        for (id in layers) {
            if (defs[id] != null) {
                setVisible(id, visible)
            } else if (s?.getLayer(id) != null) {
                val value = if (visible) Property.VISIBLE else Property.NONE
                edit(id) { setKey(it, false, "visibility", JsonPrimitive(value)) }
                try { s.getLayer(id)?.setProperties(PropertyFactory.visibility(value)) } catch (e: Exception) { report(e) }
            }
        }
    }

    // After a style loads: the basemap layers of hidden data-layer tools (the SDK's own layers keep their state).
    private fun hideLayerTools(s: Style) {
        for (entry in tools.all) {
            val layers = entry.layers ?: continue
            if (!tools.isVisible(entry.id)) applyLayers(layers.filter { defs[it] == null }, false, s)
        }
    }

    private fun renderTools() {
        toolsControl?.render(tools.states())
    }

    // The marker views follow the camera; view clusters are read again when it stops.
    private fun attachOverlay(map: MapLibreMap) {
        markers.map = map
        models?.map = map
        map.addOnCameraMoveListener { markers.layout(); interaction.cameraMoved(); models?.invalidateModels(); clustersMoving = true; clustersDirty = true }
        map.addOnCameraIdleListener { models?.invalidateModels() }
        map.addOnCameraIdleListener { markers.layout(); clustersMoving = false; clustersDirty = true; readClustersUntilSettled(0) }
        // The clusters drawn change with the frames: after a change (camera, data, style) they are read at the next
        // drawn frames — every frame while the camera moves (zooming splits and merges them), else at most every
        // 200 ms — until two reads agree. A frame drawn while tiles still load (not fully rendered) shows the tiles
        // of the zoom before in their place, so the clusters are read again until the engine has drawn them all.
        // Nothing is left to draw (every tile loaded): one last read, whatever earlier reads agreed on.
        mapView.addOnDidBecomeIdleListener { if (clusterSignatures.isNotEmpty()) { refreshClusters(); clustersDirty = false } }
        mapView.addOnDidFinishRenderingFrameListener { fully, _, _ ->
            if (!fully && clusterSignatures.isNotEmpty()) clustersDirty = true
            val now = android.os.SystemClock.uptimeMillis()
            if (clustersDirty && (clustersMoving || now - clustersReadAt >= 200)) { clustersReadAt = now; if (refreshClusters()) clustersDirty = false }
        }
        markers.layout()
    }

    private fun attachTools(map: MapLibreMap) {
        attachOverlay(map)
        if (tools.all.any { it.kind == SMapToolKind.COMPASS }) map.uiSettings.isCompassEnabled = false
        map.addOnCameraMoveListener { updateToolViews() }
        map.addOnCameraIdleListener { updateToolViews() }
        updateToolViews()
    }

    private fun updateToolViews() {
        val map = engine ?: return
        val camera = map.cameraPosition
        for (entry in tools.all) {
            when (val view = entry.payload ?: continue) {
                is SMapScaleTool -> view.update(map.projection.getMetersPerPixelAtLatitude(camera.target?.latitude ?: 0.0))
                is SMapCompassTool -> { view.setBearing(camera.bearing); showTool(entry) }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun locate() {
        val map = engine ?: return
        val granted = listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            .any { context.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        if (!granted) {
            report(SMapException("sMap: the app does not hold the location permission"))
            return
        }
        val manager = context.getSystemService(LocationManager::class.java)
        val last = manager?.getProviders(true)?.mapNotNull { provider ->
            try { manager.getLastKnownLocation(provider) } catch (e: SecurityException) { null }
        }?.maxByOrNull { it.time }
        if (last == null) {
            report(SMapException("sMap: the device's position is not known yet"))
            return
        }
        val zoom = maxOf(map.cameraPosition.zoom, LOCATE_ZOOM)
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(last.latitude, last.longitude), zoom))
    }

    // ------------------------------------------------------------------ taps

    private fun handleTap(map: MapLibreMap, latLng: LatLng): Boolean {
        toolsControl?.open(false)
        val s = style ?: return false
        val point = map.projection.toScreenLocation(latLng)
        for (id in order.ids().asReversed()) {
            val def = defs[id] ?: continue
            if (def.hidden) continue
            if (def.points?.cluster != null) {
                val clusters = SMapEngineIds.clusters(id)
                if (s.getLayer(clusters) != null) {
                    val hit = map.queryRenderedFeatures(point, clusters).firstOrNull()
                    if (hit != null) {
                        val source = s.getSourceAs<GeoJsonSource>(SMapEngineIds.source(id))
                        val geometry = hit.geometry() as? Point
                        if (source != null && geometry != null) {
                            val zoom = source.getClusterExpansionZoom(hit).toDouble()
                            map.animateCamera(
                                CameraUpdateFactory.newLatLngZoom(LatLng(geometry.latitude(), geometry.longitude()), zoom),
                            )
                        }
                        return true
                    }
                }
            }
            val handler = tapHandlers[id] ?: continue
            val layer = SMapEngineIds.tapLayer(id, def.kind, def.polygons?.extrude != null)
            if (s.getLayer(layer) == null) continue
            val hit = featureAt(map, id, layer, point) ?: continue
            handler(SMapGeoJson.propertiesOf(hit), latLng)
            return true
        }
        return false
    }

    // ------------------------------------------------------------------ controls, imagery, terrain, sync, Google, drawn tiles (G8, G10, G11, G13, G14)

    /** The app's own [view] in a corner of the map, not a tool (never hidden by the tools control). */
    fun addControl(view: View, position: SMapToolPosition = SMapToolPosition.TOP_RIGHT) {
        require(position != SMapToolPosition.NONE) { "sMap: a control sits in a corner" }
        require(view.parent == null) { "sMap: a control must not have a parent" }
        corners().add(position, view)
    }

    fun removeControl(view: View) { (view.parent as? ViewGroup)?.removeView(view) }

    private var baseImagery: SMapBaseImagery? = null
    private val imageryHid = ArrayList<String>()

    /** Imagery in place of the street map (satellite, aerial), under the labels; null goes back to the street map. */
    fun setBaseImagery(imagery: SMapBaseImagery?) {
        if (imagery != null) {
            require(imagery.tiles.isNotEmpty()) { "sMap: base imagery needs tiles" }
            SMapExternalLayers.refuseForbidden(imagery.tiles)
        }
        setImagery(imagery)
    }

    /** The imagery shown now, or null. */
    fun baseImagery(): SMapBaseImagery? = baseImagery

    private fun setImagery(imagery: SMapBaseImagery?) {
        baseImagery = imagery
        style?.let { applyImagery(it) }
    }

    private fun applyImagery(s: Style) {
        s.getLayer(BASE_IMAGERY)?.let(s::removeLayer)
        s.getSource(BASE_IMAGERY)?.let(s::removeSource)
        imageryHid.forEach { id -> s.getLayer(id)?.setProperties(PropertyFactory.visibility(Property.VISIBLE)) }
        imageryHid.clear()
        val b = baseImagery ?: return
        val set = org.maplibre.android.style.sources.TileSet("2.2.0", *b.tiles.toTypedArray()).apply {
            b.minZoom?.let { minZoom = it }
            b.maxZoom?.let { maxZoom = it }
            b.attribution?.let { attribution = it }
            if (b.tms) scheme = "tms"
        }
        s.addSource(org.maplibre.android.style.sources.RasterSource(BASE_IMAGERY, set, b.tileSize))
        val labelsAt = anchors[SMapSlot.LABELS]?.takeIf { s.getLayer(it) != null }
        val layer = org.maplibre.android.style.layers.RasterLayer(BASE_IMAGERY, BASE_IMAGERY)
        if (labelsAt != null) s.addLayerBelow(layer, labelsAt) else s.addLayer(layer)
        if (!b.labels && labelsAt != null) {
            // The basemap's labels: every basemap layer from where the labels slot begins.
            val ids = basemapOriginal?.getAsJsonArray("layers")?.mapNotNull { it.asJsonObject.str("id") } ?: emptyList()
            val from = ids.indexOf(labelsAt)
            if (from >= 0) ids.drop(from).forEach { id ->
                val l = s.getLayer(id) ?: return@forEach
                if (l.visibility.value == Property.NONE) return@forEach
                l.setProperties(PropertyFactory.visibility(Property.NONE))
                imageryHid += id
            }
        }
    }

    /** The layer switcher as a tool (G8): base maps one at a time and overlays each on or off. */
    fun addTool(id: String, layers: SMapLayersTool, label: String = "Layers", position: SMapToolPosition = SMapToolPosition.TOP_RIGHT) {
        val view = SMapLayersToolView(context, layers, position, label,
            applyBase = { b ->
                b.style?.takeIf { it != styleName }?.let { setStyle(it) }
                setImagery(b.imagery?.also { SMapExternalLayers.refuseForbidden(it.tiles) })
            },
            applyOverlay = { ov, on -> ov.layers.forEach { setVisible(it, on) } },
        )
        addTool(id, view, label, position)
        ready { view.start() }
    }

    private var terrain: SMapTerrain? = null

    /** Relief over elevation tiles (G11): hillshading under the roads; null takes it off. */
    fun setTerrain(terrain: SMapTerrain?) {
        if (terrain != null) require(terrain.tiles.isNotEmpty()) { "sMap: terrain needs tiles" }
        this.terrain = terrain
        style?.let { applyTerrain(it) }
        if (terrain != null) unsupported("terrain")
    }

    private fun applyTerrain(s: Style) {
        s.getLayer(HILLSHADE)?.let(s::removeLayer)
        s.getSource(TERRAIN_SOURCE)?.let(s::removeSource)
        val t = terrain ?: return
        val set = org.maplibre.android.style.sources.TileSet("2.2.0", *t.tiles.toTypedArray()).apply {
            maxZoom = t.maxZoom
            t.attribution?.let { attribution = it }
            encoding = t.encoding
        }
        s.addSource(org.maplibre.android.style.sources.RasterDemSource(TERRAIN_SOURCE, set, t.tileSize))
        if (!t.hillshade) return
        val layer = org.maplibre.android.style.layers.HillshadeLayer(HILLSHADE, TERRAIN_SOURCE).withProperties(
            PropertyFactory.hillshadeExaggeration(t.hillshadeExaggeration),
        )
        t.shadowColor?.let { layer.setProperties(PropertyFactory.hillshadeShadowColor(arrayOf(it))) }
        t.highlightColor?.let { layer.setProperties(PropertyFactory.hillshadeHighlightColor(arrayOf(it))) }
        val roads = anchors[SMapSlot.ROADS]?.takeIf { s.getLayer(it) != null }
        if (roads != null) s.addLayerBelow(layer, roads) else s.addLayer(layer)
    }

    private val saidUnsupported = HashSet<String>()
    private fun unsupported(what: String) { if (saidUnsupported.add(what)) options.onUnsupported?.invoke(what) }

    /**
     * Keeps [other] on this map's view, both ways (G13): centre, zoom + [offsetZoom], bearing and tilt. Returns a
     * function that ends it.
     */
    fun syncWith(other: SMap, offsetZoom: Double = 0.0): () -> Unit {
        var busy = false
        var stopped = false
        val listeners = ArrayList<Pair<MapLibreMap, MapLibreMap.OnCameraMoveListener>>()
        fun copy(from: SMap, to: SMap, dz: Double) = MapLibreMap.OnCameraMoveListener {
            val a = from.engine ?: return@OnCameraMoveListener
            val b = to.engine ?: return@OnCameraMoveListener
            if (busy || stopped) return@OnCameraMoveListener
            busy = true
            try {
                val c = a.cameraPosition
                b.moveCamera(CameraUpdateFactory.newCameraPosition(CameraPosition.Builder().target(c.target).zoom(c.zoom + dz).bearing(c.bearing).tilt(c.tilt).build()))
            } finally { busy = false }
        }
        ready { me ->
            other.ready { _ ->
                if (stopped) return@ready
                val a = copy(me, other, offsetZoom)
                val b = copy(other, me, -offsetZoom)
                me.engine!!.addOnCameraMoveListener(a); listeners += me.engine!! to a
                other.engine!!.addOnCameraMoveListener(b); listeners += other.engine!! to b
                a.onCameraMove()
            }
        }
        return { stopped = true; listeners.forEach { (m, l) -> m.removeOnCameraMoveListener(l) } }
    }

    private var google: SMapGoogleState? = null

    /**
     * Google's base maps read straight from Google with the app's Map Tiles session (G10), shown as base imagery with
     * the Google logo and the copyright of the area in view, bottom left. null takes them off.
     */
    fun setGoogleBase(g: SMapGoogleBase?) {
        google?.stop()
        google = null
        if (g == null) { setImagery(null); return }
        require(g.tiles != null || (g.session != null && g.key != null)) { "sMap: a Google layer needs session and key, or tiles" }
        val state = SMapGoogleState(this, g)
        google = state
        setImagery(SMapBaseImagery(listOf(state.tiles), 256, maxZoom = g.maxZoom, labels = g.labels))
        state.start()
    }

    internal fun googleCorner(view: View) = corners().add(SMapToolPosition.BOTTOM_LEFT, view, last = true)

    private val canvasKeys = HashMap<String, String>()

    /**
     * Raster tiles the app paints (G14): [draw] gets a canvas scaled to [tileSize] × [tileSize] density-independent
     * pixels and the tile's z / x / y; it runs on the engine's network thread.
     */
    fun addCanvasTiles(id: String, tileSize: Int = 256, minZoom: Double? = null, maxZoom: Double? = null, opacity: Double? = null, draw: (android.graphics.Canvas, Int, Int, Int, Int) -> Unit) {
        canvasKeys.remove(id)?.let(SMapLocalTiles::unregister)
        val key = SMapLocalTiles.register(SMapLocalTiles.Drawer(tileSize, min(3f, resources.displayMetrics.density), draw))
        canvasKeys[id] = key
        addRasterLayer(id, SMapRasterOptions(tiles = listOf(SMapLocalTiles.url(key)), tileSize = tileSize, minzoom = minZoom, maxzoom = maxZoom, opacity = opacity))
    }

    // ------------------------------------------------------------------ drawing and selection (G3, G4)

    private val drawTools = ArrayList<SMapDrawTool>()
    private var selecting: SMapSelect? = null

    /** A drawing and editing tool on this map (G3). */
    fun drawTool(options: SMapDrawOptions = SMapDrawOptions()): SMapDrawTool = SMapDrawTool(this, options)

    internal fun attachDraw(tool: SMapDrawTool) { drawTools += tool; if (selecting == null) interaction.capture = tool }
    internal fun detachDraw(tool: SMapDrawTool) {
        drawTools -= tool
        if (interaction.capture === tool) interaction.capture = drawTools.lastOrNull()
    }

    /**
     * Selects features by drawing on the map (G4): a box (default) or a free shape ([lasso]); [done] gets the features
     * of each of [layers] (default every point, custom marker, line and area layer) inside it, or null when cancelled.
     */
    fun selectArea(lasso: Boolean = false, layers: List<String>? = null, cancelLabel: String = "Cancel", done: (SMapSelection?) -> Unit) {
        selecting?.let { endSelect(it) }
        val ids = layers ?: order.ids().filter { defs[it]?.kind in listOf(SMapEngineIds.Kind.POINTS, SMapEngineIds.Kind.CUSTOM, SMapEngineIds.Kind.LINES, SMapEngineIds.Kind.POLYGONS) && defs[it]?.hidden == false }
        val view = SMapSelect(context, this, lasso, ids, cancelLabel, done)
        selecting = view
        addView(view, indexOfChild(markers) + 1, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        interaction.capture = view
    }

    /** [selectArea] as a suspending call. */
    suspend fun selectArea(lasso: Boolean = false, layers: List<String>? = null, cancelLabel: String = "Cancel"): SMapSelection? {
        val result = CompletableDeferred<SMapSelection?>()
        selectArea(lasso, layers, cancelLabel) { result.complete(it) }
        return result.await()
    }

    internal fun endSelect(view: SMapSelect) {
        if (selecting !== view) return
        selecting = null
        removeView(view)
        interaction.capture = drawTools.lastOrNull()
    }

    // ------------------------------------------------------------------ custom markers, view clusters (G1, G6)

    private fun clusterLayer(id: String) = "$id:clusters"

    // The marker layers in draw order: custom marker layers, and the view clusters of a point layer at its place.
    private fun markerOrder(): List<String> = order.ids().mapNotNull { id ->
        val def = defs[id] ?: return@mapNotNull null
        when {
            def.kind == SMapEngineIds.Kind.CUSTOM -> id
            def.viewClusters -> clusterLayer(id)
            else -> null
        }
    }

    private fun clusterInfo(id: String, f: org.maplibre.geojson.Feature): SMapClusterInfo {
        val p = SMapGeoJson.propertiesOf(f)
        val g = f.geometry() as Point
        return SMapClusterInfo((p["cluster_id"] as? Number)?.toInt() ?: 0, (p["point_count"] as? Number)?.toInt() ?: 0, p, LatLng(g.latitude(), g.longitude())) { limit ->
            style?.getSourceAs<GeoJsonSource>(SMapEngineIds.source(id))?.getClusterLeaves(f, limit, 0)?.features() ?: emptyList()
        }
    }

    private val clusterFeatures = HashMap<String, Map<String, org.maplibre.geojson.Feature>>()
    private var clustersDirty = false
    private val clusterSignatures = HashMap<String, String>()
    private var clustersMoving = false
    private var clustersReadAt = 0L

    private fun clusterMarkerOptions(id: String, c: SMapCluster) = SMapCustomMarkerOptions(
        render = { p ->
            val f = clusterFeatures[id]?.get("c" + ((p["cluster_id"] as? Number)?.toInt() ?: 0))
            val info = if (f != null) clusterInfo(id, f) else SMapClusterInfo(0, (p["point_count"] as? Number)?.toInt() ?: 0, p, LatLng(0.0, 0.0)) { emptyList() }
            c.render?.invoke(info) ?: SMapClusterRingView(context, info.count, SMapClusterRingView.shares(info.leaves(c.ring!!.limit), c.ring.property), c.ring.color ?: DEFAULT_COLOR)
        },
        idProperty = "cluster_key",
        onTap = { feature ->
            val f = clusterFeatures[id]?.get(feature.key) ?: return@SMapCustomMarkerOptions
            val info = clusterInfo(id, f)
            c.onTap?.invoke(info)
            if (c.zoomOnTap) {
                val zoom = style?.getSourceAs<GeoJsonSource>(SMapEngineIds.source(id))?.getClusterExpansionZoom(f)?.toDouble() ?: return@SMapCustomMarkerOptions
                engine?.animateCamera(CameraUpdateFactory.newLatLngZoom(info.position, zoom))
            }
        },
    )

    // The engine's clusters of every point layer with view clusters, read after the camera stops or the data changes.
    /** Reads the clusters of every point layer with view clusters; true once each source has answered. */
    private fun refreshClusters(): Boolean {
        val s = style ?: return false
        var settled = true
        for (id in order.ids()) {
            val def = defs[id]?.takeIf { it.viewClusters } ?: continue
            val source = s.getSourceAs<GeoJsonSource>(SMapEngineIds.source(id)) ?: continue
            val seen = LinkedHashMap<String, org.maplibre.geojson.Feature>()
            for (f in drawnClusters(id, source)) {
                val cid = f.getNumberProperty("cluster_id")?.toInt() ?: continue
                val key = "c$cid"
                if (key in seen) continue
                f.addStringProperty("cluster_key", key)
                seen[key] = f
            }
            // Tiles of the data are made one after another: read until two reads in a row find the same clusters.
            val signature = seen.keys.sorted().joinToString(",")
            if (signature != clusterSignatures[id] || (seen.isEmpty() && def.data.features()?.isNotEmpty() == true && source.querySourceFeatures(null).isEmpty())) settled = false
            clusterSignatures[id] = signature
            val changed = clusterFeatures[id]?.keys != seen.keys
            // Before the views are made: a cluster's view reads its points from here.
            clusterFeatures[id] = seen
            if (changed) markers.setData(clusterLayer(id), FeatureCollection.fromFeatures(seen.values.toList()))
        }
        return settled
    }

    /**
     * Reads the clusters now and again shortly after until two reads agree: once the camera stops the engine may draw
     * no further frame, and the last read was taken while the zoom levels were still blending.
     */
    private fun readClustersUntilSettled(attempt: Int) {
        if (!clustersDirty || clustersMoving) return
        clustersReadAt = android.os.SystemClock.uptimeMillis()
        if (refreshClusters()) { clustersDirty = false; return }
        if (attempt < 20) mapView.postDelayed({ readClustersUntilSettled(attempt + 1) }, 100)
    }

    /** The clusters drawn this frame, from the layer's hidden cluster layer (the source's own when it is missing). */
    private fun drawnClusters(id: String, source: GeoJsonSource): List<org.maplibre.geojson.Feature> {
        val map = engine
        val hits = SMapEngineIds.clusterHits(id)
        if (map == null || style?.getLayer(hits) == null || mapView.width == 0) return source.querySourceFeatures(Expression.has("point_count"))
        return map.queryRenderedFeatures(android.graphics.RectF(0f, 0f, mapView.width.toFloat(), mapView.height.toFloat()), hits)
    }

    // ---- what the interaction (drag, tooltips) reads of the layers

    internal class Interactive(val id: String, val kind: SMapEngineIds.Kind, val engineLayer: String, val tooltip: SMapTooltip?, val drag: SMapDragOptions?, val points: SMapPointOptions?)

    /** The drawn layers a long press may act on, top first. */
    internal fun interactiveLayers(): List<Interactive> = order.ids().asReversed().mapNotNull { id ->
        val def = defs[id]?.takeIf { !it.hidden } ?: return@mapNotNull null
        val tooltip = def.points?.tooltip ?: def.lines?.tooltip ?: def.polygons?.tooltip
        val drag = def.points?.drag?.takeIf { it.draggable != null }
        if (tooltip == null && drag == null) return@mapNotNull null
        if (def.kind == SMapEngineIds.Kind.STYLE || def.kind == SMapEngineIds.Kind.CUSTOM || def.kind == SMapEngineIds.Kind.HEATMAP || def.kind == SMapEngineIds.Kind.MODELS) return@mapNotNull null
        Interactive(id, def.kind, SMapEngineIds.tapLayer(id, def.kind, def.polygons?.extrude != null), tooltip, drag, def.points)
    }

    internal fun layerData(id: String): FeatureCollection? = defs[id]?.data

    /** Whether a point of this view is on a tool or control (a touch there is the control's, never the map's). */
    internal fun onControl(x: Float, y: Float): Boolean = toolCorners?.contains(x, y) == true
    internal fun currentStyle(): Style? = style
    internal fun overlay(): SMapMarkerOverlay = markers

    /** Shows a layer's data, or only part of it while a point is dragged (the layer keeps its data). */
    internal fun showData(id: String, data: FeatureCollection) { style?.getSourceAs<GeoJsonSource>(SMapEngineIds.source(id))?.setGeoJson(data) }
    internal fun replaceData(id: String, data: FeatureCollection) { defs[id]?.data = data; showData(id, data) }

    /** A copy of a point layer's look drawing from another source on top (the point being dragged). */
    internal fun addGhost(style: Style, ghostId: String, source: String, o: SMapPointOptions) {
        addPointLayers(ghostId, source, o.copy(cluster = null, label = null)) { l -> style.addLayer(l) }
    }

    override fun onInterceptTouchEvent(ev: android.view.MotionEvent): Boolean = interaction.intercept(ev) || super.onInterceptTouchEvent(ev)

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: android.view.MotionEvent): Boolean = interaction.touch(event) || super.onTouchEvent(event)

    companion object {
        /** The SDK version. */
        const val VERSION = BuildConfig.SMAP_VERSION

        private const val LABEL_FONT = "Noto Sans Medium"
        private const val BASE_IMAGERY = "smap-base-imagery"
        private const val TERRAIN_SOURCE = "smap-terrain"
        private const val HILLSHADE = "smap-hillshade"
        private const val RETRY_MILLIS = 30_000L
        /** The locate tool zooms in to at least this. */
        private const val LOCATE_ZOOM = 15.0
        private const val FETCH_TIMEOUT_MILLIS = 15_000L
        private const val CONVERT_TIMEOUT_MILLIS = 120_000L
        private const val CONVERT_LIMIT = 20 * 1024 * 1024
        private const val BUILDINGS_MIN_ZOOM = 13f
        private const val BUILDINGS_TILT = 55.0
        private const val FLAT_TILT = 30.0
        private const val TILT_MILLIS = 800
        private const val FLY_MILLIS = 1500
        private const val DEFAULT_RADIUS = 6f
        private const val DEFAULT_LINE_WIDTH = 4f
        private const val DEFAULT_FILL_OPACITY = 0.35f
        private const val DEFAULT_OUTLINE_WIDTH = 1.5f
        private val EMPTY: FeatureCollection = FeatureCollection.fromFeatures(emptyList())

        /** The headers of the SDK's own requests to nodes: the app identity, and the map key when one is given. */
        private fun ownHeaders(context: Context, apiKey: String?): Map<String, String> {
            val headers = LinkedHashMap(SMapAppIdentity.headers(context))
            if (!apiKey.isNullOrEmpty()) headers[SMapAppIdentity.KEY_HEADER] = apiKey
            return headers
        }
    }
}
