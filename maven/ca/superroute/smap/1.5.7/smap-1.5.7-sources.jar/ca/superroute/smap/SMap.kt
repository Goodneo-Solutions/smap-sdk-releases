package ca.superroute.smap

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.PointF
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.location.LocationManager
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import ca.superroute.smap.SMapJson.objOrNull
import ca.superroute.smap.SMapJson.str
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapLibreMapOptions
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.FillExtrusionLayer
import org.maplibre.android.style.layers.FillLayer
import org.maplibre.android.style.layers.HeatmapLayer
import org.maplibre.android.style.layers.Layer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.PropertyValue
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonOptions
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.Point
import java.util.Locale
import kotlin.math.min

/**
 * A map view showing the map service's basemap with the caller's points, lines and areas on top.
 *
 * Forward the host's lifecycle to it ([onCreate], [onStart], [onResume], [onPause], [onStop], [onLowMemory],
 * [onSaveInstanceState], [onDestroy]). Every method must be called on the main thread.
 *
 * Layers, sources and basemap options set before the map is ready are drawn once it is; style, language and token
 * changes keep them.
 */
@SuppressLint("ViewConstructor")
class SMap(context: Context, val options: SMapOptions = SMapOptions()) : FrameLayout(context) {

    /** The underlying map view, for anything the SDK does not wrap. */
    val mapView: MapView

    /** The underlying map controller; null until the map exists (see [ready]). */
    var engine: MapLibreMap? = null
        private set

    /** The colour scheme in use (the last scheme set while a custom style is shown). */
    var flavor: SMapFlavor = options.styleName?.takeIf { !SMapStyleUrl.isCustom(it) }?.let(SMapStyleUrl::checkFlavor) ?: options.style
        private set

    /** The style in use by name: a flavor id (`light`, …) or a saved custom style `custom:<id>`. */
    var styleName: String = options.styleName?.let(SMapStyleUrl::checkStyle) ?: options.style.id
        private set

    /** The label language in use. */
    var language: String = options.language ?: Locale.getDefault().toLanguageTag()
        private set

    internal val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val tokens = SMapTokenManager(options.token, options.getToken)
    private val http: SMapHttp = options.http ?: SMapUrlConnectionHttp(ownHeaders(context, options.apiKey))
    private val nodes = SMapNodePicker(
        options.baseUrl,
        http,
        options.store ?: SMapPreferencesStore(context),
        options.nearest,
        seeds = options.nodes,
    )
    private val readyDeferred = CompletableDeferred<SMap>()

    /** The offline regions on this device (download, list, remove; see [SMapOffline]). */
    val offline: SMapOffline by lazy { SMapOffline(context, options) }

    /** The offline region shown now; null while the map reads the map service. */
    var offlineRegionInUse: String? = null
        private set
    private var refreshedOffline = false
    private val order = SMapLayerOrder()
    private val defs = HashMap<String, LayerDef>()
    private val sources = LinkedHashMap<String, JsonObject>()
    private val tapHandlers = HashMap<String, (Map<String, Any?>, LatLng) -> Unit>()
    private val images = LinkedHashMap<String, Pair<Bitmap, Boolean>>()
    private var style: Style? = null
    private var styleGeneration = 0
    private var styleFailures = 0
    private var node: String = nodes.baseUrl
    private var refreshJob: Job? = null
    private var buildings = false
    private var buildingColor: String? = null
    private var buildingOpacity = 0.85f

    // Basemap class overrides (setBasemap), the style as it came, the overrides last applied, the slot anchors, and
    // setPaint / setLayout / setFilter on basemap layers (applied again after every style change).
    private var basemapOverrides: JsonObject = SMapBasemap.toJson(options.basemap).also { SMapBasemap.refuse(it) }
    private var basemapOriginal: JsonObject? = null
    private var basemapApplied: JsonObject? = null
    private var anchors: Map<SMapSlot, String?> = emptyMap()
    private val basemapEdits = LinkedHashMap<String, JsonObject>()
    private val attributionView: TextView

    // Map tools (MOBILE-SDK-SPEC "Map tools"): the registry holds every rule, the views are kept beside it.
    private val tools = SMapToolRegistry<View?>(options.tools.hidden).also { r -> options.tools.onChange?.let(r::addListener) }
    private var toolCorners: SMapToolCorners? = null
    private var toolsControl: SMapToolsControl? = null

    // Custom markers, clusters drawn as views and the tooltip (G1, G5, G6), over the map and under the controls.
    private val markers: SMapMarkerOverlay
    private val interaction: SMapInteraction
    // 3D models (G12), made with the first model layer, between the map and the marker views.
    private var models: SMapModels? = null
    // The credit (the external sources' attribution and the badge), drawn into every export (G29).
    private lateinit var creditView: View

    private fun models(): SMapModels = models ?: SMapModels(context).also { m ->
        models = m
        addView(m, indexOfChild(mapView) + 1, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        m.map = engine
    }

    private class LayerDef(
        val id: String,
        val kind: SMapEngineIds.Kind,
        var data: FeatureCollection,
        val points: SMapPointOptions? = null,
        val lines: SMapLineOptions? = null,
        val polygons: SMapPolygonOptions? = null,
        var layer: JsonObject? = null,
        val styleOptions: SMapStyleLayerOptions? = null,
        val custom: SMapCustomMarkerOptions? = null,
        val heatmap: SMapHeatmapOptions? = null,
        val model: SMapModelOptions? = null,
        /** Circles in metres around the points of [data] (G26): drawn as areas with [polygons]. */
        val circles: SMapCircleOptions? = null,
    ) {
        var hidden = false
        var group: String? = null
        var ownsSource: String? = null
        /** The style closures of the layer as last drawn (their values travel as hidden properties; G20). */
        var fns: List<(Map<String, Any?>) -> Any?> = emptyList()
        /** Key → place in [data], made when first asked for after a data change. */
        var keyIndex: HashMap<String, Int>? = null
        /** The key of the feature under a hovering pointer (G19). */
        var hoverKey: String? = null
        /** [data] is the SDK's own copy (the caller's objects are never changed by moves and updates). */
        var ownsData = false
        /** The engine layers of dashes that differ per feature, and each reader with the patterns drawn (G20). */
        var dashLayers: List<String> = emptyList()
        var dashSplits: List<Pair<(Map<String, Any?>) -> List<Float>?, List<List<Float>>>> = emptyList()

        val idProperty: String? get() = points?.idProperty ?: lines?.idProperty ?: polygons?.idProperty ?: custom?.idProperty
        val onHover: ((SMapFeature?, SMapLayerEvent) -> Unit)? get() = points?.onHover ?: lines?.onHover ?: polygons?.onHover ?: custom?.onHover
        val onDoubleClick: ((SMapFeature, SMapLayerEvent) -> Unit)? get() = points?.onDoubleClick ?: lines?.onDoubleClick ?: polygons?.onDoubleClick ?: custom?.onDoubleClick
        val onContextMenu: ((SMapFeature, SMapLayerEvent) -> Unit)? get() = points?.onContextMenu ?: lines?.onContextMenu ?: polygons?.onContextMenu ?: custom?.onContextMenu
        val hoverState: Boolean get() = points?.hoverState ?: lines?.hoverState ?: polygons?.hoverState ?: custom?.hoverState ?: false
        val drawn: Boolean get() = kind == SMapEngineIds.Kind.POINTS || kind == SMapEngineIds.Kind.LINES || kind == SMapEngineIds.Kind.POLYGONS

        fun keys(): HashMap<String, Int> = keyIndex ?: SMapEngineData.keys(data, idProperty).also { keyIndex = it }

        val zIndex: Int get() = points?.zIndex ?: lines?.zIndex ?: polygons?.zIndex ?: heatmap?.zIndex ?: styleOptions?.zIndex ?: 0
        val slot: SMapSlot? get() = points?.slot ?: lines?.slot ?: polygons?.slot ?: heatmap?.slot ?: styleOptions?.slot
        val before: String? get() = points?.before ?: lines?.before ?: polygons?.before ?: heatmap?.before ?: styleOptions?.before

        /** Clusters of this point layer drawn as views (ring or render). */
        val viewClusters: Boolean get() = points?.cluster?.let { it.ring != null || it.render != null } == true

        /** The engine source of a style layer whose source is given inline. */
        val inlineSource: String? get() = if (layer?.get("source")?.isJsonObject == true) "smap-inline-$id" else null

        val engineLayers: List<String>
            get() = when (kind) {
                SMapEngineIds.Kind.POINTS -> SMapEngineIds.pointLayers(id, points!!)
                SMapEngineIds.Kind.LINES -> SMapEngineIds.lineLayers(id, lines)
                SMapEngineIds.Kind.POLYGONS -> SMapEngineIds.polygonLayers(id, polygons!!)
                SMapEngineIds.Kind.STYLE -> listOf(id)
                SMapEngineIds.Kind.HEATMAP -> listOf(SMapEngineIds.heat(id))
                SMapEngineIds.Kind.CUSTOM, SMapEngineIds.Kind.MODELS -> emptyList()
            } + dashLayers
    }

    init {
        MapLibre.getInstance(context.applicationContext)
        SMapEngineHttp.install(context)
        val camera = CameraPosition.Builder().apply {
            options.center?.let { target(it) }
            options.zoom?.let { zoom(it) }
            options.bearing?.let { bearing(it) }
            options.pitch?.let { tilt(it) }
        }.build()
        // The engine's logo stays off. The sMap badge sits bottom-right; the attribution keeps its place bottom-left.
        val mapOptions = MapLibreMapOptions.createFromAttributes(context)
            .attributionEnabled(true)
            .logoEnabled(false)
            .camera(camera)
        mapView = MapView(context, mapOptions)
        addView(mapView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        markers = SMapMarkerOverlay(context, mapView, ::markerOrder, { id, data -> defs[id]?.let { it.data = data; it.keyIndex = null; it.ownsData = true } }, this)
        addView(markers, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        interaction = SMapInteraction(this)
        val density = resources.displayMetrics.density
        val badgeMargin = (SMapBadge.MARGIN_DP * density).toInt()
        // Bottom-right: the external sources' credit (when there is one), then the badge.
        val corner = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            isClickable = false
        }
        attributionView = TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
            setTextColor(SMapBadge.TEXT)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            maxWidth = (220 * density).toInt()
            includeFontPadding = false
            setPadding((6 * density).toInt(), (2 * density).toInt(), (6 * density).toInt(), (2 * density).toInt())
            background = GradientDrawable().apply { cornerRadius = 10 * density; setColor(Color.argb(209, 255, 255, 255)) }
            visibility = View.GONE
        }
        corner.addView(attributionView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { marginEnd = badgeMargin })
        corner.addView(SMapBadge(context), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        creditView = corner
        addView(corner, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.END).apply { marginEnd = badgeMargin; bottomMargin = badgeMargin })
        mapView.addOnDidFailLoadingMapListener { message -> onStyleFailed(message) }
        val gl = (context.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager)?.deviceConfigurationInfo?.reqGlEsVersion ?: 0x30000
        if (!SMapUnavailable.supports(gl)) post { markUnavailable(SMapUnavailableReason.UNSUPPORTED, SMapException("sMap: this device has no OpenGL ES 3.0")) }
        start()
    }

    // ------------------------------------------------------------------ lifecycle

    fun onCreate(savedInstanceState: Bundle?) = mapView.onCreate(savedInstanceState)
    fun onStart() = mapView.onStart()
    fun onResume() = mapView.onResume()
    fun onPause() = mapView.onPause()
    fun onStop() = mapView.onStop()
    fun onLowMemory() = mapView.onLowMemory()
    fun onSaveInstanceState(outState: Bundle) = mapView.onSaveInstanceState(outState)

    fun onDestroy() {
        SMapEngineHttp.statusListeners -= refusals
        scope.cancel()
        models?.destroy()
        mapView.onDestroy()
    }

    // ------------------------------------------------------------------ readiness

    /** Suspends until the first style has loaded. */
    suspend fun ready(): SMap = readyDeferred.await()

    /** Calls [callback] once the first style has loaded (at once when it already has). */
    fun ready(callback: (SMap) -> Unit) {
        if (readyDeferred.isCompleted) {
            callback(this)
        } else {
            scope.launch { callback(readyDeferred.await()) }
        }
    }

    /** True once the first style has loaded. */
    val isReady: Boolean get() = readyDeferred.isCompleted

    /** The token in use now, if any. */
    val token: String? get() = tokens.current

    private fun start() {
        // A region asked for at start is shown at once, without waiting for the network.
        options.offlineRegion?.let { id ->
            if (offline.styleFile(id) != null) {
                offlineRegionInUse = id
                scope.launch(Dispatchers.Main) {
                    mapView.getMapAsync { map ->
                        engine = map
                        map.addOnMapClickListener { latLng -> handleTap(map, latLng) }
                        attachTools(map)
                        loadStyle()
                    }
                }
                return
            }
            report(SMapException("sMap: the offline region \"$id\" is not on this device or has expired"))
        }
        // Posted (not immediate), so the host's onCreate has reached the map view before the map is asked for.
        scope.launch(Dispatchers.Main) {
            val tokenJob = async {
                if (options.getToken != null && options.token == null) {
                    try {
                        tokens.refresh()
                    } catch (e: Exception) {
                        report(e)
                    }
                }
            }
            val nodeJob = async { nodes.nodes() }
            tokenJob.await()
            node = nodeJob.await().first()
            mapView.getMapAsync { map ->
                engine = map
                map.addOnMapClickListener { latLng -> handleTap(map, latLng) }
                attachTools(map)
                loadStyle()
            }
            scheduleRefresh()
        }
    }

    private fun report(e: Throwable) {
        options.onError?.invoke(e)
    }

    internal fun reportError(e: Throwable) = report(e)

    // ------------------------------------------------------------------ tokens

    private fun scheduleRefresh() {
        refreshJob?.cancel()
        val wait = tokens.refreshDelayMillis() ?: return
        refreshJob = scope.launch {
            delay(wait)
            try {
                tokens.refresh()
                if (offlineRegionInUse == null) loadStyle()
                scheduleRefresh()
            } catch (e: Exception) {
                report(e)
                delay(RETRY_MILLIS)
                scheduleRefresh()
            }
        }
    }

    // ------------------------------------------------------------------ style

    /** The address of the style in use. */
    val styleUrl: String get() = SMapStyleUrl.build(node, styleName, language, tokens.current, options.apiKey)

    private fun loadStyle() {
        val map = engine ?: return
        style = null
        val generation = ++styleGeneration
        val offlineStyle = offlineRegionInUse?.let { offline.styleFile(it) }
        if (offlineRegionInUse != null && offlineStyle == null) offlineRegionInUse = null
        val uri = offlineStyle?.let { "file://" + it.absolutePath } ?: styleUrl
        map.setStyle(Style.Builder().fromUri(uri)) { loaded ->
            if (generation != styleGeneration) return@setStyle
            styleFailures = 0
            style = loaded
            // A node answered: a notice that no node did goes (G32).
            if (unavailable == SMapUnavailableReason.UNREACHABLE) hideUnavailableNotice()
            snapshotBasemap(loaded)
            restore(loaded)
            if (!readyDeferred.isCompleted) readyDeferred.complete(this)
            onStyleLoaded?.invoke(this)
            if (offlineStyle == null) refreshOfflineOnce()
        }
    }

    private fun onStyleFailed(message: String?) {
        if (offlineRegionInUse != null) {
            report(SMapException("sMap: the offline region \"$offlineRegionInUse\" could not load: ${message ?: "unknown error"}"))
            return
        }
        report(SMapException("sMap: the map style could not load: ${message ?: "unknown error"}", url = styleUrl))
        scope.launch {
            val list = nodes.nodes()
            if (list.size < 2 || styleFailures >= list.size - 1) {
                if (!fallBackOffline()) markUnavailable(SMapUnavailableReason.UNREACHABLE, SMapException("sMap: the map style could not load: ${message ?: "unknown error"}", url = styleUrl))
                return@launch
            }
            styleFailures++
            nodes.demote(node)
            node = nodes.nodes().first()
            loadStyle()
        }
    }

    /** Every node failed: a downloaded region containing the view's centre, when the app allows it. */
    private suspend fun fallBackOffline(): Boolean {
        if (!options.offlineFallback) return false
        val center = engine?.cameraPosition?.target ?: options.center ?: return false
        val pick = withContext(Dispatchers.IO) { SMapOfflineFiles.pick(offline.ready(), center.latitude, center.longitude) } ?: return false
        offlineRegionInUse = pick.id
        loadStyle()
        return true
    }

    // ------------------------------------------------------------------ when the map cannot be shown (G32)

    /** Why the map cannot be shown, once [SMapEventType.UNAVAILABLE] was fired; null while it can. */
    var unavailable: SMapUnavailableReason? = null
        private set
    private var unavailableError: Throwable? = null
    private var unavailableNotice: TextView? = null

    // The map service refused a request of this map's (401 / 403 from one of its nodes).
    private val refusals: (String, Int) -> Unit = { url, status ->
        if (SMapUnavailable.isRefusal(status) && offlineRegionInUse == null) {
            post { markUnavailable(SMapUnavailableReason.FORBIDDEN, SMapException("sMap: the map service answered $status", url = url)) }
        }
    }

    // Refusals are listened for while the map is on screen (the engine's HTTP client is one for the whole app).
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        SMapEngineHttp.statusListeners += refusals
    }

    override fun onDetachedFromWindow() {
        SMapEngineHttp.statusListeners -= refusals
        super.onDetachedFromWindow()
    }

    private fun markUnavailable(reason: SMapUnavailableReason, error: Throwable?) {
        if (options.unavailableNotice) showUnavailableNotice(unavailable ?: reason)
        if (unavailable != null) return
        unavailable = reason
        unavailableError = error
        events.fire(SMapEventType.UNAVAILABLE, unavailableEvent())
    }

    private fun unavailableEvent() = SMapEvent(SMapEventType.UNAVAILABLE.webName, reason = unavailable, error = unavailableError)

    private fun showUnavailableNotice(reason: SMapUnavailableReason) {
        val d = resources.displayMetrics.density
        val view = unavailableNotice ?: TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.rgb(31, 41, 55))
            gravity = Gravity.CENTER
            setPadding((16 * d).toInt(), (12 * d).toInt(), (16 * d).toInt(), (12 * d).toInt())
            background = GradientDrawable().apply { cornerRadius = 10 * d; setColor(Color.argb(235, 255, 255, 255)) }
            elevation = 2 * d
            unavailableNotice = this
            addView(this, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER).apply {
                leftMargin = (24 * d).toInt(); rightMargin = (24 * d).toInt()
            })
        }
        view.text = SMapTexts.text(language, reason.webName)
        view.visibility = View.VISIBLE
    }

    private fun hideUnavailableNotice() { unavailableNotice?.visibility = View.GONE }

    /** Once a map has loaded from the map service, the regions in their last days are refreshed in the background. */
    private fun refreshOfflineOnce() {
        if (refreshedOffline || !options.offlineAutoRefresh) return
        refreshedOffline = true
        scope.launch(Dispatchers.IO) {
            try {
                offline.refreshDue()
            } catch (e: Exception) {
                report(e)
            }
        }
    }

    /**
     * Shows the downloaded offline region [id] instead of the map service (no network needed). The caller's layers
     * are kept.
     *
     * @return false when the region is not on this device or has expired
     */
    fun useOfflineRegion(id: String): Boolean {
        if (offline.styleFile(id) == null) return false
        offlineRegionInUse = id
        loadStyle()
        return true
    }

    /** Reads the map service again after [useOfflineRegion] (or a fallback to a region). */
    fun useOnline() {
        offlineRegionInUse = null
        styleFailures = 0
        loadStyle()
    }

    /** Switches the colour scheme; the caller's layers are kept. */
    fun setStyle(flavor: SMapFlavor) = setStyle(flavor.id)

    /**
     * Switches the style: a flavor id (`light`, `white`, `grayscale`, `dark`, `black`) or a saved custom style
     * `custom:<id>`. The caller's layers, sources and basemap options are kept.
     *
     * @throws IllegalArgumentException for an unknown style name
     */
    fun setStyle(style: String) {
        styleName = SMapStyleUrl.checkStyle(style)
        if (!SMapStyleUrl.isCustom(style)) flavor = SMapStyleUrl.checkFlavor(style)
        offlineRegionInUse = null
        loadStyle()
    }

    /** Switches the label language (a BCP-47 tag); the caller's layers are kept. */
    fun setLanguage(tag: String) {
        language = tag
        offlineRegionInUse = null
        loadStyle()
    }

    private fun restore(style: Style) {
        for ((name, image) in images) {
            val engineName = SMapImages.engineId(name)
            if (style.getImage(engineName) == null) style.addImage(engineName, image.first, image.second)
        }
        for (id in sources.keys) addEngineSource(style, id)
        for (id in order.ids()) defs[id]?.let { addToStyle(style, it) }
        applyBuildings(style)
        applyBasemap(style)
        for ((id, edit) in basemapEdits) applyEdit(style, id, edit)
        imageryHid.clear()
        if (baseImagery != null) applyImagery(style)
        drawTools.forEach { it.addLayers(style) }
        if (terrain != null) applyTerrain(style)
        hideLayerTools(style)
        updateAttribution()
    }

    // ------------------------------------------------------------------ basemap options

    // The style as it came: its layer ids (for the slots) and its layers (for the overrides and getStyleLayer).
    private fun snapshotBasemap(style: Style) {
        basemapApplied = null
        basemapOriginal = try { SMapJson.parseObject(style.json) } catch (e: Exception) { null }
        val ids = basemapOriginal?.getAsJsonArray("layers")?.mapNotNull { it.asJsonObject.str("id") }
            ?: style.layers.map { it.id }
        anchors = SMapSlots.anchors(ids)
    }

    private fun applyBasemap(style: Style) {
        val original = basemapOriginal ?: return
        val next = SMapBasemap.apply(original, basemapOverrides)
        for (c in SMapBasemap.changes(basemapApplied ?: original, next)) {
            try {
                style.getLayer(c.layer)?.setProperties(SMapEngineStyle.property(c.paint, c.name, c.value))
            } catch (e: Exception) {
                report(e)
            }
        }
        basemapApplied = next
    }

    /**
     * Shows, hides and recolours the basemap by class (`water`, `land`, `parks`, `roads` and `roads.highway` …,
     * `labels` and `labels.places` …, `pois`, …). Replaces the overrides set before (an empty map clears them); kept
     * across style and language changes.
     *
     * @throws IllegalArgumentException naming an unknown class or field, or a value out of range
     */
    fun setBasemap(overrides: Map<String, SMapBasemapOverride>) = setBasemap(SMapBasemap.toJson(overrides))

    /** [setBasemap] with the overrides as their JSON object (`{"water":{"color":"#9cc0e6"}}`). */
    fun setBasemap(overrides: JsonObject) {
        SMapBasemap.refuse(overrides)
        basemapOverrides = overrides.deepCopy()
        style?.let { applyBasemap(it) }
    }

    /** [setBasemap] with the overrides as JSON text. */
    fun setBasemap(json: String) = setBasemap(SMapJson.parseObject(json))

    /** The basemap overrides in force. */
    fun basemap(): Map<String, SMapBasemapOverride> = SMapBasemap.fromJson(basemapOverrides)

    /** The basemap overrides in force, as their JSON object (a copy). */
    fun basemapJson(): JsonObject = basemapOverrides.deepCopy()

    // ------------------------------------------------------------------ images

    /**
     * Registers an image for point icons (`icon`, `iconProperty`); it is kept across style changes. On the map it is
     * `smap-user:<name>` ([SMapImages]), so it never meets a sprite image of the same name; adding a name again
     * replaces the image.
     */
    fun addImage(name: String, bitmap: Bitmap, sdf: Boolean = false) {
        if (putImage(name, bitmap, sdf)) refreshIcons()
    }

    /**
     * (1.5.0, G25) An image of the app's with its options: [SMapImageOptions.pixelRatio] image pixels per dp (default
     * the bitmap's own density) and [SMapImageOptions.sdf].
     */
    fun addImage(id: String, bitmap: Bitmap, options: SMapImageOptions) {
        val ratio = options.pixelRatio
        val image = if (ratio == null || ratio <= 0f) bitmap else bitmap.copy(Bitmap.Config.ARGB_8888, false).also {
            it.density = Math.round(ratio * android.util.DisplayMetrics.DENSITY_DEFAULT)
        }
        addImage(id, image, options.sdf)
    }

    /**
     * (1.5.0, G25) An image loaded from [url] (PNG, JPEG, WebP; no token or key is sent with it); returns once it is on
     * the map. [SMapImageOptions.pixelRatio] defaults to 1 here (one image pixel per dp).
     *
     * @throws java.io.IOException when it cannot be loaded or read
     */
    suspend fun addImage(id: String, url: String, options: SMapImageOptions = SMapImageOptions()) {
        val bitmap = withContext(Dispatchers.IO) {
            val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 15_000; c.readTimeout = 15_000
            try {
                if (c.responseCode !in 200..299) throw java.io.IOException("sMap: the image $url answered ${c.responseCode}")
                c.inputStream.use { android.graphics.BitmapFactory.decodeStream(it) } ?: throw java.io.IOException("sMap: the image $url could not be read")
            } finally {
                c.disconnect()
            }
        }
        addImage(id, bitmap, options.copy(pixelRatio = options.pixelRatio ?: 1f))
    }

    /** (1.5.0, G25) Whether the app's image [id] is on the map. */
    fun hasImage(id: String): Boolean = images.containsKey(id)

    /**
     * (1.5.0, G25) One character of a font drawn into an image of the app's (a glyph in place of the Web SDK's pin
     * icons): on a round disc of [SMapGlyph.background] when given; [SMapGlyph.sdf] makes it colourable by `iconColor`.
     */
    fun addGlyphImage(id: String, glyph: SMapGlyph) {
        val d = resources.displayMetrics.density
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            typeface = glyph.typeface
            textSize = glyph.sizeDp * d
            color = android.graphics.Color.parseColor(glyph.color)
            textAlign = android.graphics.Paint.Align.CENTER
        }
        val bounds = android.graphics.Rect()
        paint.getTextBounds(glyph.text, 0, glyph.text.length, bounds)
        val inner = maxOf(bounds.width(), bounds.height(), 1)
        val pad = if (glyph.background != null) (inner * 0.35f).toInt() else (2 * d).toInt()
        val size = inner + 2 * pad
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        glyph.background?.let { bg ->
            canvas.drawCircle(size / 2f, size / 2f, size / 2f, android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.parseColor(bg) })
        }
        canvas.drawText(glyph.text, size / 2f, size / 2f - bounds.exactCenterY(), paint)
        bitmap.density = Math.round(d * android.util.DisplayMetrics.DENSITY_DEFAULT)
        addImage(id, bitmap, glyph.sdf)
    }

    // Puts an image of the app's on the map; true when the id is new (the icon points' names are then made again).
    private fun putImage(name: String, bitmap: Bitmap, sdf: Boolean): Boolean {
        val known = images.containsKey(name)
        images[name] = bitmap to sdf
        style?.addImage(SMapImages.engineId(name), bitmap, sdf)
        return !known
    }

    // A constant name stays a constant: the engine reads a literal expression there as text, not as an image.
    private fun iconImageValue(o: SMapPointOptions): PropertyValue<*> {
        val json = SMapImages.iconImage(o.icon, o.iconProperty, images.keys)
        return if (json.isJsonPrimitive) PropertyFactory.iconImage(json.asString) else PropertyFactory.iconImage(raw(json))
    }

    // The icon points' icon-image after the app's images changed (the app's names are matched there).
    private fun refreshIcons() {
        val s = style ?: return
        for (def in defs.values) {
            val o = def.points ?: continue
            if (o.icon == null && o.iconProperty == null) continue
            val value = iconImageValue(o)
            // The layer's own and its moving and dragged copies.
            val main = SMapEngineIds.points(def.id).removeSuffix("points")
            for (l in s.layers) if (l is SymbolLayer && l.id.startsWith(main) && l.id.endsWith("points")) l.setProperties(value)
        }
    }

    // ------------------------------------------------------------------ 3D buildings

    /**
     * Shows the basemap's buildings in 3D under the caller's layers, and tilts the map to 55° when it is flat.
     *
     * @param color `#d9dee7` by default (`#3b4252` on dark and black)
     */
    fun setBuildings3D(on: Boolean, color: String? = null, opacity: Float? = null) {
        buildings = on
        buildingColor = color
        if (opacity != null) buildingOpacity = opacity
        style?.let { applyBuildings(it) }
        val map = engine
        if (on && map != null && map.cameraPosition.tilt < FLAT_TILT) {
            map.animateCamera(CameraUpdateFactory.tiltTo(BUILDINGS_TILT), TILT_MILLIS)
        }
    }

    private fun applyBuildings(style: Style) {
        style.getLayer(SMapEngineIds.BUILDINGS_LAYER)?.let { style.removeLayer(it) }
        if (!buildings || style.getSource(SMapEngineIds.BASEMAP_SOURCE) == null) return
        val layer = FillExtrusionLayer(SMapEngineIds.BUILDINGS_LAYER, SMapEngineIds.BASEMAP_SOURCE)
            .withSourceLayer(SMapEngineIds.BUILDINGS_SOURCE_LAYER)
            .withProperties(
                PropertyFactory.fillExtrusionColor(buildingColor ?: if (flavor.isDark) "#3b4252" else "#d9dee7"),
                PropertyFactory.fillExtrusionHeight(Expression.coalesce(Expression.get("height"), Expression.literal(8))),
                PropertyFactory.fillExtrusionBase(Expression.coalesce(Expression.get("min_height"), Expression.literal(0))),
                PropertyFactory.fillExtrusionOpacity(buildingOpacity),
            )
        layer.minZoom = BUILDINGS_MIN_ZOOM
        // Under the caller's layers that draw on top (no slot, or the top slot); slotted layers keep their places.
        val below = order.ids().firstNotNullOfOrNull { id ->
            val onTop = order.beforeOf(id) == null && (order.slotOf(id) ?: SMapSlot.TOP) == SMapSlot.TOP
            if (onTop) firstEngineLayer(style, id) else null
        }
        if (below != null) style.addLayerBelow(layer, below) else style.addLayer(layer)
    }

    // ------------------------------------------------------------------ the SDK's own layers

    /** Adds (or replaces) a point layer. */
    fun addPoints(id: String, points: List<SMapPoint>, options: SMapPointOptions = SMapPointOptions()) =
        addPoints(id, SMapGeoJson.points(points), options)

    /** Adds (or replaces) a point layer from GeoJSON. */
    fun addPoints(id: String, data: FeatureCollection, options: SMapPointOptions = SMapPointOptions()) =
        define(LayerDef(id, SMapEngineIds.Kind.POINTS, data, points = options))

    /** Adds (or replaces) a line layer. */
    fun addLines(id: String, lines: List<SMapLine>, options: SMapLineOptions = SMapLineOptions()) =
        addLines(id, SMapGeoJson.lines(lines), options)

    /** Adds (or replaces) a line layer from GeoJSON. */
    fun addLines(id: String, data: FeatureCollection, options: SMapLineOptions = SMapLineOptions()) =
        define(LayerDef(id, SMapEngineIds.Kind.LINES, data, lines = options))

    /** Adds (or replaces) an area layer. */
    fun addPolygons(id: String, polygons: List<SMapPolygon>, options: SMapPolygonOptions = SMapPolygonOptions()) =
        addPolygons(id, SMapGeoJson.polygons(polygons), options)

    /** Adds (or replaces) an area layer from GeoJSON. */
    fun addPolygons(id: String, data: FeatureCollection, options: SMapPolygonOptions = SMapPolygonOptions()) =
        define(LayerDef(id, SMapEngineIds.Kind.POLYGONS, data, polygons = options))

    /**
     * (1.5.0, G26) Circles of a radius in metres around points, true to the ground at every zoom, with every option of
     * areas ([SMapCircleOptions.area]). The layer's data, keys, callbacks and featuresAt are the points; moveFeature
     * moves a circle and updateFeature may change its radius. [data] as setData.
     */
    fun addCircles(id: String, data: Any, options: SMapCircleOptions = SMapCircleOptions()) {
        define(LayerDef(id, SMapEngineIds.Kind.POLYGONS, SMapGeoJson.toFeatureCollection(data), polygons = options.area.copy(extrude = null), circles = options))
    }

    /**
     * Custom markers (G1): the app's own view at each point, over the map's drawn layers. A view is made the first
     * time its point comes into view and is detached while out of view, so thousands stay smooth. [data] as setData.
     */
    fun addCustomMarkers(id: String, data: Any, options: SMapCustomMarkerOptions) {
        if (options.snapshot) return addSnapshotMarkers(id, SMapGeoJson.toFeatureCollection(data), options)
        define(LayerDef(id, SMapEngineIds.Kind.CUSTOM, SMapGeoJson.toFeatureCollection(data), custom = options))
    }

    // Custom markers drawn by the map (snapshot): each look is drawn once from the app's view into an image and the
    // layer is a point layer of those images, so tens of thousands pan as smoothly as points.
    private class SnapshotLayer(val options: SMapCustomMarkerOptions) {
        /** Look → image name. */
        val images = HashMap<String, String>()
        /** Image name → its size in density-independent pixels. */
        val sizes = HashMap<String, Pair<Float, Float>>()
    }

    /**
     * The top feature of a layer under a screen point. A snapshot layer is hit by each image's own box: the engine
     * finds an icon that ignores placement only near its anchor point, not over the picture.
     */
    internal fun featureAt(map: MapLibreMap, id: String, engineLayer: String, point: PointF): Feature? {
        val layer = snapshots[id] ?: return map.queryRenderedFeatures(point, engineLayer, *dashPartsOf(id, engineLayer)).firstOrNull()
        val features = defs[id]?.data?.features() ?: return null
        val o = layer.options
        val d = resources.displayMetrics.density
        // Later features draw on top (symbol-z-order source).
        for (index in features.indices.reversed()) {
            val f = features[index]
            val g = f.geometry() as? Point ?: continue
            val name = f.getStringProperty(SMapSnapshots.IMAGE) ?: continue
            val (w, h) = layer.sizes[name] ?: continue
            val at = map.projection.toScreenLocation(LatLng(g.latitude(), g.longitude()))
            val left = at.x - o.anchor.x * w * d + o.offsetDp.first * d
            val top = at.y - o.anchor.y * h * d + o.offsetDp.second * d
            // Answered as the engine answers: the feature's key as its id.
            if (point.x >= left && point.x <= left + w * d && point.y >= top && point.y <= top + h * d) {
                return Feature.fromGeometry(g, f.properties(), SMapEngineData.keyOf(f, index, SMapSnapshots.KEY))
            }
        }
        return null
    }

    // The engine layers drawing the dashed features of an engine layer (G20).
    private fun dashPartsOf(id: String, engineLayer: String): Array<String> =
        defs[id]?.dashLayers?.filter { it.startsWith("$engineLayer-dash") }?.toTypedArray() ?: emptyArray()

    private val snapshots = HashMap<String, SnapshotLayer>()
    private var snapshotImages = 0

    private fun addSnapshotMarkers(id: String, data: FeatureCollection, options: SMapCustomMarkerOptions) {
        removeLayer(id)
        val layer = SnapshotLayer(options)
        val plain = { f: SMapFeature -> SMapSnapshots.plain(f) }
        val d = options.drag
        addPoints(
            id, snapshotCollection(id, layer, data),
            SMapPointOptions(
                minZoom = options.minZoom?.toFloat(), maxZoom = options.maxZoom?.toFloat(), tooltip = options.tooltip,
                drag = SMapDragOptions(
                    draggable = d.draggable,
                    onDragStart = d.onDragStart?.let { cb -> { f, e -> cb(plain(f), e) } },
                    onDrag = d.onDrag?.let { cb -> { f, e -> cb(plain(f), e) } },
                    onDragEnd = d.onDragEnd?.let { cb -> { f, e -> cb(plain(f), e) } },
                ),
                iconProperty = SMapSnapshots.IMAGE, iconAnchor = options.anchor, iconOffsetDp = options.offsetDp,
                iconOpacityProperty = if (options.opacity != null) SMapSnapshots.OPACITY else null,
                sortProperty = if (options.zIndex != null) SMapSnapshots.ORDER else null,
                // Each feature is named by its marker key; pointer events, hover and headings as live markers (G19, G24).
                idProperty = SMapSnapshots.KEY,
                onHover = options.onHover, onDoubleClick = options.onDoubleClick, onContextMenu = options.onContextMenu,
                hoverState = options.hoverState,
                rotation = options.rotation, rotationAlignment = options.rotationAlignment,
                // (1.5.5) Its label is given the marker as the app knows it.
                overlap = options.overlap?.let { ov -> ov.copy(label = ov.label?.let { l -> { f: SMapFeature -> l(SMapSnapshots.plain(f)) } }) },
            ),
        )
        snapshots[id] = layer
        options.onTap?.let { tap ->
            onTap(id) { props, at -> tap(SMapFeature(props[SMapSnapshots.KEY]?.toString() ?: "", SMapSnapshots.stripped(props), at)) }
        }
    }

    // The layer's features with the image, key, opacity and order of each; a look not seen before is drawn now.
    private fun snapshotCollection(id: String, layer: SnapshotLayer, data: FeatureCollection): FeatureCollection {
        val o = layer.options
        var newImages = false
        val keys = SMapMarkerSet<View>(o.idProperty)
        val out = ArrayList<Feature>()
        data.features()?.forEachIndexed { index, f ->
            if (f.geometry() !is Point) return@forEachIndexed
            val props = SMapSnapshots.stripped(SMapGeoJson.propertiesOf(f)).toMutableMap()
            val look = o.snapshotKey?.invoke(props) ?: SMapSnapshots.look(props) ?: "#$index"
            val name = layer.images.getOrPut(look) {
                "smap-snapshot|$id|${snapshotImages++}".also { name ->
                    val bitmap = SMapSnapshots.draw(o.render(props), resources.displayMetrics)
                    layer.sizes[name] = bitmap.width / resources.displayMetrics.density to bitmap.height / resources.displayMetrics.density
                    if (putImage(name, bitmap, false)) newImages = true
                }
            }
            val key = keys.keyOf(f, index)
            o.opacity?.let { props[SMapSnapshots.OPACITY] = it.read(props, 1f).toDouble() }
            o.zIndex?.let { props[SMapSnapshots.ORDER] = it.read(props, 0).toDouble() }
            props[SMapSnapshots.IMAGE] = name
            props[SMapSnapshots.KEY] = key
            out.add(Feature.fromGeometry(f.geometry(), SMapGeoJson.properties(props), f.id()))
        }
        if (newImages) refreshIcons()
        return FeatureCollection.fromFeatures(out)
    }

    /** Forgets an image of [addImage] (an id the app never added does nothing; a sprite image is never removed). */
    fun removeImage(name: String) {
        if (images.remove(name) != null) {
            style?.removeImage(SMapImages.engineId(name))
            refreshIcons()
        }
    }

    /** The view of one custom marker by its key (made now if it was not in view yet), or null. */
    fun getMarker(id: String, key: String): View? = markers.marker(id, key)

    /**
     * glTF models at points (G12), drawn in 3D over the map and turned to each feature's heading. [data] as setData;
     * the model is read once from its URL.
     */
    fun addModels(id: String, data: Any, options: SMapModelOptions) {
        define(LayerDef(id, SMapEngineIds.Kind.MODELS, SMapGeoJson.toFeatureCollection(data), model = options))
    }

    /** A heat map of points (G7). [data] as setData. */
    fun addHeatmap(id: String, data: Any, options: SMapHeatmapOptions = SMapHeatmapOptions()) {
        define(LayerDef(id, SMapEngineIds.Kind.HEATMAP, SMapGeoJson.toFeatureCollection(data), heatmap = options))
    }

    /**
     * Replaces a layer's data and keeps its look. [data]: a FeatureCollection, a Feature, a GeoJSON string, or a list
     * of [SMapPoint], [SMapLine] or [SMapPolygon].
     *
     * @throws IllegalArgumentException when there is no layer [id] of addPoints / addLines / addPolygons, or the data
     *   cannot be read
     */
    fun setData(id: String, data: Any) {
        val def = defs[id]?.takeIf { it.kind != SMapEngineIds.Kind.STYLE } ?: throw IllegalArgumentException("sMap: no layer $id")
        val snapshot = snapshots[id]
        def.data = if (snapshot != null) snapshotCollection(id, snapshot, SMapGeoJson.toFeatureCollection(data)) else SMapGeoJson.toFeatureCollection(data)
        def.keyIndex = null
        def.ownsData = false
        // A feature on its way stops where the new data puts it.
        if (moves.layers.remove(id) != null) dropMovingSource(id)
        if (def.kind == SMapEngineIds.Kind.CUSTOM) return markers.setData(id, def.data)
        if (def.kind == SMapEngineIds.Kind.MODELS) return models().setData(id, def.data)
        pushData(def)
        if (def.viewClusters) clustersDirty = true
    }

    /** Shows or hides a layer. */
    fun setVisible(id: String, visible: Boolean) {
        val def = defs[id] ?: return
        def.hidden = !visible
        if (def.kind == SMapEngineIds.Kind.CUSTOM) return markers.setHidden(id, !visible)
        if (def.kind == SMapEngineIds.Kind.MODELS) return models().setHidden(id, !visible)
        if (def.viewClusters) markers.setHidden(clusterLayer(id), !visible)
        val s = style ?: return
        val value = PropertyFactory.visibility(if (visible) Property.VISIBLE else Property.NONE)
        def.engineLayers.forEach { s.getLayer(it)?.setProperties(value) }
    }

    /**
     * Removes a layer: one of the SDK's own (addPoints, addLines, addPolygons; addData's whole group), a style layer
     * (addStyleLayer and the external-layer calls, with the source such a call made for it), or a source of
     * addSource with the style layers that read it.
     */
    fun removeLayer(id: String) {
        val ids = order.ids().filter { it == id || defs[it]?.group == id }
        if (ids.isEmpty()) {
            if (id in sources) removeSource(id)
            return
        }
        for (x in ids) {
            val def = defs.remove(x) ?: continue
            style?.let { drop(it, def) }
            snapshots.remove(x)?.images?.values?.forEach { removeImage(it) }
            if (def.kind == SMapEngineIds.Kind.CUSTOM) markers.remove(x)
            if (def.kind == SMapEngineIds.Kind.MODELS) models?.remove(x)
            if (def.viewClusters) markers.remove(clusterLayer(x))
            order.remove(x)
            tapHandlers.remove(x)
            featureStates.remove(x)
            if (moves.layers.remove(x) != null) dropMovingSource(x)
            if (openTip?.first == x) closeTooltip()
            val owned = def.ownsSource
            if (owned != null && owned in sources && !sourceInUse(owned)) removeSource(owned)
        }
        updateAttribution()
    }

    /** The caller's layer ids in draw order, bottom first. */
    fun layers(): List<String> = order.ids()

    /** Moves the camera to show all of a layer's data. [padding] in density-independent pixels. */
    fun fitLayer(id: String, padding: Int = 40, maxZoom: Double = 15.0) =
        fitLayer(listOf(id), SMapFitOptions(SMapPadding(padding.toFloat()), maxZoom))

    /**
     * Fits the view to the data of several layers together (G15); an addData group counts as its layers. Nothing
     * happens when they hold no position.
     */
    fun fitLayer(ids: List<String>, options: SMapFitOptions = SMapFitOptions()) {
        val boxes = ArrayList<DoubleArray?>()
        for (x in ids) for (y in order.ids()) {
            val def = defs[y] ?: continue
            if ((y == x || def.group == x) && def.kind != SMapEngineIds.Kind.STYLE) boxes += SMapGeoJson.bounds(def.data)
        }
        SMapCameraMath.unionAll(boxes)?.let { fitBox(it, options) }
    }

    /**
     * Fits the view to bounds (`[west, south, east, north]` or [LatLngBounds]), positions ([LatLng], [SMapPoint],
     * `[lng, lat]`, or a list of them) or GeoJSON ([Feature], [FeatureCollection], [org.maplibre.geojson.Geometry],
     * a [JsonObject] or GeoJSON text, a list of features) (G15). Nothing happens when the input holds no position.
     */
    fun fitBounds(input: Any, options: SMapFitOptions = SMapFitOptions()) {
        SMapCameraMath.boundsOf(input)?.let { fitBox(it, options) }
    }

    private fun fitBox(b: DoubleArray, o: SMapFitOptions) {
        val map = engine ?: return ready { fitBox(b, o) }
        val current = map.cameraPosition
        val bearing = o.bearing ?: current.bearing
        val tilt = o.pitch ?: current.tilt
        val camera = if (b[0] == b[2] && b[1] == b[3]) {
            CameraPosition.Builder().target(LatLng(b[1], b[0])).zoom(o.maxZoom).bearing(bearing).tilt(tilt).build()
        } else {
            val d = resources.displayMetrics.density
            val p = o.padding
            val px = intArrayOf((p.left * d).toInt(), (p.top * d).toInt(), (p.right * d).toInt(), (p.bottom * d).toInt())
            val fit = map.getCameraForLatLngBounds(LatLngBounds.from(b[3], b[2], b[1], b[0]), px, bearing, tilt) ?: return
            CameraPosition.Builder(fit).zoom(min(fit.zoom, o.maxZoom)).bearing(bearing).tilt(tilt).build()
        }
        moveTo(map, CameraUpdateFactory.newCameraPosition(camera), o.durationMillis)
    }

    // null: the map's own camera animation; 0: at once.
    private fun moveTo(map: MapLibreMap, update: org.maplibre.android.camera.CameraUpdate, durationMillis: Long?, ease: Boolean = false) {
        when {
            durationMillis == 0L -> map.moveCamera(update)
            durationMillis == null -> map.animateCamera(update)
            ease -> map.easeCamera(update, durationMillis.toInt())
            else -> map.animateCamera(update, durationMillis.toInt())
        }
    }

    // ------------------------------------------------------------------ the camera and the map's events (G16-G18)

    /** The view's centre (the starting centre before the map is ready). */
    fun getCenter(): LatLng = engine?.cameraPosition?.target ?: options.center ?: LatLng(0.0, 0.0)

    fun getZoom(): Double = engine?.cameraPosition?.zoom ?: options.zoom ?: 0.0

    fun getBearing(): Double = engine?.cameraPosition?.bearing ?: options.bearing ?: 0.0

    /** The tilt in degrees. */
    fun getPitch(): Double = engine?.cameraPosition?.tilt ?: options.pitch ?: 0.0

    /** The box around the view (around a turned or tilted view too); null before the map is ready. */
    fun getBounds(): LatLngBounds? = engine?.projection?.visibleRegion?.latLngBounds

    private fun cameraUpdate(map: MapLibreMap, o: SMapCameraOptions): org.maplibre.android.camera.CameraUpdate {
        val b = CameraPosition.Builder(map.cameraPosition)
        o.center?.let { b.target(it) }
        o.zoom?.let { b.zoom(it) }
        o.bearing?.let { b.bearing(it) }
        o.pitch?.let { b.tilt(it) }
        return CameraUpdateFactory.newCameraPosition(b.build())
    }

    /** Moves the view at once; what [o] does not give stays. Before the map is ready the move waits for it. */
    fun jumpTo(o: SMapCameraOptions) {
        val map = engine ?: return ready { jumpTo(o) }
        map.moveCamera(cameraUpdate(map, o))
    }

    /** Moves the view in a straight animation over [durationMillis] (0 jumps). */
    fun easeTo(o: SMapCameraOptions, durationMillis: Long = EASE_MILLIS) {
        val map = engine ?: return ready { easeTo(o, durationMillis) }
        moveTo(map, cameraUpdate(map, o), durationMillis, ease = true)
    }

    /** One zoom level in, about the centre. */
    fun zoomIn(durationMillis: Long = EASE_MILLIS) {
        val map = engine ?: return ready { zoomIn(durationMillis) }
        moveTo(map, CameraUpdateFactory.zoomIn(), durationMillis, ease = true)
    }

    /** One zoom level out, about the centre. */
    fun zoomOut(durationMillis: Long = EASE_MILLIS) {
        val map = engine ?: return ready { zoomOut(durationMillis) }
        moveTo(map, CameraUpdateFactory.zoomOut(), durationMillis, ease = true)
    }

    /** Where a position is on the map, in pixels from its top-left corner; null before the map is ready (G17). */
    fun project(position: LatLng): PointF? = engine?.projection?.toScreenLocation(position)

    /** The position at a point of the map (pixels from its top-left corner); null before the map is ready (G17). */
    fun unproject(point: PointF): LatLng? = engine?.projection?.fromScreenLocation(point)

    /**
     * Lays the marker views and the tooltip out again (G18). The map view follows its own size by itself (a hidden
     * tab or a dialog included); the call is there so code written for the Web SDK runs unchanged.
     */
    fun resize() {
        requestLayout()
        markers.layout()
        placeOpenTooltip()
    }

    private val events = SMapEventRegistry { report(it) }
    private val zoomTracker = SMapZoomTracker()
    private var lastIdleZoom: Double? = null

    /**
     * Listens for a map event in the SDK's shape (G16): MOVE on every camera frame, MOVE_END when the camera stops,
     * ZOOM_END when it stops at another zoom, CLICK on a single tap, DOUBLE_CLICK on a double tap, CONTEXT_MENU on a
     * long press that does not start a drag, MOUSE_MOVE while a mouse or stylus hovers.
     */
    fun on(type: SMapEventType, listener: (SMapEvent) -> Unit) {
        // The map was already unavailable: told at once (G32), and kept for nothing else (it fires once).
        if (type == SMapEventType.UNAVAILABLE && unavailable != null) return listener(unavailableEvent())
        events.on(type, listener)
    }

    /** [on] with the Web SDK's event name (`move`, `moveend`, `zoomend`, `click`, `dblclick`, `contextmenu`, `mousemove`). */
    fun on(type: String, listener: (SMapEvent) -> Unit) = on(eventType(type), listener)

    fun off(type: SMapEventType, listener: (SMapEvent) -> Unit) = events.off(type, listener)

    fun off(type: String, listener: (SMapEvent) -> Unit) = off(eventType(type), listener)

    /** Listens for the next event of [type] only. */
    fun once(type: SMapEventType, listener: (SMapEvent) -> Unit) {
        if (type == SMapEventType.UNAVAILABLE && unavailable != null) return listener(unavailableEvent())
        events.on(type, listener, once = true)
    }

    /** The next event of [type]. */
    suspend fun once(type: SMapEventType): SMapEvent {
        val next = CompletableDeferred<SMapEvent>()
        once(type) { next.complete(it) }
        return next.await()
    }

    private fun eventType(name: String): SMapEventType =
        SMapEventType.of(name) ?: throw IllegalArgumentException("sMap: \"$name\" is not one of the map's events")

    internal fun hasListeners(type: SMapEventType): Boolean = events.has(type)

    private fun cameraEvent(type: SMapEventType): SMapEvent {
        val c = engine?.cameraPosition
        return SMapEvent(type.webName, center = c?.target, zoom = c?.zoom, bearing = c?.bearing, pitch = c?.tilt)
    }

    /** A pointer event of the map at [point] (pixels of this view). */
    internal fun pointerEvent(type: SMapEventType, point: PointF, motion: MotionEvent? = null): SMapEvent =
        SMapEvent(type.webName, position = unproject(point), point = point, motionEvent = motion)

    internal fun fire(type: SMapEventType, event: SMapEvent) = events.fire(type, event)

    private fun attachEvents(map: MapLibreMap) {
        map.addOnCameraMoveListener {
            zoomTracker.moved(map.cameraPosition.zoom)
            if (events.has(SMapEventType.MOVE)) events.fire(SMapEventType.MOVE, cameraEvent(SMapEventType.MOVE))
            placeOpenTooltip()
        }
        map.addOnCameraIdleListener {
            val zoom = map.cameraPosition.zoom
            val zoomed = zoomTracker.stopped(zoom, lastIdleZoom) && lastIdleZoom != null
            lastIdleZoom = zoom
            if (events.has(SMapEventType.MOVE_END)) events.fire(SMapEventType.MOVE_END, cameraEvent(SMapEventType.MOVE_END))
            if (zoomed && events.has(SMapEventType.ZOOM_END)) events.fire(SMapEventType.ZOOM_END, cameraEvent(SMapEventType.ZOOM_END))
            placeOpenTooltip()
        }
    }

    /** Calls [handler] with the tapped feature's properties and position when a feature of layer [id] is tapped. */
    fun onTap(id: String, handler: (properties: Map<String, Any?>, latLng: LatLng) -> Unit) {
        tapHandlers[id] = handler
    }

    /** Flies the camera to [center], at [zoom] when given. */
    fun flyTo(center: LatLng, zoom: Double? = null) {
        val map = engine ?: return
        val update = if (zoom != null) CameraUpdateFactory.newLatLngZoom(center, zoom) else CameraUpdateFactory.newLatLng(center)
        map.animateCamera(update, FLY_MILLIS)
    }

    // ------------------------------------------------------------------ sources and style layers

    /**
     * Adds a Style Spec v8 source (geojson, vector, raster, raster-dem, image), passed to the engine as it is and kept
     * across style and language changes. Its `attribution` is shown beside the map data credit. `pmtiles://<url>`
     * reads a PMTiles archive. A source with the same id is replaced (with the style layers that read it).
     *
     * @param source the source as JSON text, a [JsonObject] or a map of plain values
     * @throws IllegalArgumentException for a source that cannot be drawn, the id `basemap`, or Google / Bing tiles
     */
    fun addSource(id: String, source: Any) {
        val json = (if (source is JsonObject) source else SMapStyleSpec.layerObject(source)).deepCopy()
        if (id == SMapEngineIds.BASEMAP_SOURCE) throw IllegalArgumentException("sMap: the source id \"basemap\" belongs to the map")
        SMapStyleSpec.checkSource(id, json)
        SMapExternalLayers.refuseForbidden(SMapExternalLayers.sourceUrls(json))
        if (id in sources) removeSource(id)
        sources[id] = json
        style?.let { addEngineSource(it, id) }
        updateAttribution()
    }

    /** Removes a source of addSource and the style layers that read it. */
    fun removeSource(id: String) {
        if (id !in sources) return
        order.ids().filter { defs[it]?.layer?.str("source") == id }.forEach { x ->
            defs[x]?.ownsSource = null
            removeLayer(x)
        }
        sources.remove(id)
        style?.let { s -> s.getSource(id)?.let { s.removeSource(it) } }
        updateAttribution()
    }

    /** The sources added with addSource (and by the external-layer calls): id → source (copies). */
    fun sources(): Map<String, JsonObject> = sources.mapValues { it.value.deepCopy() }

    private fun sourceInUse(id: String): Boolean = defs.values.any { it.layer?.str("source") == id }

    private fun addEngineSource(style: Style, id: String) {
        val json = sources[id] ?: return
        try {
            style.getSource(id)?.let { style.removeSource(it) }
            style.addSource(SMapEngineStyle.source(id, json))
        } catch (e: Exception) {
            report(e)
        }
    }

    /**
     * Adds a Style Spec v8 layer, passed to the engine as it is: a layer copied from a style editor or another map
     * page works unchanged. Its `source` is a source of addSource, an inline source object, `basemap`, or an SDK
     * layer's source (`smap-<id>`). Without [SMapStyleLayerOptions.slot] or [SMapStyleLayerOptions.before] it draws on
     * top, in the order added.
     *
     * @param layer the layer as JSON text, a [JsonObject] or a map of plain values
     * @throws IllegalArgumentException for a layer the engine cannot draw
     */
    fun addStyleLayer(layer: Any, options: SMapStyleLayerOptions = SMapStyleLayerOptions()) {
        val json = SMapStyleSpec.checkLayer(SMapStyleSpec.layerObject(layer).deepCopy())
        json.objOrNull("source")?.let { SMapExternalLayers.refuseForbidden(SMapExternalLayers.sourceUrls(it)) }
        val def = LayerDef(json.str("id")!!, SMapEngineIds.Kind.STYLE, EMPTY, layer = json, styleOptions = options)
        if (json.objOrNull("layout")?.str("visibility") == "none") def.hidden = true
        define(def)
        updateAttribution()
    }

    private fun edit(layerId: String, apply: (JsonObject) -> Unit) {
        val def = defs[layerId]
        if (def != null && def.kind != SMapEngineIds.Kind.STYLE) {
            throw IllegalArgumentException("sMap: $layerId is a layer of addPoints / addLines / addPolygons; set its look with its options")
        }
        if (def != null) apply(def.layer!!) else apply(basemapEdits.getOrPut(layerId) { JsonObject() })
    }

    private fun setKey(layer: JsonObject, paint: Boolean, name: String, value: JsonElement?) {
        val group = SMapStyleSpec.section(layer, paint)
        if (value == null || value.isJsonNull) group.remove(name) else group.add(name, value.deepCopy())
    }

    /**
     * Sets a paint property of a style layer (yours or the basemap's); kept across style changes. [value] is a
     * Style Spec value as a [JsonElement] or plain values (strings, numbers, booleans, lists, maps); null puts the
     * style's default back.
     *
     * @throws IllegalArgumentException for a layer of addPoints / addLines / addPolygons (set its look with its options)
     */
    fun setPaint(layerId: String, name: String, value: Any?) {
        val v = value?.let { SMapJson.of(it) }
        edit(layerId) { setKey(it, true, name, v) }
        try { style?.getLayer(layerId)?.setProperties(SMapEngineStyle.property(true, name, v)) } catch (e: Exception) { report(e) }
    }

    /** Sets a layout property of a style layer (yours or the basemap's); kept across style changes. */
    fun setLayout(layerId: String, name: String, value: Any?) {
        val v = value?.let { SMapJson.of(it) }
        edit(layerId) { setKey(it, false, name, v) }
        val def = defs[layerId]
        if (def != null && name == "visibility") def.hidden = v?.takeIf { it.isJsonPrimitive }?.asString == "none"
        try { style?.getLayer(layerId)?.setProperties(SMapEngineStyle.property(false, name, v)) } catch (e: Exception) { report(e) }
    }

    /** Sets (or with null clears) the filter of a style layer (yours or the basemap's); kept across style changes. */
    fun setFilter(layerId: String, filter: Any?) {
        val f = filter?.let { SMapJson.of(it) }
        edit(layerId) { l -> if (f == null || f.isJsonNull) l.remove("filter") else l.add("filter", f.deepCopy()) }
        try { style?.getLayer(layerId)?.let { SMapEngineStyle.filter(it, f) } } catch (e: Exception) { report(e) }
    }

    private fun applyEdit(style: Style, id: String, edit: JsonObject) {
        val layer = style.getLayer(id) ?: return
        try {
            edit.objOrNull("paint")?.entrySet()?.forEach { (k, v) -> layer.setProperties(SMapEngineStyle.property(true, k, v)) }
            edit.objOrNull("layout")?.entrySet()?.forEach { (k, v) -> layer.setProperties(SMapEngineStyle.property(false, k, v)) }
            edit.get("filter")?.let { SMapEngineStyle.filter(layer, it) }
        } catch (e: Exception) {
            report(e)
        }
    }

    /** Called after each style has loaded and your layers are back on it (scheme, language, token or offline change). */
    var onStyleLoaded: ((SMap) -> Unit)? = null

    /** The style as it was loaded (before your layers and the basemap overrides), as JSON text; null before the first. */
    fun styleJson(): String? = basemapOriginal?.toString()

    /** A style layer as a Style Spec object (a copy): yours, or the basemap's; null when there is none. */
    fun getStyleLayer(layerId: String): JsonObject? {
        val def = defs[layerId]
        if (def != null) return if (def.kind == SMapEngineIds.Kind.STYLE) def.layer!!.deepCopy() else null
        val base = (basemapApplied ?: basemapOriginal)?.getAsJsonArray("layers")
            ?.firstOrNull { it.isJsonObject && it.asJsonObject.str("id") == layerId }?.asJsonObject?.deepCopy() ?: return null
        basemapEdits[layerId]?.let { e ->
            for (paint in listOf(true, false)) {
                e.objOrNull(if (paint) "paint" else "layout")?.entrySet()?.forEach { (k, v) -> SMapStyleSpec.section(base, paint).add(k, v.deepCopy()) }
            }
            e.get("filter")?.let { base.add("filter", it.deepCopy()) }
        }
        return base
    }

    // ------------------------------------------------------------------ files

    /**
     * Reads a file (KML, KMZ, GPX, encoded polyline, WKT, WKB, CSV, TopoJSON, GeoJSON) on the device and draws it:
     * its points as the layer [id], its lines as `<id>:lines`, its areas as `<id>:areas` (only those it has), with
     * simplestyle properties drawn when no colour is given. [removeLayer] with [id] removes all of them, [toGeoJSON]
     * gives them back together.
     *
     * @return the layer ids added
     * @throws IllegalArgumentException when the file cannot be read
     */
    fun addData(id: String, input: ByteArray, options: SMapDataOptions = SMapDataOptions()): List<String> =
        addFeatures(id, SMapFormats.readJson(input, options.format, options.lat, options.lng, options.fileName), options)

    /** [addData] for text input. */
    fun addData(id: String, input: String, options: SMapDataOptions = SMapDataOptions()): List<String> =
        addFeatures(id, SMapFormats.readJson(input, options.format, options.lat, options.lng, options.fileName), options)

    /** [addData] for parsed GeoJSON or TopoJSON. */
    fun addData(id: String, input: JsonObject, options: SMapDataOptions = SMapDataOptions()): List<String> =
        addFeatures(id, SMapFormats.readJson(input, options.format), options)

    private fun addFeatures(id: String, data: JsonObject, o: SMapDataOptions): List<String> {
        val (points, lines, areas) = SMapFormats.split(data)
        removeLayer(id)
        val added = ArrayList<String>()
        fun fc(j: JsonObject) = FeatureCollection.fromJson(j.toString())
        fun count(j: JsonObject) = j.getAsJsonArray("features").size()
        if (count(areas) > 0) { addPolygons("$id:areas", fc(areas), o.polygons); defs["$id:areas"]?.group = id; added += "$id:areas" }
        if (count(lines) > 0) { addLines("$id:lines", fc(lines), o.lines); defs["$id:lines"]?.group = id; added += "$id:lines" }
        if (count(points) > 0) { addPoints(id, fc(points), o.points); defs[id]?.group = id; added += id }
        return added
    }

    private fun geoJsonOf(layerId: String): JsonObject {
        val members = order.ids().filter { defs[it]?.group == layerId }
        if (members.isNotEmpty()) {
            val features = JsonArray()
            for (x in listOf("$layerId:areas", "$layerId:lines", layerId)) {
                if (x in members) SMapJson.parseObject(defs[x]!!.data.toJson()).getAsJsonArray("features").forEach(features::add)
            }
            return JsonObject().apply { addProperty("type", "FeatureCollection"); add("features", features) }
        }
        val def = defs[layerId]
        if (def != null && def.kind != SMapEngineIds.Kind.STYLE) return SMapJson.parseObject(def.data.toJson())
        val source = if (def != null) def.layer!!.objOrNull("source") ?: sources[def.layer!!.str("source")] else sources[layerId]
        val data = source?.takeIf { it.str("type") == "geojson" }?.get("data")
        if (data != null && data.isJsonObject) return SMapFormats.readGeojson(data.asJsonObject)
        throw IllegalArgumentException("sMap: $layerId has no GeoJSON features to give")
    }

    /** A layer's features as GeoJSON: an SDK layer, an addData group, or a style layer of a GeoJSON source. */
    fun toGeoJSON(layerId: String): FeatureCollection = FeatureCollection.fromJson(geoJsonOf(layerId).toString())

    /** [toGeoJSON] as JSON. */
    fun toGeoJSONObject(layerId: String): JsonObject = geoJsonOf(layerId)

    /** A layer's features as a KML document. */
    fun toKML(layerId: String): String = SMapFormats.toKml(geoJsonOf(layerId), layerId)

    /**
     * Converts a file on the map service (`POST /v1/convert`), for large files or formats the device should not
     * parse; this map's node, key and token are used.
     *
     * @param format one of [SMapFormats.FORMATS]; from [fileName]'s extension, else guessed from the content
     * @throws SMapException when the service refuses the file
     */
    suspend fun convert(input: ByteArray, format: String? = null, lat: String? = null, lng: String? = null, fileName: String? = null): FeatureCollection =
        FeatureCollection.fromJson(convertJson(input, format, lat, lng, fileName).toString())

    /** [convert] as JSON. */
    suspend fun convertJson(input: ByteArray, format: String? = null, lat: String? = null, lng: String? = null, fileName: String? = null): JsonObject {
        if (input.size > CONVERT_LIMIT) throw IllegalArgumentException("sMap: convert takes files of at most 20 MB")
        val f = format?.lowercase() ?: SMapFormats.formatOfName(fileName) ?: SMapFormats.guess(input)
        if (f == null || f !in SMapFormats.FORMATS) throw IllegalArgumentException("sMap: the file format could not be recognised; name the format")
        val url = SMapStyleUrl.convert(node, f, lat, lng)
        val headers = LinkedHashMap<String, String>()
        headers["Content-Type"] = "application/octet-stream"
        tokens.current?.let { headers["Authorization"] = "Bearer $it" }
        options.apiKey?.takeIf { it.isNotEmpty() }?.let { headers[SMapAppIdentity.KEY_HEADER] = it }
        val res = http.post(url, input, headers, CONVERT_TIMEOUT_MILLIS)
        if (!res.ok) {
            val msg = try {
                SMapJson.parseObject(res.body).let { it.str("message") ?: it.str("error") } ?: res.body
            } catch (e: Exception) { res.body }
            throw SMapException("sMap: convert failed (HTTP ${res.status})" + if (msg.isNotEmpty()) ": $msg" else "", url = url)
        }
        return SMapJson.parseObject(res.body)
    }

    // ------------------------------------------------------------------ external layers

    private fun addExternal(ext: SMapExternalLayer, place: SMapStyleLayerOptions) {
        addSource(ext.sourceId, ext.source)
        for (layer in ext.layers) {
            addStyleLayer(layer, place)
            if (ext.ownsSource) defs[layer.str("id")!!]?.ownsSource = ext.sourceId
        }
    }

    /** Raster tiles from any XYZ template or a TileJSON address. */
    fun addRasterLayer(id: String, options: SMapRasterOptions) =
        addExternal(SMapExternalLayers.raster(id, options), SMapStyleLayerOptions(options.before, options.slot, options.zIndex))

    /** An OGC WMS layer, one GetMap image per tile in Web Mercator. */
    fun addWmsLayer(id: String, options: SMapWmsOptions) =
        addExternal(SMapExternalLayers.wms(id, options), SMapStyleLayerOptions(options.before, options.slot, options.zIndex))

    /**
     * An OGC WMTS layer (Web Mercator matrix sets): from a REST template, from the capabilities' text, or from a
     * capabilities address (read now).
     */
    suspend fun addWmtsLayer(id: String, options: SMapWmtsOptions) {
        val place = SMapStyleLayerOptions(options.before, options.slot, options.zIndex)
        val url = options.url.orEmpty()
        if (SMapExternalLayers.isWmtsTemplate(url)) return addExternal(SMapExternalLayers.wmtsTemplate(id, options), place)
        options.capabilities?.let { return addExternal(SMapExternalLayers.wmtsFromCapabilities(id, it, options), place) }
        if (url.isEmpty()) throw IllegalArgumentException("sMap: addWmtsLayer needs url or capabilities")
        val capsUrl = SMapExternalLayers.wmtsCapabilitiesUrl(url)
        SMapExternalLayers.refuseForbidden(listOf(capsUrl))
        val res = http.get(capsUrl, FETCH_TIMEOUT_MILLIS)
        if (!res.ok) throw SMapException("sMap: WMTS capabilities: HTTP ${res.status}", url = capsUrl)
        addExternal(SMapExternalLayers.wmtsFromCapabilities(id, res.body, options), place)
    }

    /** Vector tiles from any address (templates, TileJSON, PMTiles), drawn by the given style layers. */
    fun addVectorTiles(id: String, options: SMapVectorTilesOptions) =
        addExternal(SMapExternalLayers.vectorTiles(id, options), SMapStyleLayerOptions(options.before, options.slot, options.zIndex))

    /** An ArcGIS REST MapServer / ImageServer (raster tiles) or VectorTileServer (vector tiles); its description is read now. */
    suspend fun addArcGisLayer(id: String, options: SMapArcGisOptions) {
        val base = SMapExternalLayers.arcGisBase(options.url)
        suspend fun json(u: String): JsonObject = try {
            val r = http.get(u, FETCH_TIMEOUT_MILLIS)
            if (r.ok) SMapJson.parseObject(r.body) else JsonObject()
        } catch (e: Exception) { JsonObject() }
        val info = json("$base?f=json")
        val styleLayers = if (SMapExternalLayers.isArcGisVector(base) && options.layers == null) {
            json(SMapExternalLayers.arcGisStyleUrl(base, info)).get("layers")?.takeIf { it.isJsonArray }?.asJsonArray?.toList() ?: emptyList()
        } else null
        addExternal(SMapExternalLayers.arcGis(id, options, info, styleLayers), SMapStyleLayerOptions(options.before, options.slot, options.zIndex))
    }

    /**
     * sMap's raster tiles of a style as an XYZ template, for tools without vector tiles:
     * `{node}/v1/raster/<style>/{z}/{x}/{y}[@2x].png?lang=…&key=…`.
     */
    fun rasterUrl(style: String = styleName, lang: String? = language, retina: Boolean = false): String =
        SMapStyleUrl.raster(node, style, lang, retina, options.apiKey)

    private fun updateAttribution() {
        val text = SMapAttribution.text(sources.values.map { it.str("attribution") } +
            defs.values.mapNotNull { it.layer?.objOrNull("source")?.str("attribution") })
        attributionView.text = text
        attributionView.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
    }

    // ------------------------------------------------------------------ layer description

    /** The map's layers as the shared layer description (`smap.layers` version 1): basemap, sources, layers. */
    fun toJSON(): JsonObject {
        val basemap = JsonObject().apply {
            addProperty("style", styleName)
            addProperty("language", language)
            add("overrides", basemapOverrides.deepCopy())
        }
        val entries = order.ids().mapNotNull { id ->
            val def = defs[id] ?: return@mapNotNull null
            // The shared description has points, lines, areas and style layers; custom markers and heat maps are left out.
            if (def.kind == SMapEngineIds.Kind.CUSTOM || def.kind == SMapEngineIds.Kind.HEATMAP || def.kind == SMapEngineIds.Kind.MODELS || id in snapshots) return@mapNotNull null
            val base = SMapLayerEntry(id = id, kind = "style", slot = def.slot, before = def.before, zIndex = def.zIndex,
                visible = !def.hidden, group = def.group)
            when (def.kind) {
                SMapEngineIds.Kind.STYLE -> base.copy(layer = def.layer!!.deepCopy())
                SMapEngineIds.Kind.POINTS -> base.copy(kind = "points", data = SMapJson.parseObject(def.data.toJson()), options = SMapLayerJson.pointOptions(def.points!!))
                SMapEngineIds.Kind.LINES -> base.copy(kind = "lines", data = SMapJson.parseObject(def.data.toJson()), options = SMapLayerJson.lineOptions(def.lines!!))
                SMapEngineIds.Kind.POLYGONS -> base.copy(kind = "polygons", data = SMapJson.parseObject(def.data.toJson()), options = SMapLayerJson.polygonOptions(def.polygons!!))
                SMapEngineIds.Kind.HEATMAP, SMapEngineIds.Kind.CUSTOM, SMapEngineIds.Kind.MODELS -> null
            }
        }
        return SMapLayerJson.write(basemap, sources, entries)
    }

    /** [toJSON] as text. */
    fun toJSONString(): String = SMapJson.stringify(toJSON())

    /**
     * Loads a layer description (a [JsonObject] or its text): its basemap, sources and layers, each through the call
     * that made it; an id already on the map is replaced, nothing else changes. A layer this map cannot draw is left
     * out (told through `onError`), never the whole description.
     *
     * @throws IllegalArgumentException when it is not a layer description, or a newer version
     */
    fun loadLayers(json: Any) {
        val desc = SMapLayerJson.read(if (json is JsonObject) json else SMapJson.parseObject(json.toString()))
        desc.basemap?.let { b ->
            val lang = b.str("language")
            val s = b.str("style")
            if (lang != null) language = lang
            if (s != null && s != styleName) setStyle(s) else if (lang != null) loadStyle()
            b.objOrNull("overrides")?.let { setBasemap(it) }
        }
        for ((id, src) in desc.sources) {
            try { addSource(id, src) } catch (e: Exception) { report(e) }
        }
        for (e in desc.layers) {
            try {
                when (e.kind) {
                    "style" -> addStyleLayer(e.layer ?: throw IllegalArgumentException("sMap: layer ${e.id} has no layer object"),
                        SMapStyleLayerOptions(e.before, e.slot, e.zIndex))
                    "points" -> addPoints(e.id, entryData(e), SMapLayerJson.pointOptions(e.options, e))
                    "lines" -> addLines(e.id, entryData(e), SMapLayerJson.lineOptions(e.options, e))
                    else -> addPolygons(e.id, entryData(e), SMapLayerJson.polygonOptions(e.options, e))
                }
                if (e.group != null) defs[e.id]?.group = e.group
                if (!e.visible) setVisible(e.id, false)
            } catch (x: Exception) {
                report(x)
            }
        }
    }

    private fun entryData(e: SMapLayerEntry): FeatureCollection =
        FeatureCollection.fromJson(SMapFormats.readGeojson(e.data ?: SMapFormats.collection(emptyList())).toString())

    // ------------------------------------------------------------------ engine layers

    private fun define(def: LayerDef) {
        if (def.slot != null && def.before != null) throw IllegalArgumentException("sMap: give a layer either slot or before")
        defs[def.id]?.let { old -> style?.let { drop(it, old) } }
        if (moves.layers.remove(def.id) != null) dropMovingSource(def.id)
        snapshots.remove(def.id)?.images?.values?.forEach { removeImage(it) }
        if (defs[def.id]?.kind == SMapEngineIds.Kind.CUSTOM) markers.remove(def.id)
        if (defs[def.id]?.kind == SMapEngineIds.Kind.MODELS) models?.remove(def.id)
        // A layer added under the id of a hidden data-layer tool starts hidden.
        if (tools.hidesLayer(def.id)) def.hidden = true
        defs[def.id] = def
        order.put(def.id, def.zIndex, def.slot, def.before)
        if (def.kind == SMapEngineIds.Kind.CUSTOM) { markers.put(def.id, def.custom!!, def.data); return }
        if (def.kind == SMapEngineIds.Kind.MODELS) { models().put(def.id, def.model!!, def.data); return }
        style?.let { addToStyle(it, def) }
    }

    private fun firstEngineLayer(style: Style, id: String): String? =
        defs[id]?.engineLayers?.firstOrNull { style.getLayer(it) != null }

    private fun drop(style: Style, def: LayerDef) {
        def.engineLayers.forEach { name -> style.getLayer(name)?.let { style.removeLayer(it) } }
        if (def.kind == SMapEngineIds.Kind.STYLE) {
            def.inlineSource?.let { s -> style.getSource(s)?.let { style.removeSource(it) } }
        } else {
            style.getSource(SMapEngineIds.source(def.id))?.let { style.removeSource(it) }
            style.getSource(SMapEngineIds.arrowPoints(def.id))?.let { style.removeSource(it) }
        }
    }

    private fun insertBelow(style: Style, id: String): String? =
        order.insertBefore(id, { anchors[it] }, { firstEngineLayer(style, it) })?.takeIf { style.getLayer(it) != null }

    private fun addToStyle(style: Style, def: LayerDef) {
        if (def.kind == SMapEngineIds.Kind.STYLE) return addStyleToStyle(style, def)
        if (def.kind == SMapEngineIds.Kind.CUSTOM || def.kind == SMapEngineIds.Kind.MODELS) return
        val src = SMapEngineIds.source(def.id)
        if (style.getSource(src) != null) drop(style, def)
        val sourceOptions = GeoJsonOptions()
        def.points?.cluster?.let {
            sourceOptions.withCluster(true).withClusterRadius(it.radius).withClusterMaxZoom(it.maxZoom)
        }
        if (def.viewClusters) { markers.put(clusterLayer(def.id), clusterMarkerOptions(def.id, def.points!!.cluster!!), EMPTY); clustersDirty = true }
        // The layers are made first: their style closures decide the hidden properties of the engine's data (G20).
        val layers = ArrayList<Triple<Layer, Float?, Float?>>()
        val build = SMapStyleBuild(stateNames(def))
        def.dashLayers = emptyList()
        def.dashSplits = emptyList()
        when (def.kind) {
            SMapEngineIds.Kind.POINTS -> addPointLayers(def.id, src, def.points!!, build) { l -> layers += Triple(l, def.points.minZoom, def.points.maxZoom) }
            SMapEngineIds.Kind.LINES -> lineLayers(def, src, def.lines!!, build).forEach { layers += Triple(it, def.lines.minZoom, def.lines.maxZoom) }
            SMapEngineIds.Kind.POLYGONS -> polygonLayers(def, src, def.polygons!!, build).forEach { layers += Triple(it, def.polygons.minZoom, def.polygons.maxZoom) }
            SMapEngineIds.Kind.HEATMAP -> {
                val o = def.heatmap!!
                layers += Triple(HeatmapLayer(SMapEngineIds.heat(def.id), src).withProperties(
                    PropertyFactory.heatmapWeight(o.weight?.let { w -> if (w is SMapValue.Fixed) Expression.literal(w.value) else Expression.coalesce(Expression.toNumber(Expression.get((w as SMapValue.Property).name)), Expression.literal(1)) } ?: Expression.literal(1)),
                    // blur (G33): the heat of a point fades over that many pixels past its radius.
                    PropertyFactory.heatmapRadius(o.radius + (o.blur?.takeIf { it > 0 } ?: 0f)),
                    PropertyFactory.heatmapIntensity(o.intensity),
                    PropertyFactory.heatmapOpacity(o.opacity),
                    PropertyFactory.heatmapColor(SMapHeat.ramp(o.colors, o.minOpacity)),
                ), o.minZoom, o.maxZoom)
            }
            else -> Unit
        }
        def.fns = build.fns
        if (def.lines?.arrows != null) addArrowImage(style)
        style.addSource(GeoJsonSource(src, engineData(def), sourceOptions))
        arrowData(def)?.let { style.addSource(GeoJsonSource(SMapEngineIds.arrowPoints(def.id), it)) }
        val before = insertBelow(style, def.id)
        val visibility = PropertyFactory.visibility(if (def.hidden) Property.NONE else Property.VISIBLE)
        for ((layer, minZoom, maxZoom) in layers) {
            layer.setProperties(visibility)
            minZoom?.let { layer.minZoom = it }
            maxZoom?.let { layer.maxZoom = it }
            if (before != null) style.addLayerBelow(layer, before) else style.addLayer(layer)
        }
        applyStates(def)
        if (def.kind == SMapEngineIds.Kind.POINTS && moves.keys(def.id).isNotEmpty()) showMoving(def)
    }

    private fun stateNames(def: LayerDef): List<String> =
        (def.points?.states?.keys ?: def.lines?.states?.keys ?: def.polygons?.states?.keys ?: emptySet<String>()).toList()

    // A constant, or a per-feature value with the layer's states over it, as an engine value.
    private fun v(json: JsonElement): Expression = raw(json)

    /**
     * [layer] as it is (a constant dash), or split for a dash that differs per feature: the solid features in [layer],
     * each pattern in a copy made by [copy] with its own dashes (the native engine takes no data expression for them).
     */
    private fun dashed(def: LayerDef, layer: Layer, v: SMapFeatureValue<List<Float>>?, constant: List<Float>?, b: SMapStyleBuild, copy: (String) -> Layer): List<Layer> {
        val reader = b.dashReader(v)
        if (reader == null) {
            b.dash(v, constant)?.let { layer.setProperties(PropertyFactory.lineDasharray(v(it))) }
            return listOf(layer)
        }
        val patterns = SMapDashSplit.patterns(def.data, reader)
        val index = b.dashIndex(reader, patterns)
        def.dashSplits = def.dashSplits + (reader to patterns)
        setFilter(layer, SMapDashSplit.filter(index, null))
        val parts = patterns.mapIndexed { i, d ->
            copy("${layer.id}-dash$i").also { part ->
                setFilter(part, SMapDashSplit.filter(index, i))
                part.setProperties(PropertyFactory.lineDasharray(d.toTypedArray()))
            }
        }
        def.dashLayers = def.dashLayers + parts.map { it.id }
        return listOf(layer) + parts
    }

    private fun setFilter(layer: Layer, filter: JsonElement) {
        when (layer) { is LineLayer -> layer.setFilter(raw(filter)); is FillLayer -> layer.setFilter(raw(filter)); else -> Unit }
    }

    private fun lineLayers(def: LayerDef, src: String, o: SMapLineOptions, b: SMapStyleBuild): List<Layer> {
        val id = def.id
        // simplestyle (stroke, stroke-width, stroke-opacity) when the layer gives no colour of its own
        val simple = o.color == null && o.colorValue == null
        val looks = o.states.values.toList()
        val color = b.color(o.colorValue, if (o.color != null) JsonPrimitive(o.color) else if (simple) SMapSimpleStyle.color("stroke", DEFAULT_COLOR) else JsonPrimitive(DEFAULT_COLOR))
        val width = b.number(o.widthValue, if (simple && o.width == DEFAULT_LINE_WIDTH) SMapSimpleStyle.number("stroke-width", DEFAULT_LINE_WIDTH) else JsonPrimitive(o.width))
        val opacity = b.number(o.opacityValue, if (simple && o.opacity == 1f) SMapSimpleStyle.number("stroke-opacity", 1) else JsonPrimitive(o.opacity))
        val colorV = b.stated(color, looks.map { it.color })
        val widthV = b.stated(width, looks.map { it.width })
        val opacityV = b.stated(opacity, looks.map { it.opacity })
        fun make(layerId: String) = LineLayer(layerId, src).withProperties(
            PropertyFactory.lineColor(v(colorV)),
            PropertyFactory.lineWidth(v(widthV)),
            PropertyFactory.lineOpacity(v(opacityV)),
            PropertyFactory.lineCap(Property.LINE_CAP_ROUND),
            PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
        ).apply { o.sortProperty?.let { setProperties(PropertyFactory.lineSortKey(v(b.sortKey(it)))) } }
        val out = ArrayList(dashed(def, make(SMapEngineIds.lines(id)), o.dashValue, o.dash, b, ::make))
        o.arrows?.let { a ->
            // Arrowheads along the line (G34): repeated by the engine every so many dp, or at points every share of it.
            val share = a.share
            val layer = SymbolLayer(SMapEngineIds.arrows(id), if (share != null) SMapEngineIds.arrowPoints(id) else src).withProperties(
                PropertyFactory.iconImage(SMapArrows.IMAGE),
                PropertyFactory.iconSize(a.sizeDp / ARROW_IMAGE_DP),
                PropertyFactory.iconColor(if (a.color != null) Expression.toColor(Expression.literal(a.color)) else v(colorV)),
                PropertyFactory.iconOpacity(a.opacity),
                PropertyFactory.iconAllowOverlap(true),
                PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
                PropertyFactory.iconKeepUpright(false),
            )
            if (share != null) layer.setProperties(PropertyFactory.iconRotate(Expression.get(SMapArrows.TURN)))
            else layer.setProperties(PropertyFactory.symbolPlacement(Property.SYMBOL_PLACEMENT_LINE), PropertyFactory.symbolSpacing(a.spacing))
            out += layer
        }
        if (o.label != null) {
            // A permanent label along each line (a route's name), repeated along long lines.
            out += SymbolLayer(SMapEngineIds.lineLabels(id), src).withProperties(
                PropertyFactory.symbolPlacement(Property.SYMBOL_PLACEMENT_LINE),
                PropertyFactory.symbolSpacing(o.labelSpacing),
                PropertyFactory.textField(Expression.toString(Expression.get(o.label))),
                PropertyFactory.textFont(arrayOf(LABEL_FONT)),
                PropertyFactory.textSize(v(b.number(o.labelSize, JsonPrimitive(12)))),
                PropertyFactory.textKeepUpright(true),
                PropertyFactory.textColor(o.labelColor),
                PropertyFactory.textHaloColor("#ffffff"),
                PropertyFactory.textHaloWidth(1.6f),
            ).also { labelOptions(it, o.allowOverlap, o.priority, b) }
        }
        return out
    }

    // Labels that always show or never overlap, and a priority per feature (G34): a higher one is placed first.
    private fun labelOptions(layer: SymbolLayer, allowOverlap: Boolean?, priority: SMapFeatureValue<Float>?, b: SMapStyleBuild) {
        when (allowOverlap) {
            true -> layer.setProperties(PropertyFactory.textAllowOverlap(true), PropertyFactory.textIgnorePlacement(true))
            false -> layer.setProperties(PropertyFactory.textAllowOverlap(false), PropertyFactory.textIgnorePlacement(false))
            null -> Unit
        }
        priority?.let { layer.setProperties(PropertyFactory.symbolSortKey(v(SMapStyleBuild.priorityKey(b.number(it, JsonPrimitive(0)))))) }
    }

    // The SDK's own arrowhead (G34): an SDF arrow pointing east, drawn in each line's colour.
    private fun addArrowImage(style: Style) {
        if (style.getImage(SMapArrows.IMAGE) != null) return
        val d = resources.displayMetrics.density
        val size = Math.round(ARROW_IMAGE_DP * d)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.BLACK
            // A soft edge, read by the engine as a distance field (its edge at alpha 0.75).
            maskFilter = android.graphics.BlurMaskFilter(size * 0.06f, android.graphics.BlurMaskFilter.Blur.NORMAL)
        }
        val m = size * 0.16f
        val path = android.graphics.Path().apply {
            moveTo(size - m, size / 2f); lineTo(m, m); lineTo(size * 0.36f, size / 2f); lineTo(m, size - m); close()
        }
        android.graphics.Canvas(bitmap).drawPath(path, paint)
        bitmap.density = Math.round(d * android.util.DisplayMetrics.DENSITY_DEFAULT)
        style.addImage(SMapArrows.IMAGE, bitmap, true)
    }

    private fun polygonLayers(def: LayerDef, src: String, o: SMapPolygonOptions, b: SMapStyleBuild): List<Layer> {
        val id = def.id
        val looks = o.states.values.toList()
        val simple = o.fill == null && o.fillValue == null
        val extrude = o.extrude
        if (extrude != null) {
            val color = b.color(o.fillValue, JsonPrimitive(o.fill ?: DEFAULT_COLOR))
            return listOf(FillExtrusionLayer(SMapEngineIds.extrusion(id), src).withProperties(
                PropertyFactory.fillExtrusionColor(v(b.stated(color, looks.map { it.fill }))),
                PropertyFactory.fillExtrusionHeight(valueExpression(extrude.height)),
                PropertyFactory.fillExtrusionBase(valueExpression(extrude.base)),
                PropertyFactory.fillExtrusionOpacity(o.opacity),
            ))
        }
        // simplestyle (fill, fill-opacity, stroke, stroke-width, stroke-opacity) of each feature when no fill is given
        val fill = b.color(o.fillValue, if (simple) SMapSimpleStyle.color("fill", DEFAULT_COLOR) else JsonPrimitive(o.fill ?: DEFAULT_COLOR))
        val opacity = b.number(o.opacityValue, if (simple && o.opacity == DEFAULT_FILL_OPACITY) SMapSimpleStyle.number("fill-opacity", DEFAULT_FILL_OPACITY) else JsonPrimitive(o.opacity))
        val ownOutline = o.outline != null || o.outlineValue != null
        val outline = b.color(o.outlineValue, when {
            o.outline != null -> JsonPrimitive(o.outline)
            simple -> SMapSimpleStyle.outlineColor(DEFAULT_COLOR)
            else -> fill
        })
        val outlineWidth = b.number(o.outlineWidthValue,
            if (simple && o.outlineWidth == DEFAULT_OUTLINE_WIDTH) SMapSimpleStyle.number("stroke-width", DEFAULT_OUTLINE_WIDTH) else JsonPrimitive(o.outlineWidth))
        val fillLayer = FillLayer(SMapEngineIds.fill(id), src).withProperties(
            PropertyFactory.fillColor(v(b.stated(fill, looks.map { it.fill }))),
            PropertyFactory.fillOpacity(v(b.stated(opacity, looks.map { it.opacity }))),
        )
        // An outline without its own colour follows the fill, in each state's look too.
        val outlineV = b.stated(outline, looks.map { it.outline ?: if (ownOutline) null else it.fill })
        val outlineWidthV = b.stated(outlineWidth, looks.map { it.outlineWidth })
        fun make(layerId: String) = LineLayer(layerId, src).withProperties(
            PropertyFactory.lineColor(v(outlineV)),
            PropertyFactory.lineWidth(v(outlineWidthV)),
        ).apply {
            if (simple) setProperties(PropertyFactory.lineOpacity(raw(SMapSimpleStyle.number("stroke-opacity", 1))))
            o.sortProperty?.let { setProperties(PropertyFactory.lineSortKey(v(b.sortKey(it)))) }
        }
        o.sortProperty?.let { fillLayer.setProperties(PropertyFactory.fillSortKey(v(b.sortKey(it)))) }
        return listOf(fillLayer) + dashed(def, make(SMapEngineIds.outline(id)), o.outlineDash, null, b, ::make)
    }

    private fun raw(json: JsonElement): Expression = SMapRawExpression.of(json)

    private fun addStyleToStyle(style: Style, def: LayerDef) {
        drop(style, def)
        var json = def.layer!!
        try {
            val inline = def.inlineSource
            if (inline != null) {
                style.addSource(SMapEngineStyle.source(inline, json.getAsJsonObject("source")))
                json = json.deepCopy().apply { addProperty("source", inline) }
            }
            val layer = SMapEngineStyle.layer(json, def.hidden)
            val before = insertBelow(style, def.id)
            if (before != null) style.addLayerBelow(layer, before) else style.addLayer(layer)
        } catch (e: Exception) {
            report(e)
        }
    }

    private fun addPointLayers(id: String, src: String, o: SMapPointOptions, b: SMapStyleBuild, add: (Layer) -> Unit) {
        val unclustered = Expression.not(Expression.has("point_count"))
        val looks = o.states.values.toList()
        // Clusters drawn as views (ring or render) have no circles of their own.
        if (o.cluster != null && o.cluster.ring == null && o.cluster.render == null) {
            add(
                CircleLayer(SMapEngineIds.clusters(id), src).withFilter(Expression.has("point_count")).withProperties(
                    PropertyFactory.circleColor(o.color ?: DEFAULT_COLOR),
                    PropertyFactory.circleOpacity(0.85f),
                    PropertyFactory.circleRadius(
                        Expression.step(
                            Expression.get("point_count"), Expression.literal(14),
                            Expression.stop(50, 18), Expression.stop(500, 24), Expression.stop(5000, 30),
                        ),
                    ),
                    PropertyFactory.circleStrokeWidth(3f),
                    PropertyFactory.circleStrokeColor("rgba(255,255,255,0.75)"),
                ),
            )
            add(
                SymbolLayer(SMapEngineIds.clusterCount(id), src).withFilter(Expression.has("point_count")).withProperties(
                    PropertyFactory.textField(Expression.toString(Expression.get("point_count_abbreviated"))),
                    PropertyFactory.textFont(arrayOf(LABEL_FONT)),
                    PropertyFactory.textSize(12f),
                    PropertyFactory.textAllowOverlap(true),
                    PropertyFactory.textIgnorePlacement(true),
                    PropertyFactory.textColor("#ffffff"),
                ),
            )
        }
        if (o.cluster != null && (o.cluster.ring != null || o.cluster.render != null)) {
            // The view clusters are read from this layer: the clusters drawn this frame, so they match the points drawn
            // beside them (the source also holds tiles kept from another zoom while new ones load). An opacity of 0
            // would leave it out of the engine's queries; 0.004 changes no pixel.
            add(
                CircleLayer(SMapEngineIds.clusterHits(id), src).withFilter(Expression.has("point_count")).withProperties(
                    PropertyFactory.circleColor("#ffffff"),
                    PropertyFactory.circleOpacity(0.004f),
                    PropertyFactory.circleRadius(24f),
                ),
            )
        }
        val main = if (o.icon != null || o.iconProperty != null) {
            SymbolLayer(SMapEngineIds.points(id), src).withProperties(
                // The app's image of the name, else the sprite's (G25: app images are namespaced on the map).
                iconImageValue(o),
                PropertyFactory.iconSize(o.iconSize),
                PropertyFactory.iconAllowOverlap(true),
                PropertyFactory.iconIgnorePlacement(o.iconProperty != null),
                // Own images per point stack in data order (later on top), as live markers do.
                PropertyFactory.symbolZOrder(if (o.iconProperty != null) Property.SYMBOL_Z_ORDER_SOURCE else Property.SYMBOL_Z_ORDER_AUTO),
                PropertyFactory.iconAnchor(o.iconAnchor.engineName),
            ).apply {
                if (o.iconOffsetDp != 0f to 0f) setProperties(PropertyFactory.iconOffset(arrayOf(o.iconOffsetDp.first, o.iconOffsetDp.second)))
                val base = o.iconOpacityProperty?.let { SMapJson.arr("to-number", SMapJson.arr("coalesce", SMapJson.arr("get", it), 1)) } ?: JsonPrimitive(1)
                if (o.opacity != null || o.iconOpacityProperty != null || looks.any { it.opacity != null }) {
                    setProperties(PropertyFactory.iconOpacity(v(b.stated(b.number(o.opacity, base), looks.map { it.opacity }))))
                }
                o.sortProperty?.let { setProperties(PropertyFactory.symbolSortKey(v(b.sortKey(it)))) }
                // The colour of an SDF image, per feature and per state (G25).
                if (o.iconColor != null || looks.any { it.iconColor != null }) {
                    setProperties(PropertyFactory.iconColor(v(b.stated(b.color(o.iconColor, JsonPrimitive("#000000")), looks.map { it.iconColor }))))
                }
                // A heading turns the icon about its anchor (G24).
                o.rotation?.let { r ->
                    setProperties(
                        PropertyFactory.iconRotate(v(b.number(r, JsonPrimitive(0)))),
                        PropertyFactory.iconRotationAlignment(o.rotationAlignment.engineName),
                    )
                }
            }
        } else {
            // simplestyle (marker-color, marker-size) when the layer gives no colour of its own
            val simple = o.color == null && o.colorValue == null
            val color = b.color(o.colorValue, if (o.color != null) JsonPrimitive(o.color) else if (simple) SMapSimpleStyle.color("marker-color", DEFAULT_COLOR) else JsonPrimitive(DEFAULT_COLOR))
            val radius = b.number(o.radiusValue, if (simple && o.radius == DEFAULT_RADIUS) SMapSimpleStyle.markerRadius() else JsonPrimitive(o.radius))
            val stroke = b.color(o.strokeColorValue, JsonPrimitive(o.strokeColor))
            val strokeWidth = b.number(o.strokeWidth, JsonPrimitive(1.5))
            val opacity = b.stated(b.number(o.opacity, JsonPrimitive(1)), looks.map { it.opacity })
            CircleLayer(SMapEngineIds.points(id), src).withProperties(
                PropertyFactory.circleColor(v(b.stated(color, looks.map { it.color }))),
                PropertyFactory.circleRadius(v(b.stated(radius, looks.map { it.radius }))),
                PropertyFactory.circleStrokeWidth(v(b.stated(strokeWidth, looks.map { it.strokeWidth }))),
                PropertyFactory.circleStrokeColor(v(b.stated(stroke, looks.map { it.strokeColor }))),
            ).apply {
                if (opacity != JsonPrimitive(1)) setProperties(PropertyFactory.circleOpacity(v(opacity)), PropertyFactory.circleStrokeOpacity(v(opacity)))
                o.sortProperty?.let { setProperties(PropertyFactory.circleSortKey(v(b.sortKey(it)))) }
            }
        }
        if (o.cluster != null) {
            if (main is SymbolLayer) main.setFilter(unclustered) else (main as CircleLayer).setFilter(unclustered)
        }
        add(main)
        if (o.label != null) {
            val labels = SymbolLayer(SMapEngineIds.labels(id), src).withProperties(
                PropertyFactory.textField(Expression.toString(Expression.get(o.label))),
                PropertyFactory.textFont(arrayOf(LABEL_FONT)),
                PropertyFactory.textSize(v(b.number(o.labelSize, JsonPrimitive(12)))),
                PropertyFactory.textOffset(arrayOf(0f, 1.2f)),
                PropertyFactory.textAnchor(Property.TEXT_ANCHOR_TOP),
                PropertyFactory.textOptional(true),
                PropertyFactory.textColor("#1f2937"),
                PropertyFactory.textHaloColor("#ffffff"),
                PropertyFactory.textHaloWidth(1.4f),
            )
            labelOptions(labels, o.allowOverlap, o.priority, b)
            if (o.cluster != null) labels.setFilter(unclustered)
            add(labels)
        }
    }
    private fun valueExpression(v: SMapValue): Expression = when (v) {
        is SMapValue.Fixed -> Expression.literal(v.value)
        is SMapValue.Property -> Expression.coalesce(Expression.toNumber(Expression.get(v.name)), Expression.literal(0))
    }

    // ------------------------------------------------------------------ map tools

    /**
     * Lays the app's [view] over the map as a tool, shown or hidden by the tools control, [setToolVisible] and
     * [setToolsVisible]. In a corner the view must not have a parent; with [SMapToolPosition.NONE] it stays where the
     * app put it and is only shown and hidden. Adding an id again replaces the first.
     *
     * @param id 1-64 letters, digits, `-`, `_` or `.`
     * @param label shown on the tool's row in the tools control and read by screen readers
     */
    fun addTool(id: String, view: View, label: String = id, position: SMapToolPosition = SMapToolPosition.TOP_LEFT) {
        SMapToolRegistry.checkId(id)
        SMapToolRegistry.checkPosition(position)
        require(position == SMapToolPosition.NONE || view.parent == null) { "sMap: a tool laid in a corner must not have a parent" }
        placeTool(SMapToolRegistry.Entry(id, label, position, null, view))
    }

    /**
     * Registers data layers as a tool: hiding it hides every layer in [layers] (layout visibility), showing it shows
     * them. The layers are the SDK's own (addPoints, addLines, addPolygons, addData groups, style and external layers)
     * or the basemap's. A layer that is not on the map is left alone; one added later under the id of a hidden tool
     * starts hidden. The tool has no view and no corner. Adding an id again replaces the first.
     *
     * @param layers one or more layer ids (a layer and its labels, …); a repeated id counts once
     */
    fun addTool(id: String, layers: List<String>, label: String = id) {
        SMapToolRegistry.checkId(id)
        val ids = SMapToolRegistry.checkLayers(layers)
        tools.add(SMapToolRegistry.Entry<View?>(id, label, SMapToolPosition.NONE, null, null, ids))?.let(::takeOff)
        joinControl()
        // A tool hidden from the start hides its layers now; a shown one leaves them as they are.
        if (!tools.isVisible(id)) applyLayers(ids, false)
        placeControl()
        renderTools()
    }

    /** Registers one data layer as a tool (see the list form). */
    fun addTool(id: String, layer: String, label: String = id) = addTool(id, listOf(layer), label)

    /** Adds a tool the SDK makes ([SMapToolKind]); its English label and corner unless given. */
    fun addTool(id: String, kind: SMapToolKind, label: String? = null, position: SMapToolPosition? = null) {
        SMapToolRegistry.checkId(id)
        val at = position ?: kind.position
        SMapToolRegistry.checkPosition(at)
        require(at != SMapToolPosition.NONE) { "sMap: a tool the SDK makes sits in a corner" }
        val name = label ?: kind.label
        val view: View = when (kind) {
            SMapToolKind.ZOOM -> SMapZoomTool(context, name) { step ->
                engine?.animateCamera(if (step > 0) CameraUpdateFactory.zoomIn() else CameraUpdateFactory.zoomOut())
            }
            SMapToolKind.COMPASS -> SMapCompassTool(context, name) {
                engine?.animateCamera(CameraUpdateFactory.bearingTo(0.0))
            }
            SMapToolKind.SCALE -> SMapScaleTool(context, name, SMapToolRegistry.usesMiles(Locale.getDefault().country))
            SMapToolKind.LOCATE -> SMapLocateTool(context, name) { locate() }
        }
        placeTool(SMapToolRegistry.Entry(id, name, at, kind, view))
    }

    /**
     * (1.5.0, G35) The search tool: a search field and a list of the app's own results ([SMapSearchOptions.search];
     * the SDK never calls a geocoder); a pick fits its bounds or flies to its position and is told to
     * [SMapSearchOptions.onPick]. Shown and hidden with the tools control like any tool.
     */
    fun addTool(id: String, search: SMapSearchOptions, label: String? = null, position: SMapToolPosition = SMapToolPosition.TOP_LEFT) {
        SMapToolRegistry.checkId(id)
        SMapToolRegistry.checkPosition(position)
        require(position != SMapToolPosition.NONE) { "sMap: a tool the SDK makes sits in a corner" }
        val name = label ?: SMapTexts.text(language, "search")
        placeTool(SMapToolRegistry.Entry(id, name, position, null, SMapSearchToolView(context, this, search)))
    }

    // ------------------------------------------------------------------ exporting the map (G29, M82)

    /**
     * (1.5.0, G29) The map as one picture: the native map's own snapshot once the view's tiles are drawn (10 s at
     * most), the 3D models, the custom markers in view and the tooltip, the drawing tools' figures, the app's views in
     * [SMapExportOptions.include] and the credit — never the tools.
     */
    suspend fun export(options: SMapExportOptions = SMapExportOptions()): Bitmap {
        val map = ready().engine ?: throw IllegalStateException("sMap: the map is not ready")
        withTimeoutOrNull(EXPORT_WAIT_MILLIS) { renderedFully() }
        val shot = kotlinx.coroutines.suspendCancellableCoroutine<Bitmap> { c -> map.snapshot { b -> c.resumeWith(Result.success(b)) } }
        val d = resources.displayMetrics.density
        val scale = SMapExportMath.scale(options.pixelRatio, d)
        val (w, h) = SMapExportMath.size(width, height, scale)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(out)
        SMapExportMath.background(options.format, options.background)?.let { canvas.drawColor(Color.parseColor(it)) }
        val paint = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(shot, null, android.graphics.Rect(0, 0, w, h), paint)
        models?.takeIf { it.isAvailable && it.visibility == View.VISIBLE }?.bitmap?.let { canvas.drawBitmap(it, null, android.graphics.Rect(0, 0, w, h), paint) }
        // Views of the map drawn where they are: the markers and tooltip, the drawing tools' labels, the credit.
        fun drawAt(v: View, x: Float, y: Float) {
            if (v.visibility != View.VISIBLE || v.width == 0 || v.height == 0) return
            canvas.save(); canvas.scale(scale, scale); canvas.translate(x, y); v.draw(canvas); canvas.restore()
        }
        drawAt(markers, markers.x, markers.y)
        drawTools.forEach { t -> t.labelView?.let { drawAt(it, it.x, it.y) } }
        val here = IntArray(2).also { getLocationInWindow(it) }
        for (inc in options.include) {
            val v = inc.view
            if (v.width == 0 || v.height == 0) continue
            val corner = inc.corner
            if (corner == null) {
                val at = IntArray(2).also { v.getLocationInWindow(it) }
                drawAt(v, (at[0] - here[0]).toFloat(), (at[1] - here[1]).toFloat())
            } else {
                val (x, y) = SMapExportMath.corner(corner, w, h, Math.round(v.width * scale), Math.round(v.height * scale), Math.round(SMapExportMath.CORNER_MARGIN_DP * d * scale))
                drawAt(v, x / scale, y / scale)
            }
        }
        drawAt(creditView, creditView.x, creditView.y)
        return out
    }

    /** (1.5.0, G29) [export] as PNG or JPEG data. */
    suspend fun exportBytes(options: SMapExportOptions = SMapExportOptions()): ByteArray {
        val bitmap = export(options)
        return withContext(Dispatchers.Default) { SMapExportMath.encode(bitmap, options.format, options.quality) }
    }

    // Until the engine has drawn a frame with every tile of the view.
    private suspend fun renderedFully() = kotlinx.coroutines.suspendCancellableCoroutine<Unit> { c ->
        var listener: MapView.OnDidFinishRenderingFrameListener? = null
        listener = MapView.OnDidFinishRenderingFrameListener { fully, _, _ ->
            if (fully && c.isActive) { mapView.removeOnDidFinishRenderingFrameListener(listener!!); c.resumeWith(Result.success(Unit)) }
        }
        mapView.addOnDidFinishRenderingFrameListener(listener)
        c.invokeOnCancellation { mapView.post { mapView.removeOnDidFinishRenderingFrameListener(listener) } }
        engine?.triggerRepaint()
    }

    /** Removes a tool: a corner view leaves the map, a view the app placed is shown again. */
    fun removeTool(id: String) {
        val entry = tools.remove(id) ?: return
        takeOff(entry)
        placeControl()
        renderTools()
    }

    /** Shows or hides one tool. A hidden tool keeps its state and comes back as it was. */
    fun setToolVisible(id: String, visible: Boolean) {
        tools.setVisible(id, visible).forEach { tools[it]?.let(::showTool) }
        renderTools()
    }

    /** Shows or hides every tool. The attribution and the sMap badge always stay. */
    fun setToolsVisible(visible: Boolean) {
        tools.setAllVisible(visible).forEach { tools[it]?.let(::showTool) }
        renderTools()
    }

    /** The tools in the order added. */
    fun tools(): List<SMapToolState> = tools.states()

    /** Called after every change of the tools' visibility; the SDK keeps no state itself. */
    fun addToolsChangeListener(listener: (SMapToolsChange) -> Unit) = tools.addListener(listener)
    fun removeToolsChangeListener(listener: (SMapToolsChange) -> Unit) = tools.removeListener(listener)

    private fun placeTool(entry: SMapToolRegistry.Entry<View?>) {
        tools.add(entry)?.let(::takeOff)
        joinControl()
        val view = entry.payload
        if (view != null && entry.position != SMapToolPosition.NONE) corners().add(entry.position, view)
        if (entry.kind == SMapToolKind.COMPASS) engine?.uiSettings?.isCompassEnabled = false
        showTool(entry)
        placeControl()
        updateToolViews()
        renderTools()
    }

    // The tools control joins the map with its first tool, so a map without tools is as before.
    private fun joinControl() {
        val control = options.tools.control
        if (toolsControl != null || control == null) return
        val at = controlCorner(control)
        toolsControl = SMapToolsControl(context, at, options.tools.labels,
            onToggle = { id -> setToolVisible(id, !tools.isVisible(id)) },
            onAll = { on -> setToolsVisible(on) },
            onOpen = { open -> toolsControl?.let { corners().raise(it.position, open) } },
        ).also { corners().add(at, it, last = true) }
    }

    private fun controlCorner(control: SMapToolPosition): SMapToolPosition =
        if (control == SMapToolPosition.TOOLBAR) tools.toolbarCorner() else control

    // The tools control is the last of its corner's tools: by default the toolbar's (the corner of the zoom tool, which
    // may change as tools come and go), kept last when tools join the corner later. Its corner is drawn above the others.
    private fun placeControl() {
        val control = toolsControl ?: return
        val at = controlCorner(options.tools.control ?: return)
        val corners = corners()
        if (control.position == at && corners.isLast(at, control)) return
        val open = control.isOpen
        if (open) corners.raise(control.position, false)
        corners.remove(control)
        if (control.position != at) control.layOut(at)
        corners.add(at, control, last = true)
        corners.raise(at, open)
    }

    private fun corners(): SMapToolCorners = toolCorners ?: SMapToolCorners(this).also { toolCorners = it }

    private fun takeOff(entry: SMapToolRegistry.Entry<View?>) {
        val layers = entry.layers
        if (layers != null) {
            // A removed data-layer tool leaves its layers shown, as a removed view is shown again.
            if (!tools.isVisible(entry.id)) applyLayers(layers, true)
            return
        }
        val view = entry.payload ?: return
        if (entry.position == SMapToolPosition.NONE) {
            view.visibility = View.VISIBLE
        } else {
            toolCorners?.remove(view)
        }
    }

    private fun showTool(entry: SMapToolRegistry.Entry<View?>) {
        entry.layers?.let { applyLayers(it, tools.isVisible(entry.id)); return }
        val view = entry.payload ?: return
        // The compass shows only while the map is rotated, like the engine's own.
        val rotated = entry.kind != SMapToolKind.COMPASS || (engine?.cameraPosition?.bearing ?: 0.0) != 0.0
        view.visibility = if (tools.isVisible(entry.id) && rotated) View.VISIBLE else View.GONE
    }

    // A data-layer tool's layers: the SDK's own through setVisible (kept across style changes), the basemap's through
    // their layout visibility; a layer that is not on the map is left alone (nothing is recorded for it).
    private fun applyLayers(layers: List<String>, visible: Boolean, s: Style? = style) {
        for (id in layers) {
            if (defs[id] != null) {
                setVisible(id, visible)
            } else if (s?.getLayer(id) != null) {
                val value = if (visible) Property.VISIBLE else Property.NONE
                edit(id) { setKey(it, false, "visibility", JsonPrimitive(value)) }
                try { s.getLayer(id)?.setProperties(PropertyFactory.visibility(value)) } catch (e: Exception) { report(e) }
            }
        }
    }

    // After a style loads: the basemap layers of hidden data-layer tools (the SDK's own layers keep their state).
    private fun hideLayerTools(s: Style) {
        for (entry in tools.all) {
            val layers = entry.layers ?: continue
            if (!tools.isVisible(entry.id)) applyLayers(layers.filter { defs[it] == null }, false, s)
        }
    }

    private fun renderTools() {
        toolsControl?.render(tools.states())
    }

    // The marker views follow the camera; view clusters are read again when it stops.
    private fun attachOverlay(map: MapLibreMap) {
        markers.map = map
        models?.map = map
        map.addOnCameraMoveListener { markers.layout(); interaction.cameraMoved(); models?.invalidateModels(); clustersMoving = true; clustersDirty = true }
        map.addOnCameraIdleListener { models?.invalidateModels() }
        map.addOnCameraIdleListener { markers.layout(); clustersMoving = false; clustersDirty = true; readClustersUntilSettled(0) }
        // The clusters drawn change with the frames: after a change (camera, data, style) they are read at the next
        // drawn frames — every frame while the camera moves (zooming splits and merges them), else at most every
        // 200 ms — until two reads agree. A frame drawn while tiles still load (not fully rendered) shows the tiles
        // of the zoom before in their place, so the clusters are read again until the engine has drawn them all.
        // Nothing is left to draw (every tile loaded): one last read, whatever earlier reads agreed on.
        mapView.addOnDidBecomeIdleListener { if (clusterSignatures.isNotEmpty()) { refreshClusters(); clustersDirty = false } }
        mapView.addOnDidFinishRenderingFrameListener { fully, _, _ ->
            if (!fully && clusterSignatures.isNotEmpty()) clustersDirty = true
            val now = android.os.SystemClock.uptimeMillis()
            if (clustersDirty && (clustersMoving || now - clustersReadAt >= 200)) { clustersReadAt = now; if (refreshClusters()) clustersDirty = false }
        }
        markers.layout()
    }

    private fun attachTools(map: MapLibreMap) {
        attachOverlay(map)
        attachEvents(map)
        if (tools.all.any { it.kind == SMapToolKind.COMPASS }) map.uiSettings.isCompassEnabled = false
        map.addOnCameraMoveListener { updateToolViews() }
        map.addOnCameraIdleListener { updateToolViews() }
        updateToolViews()
    }

    private fun updateToolViews() {
        val map = engine ?: return
        val camera = map.cameraPosition
        for (entry in tools.all) {
            when (val view = entry.payload ?: continue) {
                is SMapScaleTool -> view.update(map.projection.getMetersPerPixelAtLatitude(camera.target?.latitude ?: 0.0))
                is SMapCompassTool -> { view.setBearing(camera.bearing); showTool(entry) }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun locate() {
        val map = engine ?: return
        val granted = listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            .any { context.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        if (!granted) {
            report(SMapException("sMap: the app does not hold the location permission"))
            return
        }
        val manager = context.getSystemService(LocationManager::class.java)
        val last = manager?.getProviders(true)?.mapNotNull { provider ->
            try { manager.getLastKnownLocation(provider) } catch (e: SecurityException) { null }
        }?.maxByOrNull { it.time }
        if (last == null) {
            report(SMapException("sMap: the device's position is not known yet"))
            return
        }
        val zoom = maxOf(map.cameraPosition.zoom, LOCATE_ZOOM)
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(last.latitude, last.longitude), zoom))
    }

    // ------------------------------------------------------------------ taps

    private fun handleTap(map: MapLibreMap, latLng: LatLng): Boolean {
        toolsControl?.open(false)
        val point = map.projection.toScreenLocation(latLng)
        // A tap on the map closes a tooltip opened from code (G22); the map's click comes first (G16).
        if (openTip != null) closeTooltip()
        if (events.has(SMapEventType.CLICK)) events.fire(SMapEventType.CLICK, SMapEvent(SMapEventType.CLICK.webName, latLng, point))
        // The map's own click of a touch a custom marker view already answered (1.5.5).
        if (repeatsMarkerTap(point)) return true
        val s = style ?: return false
        val tol = tapTolerancePx()
        val near = tapCandidates(map, point, tol, latLng)
        // Custom markers are drawn over the map: one under the finger answers before any layer.
        if (near.any { it.item.custom && it.distance <= 0f }) return answerTap(near, tol, point)
        val pointIds = near.mapTo(HashSet()) { it.item.layerId }
        for (id in order.ids().asReversed()) {
            val def = defs[id] ?: continue
            if (def.hidden) continue
            val cluster = def.points?.cluster
            if (cluster != null) {
                val clusters = SMapEngineIds.clusters(id)
                if (s.getLayer(clusters) != null) {
                    val hit = map.queryRenderedFeatures(point, clusters).firstOrNull()
                    if (hit != null && hit.geometry() is Point) {
                        // A plain cluster: its onTap gets the cluster with its points (G19), zoomOnTap as view clusters.
                        val info = clusterInfo(id, hit)
                        cluster.onTap?.let { tap -> try { tap(info) } catch (e: Exception) { report(e) } }
                        val source = s.getSourceAs<GeoJsonSource>(SMapEngineIds.source(id))
                        if (cluster.zoomOnTap && source != null) {
                            val zoom = source.getClusterExpansionZoom(hit).toDouble()
                            map.animateCamera(CameraUpdateFactory.newLatLngZoom(info.position, zoom))
                        }
                        return true
                    }
                }
            }
            // (1.5.5) Points and custom markers answer where they are drawn, nearest first, piled ones to choose from.
            if (id in pointIds) return answerTap(near, tol, point)
            if (def.kind == SMapEngineIds.Kind.POINTS || def.kind == SMapEngineIds.Kind.CUSTOM) continue
            val handler = tapHandlers[id] ?: continue
            val layer = SMapEngineIds.tapLayer(id, def.kind, def.polygons?.extrude != null)
            if (s.getLayer(layer) == null) continue
            val hit = featureAt(map, id, layer, point) ?: continue
            handler(dataProperties(def, hit), latLng)
            return true
        }
        return answerTap(near, tol, point)
    }

    // ------------------------------------------------------------------ precise taps and piled points (1.5.5)
    //
    // A point or custom marker counts for a tap only where it is drawn (a circle within its radius and stroke, an icon
    // within its image's box, a marker within its view's frame) plus the finger tolerance; the one holding the tap
    // comes first, then the nearest, then the drawing order. Two or more holding the tap itself (of layers whose
    // overlap is on) are listed in a small menu at the tap; the camera never moves for it.

    /** A point or custom marker near a tap: its layer and key, the feature as callbacks see it, and its tap. */
    private class TapHit(
        val layerId: String,
        val key: String,
        val custom: Boolean,
        val labelValue: Any?,
        val feature: () -> SMapFeature,
        val answer: () -> Unit,
    )

    // A marker view's tap (uptime, x, y): the map's own click of the same touch comes after it and is not answered again.
    private var markerTap: Triple<Long, Float, Float>? = null
    private var chooser: android.widget.PopupMenu? = null
    private var chooserAnchor: View? = null

    private fun tapTolerancePx(): Float = maxOf(0f, options.tapTolerance) * resources.displayMetrics.density

    private fun overlapOn(def: LayerDef): Boolean = (def.points?.overlap ?: def.custom?.overlap)?.enabled == true

    /** A custom marker view was tapped at a point of the map: answered here (true) unless its layer is not a custom marker layer. */
    internal fun markerTapped(layerId: String, x: Float, y: Float): Boolean {
        if (defs[layerId]?.kind != SMapEngineIds.Kind.CUSTOM) return false
        val map = engine ?: return true
        markerTap = Triple(android.os.SystemClock.uptimeMillis(), x, y)
        val point = PointF(x, y)
        val tol = tapTolerancePx()
        answerTap(tapCandidates(map, point, tol, map.projection.fromScreenLocation(point)), tol, point)
        return true
    }

    // Whether the map's click repeats the tap a marker view just answered (once).
    private fun repeatsMarkerTap(point: PointF): Boolean {
        val (at, x, y) = markerTap ?: return false
        markerTap = null
        val window = android.view.ViewConfiguration.getDoubleTapTimeout() + 400L
        return android.os.SystemClock.uptimeMillis() - at <= window && SMapTapMath.sameTap(x, y, point.x, point.y, 24 * resources.displayMetrics.density)
    }

    private fun answerTap(near: List<SMapTapMath.Candidate<TapHit>>, tol: Float, point: PointF): Boolean =
        when (val a = SMapTapMath.answer(near, tol)) {
            is SMapTapMath.Answer.None -> false
            is SMapTapMath.Answer.One -> { a.item.answer(); true }
            is SMapTapMath.Answer.Choose -> { showChooser(a.items, point); true }
        }

    /** The points (of layers with a tap handler) and custom markers (of layers with onTap) within [tol] pixels of [point], top first. */
    private fun tapCandidates(map: MapLibreMap, point: PointF, tol: Float, latLng: LatLng): List<SMapTapMath.Candidate<TapHit>> {
        val out = ArrayList<SMapTapMath.Candidate<TapHit>>()
        var rank = 0
        // Custom markers are drawn over the map.
        val customIds = defs.values.filter { it.kind == SMapEngineIds.Kind.CUSTOM && !it.hidden && it.custom?.onTap != null }.map { it.id }.toSet()
        if (customIds.isNotEmpty()) for ((id, item, d) in markers.near(point.x, point.y, tol, customIds)) {
            val def = defs[id] ?: continue
            val f = SMapFeature(item.key, SMapGeoJson.propertiesOf(item.feature), LatLng(item.lat, item.lng))
            out += SMapTapMath.Candidate(TapHit(id, item.key, true, null, { f }) { def.custom?.onTap?.invoke(f) }, d, rank++, overlapOn(def))
        }
        val s = style ?: return out
        for (id in order.ids().asReversed()) {
            val def = defs[id] ?: continue
            if (def.hidden || def.kind != SMapEngineIds.Kind.POINTS) continue
            val handler = tapHandlers[id] ?: continue
            val o = def.points ?: continue
            for ((hit, d) in pointHits(map, s, def, o, point, tol)) {
                val props = dataProperties(def, hit)
                val key = hit.id() ?: ""
                val labelValue = o.label?.let { props[it] }
                out += SMapTapMath.Candidate(TapHit(id, key, false, labelValue, { userFeature(def, hit, latLng) }) { handler(props, latLng) }, d, rank++, overlapOn(def))
            }
        }
        return out
    }

    /** The features of a point layer within [tol] pixels of [point] as drawn, top first, each with its distance (0 on it). */
    private fun pointHits(map: MapLibreMap, s: Style, def: LayerDef, o: SMapPointOptions, point: PointF, tol: Float): List<Pair<Feature, Float>> {
        snapshots[def.id]?.let { return snapshotHits(map, def, it, point, tol) }
        val d = resources.displayMetrics.density
        val icons = o.icon != null || o.iconProperty != null
        // The features moving now are drawn from their own source above the layer (G23).
        val layers = buildList {
            if (moves.keys(def.id).isNotEmpty()) add(SMapEngineIds.points(movingId(def.id)))
            add(SMapEngineIds.points(def.id))
        }.filter { s.getLayer(it) != null }
        // The engine finds a circle by its disc, an icon only near its anchor: the box searched reaches that far.
        val reach = tol + 1f + if (icons) iconReachDp(o) * d else 0f
        val box = android.graphics.RectF(point.x - reach, point.y - reach, point.x + reach, point.y + reach)
        val seen = HashSet<String>()
        val out = ArrayList<Pair<Feature, Float>>()
        for (layer in layers) for (hit in map.queryRenderedFeatures(box, layer)) {
            if (hit.hasProperty("point_count")) continue
            val g = hit.geometry() as? Point ?: continue
            if (!seen.add(hit.id() ?: (g.toJson() + hit.properties()))) continue
            val at = map.projection.toScreenLocation(LatLng(g.latitude(), g.longitude()))
            val props = dataProperties(def, hit)
            val dist = if (icons) {
                val name = o.iconProperty?.let { props[it]?.toString() } ?: o.icon
                val size = name?.let(::imageSizeDp)
                if (size == null) {
                    // An image of the basemap's sprite: its size is not known here, so the engine's own hit decides.
                    if (map.queryRenderedFeatures(point, layer).any { it.id() == hit.id() }) 0f else tol
                } else {
                    val k = o.iconSize * d
                    val b = SMapTapMath.iconBox(at.x, at.y, size.first * k, size.second * k, o.iconAnchor, o.iconOffsetDp.first * k, o.iconOffsetDp.second * k)
                    SMapTapMath.toBox(b[0], b[1], b[2], b[3], point.x, point.y)
                }
            } else SMapTapMath.toDisc(at.x, at.y, circleExtentDp(def, o, props, hit.id()) * d, point.x, point.y)
            if (dist <= tol) out += hit to dist
        }
        return out
    }

    /** A circle's radius and stroke width as drawn, in dp: per feature, simplestyle and the looks of its states. */
    private fun circleExtentDp(def: LayerDef, o: SMapPointOptions, props: Map<String, Any?>, key: String?): Float {
        val simple = o.color == null && o.colorValue == null
        var r = if (o.radiusValue == null && simple && o.radius == DEFAULT_RADIUS) {
            when (props["marker-size"]) { "small" -> 4f; "large" -> 9f; else -> 6f }
        } else o.radiusValue.read(props, o.radius)
        var stroke = o.strokeWidth.read(props, 1.5f)
        val st = key?.let { featureStates[def.id]?.get(it) }
        if (st != null) for ((name, look) in o.states) if (st[name] == true) { look.radius?.let { r = it }; look.strokeWidth?.let { stroke = it } }
        return r + stroke
    }

    /** An image of the app's as drawn at icon size 1, in dp (null for an image the map does not hold). */
    private fun imageSizeDp(name: String): Pair<Float, Float>? {
        val b = images[name]?.first ?: return null
        val perDp = if (b.density > 0) b.density / android.util.DisplayMetrics.DENSITY_DEFAULT.toFloat() else resources.displayMetrics.density
        return b.width / perDp to b.height / perDp
    }

    // How far from its anchor an icon of the layer may reach, in dp.
    private fun iconReachDp(o: SMapPointOptions): Float {
        val sizes = if (o.iconProperty != null) images.keys.mapNotNull(::imageSizeDp) else listOfNotNull(o.icon?.let(::imageSizeDp))
        val image = sizes.maxOfOrNull { maxOf(it.first, it.second) } ?: 64f
        return (image + maxOf(kotlin.math.abs(o.iconOffsetDp.first), kotlin.math.abs(o.iconOffsetDp.second))) * o.iconSize
    }

    /** The features of a snapshot marker layer within [tol] pixels of [point], by each image's own box, top first. */
    private fun snapshotHits(map: MapLibreMap, def: LayerDef, layer: SnapshotLayer, point: PointF, tol: Float): List<Pair<Feature, Float>> {
        val features = def.data.features() ?: return emptyList()
        val o = layer.options
        val d = resources.displayMetrics.density
        val out = ArrayList<Pair<Feature, Float>>()
        // Later features draw on top (symbol-z-order source).
        for (index in features.indices.reversed()) {
            val f = features[index]
            val g = f.geometry() as? Point ?: continue
            val name = f.getStringProperty(SMapSnapshots.IMAGE) ?: continue
            val (w, h) = layer.sizes[name] ?: continue
            val at = map.projection.toScreenLocation(LatLng(g.latitude(), g.longitude()))
            val b = SMapTapMath.iconBox(at.x, at.y, w * d, h * d, o.anchor, o.offsetDp.first * d, o.offsetDp.second * d)
            val dist = SMapTapMath.toBox(b[0], b[1], b[2], b[3], point.x, point.y)
            // Answered as the engine answers: the feature's key as its id.
            if (dist <= tol) out += Feature.fromGeometry(g, f.properties(), SMapEngineData.keyOf(f, index, SMapSnapshots.KEY)) to dist
        }
        return out
    }

    /** The small list of the features piled under a tap; choosing one answers its tap, dismissing does nothing. */
    private fun showChooser(items: List<TapHit>, point: PointF) {
        chooser?.dismiss()
        val anchor = chooserAnchor ?: View(context).also { v ->
            v.isClickable = false
            v.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            addView(v, LayoutParams(1, 1, Gravity.TOP or Gravity.START))
            chooserAnchor = v
        }
        anchor.translationX = point.x
        anchor.translationY = point.y
        val menu = android.widget.PopupMenu(context, anchor)
        val rows = items.mapIndexed { i, item ->
            val def = defs[item.layerId]
            val own = (def?.points?.overlap ?: def?.custom?.overlap)?.label?.let { label ->
                try { label(item.feature()) } catch (e: Exception) { report(e); null }
            }
            SMapTapMath.label(i, own, item.labelValue, item.key) to i
        }
        // Rows in natural order of their text; the item id stays the item's place in [items].
        SMapTapMath.naturalRows(rows).forEachIndexed { order, (text, i) ->
            menu.menu.add(android.view.Menu.NONE, i, order, text)
        }
        menu.setOnMenuItemClickListener { mi -> items.getOrNull(mi.itemId)?.answer?.invoke(); true }
        menu.setOnDismissListener { if (chooser === it) chooser = null }
        chooser = menu
        menu.show()
    }

    // ------------------------------------------------------------------ features by key (G19-G23)
    //
    // A feature of a layer is named by its key: the layer's idProperty value, else its own id, else '#<index>'. The
    // engine draws a copy of a drawn layer's data whose features carry their key as id (states, hits and moves find
    // them by it) and the values of style closures as hidden properties.

    // Layer → key → state (kept across setData and style changes, and when a layer is added again under its id).
    private val featureStates = HashMap<String, LinkedHashMap<String, MutableMap<String, Any?>>>()
    private val moves = SMapMoves()
    // Layers whose own source is set again at the next frame (features started or stopped moving, a feature changed).
    private val dirtyData = LinkedHashSet<String>()
    private var frameQueued = false
    private var settleQueued = false
    // The tooltip opened from code: its layer and key (G22).
    private var openTip: Pair<String, String>? = null

    private fun layerOf(id: String): LayerDef =
        defs[id]?.takeIf { it.kind != SMapEngineIds.Kind.STYLE } ?: throw IllegalArgumentException("sMap: no layer $id")

    private fun engineData(def: LayerDef): FeatureCollection =
        def.circles?.let { SMapEngineData.build(SMapCircles.engineData(def.data, it), def.idProperty, def.fns) }
            ?: SMapEngineData.build(def.data, def.idProperty, def.fns, moves.keys(def.id))

    // Arrowheads by share of a line layer, worked out again from its data (G34).
    private fun arrowData(def: LayerDef): FeatureCollection? {
        val share = def.lines?.arrows?.share ?: return null
        return SMapArrows.points(engineData(def), share.toDouble())
    }

    private fun pushData(def: LayerDef) {
        // A dash pattern not drawn yet needs a part of its own: the layer is made again.
        val s = style
        if (s != null && def.dashSplits.any { (reader, drawn) -> !drawn.containsAll(SMapDashSplit.patterns(def.data, reader)) }) {
            addToStyle(s, def)
            return
        }
        style?.getSourceAs<GeoJsonSource>(SMapEngineIds.source(def.id))?.setGeoJson(engineData(def))
        arrowData(def)?.let { style?.getSourceAs<GeoJsonSource>(SMapEngineIds.arrowPoints(def.id))?.setGeoJson(it) }
        if (def.viewClusters) clustersDirty = true
    }

    /** The properties of the layer's own feature behind an engine hit (the hit's own, without hidden ones, else). */
    private fun dataProperties(def: LayerDef, hit: Feature): Map<String, Any?> {
        if (def.drawn) {
            val i = hit.id()?.let { def.keys()[it] }
            val f = i?.let { def.data.features()?.getOrNull(it) }
            if (f != null) return SMapGeoJson.propertiesOf(f)
        }
        return SMapGeoJson.propertiesOf(hit).filterKeys { !it.startsWith(SMapEngineData.FN) }
    }

    internal fun dataPropertiesOf(id: String, hit: Feature): Map<String, Any?> = defs[id]?.let { dataProperties(it, hit) } ?: SMapGeoJson.propertiesOf(hit)

    private fun positionOf(f: Feature): LatLng? = SMapCameraMath.anchorOf(f.geometry())?.let { LatLng(it[1], it[0]) }

    /** The layer's own feature of an engine hit as the app's callbacks see it; a cluster as a feature of its layer. */
    private fun userFeature(def: LayerDef, hit: Feature, at: LatLng?): SMapFeature {
        val props = SMapGeoJson.propertiesOf(hit)
        if (props.containsKey("point_count") && props.containsKey("cluster_id")) {
            return SMapFeature(CLUSTER_KEY + SMapEngineData.keyText(props["cluster_id"]), props, positionOf(hit) ?: at ?: LatLng(0.0, 0.0))
        }
        val i = hit.id()?.let { def.keys()[it] }
        val f = i?.let { def.data.features()?.getOrNull(it) }
        if (f == null || i == null) {
            return SMapFeature(hit.id() ?: "", props.filterKeys { !it.startsWith(SMapEngineData.HIDDEN) }, (hit.geometry() as? Point)?.let { LatLng(it.latitude(), it.longitude()) } ?: at ?: LatLng(0.0, 0.0))
        }
        return featureOf(def, f, i, at)
    }

    private fun featureOf(def: LayerDef, f: Feature, index: Int, at: LatLng?): SMapFeature {
        val g = f.geometry()
        val position = if (g is Point) LatLng(g.latitude(), g.longitude()) else at ?: positionOf(f) ?: LatLng(0.0, 0.0)
        return SMapFeature(SMapEngineData.keyOf(f, index, def.idProperty), SMapEngineData.userProperties(f), position)
    }

    /**
     * The features under a point of the map (pixels from its top-left corner), top first: custom markers, then the
     * drawn layers' features, each with its SDK layer id and the layer's own feature (G19). [layers] limits the answer
     * (an addData group counts as its layers). Empty for a point on the map itself.
     */
    fun featuresAt(point: PointF, layers: List<String>? = null): List<SMapFeatureAt> {
        val map = engine ?: return emptyList()
        val s = style
        fun wanted(id: String) = layers == null || id in layers || defs[id]?.group?.let { it in layers } == true
        val out = ArrayList<SMapFeatureAt>()
        for ((layer, item) in markers.hits(point.x, point.y)) {
            val id = layer.removeSuffix(":clusters")
            val def = defs[id] ?: continue
            if (def.hidden || !wanted(id)) continue
            val g = item.feature.geometry() as Point
            val position = LatLng(item.lat, item.lng)
            out += if (layer != id) {
                val p = SMapGeoJson.propertiesOf(item.feature)
                SMapFeatureAt(id, SMapFeature(CLUSTER_KEY + SMapEngineData.keyText(p["cluster_id"]), p, LatLng(g.latitude(), g.longitude())))
            } else SMapFeatureAt(id, SMapFeature(item.key, SMapEngineData.userProperties(item.feature), position))
        }
        if (s == null) return out
        val at = map.projection.fromScreenLocation(point)
        for (id in order.ids().asReversed()) {
            val def = defs[id] ?: continue
            if (def.hidden || !wanted(id)) continue
            if (def.kind == SMapEngineIds.Kind.CUSTOM || def.kind == SMapEngineIds.Kind.MODELS || def.kind == SMapEngineIds.Kind.HEATMAP) continue
            val engineLayers = def.engineLayers.filter { !it.endsWith("-cluster-hits") && !it.endsWith("-count") && s.getLayer(it) != null }
            if (engineLayers.isEmpty()) continue
            val hits = if (snapshots[id] != null) listOfNotNull(featureAt(map, id, SMapEngineIds.points(id), point))
            else map.queryRenderedFeatures(point, *engineLayers.toTypedArray()).toMutableList().also { list ->
                // The features moving now are drawn from their own source above the layer (G23).
                if (moves.keys(id).isNotEmpty()) list.addAll(0, map.queryRenderedFeatures(point, *SMapEngineIds.pointLayers(movingId(id), def.points!!.copy(cluster = null)).filter { s.getLayer(it) != null }.toTypedArray()))
            }
            val seen = HashSet<String>()
            for (hit in hits) {
                val f = if (def.kind == SMapEngineIds.Kind.STYLE) SMapFeature(hit.id() ?: "", SMapGeoJson.propertiesOf(hit), positionOf(hit) ?: at)
                else userFeature(def, hit, at)
                if (seen.add(f.key)) out += SMapFeatureAt(id, f)
            }
        }
        return out
    }

    // ---- feature state (G21)

    /**
     * Sets values of a feature's state (merged into what it has), e.g. `mapOf("selected" to true)`: the layer's
     * `states` looks follow it; a custom marker layer's onStateChange is told. [key] as text: the idProperty value,
     * else the feature's id, else `#<index>`. Kept across setData and style changes.
     *
     * @throws IllegalArgumentException when there is no layer [layerId]
     */
    fun setFeatureState(layerId: String, key: Any, state: Map<String, Any?>) {
        val def = layerOf(layerId)
        val k = SMapEngineData.keyText(key) ?: return
        val all = featureStates.getOrPut(layerId) { LinkedHashMap() }
        all.getOrPut(k) { LinkedHashMap() }.putAll(state)
        pushState(def, k, state, emptySet())
    }

    /** A copy of a feature's state (empty when it has none). */
    fun featureState(layerId: String, key: Any): Map<String, Any?> {
        layerOf(layerId)
        return featureStates[layerId]?.get(SMapEngineData.keyText(key))?.toMap() ?: emptyMap()
    }

    /** Removes one value ([name]) of a feature's state, its whole state, or (without [key]) that value or every state of the layer. */
    fun removeFeatureState(layerId: String, key: Any? = null, name: String? = null) {
        val def = layerOf(layerId)
        val all = featureStates[layerId] ?: return
        val keys = if (key == null) all.keys.toList() else listOfNotNull(SMapEngineData.keyText(key))
        for (k in keys) {
            val st = all[k] ?: continue
            val gone = if (name == null) st.keys.toSet().also { all.remove(k) } else if (name in st) setOf(name).also { st.remove(name) } else emptySet()
            if (gone.isNotEmpty()) pushState(def, k, emptyMap(), gone)
        }
    }

    private fun stateJson(state: Map<String, Any?>): JsonObject = JsonObject().also { o -> state.forEach { (k, v) -> o.add(k, SMapJson.of(v)) } }

    private fun pushState(def: LayerDef, key: String, set: Map<String, Any?>, gone: Set<String>) {
        if (def.kind == SMapEngineIds.Kind.CUSTOM) {
            val now = featureStates[def.id]?.get(key)?.toMap() ?: emptyMap()
            def.custom?.onStateChange?.let { cb -> try { cb(key, now, markers.viewOf(def.id, key)) } catch (e: Exception) { report(e) } }
            return
        }
        val s = style ?: return
        for (src in listOf(SMapEngineIds.source(def.id), SMapEngineIds.source(movingId(def.id)))) {
            val source = s.getSourceAs<GeoJsonSource>(src) ?: continue
            if (set.isNotEmpty()) source.setFeatureState(key, stateJson(set))
            gone.forEach { source.removeFeatureState(key, it) }
        }
    }

    // Every state of a layer to the engine again (its source was just added).
    private fun applyStates(def: LayerDef, sourceId: String = SMapEngineIds.source(def.id)) {
        val all = featureStates[def.id] ?: return
        val source = style?.getSourceAs<GeoJsonSource>(sourceId) ?: return
        for ((k, st) in all) if (st.isNotEmpty()) source.setFeatureState(k, stateJson(st))
    }

    /** The state of a custom marker as its view is made: told to the layer's onStateChange (G21). */
    internal fun markerRendered(layerId: String, key: String, view: View) {
        val st = featureStates[layerId]?.get(key)?.takeIf { it.isNotEmpty() } ?: return
        defs[layerId]?.custom?.onStateChange?.let { cb -> try { cb(key, st.toMap(), view) } catch (e: Exception) { report(e) } }
    }

    // ---- pointer events (G19): hover, double tap and long press, as SMapInteraction and the marker views report them

    /** A hovering pointer at [point]: `mousemove`, then each hover layer's feature under it. */
    internal fun hoverAt(point: PointF, motion: MotionEvent?) {
        if (events.has(SMapEventType.MOUSE_MOVE)) events.fire(SMapEventType.MOUSE_MOVE, pointerEvent(SMapEventType.MOUSE_MOVE, point, motion))
        val ids = order.ids().filter { id -> defs[id]?.let { (it.onHover != null || it.hoverState) && !it.hidden } == true }
        if (ids.isEmpty()) return
        for (id in ids) {
            val def = defs[id] ?: continue
            val hit = featuresAt(point, listOf(id)).firstOrNull { it.layer == id }?.feature
            setHover(def, hit, point)
        }
    }

    /** The pointer left the map: every hovered feature is left. */
    internal fun hoverExit(point: PointF) {
        for (id in order.ids()) defs[id]?.takeIf { it.hoverKey != null }?.let { setHover(it, null, point) }
    }

    private fun setHover(def: LayerDef, f: SMapFeature?, point: PointF) {
        val key = f?.key
        if (key == def.hoverKey) return
        val before = def.hoverKey
        def.hoverKey = key
        if (def.hoverState) {
            if (before != null && !before.startsWith(CLUSTER_KEY)) removeFeatureState(def.id, before, "hover")
            if (key != null && !key.startsWith(CLUSTER_KEY)) setFeatureState(def.id, key, mapOf("hover" to true))
        }
        def.onHover?.let { cb -> try { cb(f, SMapLayerEvent("mousemove", f?.position ?: unproject(point), point)) } catch (e: Exception) { report(e) } }
    }

    /**
     * A double tap at [point]: the top feature with an onDoubleClick gets it, then the map's `dblclick`. True when
     * the map must not zoom (a layer took it, or a listener called preventDefault).
     */
    internal fun doubleTapAt(point: PointF, motion: MotionEvent?): Boolean {
        var taken = false
        if (order.ids().any { defs[it]?.onDoubleClick != null }) {
            for (h in featuresAt(point)) {
                if (h.feature.key.startsWith(CLUSTER_KEY)) continue
                val cb = defs[h.layer]?.onDoubleClick ?: continue
                try { cb(h.feature, SMapLayerEvent("dblclick", unproject(point), point)) } catch (e: Exception) { report(e) }
                taken = true
                break
            }
        }
        val e = pointerEvent(SMapEventType.DOUBLE_CLICK, point, motion)
        if (taken) e.preventDefault()
        events.fire(SMapEventType.DOUBLE_CLICK, e)
        return e.defaultPrevented
    }

    /** Whether a long press may be a context menu: some layer or listener wants it. */
    internal fun wantsContextMenu(): Boolean = events.has(SMapEventType.CONTEXT_MENU) || order.ids().any { defs[it]?.onContextMenu != null }

    /** A long press at [point] that did not start a drag: the top feature with an onContextMenu, then the map's `contextmenu`. */
    internal fun contextMenuAt(point: PointF, motion: MotionEvent?) {
        if (order.ids().any { defs[it]?.onContextMenu != null }) {
            for (h in featuresAt(point)) {
                if (h.feature.key.startsWith(CLUSTER_KEY)) continue
                val cb = defs[h.layer]?.onContextMenu ?: continue
                try { cb(h.feature, SMapLayerEvent("contextmenu", unproject(point), point)) } catch (e: Exception) { report(e) }
                break
            }
        }
        if (events.has(SMapEventType.CONTEXT_MENU)) events.fire(SMapEventType.CONTEXT_MENU, pointerEvent(SMapEventType.CONTEXT_MENU, point, motion))
    }

    // ---- a feature's own popup and tooltip from code (G22)

    private class Found(val index: Int, val feature: Feature)

    private fun find(def: LayerDef, key: String): Found? {
        val i = def.keys()[key] ?: return null
        val f = def.data.features()?.getOrNull(i) ?: return null
        return Found(i, f)
    }

    private fun tooltipOf(def: LayerDef): SMapTooltip? = def.points?.tooltip ?: def.lines?.tooltip ?: def.polygons?.tooltip ?: def.custom?.tooltip

    /**
     * Does what a tap on the feature does (G22): the native SDKs have no popups, so the layer's tap handler ([onTap],
     * or a custom marker layer's onTap) is called with the feature, as if tapped at its anchor.
     *
     * @return whether a handler was called
     * @throws IllegalArgumentException when there is no layer [layerId]
     */
    fun openFeaturePopup(layerId: String, key: Any): Boolean {
        val def = layerOf(layerId)
        val k = SMapEngineData.keyText(key) ?: return false
        val found = find(def, k) ?: return false
        val at = positionOf(found.feature) ?: return false
        if (def.kind == SMapEngineIds.Kind.CUSTOM) {
            val tap = def.custom?.onTap ?: return false
            tap(featureOf(def, found.feature, found.index, at))
            return true
        }
        val handler = tapHandlers[layerId] ?: return false
        handler(SMapGeoJson.propertiesOf(found.feature), at)
        return true
    }

    /**
     * Shows a feature's own tooltip (its layer's `tooltip`; G22): beside a point or marker, halfway along a line,
     * inside an area. It follows its feature until [closeTooltip] or a tap on the map. Nothing happens without a
     * tooltip or for an unknown key.
     *
     * @throws IllegalArgumentException when there is no layer [layerId]
     */
    fun openTooltip(layerId: String, key: Any) {
        val def = layerOf(layerId)
        val k = SMapEngineData.keyText(key) ?: return
        if (tooltipOf(def) == null || find(def, k) == null) return
        openTip = layerId to k
        if (engine == null) return ready { placeOpenTooltip() }
        placeOpenTooltip()
    }

    /** Hides the map's tooltip (one opened from code, or one a resting finger shows). */
    fun closeTooltip() {
        openTip = null
        markers.hideTooltip()
    }

    private fun placeOpenTooltip() {
        val (id, key) = openTip ?: return
        val map = engine ?: return
        val def = defs[id] ?: return closeTooltip()
        val tip = tooltipOf(def) ?: return closeTooltip()
        val found = find(def, key) ?: return closeTooltip()
        val props = SMapEngineData.userProperties(found.feature)
        if (def.kind == SMapEngineIds.Kind.CUSTOM) {
            val view = markers.viewOf(id, key)
            if (view != null && view.visibility == View.VISIBLE) return markers.showTooltip(tip, props, view)
        }
        val moving = moves.layers[id]?.get(key)?.at
        val anchor = moving ?: SMapCameraMath.anchorOf(found.feature.geometry()) ?: return
        val p = map.projection.toScreenLocation(LatLng(anchor[1], anchor[0]))
        val size = if (def.kind == SMapEngineIds.Kind.POINTS) (def.points?.radius ?: DEFAULT_RADIUS) * 2 * resources.displayMetrics.density
        else if (def.kind == SMapEngineIds.Kind.CUSTOM) 20 * resources.displayMetrics.density else 0f
        markers.showTooltip(tip, props, p.x, p.y, size)
    }

    // ---- moving and changing one feature (G23)

    private fun movingId(id: String) = "$id-moving"

    private fun own(def: LayerDef) {
        if (def.ownsData) return
        def.data = FeatureCollection.fromFeatures(ArrayList(def.data.features() ?: emptyList()))
        def.ownsData = true
        if (def.kind == SMapEngineIds.Kind.CUSTOM) markers.shareData(def.id, def.data)
    }

    // The feature at [index] replaced in the layer's own copy of its data.
    private fun put(def: LayerDef, index: Int, f: Feature) {
        own(def)
        (def.data.features() as MutableList<Feature>)[index] = f
    }

    /**
     * Moves one point of a layer (custom markers too) to [position] in a straight line over [durationMillis] (0, the
     * default: at once; [easing] shapes the move, linear by default). A later call for the same feature starts from
     * where it is. Its tooltip goes with it; the layer's data holds the new position (a copy: the caller's objects are
     * not changed). While it moves, the feature is drawn from a small source of the layer's moving features, so the
     * layer's own data is sent again only when features start or stop moving (G23).
     *
     * @throws IllegalArgumentException when there is no layer [layerId]
     */
    fun moveFeature(layerId: String, key: Any, position: LatLng, durationMillis: Long = 0, easing: ((Float) -> Float)? = null) {
        val def = layerOf(layerId)
        if (def.kind != SMapEngineIds.Kind.POINTS && def.kind != SMapEngineIds.Kind.CUSTOM && def.circles == null) return
        val k = SMapEngineData.keyText(key) ?: return
        val found = find(def, k) ?: return
        val g = found.feature.geometry() as? Point ?: return
        val to = doubleArrayOf(position.longitude, position.latitude)
        val now = android.os.SystemClock.uptimeMillis()
        val fresh = moves.start(layerId, k, doubleArrayOf(g.longitude(), g.latitude()), to, durationMillis, easing, now)
        if (fresh && def.kind == SMapEngineIds.Kind.POINTS) dirtyData += layerId
        if (durationMillis <= 0) writePosition(def, k, to)
        if (def.circles != null) dirtyData += layerId
        queueFrame()
    }

    /**
     * Changes one feature's properties (merged into its own; a null value removes the property; the idProperty is never
     * changed) without the caller sending the layer again; its look, tooltip and per-feature values follow (G23). The
     * layer's source is set again once per frame at most.
     *
     * @throws IllegalArgumentException when there is no layer [layerId]
     */
    fun updateFeature(layerId: String, key: Any, properties: Map<String, Any?>) {
        val def = layerOf(layerId)
        val k = SMapEngineData.keyText(key) ?: return
        val found = find(def, k) ?: return
        val snapshot = snapshots[layerId]
        if (snapshot != null) {
            // A snapshot marker's look may change: the layer is worked out again (images only for new looks).
            val originals = def.data.features()!!.mapIndexed { i, f ->
                val plain = Feature.fromGeometry(f.geometry(), SMapGeoJson.properties(SMapEngineData.userProperties(f)), f.id())
                if (i == found.index) SMapEngineData.merged(plain, properties, snapshot.options.idProperty) else plain
            }
            return setData(layerId, FeatureCollection.fromFeatures(originals))
        }
        put(def, found.index, SMapEngineData.merged(found.feature, properties, def.idProperty))
        when (def.kind) {
            SMapEngineIds.Kind.CUSTOM -> markers.refresh(layerId, k, def.data.features()!![found.index])
            SMapEngineIds.Kind.MODELS -> models().setData(layerId, def.data)
            else -> if (moves.isMoving(layerId, k)) showMoving(def) else dirtyData += layerId
        }
        if (openTip == layerId to k) placeOpenTooltip()
        queueFrame()
    }

    private fun writePosition(def: LayerDef, key: String, at: DoubleArray) {
        val found = find(def, key) ?: return
        val next = SMapEngineData.moved(found.feature, at)
        put(def, found.index, next)
        if (def.kind == SMapEngineIds.Kind.CUSTOM) markers.refresh(def.id, key, next, moved = true)
    }

    private fun queueFrame() {
        if (frameQueued) return
        frameQueued = true
        android.view.Choreographer.getInstance().postFrameCallback { frameQueued = false; frame() }
    }

    private fun frame() {
        val now = android.os.SystemClock.uptimeMillis()
        for (layerId in moves.layers.keys.toList()) {
            val def = defs[layerId]
            if (def == null) { moves.remove(layerId); continue }
            for ((key, e) in moves.layers[layerId]!!.entries.toList()) {
                if (e.move == null) continue
                moves.step(e, now)
                writePosition(def, key, e.at)
            }
            if (moves.settle(layerId, now).isNotEmpty() && def.kind == SMapEngineIds.Kind.POINTS) dirtyData += layerId
            // A circle is worked out again where its point is now (G26).
            if (def.circles != null) dirtyData += layerId
            if (def.kind == SMapEngineIds.Kind.POINTS) showMoving(def)
            if (openTip?.first == layerId) placeOpenTooltip()
        }
        for (layerId in dirtyData.toList()) defs[layerId]?.takeIf { it.drawn }?.let { pushData(it) }
        dirtyData.clear()
        markers.layout()
        if (moves.animating()) queueFrame()
        else moves.nextSettle()?.let { at ->
            if (!settleQueued) {
                settleQueued = true
                mapView.postDelayed({ settleQueued = false; frame() }, maxOf(16L, at - android.os.SystemClock.uptimeMillis()))
            }
        }
    }

    /** The moving features of a point layer, drawn from their own source above the layer with its look (or taken off). */
    private fun showMoving(def: LayerDef) {
        val s = style ?: return
        val keys = moves.layers[def.id]
        val src = SMapEngineIds.source(movingId(def.id))
        if (keys.isNullOrEmpty()) return dropMovingSource(def.id)
        val features = keys.mapNotNull { (k, e) ->
            val found = find(def, k) ?: return@mapNotNull null
            SMapEngineData.engineFeature(found.feature, k, def.fns, Point.fromLngLat(e.at[0], e.at[1]))
        }
        val source = s.getSourceAs<GeoJsonSource>(src)
        if (source != null) return source.setGeoJson(FeatureCollection.fromFeatures(features))
        s.addSource(GeoJsonSource(src, FeatureCollection.fromFeatures(features)))
        val o = def.points ?: return
        val top = def.engineLayers.lastOrNull { s.getLayer(it) != null }
        val added = ArrayList<Layer>()
        addPointLayers(movingId(def.id), src, o.copy(cluster = null), SMapStyleBuild(o.states.keys.toList())) { l -> added += l }
        var above = top
        for (l in added) {
            if (def.hidden) l.setProperties(PropertyFactory.visibility(Property.NONE))
            if (above != null) s.addLayerAbove(l, above) else s.addLayer(l)
            above = l.id
        }
        applyStates(def, src)
    }

    private fun dropMovingSource(id: String) {
        val s = style ?: return
        val src = SMapEngineIds.source(movingId(id))
        if (s.getSource(src) == null) return
        defs[id]?.points?.let { o -> SMapEngineIds.pointLayers(movingId(id), o.copy(cluster = null)).forEach { l -> s.getLayer(l)?.let(s::removeLayer) } }
            ?: s.layers.filter { it.id.startsWith("smap-${movingId(id)}-") }.forEach(s::removeLayer)
        s.getSource(src)?.let(s::removeSource)
    }

    // ------------------------------------------------------------------ controls, imagery, terrain, sync, Google, drawn tiles (G8, G10, G11, G13, G14)

    /** The app's own [view] in a corner of the map, not a tool (never hidden by the tools control). */
    fun addControl(view: View, position: SMapToolPosition = SMapToolPosition.TOP_RIGHT) {
        require(position != SMapToolPosition.NONE) { "sMap: a control sits in a corner" }
        require(view.parent == null) { "sMap: a control must not have a parent" }
        corners().add(position, view)
    }

    fun removeControl(view: View) { (view.parent as? ViewGroup)?.removeView(view) }

    private var baseImagery: SMapBaseImagery? = null
    private val imageryHid = ArrayList<String>()

    /** Imagery in place of the street map (satellite, aerial), under the labels; null goes back to the street map. */
    fun setBaseImagery(imagery: SMapBaseImagery?) {
        if (imagery != null) {
            require(imagery.tiles.isNotEmpty()) { "sMap: base imagery needs tiles" }
            SMapExternalLayers.refuseForbidden(imagery.tiles)
        }
        setImagery(imagery)
    }

    /** The imagery shown now, or null. */
    fun baseImagery(): SMapBaseImagery? = baseImagery

    private fun setImagery(imagery: SMapBaseImagery?) {
        baseImagery = imagery
        style?.let { applyImagery(it) }
    }

    private fun applyImagery(s: Style) {
        s.getLayer(BASE_IMAGERY)?.let(s::removeLayer)
        s.getSource(BASE_IMAGERY)?.let(s::removeSource)
        imageryHid.forEach { id -> s.getLayer(id)?.setProperties(PropertyFactory.visibility(Property.VISIBLE)) }
        imageryHid.clear()
        val b = baseImagery ?: return
        val set = org.maplibre.android.style.sources.TileSet("2.2.0", *b.tiles.toTypedArray()).apply {
            b.minZoom?.let { minZoom = it }
            b.maxZoom?.let { maxZoom = it }
            b.attribution?.let { attribution = it }
            if (b.tms) scheme = "tms"
        }
        s.addSource(org.maplibre.android.style.sources.RasterSource(BASE_IMAGERY, set, b.tileSize))
        val labelsAt = anchors[SMapSlot.LABELS]?.takeIf { s.getLayer(it) != null }
        val layer = org.maplibre.android.style.layers.RasterLayer(BASE_IMAGERY, BASE_IMAGERY)
        if (labelsAt != null) s.addLayerBelow(layer, labelsAt) else s.addLayer(layer)
        if (!b.labels && labelsAt != null) {
            // The basemap's labels: every basemap layer from where the labels slot begins.
            val ids = basemapOriginal?.getAsJsonArray("layers")?.mapNotNull { it.asJsonObject.str("id") } ?: emptyList()
            val from = ids.indexOf(labelsAt)
            if (from >= 0) ids.drop(from).forEach { id ->
                val l = s.getLayer(id) ?: return@forEach
                if (l.visibility.value == Property.NONE) return@forEach
                l.setProperties(PropertyFactory.visibility(Property.NONE))
                imageryHid += id
            }
        }
    }

    /** The layer switcher as a tool (G8): base maps one at a time and overlays each on or off. */
    fun addTool(id: String, layers: SMapLayersTool, label: String = "Layers", position: SMapToolPosition = SMapToolPosition.TOP_RIGHT) {
        val view = SMapLayersToolView(context, layers, position, label,
            applyBase = { b ->
                for (step in SMapBaseSwitch.steps(b, google != null, styleName)) when (step) {
                    SMapBaseSwitch.Step.GOOGLE_OFF -> setGoogleBase(null)
                    SMapBaseSwitch.Step.STYLE -> setStyle(b.style!!)
                    SMapBaseSwitch.Step.IMAGERY -> setImagery(b.imagery?.also { SMapExternalLayers.refuseForbidden(it.tiles) })
                    SMapBaseSwitch.Step.GOOGLE_ON -> setGoogleBase(b.google)
                }
            },
            applyOverlay = { ov, on -> ov.layers.forEach { setVisible(it, on) } },
        )
        addTool(id, view, label, position)
        ready { view.start() }
    }

    private var terrain: SMapTerrain? = null

    /** Relief over elevation tiles (G11): hillshading under the roads; null takes it off. */
    fun setTerrain(terrain: SMapTerrain?) {
        if (terrain != null) require(terrain.tiles.isNotEmpty()) { "sMap: terrain needs tiles" }
        this.terrain = terrain
        style?.let { applyTerrain(it) }
        if (terrain != null) unsupported("terrain")
    }

    private fun applyTerrain(s: Style) {
        s.getLayer(HILLSHADE)?.let(s::removeLayer)
        s.getSource(TERRAIN_SOURCE)?.let(s::removeSource)
        val t = terrain ?: return
        val set = org.maplibre.android.style.sources.TileSet("2.2.0", *t.tiles.toTypedArray()).apply {
            maxZoom = t.maxZoom
            t.attribution?.let { attribution = it }
            encoding = t.encoding
        }
        s.addSource(org.maplibre.android.style.sources.RasterDemSource(TERRAIN_SOURCE, set, t.tileSize))
        if (!t.hillshade) return
        val layer = org.maplibre.android.style.layers.HillshadeLayer(HILLSHADE, TERRAIN_SOURCE).withProperties(
            PropertyFactory.hillshadeExaggeration(t.hillshadeExaggeration),
        )
        t.shadowColor?.let { layer.setProperties(PropertyFactory.hillshadeShadowColor(arrayOf(it))) }
        t.highlightColor?.let { layer.setProperties(PropertyFactory.hillshadeHighlightColor(arrayOf(it))) }
        val roads = anchors[SMapSlot.ROADS]?.takeIf { s.getLayer(it) != null }
        if (roads != null) s.addLayerBelow(layer, roads) else s.addLayer(layer)
    }

    private val saidUnsupported = HashSet<String>()
    private fun unsupported(what: String) { if (saidUnsupported.add(what)) options.onUnsupported?.invoke(what) }

    /**
     * Keeps [other] on this map's view, both ways (G13): centre, zoom + [offsetZoom], bearing and tilt. Returns a
     * function that ends it.
     */
    fun syncWith(other: SMap, offsetZoom: Double = 0.0): () -> Unit {
        var busy = false
        var stopped = false
        val listeners = ArrayList<Pair<MapLibreMap, MapLibreMap.OnCameraMoveListener>>()
        fun copy(from: SMap, to: SMap, dz: Double) = MapLibreMap.OnCameraMoveListener {
            val a = from.engine ?: return@OnCameraMoveListener
            val b = to.engine ?: return@OnCameraMoveListener
            if (busy || stopped) return@OnCameraMoveListener
            busy = true
            try {
                val c = a.cameraPosition
                b.moveCamera(CameraUpdateFactory.newCameraPosition(CameraPosition.Builder().target(c.target).zoom(c.zoom + dz).bearing(c.bearing).tilt(c.tilt).build()))
            } finally { busy = false }
        }
        ready { me ->
            other.ready { _ ->
                if (stopped) return@ready
                val a = copy(me, other, offsetZoom)
                val b = copy(other, me, -offsetZoom)
                me.engine!!.addOnCameraMoveListener(a); listeners += me.engine!! to a
                other.engine!!.addOnCameraMoveListener(b); listeners += other.engine!! to b
                a.onCameraMove()
            }
        }
        return { stopped = true; listeners.forEach { (m, l) -> m.removeOnCameraMoveListener(l) } }
    }

    private var google: SMapGoogleState? = null

    /**
     * Google's base maps read straight from Google with the app's Map Tiles session (G10), shown as base imagery with
     * the Google logo and the copyright of the area in view, bottom left. null takes them off.
     */
    fun setGoogleBase(g: SMapGoogleBase?) {
        google?.stop()
        google = null
        if (g == null) { setImagery(null); return }
        require(g.tiles != null || (g.session != null && g.key != null)) { "sMap: a Google layer needs session and key, or tiles" }
        val state = SMapGoogleState(this, g)
        google = state
        setImagery(SMapBaseImagery(listOf(state.tiles), 256, maxZoom = g.maxZoom, labels = g.labels))
        state.start()
    }

    internal fun googleCorner(view: View) = corners().add(SMapToolPosition.BOTTOM_LEFT, view, last = true)

    private val canvasKeys = HashMap<String, String>()

    /**
     * Raster tiles the app paints (G14): [draw] gets a canvas scaled to [tileSize] × [tileSize] density-independent
     * pixels and the tile's z / x / y; it runs on the engine's network thread.
     */
    fun addCanvasTiles(id: String, tileSize: Int = 256, minZoom: Double? = null, maxZoom: Double? = null, opacity: Double? = null, draw: (android.graphics.Canvas, Int, Int, Int, Int) -> Unit) {
        canvasKeys.remove(id)?.let(SMapLocalTiles::unregister)
        val key = SMapLocalTiles.register(SMapLocalTiles.Drawer(tileSize, min(3f, resources.displayMetrics.density), draw))
        canvasKeys[id] = key
        addRasterLayer(id, SMapRasterOptions(tiles = listOf(SMapLocalTiles.url(key)), tileSize = tileSize, minzoom = minZoom, maxzoom = maxZoom, opacity = opacity))
    }

    // ------------------------------------------------------------------ drawing and selection (G3, G4)

    private val drawTools = ArrayList<SMapDrawTool>()
    private var selecting: SMapSelect? = null

    /** A drawing and editing tool on this map (G3). */
    fun drawTool(options: SMapDrawOptions = SMapDrawOptions()): SMapDrawTool = SMapDrawTool(this, options)

    internal fun attachDraw(tool: SMapDrawTool) { drawTools += tool; if (selecting == null) interaction.capture = tool }
    internal fun detachDraw(tool: SMapDrawTool) {
        drawTools -= tool
        if (interaction.capture === tool) interaction.capture = drawTools.lastOrNull()
    }

    /**
     * Selects features by drawing on the map (G4): a box (default) or a free shape ([lasso]); [done] gets the features
     * of each of [layers] (default every point, custom marker, line and area layer) inside it, or null when cancelled.
     */
    fun selectArea(lasso: Boolean = false, layers: List<String>? = null, cancelLabel: String = "Cancel", done: (SMapSelection?) -> Unit) {
        selecting?.let { endSelect(it) }
        val ids = layers ?: order.ids().filter { defs[it]?.kind in listOf(SMapEngineIds.Kind.POINTS, SMapEngineIds.Kind.CUSTOM, SMapEngineIds.Kind.LINES, SMapEngineIds.Kind.POLYGONS) && defs[it]?.hidden == false }
        val view = SMapSelect(context, this, lasso, ids, cancelLabel, done)
        selecting = view
        addView(view, indexOfChild(markers) + 1, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        interaction.capture = view
    }

    /** [selectArea] as a suspending call. */
    suspend fun selectArea(lasso: Boolean = false, layers: List<String>? = null, cancelLabel: String = "Cancel"): SMapSelection? {
        val result = CompletableDeferred<SMapSelection?>()
        selectArea(lasso, layers, cancelLabel) { result.complete(it) }
        return result.await()
    }

    internal fun endSelect(view: SMapSelect) {
        if (selecting !== view) return
        selecting = null
        removeView(view)
        interaction.capture = drawTools.lastOrNull()
    }

    // ------------------------------------------------------------------ custom markers, view clusters (G1, G6)

    private fun clusterLayer(id: String) = "$id:clusters"

    // The marker layers in draw order: custom marker layers, and the view clusters of a point layer at its place.
    private fun markerOrder(): List<String> = order.ids().mapNotNull { id ->
        val def = defs[id] ?: return@mapNotNull null
        when {
            def.kind == SMapEngineIds.Kind.CUSTOM -> id
            def.viewClusters -> clusterLayer(id)
            else -> null
        }
    }

    private fun clusterInfo(id: String, f: org.maplibre.geojson.Feature): SMapClusterInfo {
        val p = SMapGeoJson.propertiesOf(f)
        val g = f.geometry() as Point
        return SMapClusterInfo((p["cluster_id"] as? Number)?.toInt() ?: 0, (p["point_count"] as? Number)?.toInt() ?: 0, p, LatLng(g.latitude(), g.longitude())) { limit ->
            style?.getSourceAs<GeoJsonSource>(SMapEngineIds.source(id))?.getClusterLeaves(f, limit, 0)?.features() ?: emptyList()
        }
    }

    private val clusterFeatures = HashMap<String, Map<String, org.maplibre.geojson.Feature>>()
    private var clustersDirty = false
    private val clusterSignatures = HashMap<String, String>()
    private var clustersMoving = false
    private var clustersReadAt = 0L

    private fun clusterMarkerOptions(id: String, c: SMapCluster) = SMapCustomMarkerOptions(
        render = { p ->
            val f = clusterFeatures[id]?.get("c" + ((p["cluster_id"] as? Number)?.toInt() ?: 0))
            val info = if (f != null) clusterInfo(id, f) else SMapClusterInfo(0, (p["point_count"] as? Number)?.toInt() ?: 0, p, LatLng(0.0, 0.0)) { emptyList() }
            c.render?.invoke(info) ?: SMapClusterRingView(context, info.count, SMapClusterRingView.shares(info.leaves(c.ring!!.limit), c.ring.property), c.ring.color ?: DEFAULT_COLOR)
        },
        idProperty = "cluster_key",
        onTap = { feature ->
            val f = clusterFeatures[id]?.get(feature.key) ?: return@SMapCustomMarkerOptions
            val info = clusterInfo(id, f)
            c.onTap?.invoke(info)
            if (c.zoomOnTap) {
                val zoom = style?.getSourceAs<GeoJsonSource>(SMapEngineIds.source(id))?.getClusterExpansionZoom(f)?.toDouble() ?: return@SMapCustomMarkerOptions
                engine?.animateCamera(CameraUpdateFactory.newLatLngZoom(info.position, zoom))
            }
        },
    )

    // The engine's clusters of every point layer with view clusters, read after the camera stops or the data changes.
    /** Reads the clusters of every point layer with view clusters; true once each source has answered. */
    private fun refreshClusters(): Boolean {
        val s = style ?: return false
        var settled = true
        for (id in order.ids()) {
            val def = defs[id]?.takeIf { it.viewClusters } ?: continue
            val source = s.getSourceAs<GeoJsonSource>(SMapEngineIds.source(id)) ?: continue
            val seen = LinkedHashMap<String, org.maplibre.geojson.Feature>()
            for (f in drawnClusters(id, source)) {
                val cid = f.getNumberProperty("cluster_id")?.toInt() ?: continue
                val key = "c$cid"
                if (key in seen) continue
                f.addStringProperty("cluster_key", key)
                seen[key] = f
            }
            // Tiles of the data are made one after another: read until two reads in a row find the same clusters.
            val signature = seen.keys.sorted().joinToString(",")
            if (signature != clusterSignatures[id] || (seen.isEmpty() && def.data.features()?.isNotEmpty() == true && source.querySourceFeatures(null).isEmpty())) settled = false
            clusterSignatures[id] = signature
            val changed = clusterFeatures[id]?.keys != seen.keys
            // Before the views are made: a cluster's view reads its points from here.
            clusterFeatures[id] = seen
            if (changed) markers.setData(clusterLayer(id), FeatureCollection.fromFeatures(seen.values.toList()))
        }
        return settled
    }

    /**
     * Reads the clusters now and again shortly after until two reads agree: once the camera stops the engine may draw
     * no further frame, and the last read was taken while the zoom levels were still blending.
     */
    private fun readClustersUntilSettled(attempt: Int) {
        if (!clustersDirty || clustersMoving) return
        clustersReadAt = android.os.SystemClock.uptimeMillis()
        if (refreshClusters()) { clustersDirty = false; return }
        if (attempt < 20) mapView.postDelayed({ readClustersUntilSettled(attempt + 1) }, 100)
    }

    /** The clusters drawn this frame, from the layer's hidden cluster layer (the source's own when it is missing). */
    private fun drawnClusters(id: String, source: GeoJsonSource): List<org.maplibre.geojson.Feature> {
        val map = engine
        val hits = SMapEngineIds.clusterHits(id)
        if (map == null || style?.getLayer(hits) == null || mapView.width == 0) return source.querySourceFeatures(Expression.has("point_count"))
        return map.queryRenderedFeatures(android.graphics.RectF(0f, 0f, mapView.width.toFloat(), mapView.height.toFloat()), hits)
    }

    // ---- what the interaction (drag, tooltips) reads of the layers

    internal class Interactive(val id: String, val kind: SMapEngineIds.Kind, val engineLayer: String, val tooltip: SMapTooltip?, val drag: SMapDragOptions?, val points: SMapPointOptions?)

    /** The drawn layers a long press may act on, top first. */
    internal fun interactiveLayers(): List<Interactive> = order.ids().asReversed().mapNotNull { id ->
        val def = defs[id]?.takeIf { !it.hidden } ?: return@mapNotNull null
        val tooltip = def.points?.tooltip ?: def.lines?.tooltip ?: def.polygons?.tooltip
        val drag = def.points?.drag?.takeIf { it.draggable != null }
        if (tooltip == null && drag == null) return@mapNotNull null
        if (def.kind == SMapEngineIds.Kind.STYLE || def.kind == SMapEngineIds.Kind.CUSTOM || def.kind == SMapEngineIds.Kind.HEATMAP || def.kind == SMapEngineIds.Kind.MODELS) return@mapNotNull null
        Interactive(id, def.kind, SMapEngineIds.tapLayer(id, def.kind, def.polygons?.extrude != null), tooltip, drag, def.points)
    }

    internal fun layerData(id: String): FeatureCollection? = defs[id]?.data

    /** Whether a point of this view is on a tool or control (a touch there is the control's, never the map's). */
    internal fun onControl(x: Float, y: Float): Boolean = toolCorners?.contains(x, y) == true
    internal fun currentStyle(): Style? = style

    /** The geometries of layers (an addData group counts as its layers) the drawing tool snaps to (G28). */
    internal fun snapGeometries(ids: List<String>): List<org.maplibre.geojson.Geometry> = ids.flatMap { x ->
        order.ids().filter { it == x || defs[it]?.group == x }.mapNotNull { defs[it] }.filter { it.kind != SMapEngineIds.Kind.STYLE }
            .flatMap { d -> d.data.features().orEmpty().mapNotNull { it.geometry() } }
    }
    internal fun overlay(): SMapMarkerOverlay = markers

    /** Shows a layer's data without one feature while it is dragged (the layer keeps its data). */
    internal fun showDataWithout(id: String, index: Int) {
        val def = defs[id] ?: return
        val key = SMapEngineData.keyOf(def.data.features()!![index], index, def.idProperty)
        val all = engineData(def)
        style?.getSourceAs<GeoJsonSource>(SMapEngineIds.source(id))?.setGeoJson(FeatureCollection.fromFeatures(all.features()!!.filter { it.id() != key }))
    }

    /** Shows the layer's own data again (a drag that ended without a position). */
    internal fun showLayerData(id: String) { defs[id]?.let { pushData(it) } }

    internal fun replaceData(id: String, data: FeatureCollection) {
        val def = defs[id] ?: return
        def.data = data; def.keyIndex = null; def.ownsData = true
        pushData(def)
    }

    /** One feature of a layer as the engine draws it (the dragged copy). */
    internal fun engineFeatureAt(id: String, index: Int): Feature? {
        val def = defs[id] ?: return null
        val f = def.data.features()?.getOrNull(index) ?: return null
        return SMapEngineData.engineFeature(f, SMapEngineData.keyOf(f, index, def.idProperty), def.fns)
    }

    /** The place in the layer's data of a feature the engine answered (by its key), or -1. */
    internal fun indexOfHit(id: String, hit: Feature): Int {
        val def = defs[id] ?: return -1
        hit.id()?.let { k -> def.keys()[k]?.let { return it } }
        return SMapInteraction.indexOf(def.data, hit)
    }

    /** A copy of a point layer's look drawing from another source on top (the point being dragged). */
    internal fun addGhost(style: Style, ghostId: String, source: String, o: SMapPointOptions) {
        // The same option order gives the same closures their same hidden properties as the layer's own.
        val states = o.states.keys.toList()
        addPointLayers(ghostId, source, o.copy(cluster = null, label = null), SMapStyleBuild(states)) { l -> style.addLayer(l) }
    }

    override fun onInterceptTouchEvent(ev: android.view.MotionEvent): Boolean = interaction.intercept(ev) || super.onInterceptTouchEvent(ev)

    // Cooperative gestures (G36): one finger leaves the map still and the screen around it may scroll; two move it.
    private var cooperative: SMapCooperative? = null
    private var gestureHint: TextView? = null

    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        if (options.cooperativeGestures) {
            val c = cooperative ?: SMapCooperative(android.view.ViewConfiguration.get(context).scaledTouchSlop.toFloat()).also { cooperative = it }
            val d = c.touch(ev.actionMasked, ev.pointerCount, ev.x, ev.y)
            engine?.uiSettings?.isScrollGesturesEnabled = d.mapScroll
            if (d.claim) parent?.requestDisallowInterceptTouchEvent(true)
            if (d.hint) showGestureHint()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun showGestureHint() {
        val d = resources.displayMetrics.density
        val hint = gestureHint ?: TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding((16 * d).toInt(), (10 * d).toInt(), (16 * d).toInt(), (10 * d).toInt())
            background = GradientDrawable().apply { cornerRadius = 8 * d; setColor(Color.argb(170, 0, 0, 0)) }
            // Over the notices and the marker views.
            elevation = 8 * d
            gestureHint = this
            addView(this, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        }
        hint.text = SMapTexts.text(language, "gestureMobile")
        hint.animate().cancel()
        hint.alpha = 1f
        hint.visibility = View.VISIBLE
        hint.animate().alpha(0f).setStartDelay(1500).setDuration(250).withEndAction { hint.visibility = View.GONE }.start()
    }

    // A hovering pointer is watched on its way to the map and the marker views, never taken from them (G19).
    override fun onInterceptHoverEvent(event: android.view.MotionEvent): Boolean {
        interaction.hover(event)
        return super.onInterceptHoverEvent(event)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: android.view.MotionEvent): Boolean = interaction.touch(event) || super.onTouchEvent(event)

    companion object {
        /** The SDK version. */
        const val VERSION = BuildConfig.SMAP_VERSION

        private const val LABEL_FONT = "Noto Sans Medium"
        private const val BASE_IMAGERY = "smap-base-imagery"
        private const val TERRAIN_SOURCE = "smap-terrain"
        private const val HILLSHADE = "smap-hillshade"
        private const val RETRY_MILLIS = 30_000L
        /** The locate tool zooms in to at least this. */
        private const val LOCATE_ZOOM = 15.0
        private const val FETCH_TIMEOUT_MILLIS = 15_000L
        private const val CONVERT_TIMEOUT_MILLIS = 120_000L
        private const val CONVERT_LIMIT = 20 * 1024 * 1024
        private const val BUILDINGS_MIN_ZOOM = 13f
        private const val BUILDINGS_TILT = 55.0
        private const val FLAT_TILT = 30.0
        private const val TILT_MILLIS = 800
        private const val FLY_MILLIS = 1500
        private const val EASE_MILLIS = 500L
        private const val EXPORT_WAIT_MILLIS = 10_000L
        /** The key prefix of a cluster in featuresAt and the pointer events. */
        private const val CLUSTER_KEY = "cluster:"
        private const val DEFAULT_RADIUS = 6f
        private const val DEFAULT_LINE_WIDTH = 4f
        private const val DEFAULT_FILL_OPACITY = 0.35f
        private const val DEFAULT_OUTLINE_WIDTH = 1.5f
        private val EMPTY: FeatureCollection = FeatureCollection.fromFeatures(emptyList())

        /** The headers of the SDK's own requests to nodes: the app identity, and the map key when one is given. */
        private fun ownHeaders(context: Context, apiKey: String?): Map<String, String> {
            val headers = LinkedHashMap(SMapAppIdentity.headers(context))
            if (!apiKey.isNullOrEmpty()) headers[SMapAppIdentity.KEY_HEADER] = apiKey
            return headers
        }
    }
}
