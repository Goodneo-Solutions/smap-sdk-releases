package ca.superroute.smap

import com.google.gson.JsonObject

/**
 * One feature drawn for a plan: [kind] `leg`, `start`, `stop` or `unassigned`, its coordinates as `[lng, lat]` (one
 * for a point), and its properties (`kind`, `vehicle_id`, `position`, `id` for stops and jobs, `color`, and for stops
 * `label`, `border`, `locked`, `violated`).
 */
class SMapPlanFeature(val kind: String, val coordinates: List<DoubleArray>, val properties: Map<String, Any?>)

/** The four layers of a plan (MOBILE-SDK-SPEC "Plan editor", On the map). */
class SMapPlanFeatures(
    val legs: List<SMapPlanFeature>,
    val starts: List<SMapPlanFeature>,
    val stops: List<SMapPlanFeature>,
    val unassigned: List<SMapPlanFeature>,
)

/** Where a drop lands: before the stop at [position] of [vehicleId]'s route (past the last stop: after it). */
data class SMapPlanDropTarget(val vehicleId: String, val position: Int)

/** Drawing a plan: route colours, the features of the current entry, and where a drop lands. */
object SMapPlanDraw {
    /** One colour per vehicle in plan order, repeated. */
    val COLORS = listOf("#2563eb", "#dc2626", "#16a34a", "#9333ea", "#ea580c", "#0891b2", "#db2777", "#65a30d", "#4f46e5", "#b45309")
    const val VIOLATED = "#b91c1c"
    const val LOCKED = "#111827"
    const val UNASSIGNED = "#6b7280"

    fun colorOf(vehicleIds: List<String>, vehicleId: String, colors: List<String> = COLORS): String {
        val i = vehicleIds.indexOf(vehicleId).coerceAtLeast(0)
        return colors[i % colors.size]
    }

    /** The features drawn for [editor]'s plan; [id] is written as `smap_plan` on each. */
    fun features(editor: SMapPlanEditor, id: String = "plan", colors: List<String> = COLORS): SMapPlanFeatures {
        val plan = editor.plan() ?: return SMapPlanFeatures(emptyList(), emptyList(), emptyList(), emptyList())
        return features(plan, editor.result(), editor::isLocked, id, colors)
    }

    fun features(plan: SMapPlan, result: SMapPlanResult?, isLocked: (String) -> Boolean, id: String = "plan", colors: List<String> = COLORS): SMapPlanFeatures {
        val legs = ArrayList<SMapPlanFeature>()
        val starts = ArrayList<SMapPlanFeature>()
        val stops = ArrayList<SMapPlanFeature>()
        val unassigned = ArrayList<SMapPlanFeature>()
        val jobs = plan.jobs.associateBy(SMapPlanIds::ofJob)
        val vehicleIds = plan.vehicles.map(SMapPlanIds::ofJob)
        val vehicles = plan.vehicles.associateBy(SMapPlanIds::ofJob)
        fun feature(kind: String, coords: List<DoubleArray>, props: Map<String, Any?>) =
            SMapPlanFeature(kind, coords, LinkedHashMap(props).apply { put("kind", kind); put("smap_plan", id) })
        for (r in plan.routes) {
            val v = vehicles[r.vehicleId] ?: JsonObject()
            val color = colorOf(vehicleIds, r.vehicleId, colors)
            val start = SMapPlanOps.lngLat(v.get("start"))
            val returns = v.get("return_to_start")?.let { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean && it.asBoolean } == true
            val end = SMapPlanOps.lngLat(v.get("end")) ?: if (returns) start else null
            if (start != null) starts.add(feature("start", listOf(start), mapOf("vehicle_id" to r.vehicleId, "position" to 1, "color" to color)))
            val p = result?.route(r.vehicleId)
            val pricedStops = p?.get("stops")?.takeIf { it.isJsonArray }?.asJsonArray?.filter { it.isJsonObject }?.map { it.asJsonObject } ?: emptyList()
            fun type(o: JsonObject) = o.get("type")?.takeIf { it.isJsonPrimitive }?.asString
            // The answer's legs (with their lines) while the drawn order is the answered one; straight lines before.
            val answered = p != null && p.get("stops")?.isJsonArray == true &&
                pricedStops.filter { type(it) == "job" }.map { SMapPlanIds.of(it.get("id")) } == r.stops
            val points = r.stops.map { SMapPlanOps.lngLat(jobs[it]?.get("location")) }
            var prev = start
            if (answered) {
                var k = 0
                for (st in pricedStops) {
                    val t = type(st)
                    if (t == "start") continue
                    val position = if (t == "job") ++k else r.stops.size + 1
                    val to = if (t == "job") points.getOrNull(position - 1) else end
                    val geometry = st.get("leg_geometry")?.takeIf { it.isJsonPrimitive }?.asString
                    val line = if (geometry != null) SMapPlanOps.decodePolyline(geometry) else if (prev != null && to != null) listOf(prev, to) else null
                    if (line != null && line.size > 1) legs.add(feature("leg", line, mapOf("vehicle_id" to r.vehicleId, "position" to position, "color" to color)))
                    if (to != null) prev = to
                }
            } else {
                (points + listOfNotNull(end)).forEachIndexed { i, to ->
                    val from = prev
                    if (from != null && to != null) legs.add(feature("leg", listOf(from, to), mapOf("vehicle_id" to r.vehicleId, "position" to i + 1, "color" to color)))
                    if (to != null) prev = to
                }
            }
            val info = pricedStops.filter { type(it) == "job" }.associateBy { SMapPlanIds.of(it.get("id")) }
            r.stops.forEachIndexed { i, s ->
                val at = points[i] ?: return@forEachIndexed
                val st = if (answered) info[s] else null
                val violated = st != null && ((st.get("violations")?.takeIf { it.isJsonArray }?.asJsonArray?.size() ?: 0) > 0 ||
                    st.get("reachable")?.let { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean && !it.asBoolean } == true)
                val locked = isLocked(s)
                stops.add(feature("stop", listOf(at), mapOf(
                    "id" to s, "vehicle_id" to r.vehicleId, "position" to i + 1, "label" to (i + 1).toString(), "color" to color,
                    "border" to if (violated) VIOLATED else if (locked) LOCKED else color, "locked" to locked, "violated" to violated,
                )))
            }
        }
        for (s in plan.unassigned) {
            val at = SMapPlanOps.lngLat(jobs[s]?.get("location")) ?: continue
            unassigned.add(feature("unassigned", listOf(at), mapOf("id" to s, "color" to UNASSIGNED)))
        }
        return SMapPlanFeatures(legs, starts, stops, unassigned)
    }

    /**
     * Where a drop at these features goes (properties of the features under the pointer, nearest first): before the
     * first other stop, else into a leg (before the stop it leads to), else first after a start.
     */
    fun dropTarget(hits: List<Map<String, Any?>>, dragged: String): SMapPlanDropTarget? {
        fun target(p: Map<String, Any?>): SMapPlanDropTarget? {
            val vehicle = p["vehicle_id"]?.toString() ?: return null
            val position = (p["position"] as? Number)?.toInt() ?: p["position"]?.toString()?.toDoubleOrNull()?.toInt() ?: return null
            return SMapPlanDropTarget(vehicle, position)
        }
        hits.firstOrNull { it["kind"] == "stop" && it["id"]?.toString() != dragged }?.let { return target(it) }
        hits.firstOrNull { it["kind"] == "leg" || it["kind"] == "start" }?.let { return target(it) }
        return null
    }
}

/** Runs a block after a delay; the returned function cancels it. */
fun interface SMapPlanScheduler {
    fun schedule(delayMillis: Long, block: () -> Unit): () -> Unit
}

/**
 * A stop dragged on a map: [start] when the pointer goes down on a stop or an unassigned job (on Android: after a
 * long press), [move] with the features under the pointer (it becomes a drag past [threshold] pixels, and the plan with
 * the stop at the target is priced as a preview [previewMillis] after the target last changed), [end] drops it
 * (`dropStop`; the last target when no hits are given), [cancel] gives it up.
 */
class SMapPlanDrag(
    private val editor: SMapPlanEditor,
    private val scheduler: SMapPlanScheduler,
    private val preview: Boolean = true,
    private val previewMillis: Long = PREVIEW_MILLIS,
    private val threshold: Float = DRAG_PX,
) {
    private class Drag(val id: String, val x: Float?, val y: Float?) {
        var moved = false
        var target: SMapPlanDropTarget? = null
        var key: String? = null
    }

    private var drag: Drag? = null
    private var timer: (() -> Unit)? = null

    private fun stopTimer() {
        timer?.invoke()
        timer = null
    }

    val dragging: String? get() = drag?.id
    val moved: Boolean get() = drag?.moved == true
    val target: SMapPlanDropTarget? get() = drag?.target

    fun start(stopId: String, x: Float? = null, y: Float? = null) {
        stopTimer()
        drag = Drag(stopId, x, y)
    }

    fun move(hits: List<Map<String, Any?>>, x: Float? = null, y: Float? = null): SMapPlanDropTarget? {
        val d = drag ?: return null
        if (!d.moved && x != null && y != null && d.x != null && d.y != null && Math.abs(x - d.x) + Math.abs(y - d.y) < threshold) return null
        d.moved = true
        val t = SMapPlanDraw.dropTarget(hits, d.id)
        val key = t?.let { "${it.vehicleId}#${it.position}" }
        if (key == d.key) return t
        d.key = key
        d.target = t
        stopTimer()
        if (!preview) return t
        val routes = t?.let { editor.plan()?.routes?.let { r -> SMapPlanOps.dropRoutes(r, d.id, it.vehicleId, it.position) } }
        if (routes == null) {
            editor.clearPreview()
            return t
        }
        timer = scheduler.schedule(previewMillis) {
            timer = null
            editor.perform { preview(routes) }
        }
        return t
    }

    /** Drops the stop; the target it was dropped on, or null when the drop changes nothing. */
    fun end(hits: List<Map<String, Any?>>? = null): SMapPlanDropTarget? {
        val d = drag ?: return null
        drag = null
        stopTimer()
        if (!d.moved) return null
        val t = if (hits != null) SMapPlanDraw.dropTarget(hits, d.id) else d.target
        editor.clearPreview()
        if (t == null) return null
        editor.perform { dropStop(d.id, t.vehicleId, t.position) }
        return t
    }

    fun cancel() {
        val d = drag
        drag = null
        stopTimer()
        if (d != null && d.moved) editor.clearPreview()
    }

    companion object {
        const val DRAG_PX = 4f
        const val PREVIEW_MILLIS = 250L
    }
}
