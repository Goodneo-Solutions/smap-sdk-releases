package ca.superroute.smap

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import org.maplibre.geojson.Feature

/**
 * A cluster drawn as a view (G6): the bold count on a white disc inside a ring of the points' colours, each colour's
 * share of the points, largest first; up to six slices, the rest in the last. 32 / 38 / 44 dp across.
 */
@SuppressLint("ViewConstructor")
internal class SMapClusterRingView(context: Context, private val count: Int, private val shares: List<Pair<String, Float>>, fallback: String) : View(context) {
    private val density = resources.displayMetrics.density
    private val sizePx = ((if (count >= 100) 44 else if (count >= 10) 38 else 32) * density).toInt()
    private val fallbackColor = parse(fallback) ?: Color.rgb(37, 99, 235)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(17, 24, 39); textAlign = Paint.Align.CENTER; textSize = 12 * density; typeface = Typeface.DEFAULT_BOLD
    }

    init { isClickable = true; elevation = 3 * density }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) = setMeasuredDimension(sizePx, sizePx)

    override fun onDraw(canvas: Canvas) {
        val r = width / 2f
        val box = RectF(0f, 0f, width.toFloat(), height.toFloat())
        if (shares.isEmpty()) {
            paint.color = fallbackColor
            canvas.drawCircle(r, r, r, paint)
        } else {
            var start = -90f
            shares.forEach { (c, share) ->
                paint.color = parse(c) ?: fallbackColor
                canvas.drawArc(box, start, share * 360f, true, paint)
                start += share * 360f
            }
        }
        paint.color = Color.WHITE
        canvas.drawCircle(r, r, r - 4 * density, paint)
        canvas.drawText(count.toString(), r, r - (text.descent() + text.ascent()) / 2, text)
    }

    companion object {
        private fun parse(c: String): Int? = try { Color.parseColor(c) } catch (e: IllegalArgumentException) { null }

        /** Each colour's share of the leaves (largest first, up to six; the rest folded into the sixth). */
        fun shares(leaves: List<Feature>, property: String): List<Pair<String, Float>> =
            sharesOf(leaves.mapNotNull { f -> f.getStringProperty(property)?.takeIf { it.isNotEmpty() } })

        fun sharesOf(colors: List<String>): List<Pair<String, Float>> {
            if (colors.isEmpty()) return emptyList()
            val counts = colors.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }
            val total = colors.size.toFloat()
            val shown = counts.take(6)
            val rest = counts.drop(6).sumOf { it.value }
            return shown.mapIndexed { i, e -> e.key to ((e.value + if (i == shown.size - 1) rest else 0) / total) }
        }
    }
}
