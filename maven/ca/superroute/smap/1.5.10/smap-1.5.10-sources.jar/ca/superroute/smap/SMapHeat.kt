package ca.superroute.smap

import org.maplibre.android.style.expressions.Expression

/** The heat map colour ramp (G7), as the Web SDK writes it. */
internal object SMapHeat {
    /** The Web SDK's default: transparent, then five colours from blue to red. */
    val DEFAULT = listOf(
        0.0 to "rgba(33, 102, 172, 0)", 0.2 to "rgb(103, 169, 207)", 0.4 to "rgb(209, 229, 240)",
        0.6 to "rgb(253, 219, 199)", 0.8 to "rgb(239, 138, 98)", 1.0 to "rgb(178, 24, 43)",
    )

    /** Colours from low to high: transparent at no density, then evenly spaced (or the default ramp). */
    fun stops(colors: List<String>?): List<Pair<Double, String>> =
        if (colors.isNullOrEmpty()) DEFAULT
        else listOf(0.0 to "rgba(0, 0, 0, 0)") + colors.mapIndexed { i, c -> (i + 1).toDouble() / colors.size to c }

    fun ramp(colors: List<String>?, minOpacity: Float? = null): Expression {
        val stops = if (minOpacity != null && minOpacity > 0) minOpacityStops(stops(colors), minOf(1.0, minOpacity.toDouble())) else stops(colors)
        return Expression.interpolate(
            Expression.linear(), Expression.heatmapDensity(),
            *stops.map { (d, c) -> Expression.stop(d, Expression.toColor(Expression.literal(c))) }.toTypedArray(),
        )
    }

    /** Where heat starts to show (G33). */
    private const val HEAT_SHOWS = 0.05

    /**
     * The Web SDK's minOpacityRamp (G33): from the density where heat starts to show (0.05, or the ramp's first stop
     * above no density when that is lower) every colour is at least [floor] opaque, with a stop added there in the
     * ramp's own colour, so one faint point shows and a spot's edge stays soft. Colours it cannot read leave the ramp
     * as it is.
     */
    fun minOpacityStops(ramp: List<Pair<Double, String>>, floor: Double): List<Pair<Double, String>> {
        val parts = ramp.map { colorParts(it.second) ?: return ramp }
        val firstUp = ramp.indexOfFirst { it.first > 0 }.takeIf { it >= 0 } ?: return ramp
        val at = minOf(HEAT_SHOWS, ramp[firstUp].first)
        fun colourAt(d: Double): DoubleArray {
            for (k in 1 until ramp.size) {
                if (d <= ramp[k].first) {
                    val a = parts[k - 1]; val b = parts[k]
                    val t = if (ramp[k].first == ramp[k - 1].first) 1.0 else (d - ramp[k - 1].first) / (ramp[k].first - ramp[k - 1].first)
                    return DoubleArray(4) { j -> a[j] + (b[j] - a[j]) * t }
                }
            }
            return parts.last().copyOf()
        }
        val out = ArrayList<Pair<Double, String>>()
        var added = false
        ramp.forEachIndexed { i, (d, c) ->
            if (!added && d > at) {
                val p = colourAt(at)
                p[3] = maxOf(p[3], floor)
                out += at to rgbaText(p)
                added = true
            }
            if (d <= 0) { out += d to c; return@forEachIndexed }
            val p = parts[i].copyOf()
            if (d >= at) p[3] = maxOf(p[3], floor)
            out += d to rgbaText(p)
        }
        return out
    }

    private fun trim(v: Double): String = if (v == Math.floor(v) && kotlin.math.abs(v) < 1e15) v.toLong().toString() else v.toString()

    /** As the web writes it: `rgba(r, g, b, a)` with whole channels and the alpha to four decimals. */
    fun rgbaText(p: DoubleArray): String =
        "rgba(${Math.round(p[0])}, ${Math.round(p[1])}, ${Math.round(p[2])}, ${trim(Math.round(p[3] * 10000) / 10000.0)})"

    /** A CSS colour (`#rgb`, `#rgba`, `#rrggbb`, `#rrggbbaa`, `rgb()`, `rgba()`) as [r, g, b, a], or null. */
    fun colorParts(c: String): DoubleArray? {
        val s = c.trim()
        Regex("^#([0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$").find(s)?.let { m ->
            var h = m.groupValues[1]
            if (h.length <= 4) h = h.map { "$it$it" }.joinToString("")
            val n = (0 until h.length / 2).map { h.substring(it * 2, it * 2 + 2).toInt(16).toDouble() }
            return doubleArrayOf(n[0], n[1], n[2], if (n.size > 3) n[3] / 255 else 1.0)
        }
        Regex("^rgba?\\(([^)]*)\\)$", RegexOption.IGNORE_CASE).find(s)?.let { m ->
            val v = m.groupValues[1].split(Regex("[\\s,/]+")).filter { it.isNotEmpty() }
            if (v.size < 3) return null
            fun ch(x: String) = if (x.endsWith("%")) x.dropLast(1).toDouble() * 2.55 else x.toDouble()
            return try {
                doubleArrayOf(ch(v[0]), ch(v[1]), ch(v[2]), if (v.size > 3) (if (v[3].endsWith("%")) v[3].dropLast(1).toDouble() / 100 else v[3].toDouble()) else 1.0)
            } catch (e: NumberFormatException) { null }
        }
        return null
    }
}
