package ca.superroute.smap

import ca.superroute.smap.SMapJson.arrOrNull
import ca.superroute.smap.SMapJson.bool
import ca.superroute.smap.SMapJson.num
import ca.superroute.smap.SMapJson.objOrNull
import ca.superroute.smap.SMapJson.str
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive

/**
 * One layer of a layer description: an SDK layer (`points`, `lines`, `polygons`, with [data] and [options]) or a
 * Style Spec layer (`style`, with [layer]).
 */
data class SMapLayerEntry(
    val id: String,
    val kind: String,
    val slot: SMapSlot? = null,
    val before: String? = null,
    val zIndex: Int = 0,
    val visible: Boolean = true,
    val group: String? = null,
    val data: JsonObject? = null,
    val options: JsonObject? = null,
    val layer: JsonObject? = null,
)

/** A layer description read back: the basemap (when given), the sources and the layers in drawing order. */
data class SMapLayerDescription(
    val basemap: JsonObject?,
    val sources: Map<String, JsonObject>,
    val layers: List<SMapLayerEntry>,
)

/**
 * The layer description every SDK and adapter reads and writes (`shared/LAYER-JSON.md`, version 1):
 * `{"type":"smap.layers","version":1,"basemap":…,"sources":…,"layers":[…]}`.
 */
object SMapLayerJson {
    const val TYPE = "smap.layers"
    const val VERSION = 1
    val KINDS = setOf("points", "lines", "polygons", "style")

    fun write(basemap: JsonObject?, sources: Map<String, JsonObject>, layers: List<SMapLayerEntry>): JsonObject = JsonObject().apply {
        addProperty("type", TYPE)
        addProperty("version", VERSION)
        if (basemap != null) add("basemap", basemap)
        if (sources.isNotEmpty()) add("sources", JsonObject().also { s -> sources.forEach { (k, v) -> s.add(k, v.deepCopy()) } })
        add("layers", SMapJson.of(layers.map(::entry)))
    }

    private fun entry(e: SMapLayerEntry): JsonObject = JsonObject().apply {
        addProperty("id", e.id)
        addProperty("kind", e.kind)
        if (e.before != null) addProperty("before", e.before) else e.slot?.let { addProperty("slot", it.id) }
        if (e.zIndex != 0) addProperty("zIndex", e.zIndex)
        if (!e.visible) addProperty("visible", false)
        e.group?.let { addProperty("group", it) }
        e.data?.let { add("data", it.deepCopy()) }
        e.options?.let { add("options", it.deepCopy()) }
        e.layer?.let { add("layer", it.deepCopy()) }
    }

    /**
     * Reads a description.
     *
     * @throws IllegalArgumentException when it is not one or its major version is newer than this SDK reads
     */
    fun read(json: JsonObject): SMapLayerDescription {
        if (json.str("type") != TYPE) throw IllegalArgumentException("sMap: not an sMap layer description (type smap.layers)")
        val version = json.num("version") ?: throw IllegalArgumentException("sMap: the layer description has no version")
        if (Math.floor(version) > VERSION) {
            throw IllegalArgumentException("sMap: layer description version ${SMapJson.number(version)} is newer than this SDK reads ($VERSION)")
        }
        val sources = LinkedHashMap<String, JsonObject>()
        json.objOrNull("sources")?.entrySet()?.forEach { (k, v) -> if (v.isJsonObject) sources[k] = v.asJsonObject }
        val list = json.arrOrNull("layers") ?: throw IllegalArgumentException("sMap: a layer description needs layers")
        val layers = list.mapIndexed { i, el ->
            val o = el.takeIf { it.isJsonObject }?.asJsonObject
            val id = o?.str("id")?.takeIf { it.isNotEmpty() } ?: throw IllegalArgumentException("sMap: layer $i has no id")
            val kind = o.str("kind")
            if (kind !in KINDS) throw IllegalArgumentException("sMap: layer $id has an unknown kind $kind")
            val slot = o.str("slot")?.let { s -> SMapSlot.entries.firstOrNull { it.id == s } ?: throw IllegalArgumentException("sMap: layer $id has an unknown slot $s") }
            SMapLayerEntry(
                id = id,
                kind = kind!!,
                slot = slot,
                before = o.str("before"),
                zIndex = o.num("zIndex")?.toInt() ?: 0,
                visible = o.bool("visible") ?: true,
                group = o.str("group"),
                data = o.objOrNull("data"),
                options = o.objOrNull("options"),
                layer = o.objOrNull("layer"),
            )
        }
        return SMapLayerDescription(json.objOrNull("basemap"), sources, layers)
    }

    // ------------------------------------------------------------------ options

    /** A float as the decimal it was written as (0.35f → 0.35, not 0.3499999940395355). */
    internal fun f(v: Float): Double = v.toString().toDouble()

    private fun JsonObject.put(key: String, v: Any?) { if (v != null) add(key, SMapJson.of(v)) }

    /** A constant number of an option; a property reference or expression (which this SDK cannot take here) is null. */
    private fun JsonObject.float(key: String): Float? = num(key)?.toFloat()

    fun pointOptions(o: SMapPointOptions): JsonObject = JsonObject().apply {
        val d = SMapPointOptions()
        o.cluster?.let { c -> add("cluster", if (c == SMapCluster()) JsonPrimitive(true) else SMapJson.obj("radius" to c.radius, "maxZoom" to c.maxZoom)) }
        put("color", o.color)
        if (o.radius != d.radius) put("radius", f(o.radius))
        if (o.strokeColor != d.strokeColor) put("strokeColor", o.strokeColor)
        put("icon", o.icon)
        if (o.iconSize != d.iconSize) put("iconSize", f(o.iconSize))
        put("iconProperty", o.iconProperty)
        if (o.iconAnchor != d.iconAnchor) put("iconAnchor", o.iconAnchor.engineName)
        if (o.iconOffsetDp != d.iconOffsetDp) add("iconOffset", SMapJson.of(listOf(f(o.iconOffsetDp.first), f(o.iconOffsetDp.second))))
        put("iconOpacityProperty", o.iconOpacityProperty)
        put("sortProperty", o.sortProperty)
        put("label", o.label)
        o.minZoom?.let { put("minzoom", f(it)) }
        o.maxZoom?.let { put("maxzoom", f(it)) }
    }

    fun pointOptions(o: JsonObject?, e: SMapLayerEntry): SMapPointOptions {
        val d = SMapPointOptions()
        if (o == null) return d.copy(zIndex = e.zIndex, slot = e.slot, before = e.before)
        val cluster = when (val c = o.get("cluster")) {
            null -> null
            else -> when {
                c.isJsonPrimitive && c.asJsonPrimitive.isBoolean -> if (c.asBoolean) SMapCluster() else null
                c.isJsonObject -> SMapCluster(c.asJsonObject.num("radius")?.toInt() ?: 50, c.asJsonObject.num("maxZoom")?.toInt() ?: 14)
                else -> null
            }
        }
        return SMapPointOptions(
            cluster = cluster,
            color = o.str("color"),
            radius = o.float("radius") ?: d.radius,
            strokeColor = o.str("strokeColor") ?: d.strokeColor,
            icon = o.str("icon"),
            iconSize = o.float("iconSize") ?: d.iconSize,
            iconProperty = o.str("iconProperty"),
            iconAnchor = o.str("iconAnchor")?.let { a -> SMapAnchor.entries.firstOrNull { it.engineName == a } } ?: d.iconAnchor,
            iconOffsetDp = o.get("iconOffset")?.takeIf { it.isJsonArray && it.asJsonArray.size() == 2 }?.asJsonArray
                ?.let { it[0].asFloat to it[1].asFloat } ?: d.iconOffsetDp,
            iconOpacityProperty = o.str("iconOpacityProperty"),
            sortProperty = o.str("sortProperty"),
            label = o.str("label"),
            minZoom = o.float("minzoom"),
            maxZoom = o.float("maxzoom"),
            zIndex = e.zIndex,
            slot = e.slot,
            before = e.before,
        )
    }

    fun lineOptions(o: SMapLineOptions): JsonObject = JsonObject().apply {
        val d = SMapLineOptions()
        put("color", o.color)
        if (o.width != d.width) put("width", f(o.width))
        o.dash?.let { put("dash", it.map(::f)) }
        if (o.opacity != d.opacity) put("opacity", f(o.opacity))
        o.minZoom?.let { put("minzoom", f(it)) }
        o.maxZoom?.let { put("maxzoom", f(it)) }
    }

    fun lineOptions(o: JsonObject?, e: SMapLayerEntry): SMapLineOptions {
        val d = SMapLineOptions()
        if (o == null) return d.copy(zIndex = e.zIndex, slot = e.slot, before = e.before)
        return SMapLineOptions(
            color = o.str("color"),
            width = o.float("width") ?: d.width,
            dash = o.arrOrNull("dash")?.takeIf { a -> a.all { it.isJsonPrimitive && it.asJsonPrimitive.isNumber } }?.map { it.asFloat },
            opacity = o.float("opacity") ?: d.opacity,
            minZoom = o.float("minzoom"),
            maxZoom = o.float("maxzoom"),
            zIndex = e.zIndex,
            slot = e.slot,
            before = e.before,
        )
    }

    private fun value(v: SMapValue): Any = when (v) {
        is SMapValue.Fixed -> v.value
        is SMapValue.Property -> v.name
    }

    private fun value(e: JsonElement?, fallback: SMapValue): SMapValue = when {
        e == null || !e.isJsonPrimitive -> fallback
        e.asJsonPrimitive.isNumber -> SMapValue.Fixed(e.asDouble)
        e.asJsonPrimitive.isString -> SMapValue.Property(e.asString)
        else -> fallback
    }

    fun polygonOptions(o: SMapPolygonOptions): JsonObject = JsonObject().apply {
        val d = SMapPolygonOptions()
        put("fill", o.fill)
        if (o.opacity != d.opacity) put("opacity", f(o.opacity))
        put("outline", o.outline)
        if (o.outlineWidth != d.outlineWidth) put("outlineWidth", f(o.outlineWidth))
        o.extrude?.let { x -> add("extrude", SMapJson.obj("height" to value(x.height), "base" to value(x.base))) }
        o.minZoom?.let { put("minzoom", f(it)) }
        o.maxZoom?.let { put("maxzoom", f(it)) }
    }

    fun polygonOptions(o: JsonObject?, e: SMapLayerEntry): SMapPolygonOptions {
        val d = SMapPolygonOptions()
        if (o == null) return d.copy(zIndex = e.zIndex, slot = e.slot, before = e.before)
        val extrude = o.objOrNull("extrude")?.let { x ->
            val dx = SMapExtrude()
            SMapExtrude(value(x.get("height"), dx.height), value(x.get("base"), dx.base))
        }
        return SMapPolygonOptions(
            fill = o.str("fill"),
            opacity = o.float("opacity") ?: d.opacity,
            outline = o.str("outline"),
            outlineWidth = o.float("outlineWidth") ?: d.outlineWidth,
            extrude = extrude,
            minZoom = o.float("minzoom"),
            maxZoom = o.float("maxzoom"),
            zIndex = e.zIndex,
            slot = e.slot,
            before = e.before,
        )
    }
}
