package ca.superroute.smap

import ca.superroute.smap.SMapJson.objOrNull
import ca.superroute.smap.SMapJson.str
import com.google.gson.JsonObject

/** Checks Style Spec v8 sources and layers before they reach the engine, with messages naming what is wrong. */
object SMapStyleSpec {
    /** Layer types the engine draws. */
    val LAYER_TYPES = setOf(
        "fill", "line", "symbol", "circle", "heatmap", "fill-extrusion", "raster", "hillshade", "background", "color-relief",
    )

    /** Source types the engine reads. (`video` is not drawn by the Android engine.) */
    val SOURCE_TYPES = setOf("vector", "raster", "raster-dem", "geojson", "image")

    /** A layer given as JSON text, a [JsonObject] or a map of plain values, as a [JsonObject]. */
    fun layerObject(layer: Any): JsonObject = when (layer) {
        is JsonObject -> layer
        is String -> SMapJson.parseObject(layer)
        is Map<*, *> -> SMapJson.of(layer).asJsonObject
        else -> throw IllegalArgumentException("sMap: a style layer is a JSON object")
    }

    /**
     * Checks a style layer: an `id`, a known `type`, a `source` (except background), `paint` / `layout` objects.
     *
     * @throws IllegalArgumentException naming the problem
     */
    fun checkLayer(layer: JsonObject): JsonObject {
        val id = layer.str("id")
        if (id.isNullOrEmpty()) throw IllegalArgumentException("sMap: a style layer needs an id")
        val type = layer.str("type") ?: throw IllegalArgumentException("sMap: style layer $id needs a type")
        if (type !in LAYER_TYPES) throw IllegalArgumentException("sMap: style layer $id has an unknown type \"$type\"")
        val source = layer.get("source")
        if (source != null && source.isJsonObject) {
            checkSource(id, source.asJsonObject)
        } else if (type != "background" && layer.str("source").isNullOrEmpty()) {
            throw IllegalArgumentException("sMap: style layer $id needs a source")
        }
        for (key in listOf("paint", "layout")) {
            if (layer.has(key) && !layer.get(key).isJsonObject) throw IllegalArgumentException("sMap: style layer $id: $key must be an object")
        }
        return layer
    }

    /**
     * Checks a source: a known `type`, and for tiled sources `tiles` or `url`; geojson needs `data`.
     *
     * @throws IllegalArgumentException naming the problem
     */
    fun checkSource(id: String, source: JsonObject): JsonObject {
        if (id.isEmpty()) throw IllegalArgumentException("sMap: a source needs an id")
        val type = source.str("type") ?: throw IllegalArgumentException("sMap: source $id needs a type")
        if (type == "video") throw IllegalArgumentException("sMap: source $id: video sources are not drawn on Android")
        if (type !in SOURCE_TYPES) throw IllegalArgumentException("sMap: source $id has an unknown type \"$type\"")
        when (type) {
            "vector", "raster", "raster-dem" -> if (!source.has("tiles") && source.str("url").isNullOrEmpty()) {
                throw IllegalArgumentException("sMap: source $id needs tiles or url")
            }
            "geojson" -> if (!source.has("data")) throw IllegalArgumentException("sMap: source $id needs data")
            "image" -> if (source.str("url").isNullOrEmpty() || !source.has("coordinates")) {
                throw IllegalArgumentException("sMap: source $id needs url and coordinates")
            }
        }
        return source
    }

    /** The paint or layout object of a layer, created when missing. */
    fun section(layer: JsonObject, paint: Boolean): JsonObject {
        val key = if (paint) "paint" else "layout"
        return layer.objOrNull(key) ?: JsonObject().also { layer.add(key, it) }
    }
}
