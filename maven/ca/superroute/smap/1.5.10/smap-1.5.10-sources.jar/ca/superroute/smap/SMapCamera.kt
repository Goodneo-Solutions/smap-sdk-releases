package ca.superroute.smap

import android.graphics.PointF
import android.view.MotionEvent
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.Geometry
import org.maplibre.geojson.GeometryCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.MultiLineString
import org.maplibre.geojson.MultiPoint
import org.maplibre.geojson.MultiPolygon
import org.maplibre.geojson.Point
import org.maplibre.geojson.Polygon

/** Space kept free around a fitted view, in density-independent pixels (G15). */
data class SMapPadding(val top: Float = 40f, val bottom: Float = 40f, val left: Float = 40f, val right: Float = 40f) {
    constructor(all: Float) : this(all, all, all, all)
}

/**
 * How [SMap.fitBounds] and [SMap.fitLayer] fit the view (G15).
 *
 * @param pitch the tilt on landing (the current one when null)
 * @param bearing the bearing on landing; the bounds are fitted as turned (the current one when null)
 * @param durationMillis null animates as the map's camera animations do, 0 jumps
 */
data class SMapFitOptions(
    val padding: SMapPadding = SMapPadding(40f),
    val maxZoom: Double = 15.0,
    val pitch: Double? = null,
    val bearing: Double? = null,
    val durationMillis: Long? = null,
)

/** Where [SMap.jumpTo] / [SMap.easeTo] put the camera; what is not given stays (G16). */
data class SMapCameraOptions(
    val center: LatLng? = null,
    val zoom: Double? = null,
    val bearing: Double? = null,
    val pitch: Double? = null,
)

/** The map's events in the SDK's shape (G16); [webName] is the Web SDK's name of each. */
enum class SMapEventType(val webName: String) {
    MOVE("move"), MOVE_END("moveend"), ZOOM_END("zoomend"), CLICK("click"), DOUBLE_CLICK("dblclick"),
    CONTEXT_MENU("contextmenu"), MOUSE_MOVE("mousemove"),
    /** (1.5.0, G32) The map cannot be shown: [SMapEvent.reason] says why; fired once, told at once to a later listener. */
    UNAVAILABLE("smap.unavailable");

    companion object {
        /** The type of a Web SDK event name; null for a name the SDK does not hand over. */
        fun of(webName: String): SMapEventType? = entries.firstOrNull { it.webName == webName }
    }
}

/**
 * A map event (G16). Pointer events carry [position] and [point] (pixels from the map's top-left corner); camera
 * events carry the view after the change. On `click` and `dblclick`, [preventDefault] skips the map's own response
 * (a double tap prevented does not zoom).
 */
class SMapEvent internal constructor(
    val type: String,
    val position: LatLng? = null,
    val point: PointF? = null,
    val center: LatLng? = null,
    val zoom: Double? = null,
    val bearing: Double? = null,
    val pitch: Double? = null,
    /** The touch or pointer event behind it, where there is one. */
    val motionEvent: MotionEvent? = null,
    /** (G32) Why the map cannot be shown, on UNAVAILABLE. */
    val reason: SMapUnavailableReason? = null,
    /** (G32) What failed, when known, on UNAVAILABLE. */
    val error: Throwable? = null,
) {
    var defaultPrevented: Boolean = false
        private set

    fun preventDefault() { defaultPrevented = true }
}

/** A pointer event on a layer's feature (onHover, onDoubleClick, onContextMenu; G19). */
data class SMapLayerEvent(val type: String, val position: LatLng?, val point: PointF?)

/** What [SMap.featuresAt] answers per feature: the SDK layer's id and the layer's own feature (G19). */
data class SMapFeatureAt(val layer: String, val feature: SMapFeature)

/** Which way a heading is counted (G24): from north, turning with the map, or from the top of the screen. */
enum class SMapRotationAlignment(val engineName: String) { MAP("map"), VIEWPORT("viewport") }

/** A look a point has while it has a state (G21); null values keep the layer's own. */
data class SMapPointLook(
    val color: String? = null,
    val radius: Float? = null,
    val strokeColor: String? = null,
    val strokeWidth: Float? = null,
    val opacity: Float? = null,
    /** (1.5.0, G25) The colour of an SDF icon in this state. */
    val iconColor: String? = null,
)

/** A look a line has while it has a state (G21). */
data class SMapLineLook(val color: String? = null, val width: Float? = null, val opacity: Float? = null)

/** A look an area has while it has a state (G21); an outline without its own colour follows [fill]. */
data class SMapPolygonLook(
    val fill: String? = null,
    val opacity: Float? = null,
    val outline: String? = null,
    val outlineWidth: Float? = null,
)

/** Fitting, anchors and the event registry: the parts of G15–G22 that need no screen. */
internal object SMapCameraMath {
    private fun union(a: DoubleArray?, b: DoubleArray?): DoubleArray? {
        if (a == null) return b?.copyOf()
        if (b == null) return a
        return doubleArrayOf(minOf(a[0], b[0]), minOf(a[1], b[1]), maxOf(a[2], b[2]), maxOf(a[3], b[3]))
    }

    fun unionAll(list: List<DoubleArray?>): DoubleArray? = list.fold(null as DoubleArray?) { acc, b -> union(acc, b) }

    private fun finite(v: Any?): Double? = (v as? Number)?.toDouble()?.takeIf { it.isFinite() }

    /**
     * `[west, south, east, north]` around what fitBounds takes, or null when it holds no position: a box of four
     * numbers, [LatLngBounds], a position ([LatLng], [SMapPoint], `[lng, lat]`), a list of any of these, GeoJSON
     * ([Feature], [FeatureCollection], [Geometry], a [JsonObject] or its text) or a list of features.
     */
    fun boundsOf(v: Any?): DoubleArray? = when (v) {
        null -> null
        is LatLngBounds -> doubleArrayOf(v.longitudeWest, v.latitudeSouth, v.longitudeEast, v.latitudeNorth)
        is LatLng -> doubleArrayOf(v.longitude, v.latitude, v.longitude, v.latitude)
        is SMapPoint -> doubleArrayOf(v.lng, v.lat, v.lng, v.lat)
        is DoubleArray -> boundsOf(v.toList())
        is FloatArray -> boundsOf(v.toList())
        is FeatureCollection -> SMapGeoJson.bounds(v)
        is Feature -> v.geometry()?.let { boundsOf(it) }
        is Geometry -> SMapGeoJson.bounds(FeatureCollection.fromFeatures(listOf(Feature.fromGeometry(v))))
        is JsonElement -> jsonBounds(v)
        is String -> try { jsonBounds(SMapJson.parse(v)) } catch (e: Exception) { null }
        is Collection<*> -> {
            val list = v.toList()
            val nums = list.map(::finite)
            when {
                list.size == 4 && nums.all { it != null } -> doubleArrayOf(nums[0]!!, nums[1]!!, nums[2]!!, nums[3]!!)
                list.size >= 2 && nums[0] != null && nums[1] != null -> doubleArrayOf(nums[0]!!, nums[1]!!, nums[0]!!, nums[1]!!)
                else -> unionAll(list.map(::boundsOf))
            }
        }
        else -> null
    }

    private fun jsonBounds(e: JsonElement): DoubleArray? = when {
        e.isJsonArray -> boundsOf((e as JsonArray).map { x -> if (x.isJsonPrimitive && x.asJsonPrimitive.isNumber) x.asDouble else x })
        e.isJsonObject -> {
            val o = e.asJsonObject
            when {
                o.has("type") -> try {
                    when (o.get("type").asString) {
                        "FeatureCollection" -> SMapGeoJson.bounds(FeatureCollection.fromJson(o.toString()))
                        "Feature" -> boundsOf(Feature.fromJson(o.toString()))
                        else -> o.get("coordinates")?.let { jsonBounds(it) }
                            ?: o.get("geometries")?.takeIf { it.isJsonArray }?.let { jsonBounds(it) }
                    }
                } catch (x: Exception) { null }
                o.has("lng") || o.has("lon") || o.has("longitude") -> {
                    val lng = (o.get("lng") ?: o.get("lon") ?: o.get("longitude"))?.asDouble
                    val lat = (o.get("lat") ?: o.get("latitude"))?.asDouble
                    if (lng != null && lat != null) doubleArrayOf(lng, lat, lng, lat) else null
                }
                o.has("coordinates") -> jsonBounds(o.get("coordinates"))
                else -> null
            }
        }
        else -> null
    }

    /**
     * Where a feature's tooltip opens (G22), `[lng, lat]`: a point at itself, a line halfway along (by distance), an
     * area inside it (the middle of its box when inside, else the middle of the widest stretch across it at that
     * latitude), as the Web SDK's featureAnchor.
     */
    fun anchorOf(g: Geometry?): DoubleArray? = when (g) {
        is Point -> doubleArrayOf(g.longitude(), g.latitude())
        is MultiPoint -> g.coordinates().firstOrNull()?.let { doubleArrayOf(it.longitude(), it.latitude()) }
        is LineString -> middleOf(g.coordinates())
        is MultiLineString -> g.lineStrings().maxByOrNull { SMapGeo.length(it.coordinates().map { p -> doubleArrayOf(p.longitude(), p.latitude()) }) }
            ?.let { middleOf(it.coordinates()) }
        is Polygon, is MultiPolygon -> areaAnchor(g)
        is GeometryCollection -> g.geometries().firstNotNullOfOrNull { anchorOf(it) }
        else -> null
    }

    private fun middleOf(line: List<Point>): DoubleArray? {
        if (line.isEmpty()) return null
        val pts = line.map { doubleArrayOf(it.longitude(), it.latitude()) }
        var half = SMapGeo.length(pts) / 2
        for (i in 1 until pts.size) {
            val d = SMapGeo.distance(pts[i - 1], pts[i])
            if (half <= d && d > 0) {
                val t = half / d
                return doubleArrayOf(pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * t, pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * t)
            }
            half -= d
        }
        return pts[0]
    }

    private fun areaAnchor(g: Geometry): DoubleArray? {
        val b = boundsOf(g) ?: return null
        val mid = doubleArrayOf((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)
        val json = SMapJson.parseObject(g.toJson())
        if (SMapGeo.pointInPolygon(mid, json)) return mid
        val ring = (if (g is Polygon) g.coordinates().firstOrNull() else (g as MultiPolygon).coordinates().firstOrNull()?.firstOrNull())
            ?.map { doubleArrayOf(it.longitude(), it.latitude()) } ?: return null
        val xs = ArrayList<Double>()
        for (k in 1 until ring.size) {
            val a = ring[k - 1]; val z = ring[k]
            if ((a[1] > mid[1]) != (z[1] > mid[1])) xs += a[0] + (mid[1] - a[1]) / (z[1] - a[1]) * (z[0] - a[0])
        }
        xs.sort()
        var best: Pair<Double, Double>? = null
        var j = 0
        while (j + 1 < xs.size) {
            if (best == null || xs[j + 1] - xs[j] > best.second - best.first) best = xs[j] to xs[j + 1]
            j += 2
        }
        return best?.let { doubleArrayOf((it.first + it.second) / 2, mid[1]) } ?: ring.firstOrNull()
    }
}

/** The map's event listeners by type (G16): on / off / once, a listener removed while firing is not called. */
internal class SMapEventRegistry(private val report: (Throwable) -> Unit) {
    private class Entry(val type: SMapEventType, val listener: (SMapEvent) -> Unit, val once: Boolean)

    private val entries = ArrayList<Entry>()

    fun on(type: SMapEventType, listener: (SMapEvent) -> Unit, once: Boolean = false) { entries += Entry(type, listener, once) }

    fun off(type: SMapEventType, listener: (SMapEvent) -> Unit) {
        val i = entries.indexOfLast { it.type == type && it.listener === listener }
        if (i >= 0) entries.removeAt(i)
    }

    fun has(type: SMapEventType): Boolean = entries.any { it.type == type }

    /** Calls every listener of [event]'s type in the order added; one that throws is reported and the rest still run. */
    fun fire(type: SMapEventType, event: SMapEvent) {
        val now = entries.filter { it.type == type }
        if (now.isEmpty()) return
        for (e in now) {
            if (e !in entries) continue
            if (e.once) entries.remove(e)
            try { e.listener(event) } catch (x: Exception) { report(x) }
        }
    }
}

/**
 * Whether a camera stop ends a zoom (G16 `zoomend`): the zoom where the move began is kept until the camera stops.
 */
internal class SMapZoomTracker {
    private var startZoom: Double? = null

    fun moved(zoom: Double) { if (startZoom == null) startZoom = zoom }

    /** The camera stopped at [zoom]: true when it differs from where the move began. */
    fun stopped(zoom: Double, before: Double?): Boolean {
        val from = startZoom ?: before
        startZoom = null
        return from != null && kotlin.math.abs(from - zoom) > 1e-9
    }
}

internal fun JsonObject.copyWithout(prefix: String): JsonObject {
    val out = JsonObject()
    entrySet().forEach { (k, v) -> if (!k.startsWith(prefix)) out.add(k, v) }
    return out
}
