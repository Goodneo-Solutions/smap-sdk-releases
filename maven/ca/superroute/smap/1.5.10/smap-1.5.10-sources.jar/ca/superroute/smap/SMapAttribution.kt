package ca.superroute.smap

/** The credit line of the external sources on a map (shown beside the map data credit and the sMap badge). */
object SMapAttribution {
    private val TAG = Regex("<[^>]*>")
    private val ENTITY = mapOf("&copy;" to "©", "&amp;" to "&", "&lt;" to "<", "&gt;" to ">", "&quot;" to "\"", "&#39;" to "'", "&apos;" to "'", "&nbsp;" to " ")

    /** One source's attribution as plain text: HTML tags dropped, common entities decoded, white space collapsed. */
    fun plain(html: String): String {
        var s = TAG.replace(html, "")
        for ((k, v) in ENTITY) s = s.replace(k, v, ignoreCase = true)
        return s.replace(Regex("\\s+"), " ").trim()
    }

    /** Every distinct attribution, as plain text, joined by " · "; empty when there is none. */
    fun text(attributions: Iterable<String?>): String =
        attributions.filterNotNull().map(::plain).filter { it.isNotEmpty() }.distinct().joinToString(" · ")
}
