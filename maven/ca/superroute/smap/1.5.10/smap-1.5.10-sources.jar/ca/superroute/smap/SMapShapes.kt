package ca.superroute.smap

import com.google.gson.JsonObject
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.MultiLineString
import org.maplibre.geojson.Point
import org.maplibre.geojson.Polygon
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Arrowheads every share of a line (G34), as the Web SDK's `arrowPoints`. */
internal object SMapArrows {
    /** The hidden property holding an arrow's turn: degrees clockwise from east, on the map as drawn. */
    const val TURN = "__smap_turn"

    /** The SDK's own arrowhead image (never one of the app's: those are `smap-user:…`). */
    const val IMAGE = "smap-arrowhead"

    private fun merc(lat: Double): Double {
        val s = sin(max(-85.051129, min(85.051129, lat)) * PI / 180)
        return ln((1 + s) / (1 - s)) / 2 * 180 / PI
    }

    /** Points every [share] of each line (at share, 2 × share, … before its end) with the line's properties and its turn there. */
    fun points(fc: FeatureCollection, share: Double): FeatureCollection {
        val out = ArrayList<Feature>()
        for (f in fc.features().orEmpty()) {
            val parts: List<List<Point>> = when (val g = f.geometry()) {
                is LineString -> listOf(g.coordinates())
                is MultiLineString -> g.coordinates()
                else -> emptyList()
            }
            for (line in parts) {
                if (line.size < 2) continue
                val lens = ArrayList<Double>()
                var total = 0.0
                for (i in 1 until line.size) {
                    val d = SMapGeo.distance(doubleArrayOf(line[i - 1].longitude(), line[i - 1].latitude()), doubleArrayOf(line[i].longitude(), line[i].latitude()))
                    lens += d; total += d
                }
                if (!(total > 0)) continue
                var k = 1; var walked = 0.0; var seg = 0
                while (k * share < 1 - 1e-9) {
                    val at = k * share * total
                    while (seg < lens.size - 1 && walked + lens[seg] < at) { walked += lens[seg]; seg++ }
                    val a = line[seg]; val b = line[seg + 1]
                    val t = if (lens[seg] != 0.0) (at - walked) / lens[seg] else 0.0
                    val props = f.properties()?.deepCopy() ?: JsonObject()
                    props.addProperty(TURN, -atan2(merc(b.latitude()) - merc(a.latitude()), b.longitude() - a.longitude()) * 180 / PI)
                    out += Feature.fromGeometry(
                        Point.fromLngLat(a.longitude() + (b.longitude() - a.longitude()) * t, a.latitude() + (b.latitude() - a.latitude()) * t), props, f.id(),
                    )
                    k++
                }
            }
        }
        return FeatureCollection.fromFeatures(out)
    }
}

/** The engine's copy of a circle layer (G26): each point as its circle, the point's id and properties kept. */
internal object SMapCircles {
    /**
     * Every feature of [data] in its place: a point with a radius above 0 as its circle, anything else left as it is
     * (an area layer draws no point or line), so keys by place (`#<index>`) stay the same.
     */
    fun engineData(data: FeatureCollection, o: SMapCircleOptions): FeatureCollection = FeatureCollection.fromFeatures(
        data.features().orEmpty().map { f ->
            val g = f.geometry() as? Point ?: return@map f
            val radius = o.radius.read(SMapGeoJson.propertiesOf(f), 0.0)
            if (!(radius > 0)) return@map f
            val ring = SMapGeoOps.circleRing(doubleArrayOf(g.longitude(), g.latitude()), radius, o.steps)
            Feature.fromGeometry(Polygon.fromLngLats(listOf(ring.map { Point.fromLngLat(it[0], it[1]) })), f.properties(), f.id())
        },
    )
}

/** The arrowhead image's size in dp (G34). */
internal const val ARROW_IMAGE_DP = 16f

/** What choosing a base map of the layer switcher does (G8, G37), in order. */
internal object SMapBaseSwitch {
    enum class Step { GOOGLE_OFF, STYLE, IMAGERY, GOOGLE_ON }

    /**
     * A Google entry shows Google's map ([SMap.setGoogleBase]) after its style, if it names one; any other entry takes
     * Google off first, then its style and its imagery (none takes imagery off) as before 1.5.0.
     */
    fun steps(base: SMapLayersBase, googleShown: Boolean, styleName: String): List<Step> = buildList {
        if (base.google == null && googleShown) add(Step.GOOGLE_OFF)
        if (base.style != null && base.style != styleName) add(Step.STYLE)
        add(if (base.google != null) Step.GOOGLE_ON else Step.IMAGERY)
    }
}
