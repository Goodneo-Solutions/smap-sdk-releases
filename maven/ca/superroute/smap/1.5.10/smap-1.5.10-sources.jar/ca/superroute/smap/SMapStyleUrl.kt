package ca.superroute.smap

import java.net.URLEncoder

/** Builds style addresses: `{node}/v1/styles/{flavor}?lang={language}&token={token}&key={apiKey}`. */
object SMapStyleUrl {
    /** The prefix of a saved custom style (`custom:sms_…`). */
    const val CUSTOM_PREFIX = "custom:"

    /**
     * @param node the node address, with or without a trailing slash
     * @param token added only when not null or empty; the style the service returns carries it into its tile URLs
     * @param apiKey a map key, added only when not null or empty and carried into the tile URLs the same way; with a
     *   token both are sent (the service checks the token first)
     */
    fun build(node: String, flavor: SMapFlavor, language: String, token: String?, apiKey: String? = null): String =
        build(node, flavor.id, language, token, apiKey)

    /**
     * The address of a style named [style]: a flavor id (`light`, …) or a saved custom style `custom:<id>`, read from
     * `/v1/styles/custom/<id>`.
     *
     * @throws IllegalArgumentException for an unknown flavor or an empty custom id
     */
    fun build(node: String, style: String, language: String, token: String?, apiKey: String? = null): String {
        val path = if (isCustom(style)) "custom/" + encode(customId(style)) else checkFlavor(style).id
        return withAccess(
            StringBuilder(node.trimEnd('/')).append("/v1/styles/").append(path).append("?lang=").append(encode(language)),
            token, apiKey,
        )
    }

    /** True for a `custom:<id>` style name. */
    fun isCustom(style: String): Boolean = style.startsWith(CUSTOM_PREFIX)

    private val CUSTOM = Regex("^custom:[A-Za-z0-9_-]+$")

    /** The id of a `custom:<id>` style; throws when [style] is not one. */
    fun customId(style: String): String {
        if (!CUSTOM.matches(style)) throw IllegalArgumentException("sMap: unknown style \"$style\" (a scheme or custom:<id>)")
        return style.substring(CUSTOM_PREFIX.length)
    }

    /** The flavor named [id]; throws for an unknown one. */
    fun checkFlavor(id: String): SMapFlavor = SMapFlavor.entries.firstOrNull { it.id == id }
        ?: throw IllegalArgumentException("sMap: unknown style \"$id\" (a scheme or custom:<id>)")

    /** Checks a style name (a flavor id or `custom:<id>`) and returns it. */
    fun checkStyle(style: String): String {
        if (isCustom(style)) customId(style) else checkFlavor(style)
        return style
    }

    private fun query(lang: String?, apiKey: String?): String {
        val q = ArrayList<String>()
        if (!lang.isNullOrEmpty()) q += "lang=" + SMapJsNumber.encodeURIComponent(lang)
        if (!apiKey.isNullOrEmpty()) q += "key=" + SMapJsNumber.encodeURIComponent(apiKey)
        return if (q.isEmpty()) "" else "?" + q.joinToString("&")
    }

    /**
     * sMap's raster tiles as an XYZ template, for tools without vector tiles (the same as the JavaScript SDK's
     * `rasterUrl`): `{node}/v1/raster/<style>/{z}/{x}/{y}[@2x].png?lang=…&key=…`. [style] is a flavor id or
     * `custom:<id>`; [retina] asks for 512 px tiles.
     */
    fun raster(node: String, style: String, language: String?, retina: Boolean, apiKey: String?): String =
        node.trimEnd('/') + "/v1/raster/" + checkStyle(style) + "/{z}/{x}/{y}" + (if (retina) "@2x" else "") + ".png" + query(language, apiKey)

    /** The TileJSON of sMap's raster tiles of a style. */
    fun rasterTileJson(node: String, style: String, language: String?, apiKey: String?): String =
        node.trimEnd('/') + "/v1/raster/" + checkStyle(style) + ".json" + query(language, apiKey)

    /** The converting endpoint: `{node}/v1/convert?from=<format>[&lat=col&lng=col]` (the token and key go as headers). */
    fun convert(node: String, format: String, lat: String?, lng: String?): String {
        if (format !in SMapFormats.FORMATS) throw IllegalArgumentException("sMap: unknown format \"$format\"")
        val sb = StringBuilder(node.trimEnd('/')).append("/v1/convert?from=").append(SMapJsNumber.encodeURIComponent(format))
        if (!lat.isNullOrEmpty()) sb.append("&lat=").append(SMapJsNumber.encodeURIComponent(lat))
        if (!lng.isNullOrEmpty()) sb.append("&lng=").append(SMapJsNumber.encodeURIComponent(lng))
        return sb.toString()
    }

    private fun withAccess(sb: StringBuilder, token: String?, apiKey: String?): String {
        if (!token.isNullOrEmpty()) sb.append("&token=").append(encode(token))
        if (!apiKey.isNullOrEmpty()) sb.append("&key=").append(encode(apiKey))
        return sb.toString()
    }

    internal fun encode(value: String): String = URLEncoder.encode(value, "UTF-8").replace("+", "%20")
}
