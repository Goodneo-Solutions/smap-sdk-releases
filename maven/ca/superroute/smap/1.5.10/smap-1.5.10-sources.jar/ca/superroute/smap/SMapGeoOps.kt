package ca.superroute.smap

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.JsonObject
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * More geometry (G26, G27), ported line for line from the Web SDK's `js/src/smap-interop.js` so every SDK gives the
 * same answers (`shared/geo-vectors-more.json`). Positions are `[lng, lat]`; rings are closed lists of positions.
 */
internal object SMapGeoOps {
    private const val EARTH_RADIUS = 6371008.8
    private const val AREA_RADIUS = 6378137.0
    private const val KEY_SCALE = 1e5

    private fun rad(d: Double) = d * PI / 180

    // ---------------------------------------------------------------- reading GeoJSON

    class Parts {
        val polygons = ArrayList<List<List<DoubleArray>>>()
        val lines = ArrayList<List<DoubleArray>>()
        val points = ArrayList<DoubleArray>()
    }

    private fun pos(e: JsonElement): DoubleArray = e.asJsonArray.let { doubleArrayOf(it[0].asDouble, it[1].asDouble) }
    private fun isPosition(a: JsonArray) = a.size() >= 2 && a[0].isJsonPrimitive
    private fun closedRing(r: List<DoubleArray>): List<DoubleArray> {
        if (r.isEmpty()) return r
        val a = r[0]; val z = r[r.size - 1]
        return if (a[0] == z[0] && a[1] == z[1]) r else r + listOf(a)
    }

    fun partsOf(input: JsonElement?): Parts {
        val out = Parts()
        fun walk(v: JsonElement?) {
            if (v == null || v.isJsonNull) return
            if (v.isJsonArray) {
                val a = v.asJsonArray
                // A ring of positions, or a list of features / geometries.
                if (a.size() > 0 && a[0].isJsonArray && isPosition(a[0].asJsonArray)) { out.polygons += listOf(closedRing(a.map(::pos))); return }
                a.forEach { walk(it) }
                return
            }
            if (!v.isJsonObject) return
            val o = v.asJsonObject
            when (o.get("type")?.takeIf { it.isJsonPrimitive }?.asString) {
                "FeatureCollection" -> { o.get("features")?.takeIf { it.isJsonArray }?.asJsonArray?.forEach { walk(it) }; return }
                "Feature" -> { walk(o.get("geometry")); return }
                "GeometryCollection" -> { o.get("geometries")?.takeIf { it.isJsonArray }?.asJsonArray?.forEach { walk(it) }; return }
            }
            val c = o.get("coordinates")?.takeIf { it.isJsonArray }?.asJsonArray ?: return
            when (o.get("type")?.asString) {
                "Polygon" -> if (c.size() > 0) out.polygons += c.map { r -> closedRing(r.asJsonArray.map(::pos)) }
                "MultiPolygon" -> c.forEach { p -> val pa = p.asJsonArray; if (pa.size() > 0) out.polygons += pa.map { r -> closedRing(r.asJsonArray.map(::pos)) } }
                "LineString" -> if (c.size() > 0) out.lines += c.map(::pos)
                "MultiLineString" -> c.forEach { l -> val la = l.asJsonArray; if (la.size() > 0) out.lines += la.map(::pos) }
                "Point" -> out.points += doubleArrayOf(c[0].asDouble, c[1].asDouble)
                "MultiPoint" -> c.forEach { out.points += pos(it) }
            }
        }
        walk(input)
        return out
    }

    /** `[[w, s], [e, n]]` of the positions, as the web's `bounds`. */
    private fun bounds(input: JsonElement?): Array<DoubleArray>? = SMapGeo.bounds(input ?: JsonNull.INSTANCE)?.let { arrayOf(doubleArrayOf(it[0], it[1]), doubleArrayOf(it[2], it[3])) }

    private fun boundsOfPolygons(polys: List<List<List<DoubleArray>>>): Array<DoubleArray>? {
        var b: DoubleArray? = null
        for (rings in polys) for (r in rings) for (p in r) {
            val cur = b
            b = if (cur == null) doubleArrayOf(p[0], p[1], p[0], p[1]) else doubleArrayOf(min(cur[0], p[0]), min(cur[1], p[1]), max(cur[2], p[0]), max(cur[3], p[1]))
        }
        return b?.let { arrayOf(doubleArrayOf(it[0], it[1]), doubleArrayOf(it[2], it[3])) }
    }

    // ---------------------------------------------------------------- area, centroid, a point on a feature

    // The area of a ring on the sphere in square metres (signed), as Chamberlain and Duquette's formula.
    private fun ringArea(ring: List<DoubleArray>): Double {
        val n = ring.size - 1
        if (n < 3) return 0.0
        var total = 0.0
        for (i in 0 until n) {
            val prev = ring[(i + n - 1) % n]; val cur = ring[i]; val next = ring[(i + 1) % n]
            total += (rad(next[0]) - rad(prev[0])) * sin(rad(cur[1]))
        }
        return total * AREA_RADIUS * AREA_RADIUS / 2
    }

    fun polygonArea(rings: List<List<DoubleArray>>): Double {
        var a = abs(ringArea(rings[0]))
        for (k in 1 until rings.size) a -= abs(ringArea(rings[k]))
        return max(0.0, a)
    }

    fun area(input: JsonElement?): Double = partsOf(input).polygons.sumOf { polygonArea(it) }

    /** A flat projection around a position in metres: x east, y north (affine in longitude and latitude). */
    class Flat(at: DoubleArray) {
        private val lng0 = at[0]
        private val lat0 = at[1]
        private val kx = (cos(rad(lat0)) * rad(1.0) * EARTH_RADIUS).let { if (abs(it) < 1e-9) 1e-9 else it }
        private val ky = rad(1.0) * EARTH_RADIUS
        fun to(c: DoubleArray) = doubleArrayOf((c[0] - lng0) * kx, (c[1] - lat0) * ky)
        fun from(p: DoubleArray) = doubleArrayOf(lng0 + p[0] / kx, lat0 + p[1] / ky)
    }

    private fun middleOfBounds(b: Array<DoubleArray>) = doubleArrayOf((b[0][0] + b[1][0]) / 2, (b[0][1] + b[1][1]) / 2)

    fun planarRingArea(r: List<DoubleArray>): Double {
        var s = 0.0
        val n = r.size
        for (i in 0 until n) { val a = r[i]; val b = r[(i + 1) % n]; s += a[0] * b[1] - b[0] * a[1] }
        return s / 2
    }

    fun centroid(input: JsonElement?): DoubleArray? = centroidOf(partsOf(input), bounds(input))

    private fun centroidOf(parts: Parts, b: Array<DoubleArray>?): DoubleArray? {
        if (b == null) return null
        val p = Flat(middleOfBounds(b))
        var sx = 0.0; var sy = 0.0; var sw = 0.0
        if (parts.polygons.isNotEmpty()) {
            for (rings in parts.polygons) {
                rings.forEachIndexed { k, ring ->
                    val r = ring.subList(0, max(0, ring.size - 1)).map(p::to)
                    val a = planarRingArea(r)
                    // Outer rings add, holes take away, whatever way each is wound.
                    val sign = if (k == 0) (if (a < 0) -1 else 1) else (if (a < 0) 1 else -1)
                    var cx = 0.0; var cy = 0.0
                    val n = r.size
                    for (i in 0 until n) {
                        val pp = r[i]; val q = r[(i + 1) % n]; val f = pp[0] * q[1] - q[0] * pp[1]
                        cx += (pp[0] + q[0]) * f; cy += (pp[1] + q[1]) * f
                    }
                    if (a != 0.0) { sx += sign * cx / 6; sy += sign * cy / 6; sw += sign * a }
                }
            }
            if (abs(sw) > 1e-9) return p.from(doubleArrayOf(sx / sw, sy / sw))
        }
        if (parts.lines.isNotEmpty()) {
            sx = 0.0; sy = 0.0; sw = 0.0
            for (l in parts.lines) {
                for (i in 1 until l.size) {
                    val a = p.to(l[i - 1]); val c = p.to(l[i])
                    val w = sqrt((c[0] - a[0]) * (c[0] - a[0]) + (c[1] - a[1]) * (c[1] - a[1]))
                    sx += (a[0] + c[0]) / 2 * w; sy += (a[1] + c[1]) / 2 * w; sw += w
                }
            }
            if (sw > 0) return p.from(doubleArrayOf(sx / sw, sy / sw))
        }
        val pts = if (parts.points.isNotEmpty()) parts.points else parts.lines.flatten() + parts.polygons.flatten().flatten()
        if (pts.isEmpty()) return null
        val flat = pts.map(p::to)
        return p.from(doubleArrayOf(flat.sumOf { it[0] } / flat.size, flat.sumOf { it[1] } / flat.size))
    }

    private fun middleOfLine(line: List<DoubleArray>): DoubleArray? {
        var total = 0.0
        for (i in 1 until line.size) total += SMapGeo.distance(line[i - 1], line[i])
        var half = total / 2
        for (i in 1 until line.size) {
            val d = SMapGeo.distance(line[i - 1], line[i])
            if (half <= d && d > 0) {
                val t = half / d
                return doubleArrayOf(line[i - 1][0] + (line[i][0] - line[i - 1][0]) * t, line[i - 1][1] + (line[i][1] - line[i - 1][1]) * t)
            }
            half -= d
        }
        return line.firstOrNull()?.let { doubleArrayOf(it[0], it[1]) }
    }

    private fun inRing(p: DoubleArray, ring: List<DoubleArray>): Boolean = SMapGeo.pointInPolygon(p, ring)

    private fun inPolygon(p: DoubleArray, rings: List<List<DoubleArray>>): Boolean =
        rings.isNotEmpty() && inRing(p, rings[0]) && (1 until rings.size).none { inRing(p, rings[it]) }

    // A position inside a polygon: its centre when inside, else the middle of the widest stretch across it.
    private fun inside(rings: List<List<DoubleArray>>): DoubleArray {
        val parts = Parts().also { it.polygons += rings }
        val b = boundsOfPolygons(listOf(rings))!!
        val c = centroidOf(parts, b)
        if (c != null && inPolygon(c, rings)) return c
        val tries = ArrayList<Double>()
        tries += c?.get(1) ?: ((b[0][1] + b[1][1]) / 2)
        for (k in 1 until 16) tries += b[0][1] + (b[1][1] - b[0][1]) * (k / 16.0)
        for (y in tries) {
            val xs = ArrayList<Double>()
            for (ring in rings) {
                for (i in 1 until ring.size) {
                    val a = ring[i - 1]; val z = ring[i]
                    if ((a[1] > y) != (z[1] > y)) xs += a[0] + (y - a[1]) / (z[1] - a[1]) * (z[0] - a[0])
                }
            }
            xs.sort()
            var best: DoubleArray? = null
            var j = 0
            while (j + 1 < xs.size) {
                if (best == null || xs[j + 1] - xs[j] > best[1] - best[0]) best = doubleArrayOf(xs[j], xs[j + 1])
                j += 2
            }
            if (best != null && best[1] > best[0]) return doubleArrayOf((best[0] + best[1]) / 2, y)
        }
        return doubleArrayOf(rings[0][0][0], rings[0][0][1])
    }

    fun pointOnFeature(input: JsonElement?): DoubleArray? {
        val parts = partsOf(input)
        if (parts.polygons.isNotEmpty()) {
            var big = parts.polygons[0]
            for (p in parts.polygons) if (polygonArea(p) > polygonArea(big)) big = p
            return inside(big)
        }
        if (parts.lines.isNotEmpty()) {
            var long = parts.lines[0]
            for (l in parts.lines) if (SMapGeo.length(l) > SMapGeo.length(long)) long = l
            return middleOfLine(long)
        }
        return parts.points.firstOrNull()?.let { doubleArrayOf(it[0], it[1]) }
    }

    /** A circle of [metres] around [center], [steps] sides, counter-clockwise, closed: a GeoJSON Polygon. */
    fun circleRing(center: DoubleArray, metres: Double, steps: Int = 64): List<DoubleArray> {
        val n = max(3, steps)
        val d = metres / EARTH_RADIUS
        val lat1 = rad(center[1]); val lng1 = rad(center[0])
        val ring = ArrayList<DoubleArray>(n + 1)
        for (i in 0 until n) {
            val brg = -2 * PI * i / n
            val lat2 = asin(sin(lat1) * cos(d) + cos(lat1) * sin(d) * cos(brg))
            val lng2 = lng1 + atan2(sin(brg) * sin(d) * cos(lat1), cos(d) - sin(lat1) * sin(lat2))
            ring += doubleArrayOf(lng2 * 180 / PI, lat2 * 180 / PI)
        }
        ring += ring[0].copyOf()
        return ring
    }

    fun circle(center: DoubleArray, metres: Double, steps: Int = 64): JsonObject = polygonJson(listOf(circleRing(center, metres, steps)))

    // ---------------------------------------------------------------- union and buffer

    private fun cross2(ax: Double, ay: Double, bx: Double, by: Double) = ax * by - ay * bx

    private fun vkey(p: DoubleArray): String = Math.round(p[0] * KEY_SCALE).toString() + "," + Math.round(p[1] * KEY_SCALE)

    private class Shape(val rings: List<List<DoubleArray>>, val box: DoubleArray)

    private fun shapeOf(rings: List<List<DoubleArray>>): Shape {
        val box = doubleArrayOf(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY)
        for (p in rings[0]) { box[0] = min(box[0], p[0]); box[1] = min(box[1], p[1]); box[2] = max(box[2], p[0]); box[3] = max(box[3], p[1]) }
        return Shape(rings, box)
    }

    private fun inShape(p: DoubleArray, shape: Shape): Boolean {
        val b = shape.box
        if (p[0] < b[0] || p[0] > b[2] || p[1] < b[1] || p[1] > b[3]) return false
        if (!inRing(p, shape.rings[0])) return false
        for (k in 1 until shape.rings.size) if (inRing(p, shape.rings[k])) return false
        return true
    }

    private class RingIn(val pts: List<DoubleArray>, val s: Int, val left: Boolean)
    private class Cut(val t: Double, val p: DoubleArray)
    private class Edge(val a: DoubleArray, val b: DoubleArray, val s: Int, val left: Boolean) {
        val minx = min(a[0], b[0]); val maxx = max(a[0], b[0]); val miny = min(a[1], b[1]); val maxy = max(a[1], b[1])
        val cuts = ArrayList<Cut>()
    }
    private class Piece(val a: DoubleArray, val b: DoubleArray, val s: Int, val left: Boolean)

    private fun splitEdges(rings: List<RingIn>): List<Piece> {
        val edges = ArrayList<Edge>()
        for (ring in rings) {
            val r = ring.pts
            for (i in 1 until r.size) {
                val a = r[i - 1]; val b = r[i]
                if (a[0] == b[0] && a[1] == b[1]) continue
                edges += Edge(a, b, ring.s, ring.left)
            }
        }
        fun param(e: Edge, p: DoubleArray): Double {
            val dx = e.b[0] - e.a[0]; val dy = e.b[1] - e.a[1]
            return ((p[0] - e.a[0]) * dx + (p[1] - e.a[1]) * dy) / (dx * dx + dy * dy)
        }
        fun cut(e: Edge, t: Double, p: DoubleArray) { if (t > 1e-12 && t < 1 - 1e-12) e.cuts += Cut(t, p) }
        fun meet(e: Edge, o: Edge) {
            val rx = e.b[0] - e.a[0]; val ry = e.b[1] - e.a[1]; val sx = o.b[0] - o.a[0]; val sy = o.b[1] - o.a[1]
            val qx = o.a[0] - e.a[0]; val qy = o.a[1] - e.a[1]
            val den = cross2(rx, ry, sx, sy); val lr = sqrt(rx * rx + ry * ry); val ls = sqrt(sx * sx + sy * sy)
            if (abs(den) > 1e-12 * lr * ls) {
                val t = cross2(qx, qy, sx, sy) / den; val u = cross2(qx, qy, rx, ry) / den
                val et = 1e-12
                if (t < -et || t > 1 + et || u < -et || u > 1 + et) return
                // One point for both edges: an end of either when they meet there, else the crossing.
                val p = when {
                    t <= et -> e.a
                    t >= 1 - et -> e.b
                    u <= et -> o.a
                    u >= 1 - et -> o.b
                    else -> doubleArrayOf(e.a[0] + rx * t, e.a[1] + ry * t)
                }
                cut(e, param(e, p), p)
                cut(o, param(o, p), p)
                return
            }
            // Parallel: only edges on one line meet, along their overlap.
            if (abs(cross2(qx, qy, rx, ry)) > 1e-9 * lr * max(1.0, sqrt(qx * qx + qy * qy))) return
            for (p in listOf(o.a, o.b)) cut(e, param(e, p), p)
            for (p in listOf(e.a, e.b)) cut(o, param(o, p), p)
        }
        val order = edges.sortedBy { it.minx }
        var active = ArrayList<Edge>()
        val tol = 1e-9
        for (e in order) {
            active = active.filterTo(ArrayList()) { it.maxx >= e.minx - tol }
            for (o in active) {
                if (o.maxy < e.miny - tol || o.miny > e.maxy + tol) continue
                meet(e, o)
            }
            active += e
        }
        val pieces = ArrayList<Piece>()
        for (e in edges) {
            val pts = ArrayList<DoubleArray>()
            pts += e.a
            e.cuts.sortedBy { it.t }.forEach { pts += it.p }
            pts += e.b
            for (i in 1 until pts.size) pieces += Piece(pts[i - 1], pts[i], e.s, e.left)
        }
        return pieces
    }

    private class Vertex(val p: DoubleArray, val k: String) { val out = ArrayList<Kept>() }
    private class Kept(val from: Vertex, val to: Vertex) { var used = false }
    private class Entry(val a: Vertex, val b: Vertex) { val on = HashMap<Int, Boolean>() }

    private fun traceRegion(shapes: List<Shape>, isIn: ((Int) -> Boolean) -> Boolean): List<List<DoubleArray>> {
        val rings = ArrayList<RingIn>()
        shapes.forEachIndexed { k, sh ->
            sh.rings.forEachIndexed { i, r ->
                val a = planarRingArea(r)
                rings += RingIn(r, k, if (i == 0) a > 0 else a < 0)
            }
        }
        val canon = HashMap<String, Vertex>()
        fun at(p: DoubleArray): Vertex { val key = vkey(p); return canon.getOrPut(key) { Vertex(p, key) } }
        val byKey = HashMap<String, Entry>()
        val list = ArrayList<Entry>()
        for (pc in splitEdges(rings)) {
            val a = at(pc.a); val b = at(pc.b)
            if (a === b) continue
            val forward = a.k < b.k
            val u = if (forward) a.k + "|" + b.k else b.k + "|" + a.k
            val entry = byKey.getOrPut(u) { Entry(if (forward) a else b, if (forward) b else a).also { list += it } }
            // The shape's side, for the edge taken from its lower key to its higher.
            entry.on[pc.s] = if (forward) pc.left else !pc.left
        }
        val kept = ArrayList<Kept>()
        for (en in list) {
            val mid = doubleArrayOf((en.a.p[0] + en.b.p[0]) / 2, (en.a.p[1] + en.b.p[1]) / 2)
            val cache = HashMap<Int, Boolean>()
            fun member(side: Boolean): (Int) -> Boolean = { k ->
                val on = en.on[k]
                if (on != null) (if (side) on else !on) else cache.getOrPut(k) { inShape(mid, shapes[k]) }
            }
            val left = isIn(member(true)); val right = isIn(member(false))
            if (left == right) continue
            // Kept with the inside on its left.
            val e = if (left) Kept(en.a, en.b) else Kept(en.b, en.a)
            e.from.out += e
            kept += e
        }
        val out = ArrayList<List<DoubleArray>>()
        for (start in kept) {
            if (start.used) continue
            val ring = ArrayList<DoubleArray>()
            var e: Kept? = start
            var guard = 0
            while (e != null && !e.used && guard++ < 1_000_000) {
                e.used = true
                ring += e.from.p
                val v = e.to
                val inx = e.to.p[0] - e.from.p[0]; val iny = e.to.p[1] - e.from.p[1]
                // The next edge turns furthest to the left, so rings that only touch stay apart.
                var best: Kept? = null
                var bestA = Double.NEGATIVE_INFINITY
                for (c in v.out) {
                    if (c.used && c !== start) continue
                    val ox = c.to.p[0] - v.p[0]; val oy = c.to.p[1] - v.p[1]
                    val ang = atan2(cross2(inx, iny, ox, oy), inx * ox + iny * oy)
                    if (ang > bestA) { bestA = ang; best = c }
                }
                if (best == null || best === start) break
                e = best
            }
            if (ring.size >= 3) out += tidyRing(ring)
        }
        return out.filter { it.size >= 3 && abs(planarRingArea(it)) > 1e-6 }
    }

    // A ring without the vertices on a straight line between their neighbours (left there by the splitting).
    private fun tidyRing(r: List<DoubleArray>): List<DoubleArray> {
        val out = r.toMutableList()
        var changed = true
        while (changed && out.size > 3) {
            changed = false
            var i = 0
            while (i < out.size && out.size > 3) {
                val a = out[(i + out.size - 1) % out.size]; val b = out[i]; val c = out[(i + 1) % out.size]
                val abx = b[0] - a[0]; val aby = b[1] - a[1]; val bcx = c[0] - b[0]; val bcy = c[1] - b[1]
                val l = sqrt(abx * abx + aby * aby) * sqrt(bcx * bcx + bcy * bcy)
                if (l == 0.0 || (abs(cross2(abx, aby, bcx, bcy)) <= 1e-12 * l && abx * bcx + aby * bcy > 0)) {
                    out.removeAt(i); i--; changed = true
                }
                i++
            }
        }
        return out
    }

    // Rings (open, flat) to polygons: each hole goes into the smallest outer ring around it.
    private fun assemble(rings: List<List<DoubleArray>>): List<List<List<DoubleArray>>> {
        class R(val r: List<DoubleArray>, val a: Double)
        class Poly(val outer: R) { val holes = ArrayList<List<DoubleArray>>() }
        val outers = ArrayList<R>(); val holes = ArrayList<R>()
        for (r in rings) { val a = planarRingArea(r); (if (a > 0) outers else holes) += R(r, abs(a)) }
        val polys = outers.map { Poly(it) }
        for (h in holes) {
            val a = h.r[0]; val b = h.r[1]; val dx = b[0] - a[0]; val dy = b[1] - a[1]
            val len = sqrt(dx * dx + dy * dy).let { if (it == 0.0) 1.0 else it }
            // A point just beside the hole's first edge, on the side of the area around it.
            val eps = max(1e-7, min(1e-3, len * 0.01))
            val p = doubleArrayOf((a[0] + b[0]) / 2 - dy / len * eps, (a[1] + b[1]) / 2 + dx / len * eps)
            var home: Poly? = null
            for (pg in polys) if (inRing(p, pg.outer.r) && (home == null || pg.outer.a < home.outer.a)) home = pg
            home?.holes?.add(h.r)
        }
        return polys.map { listOf(it.outer.r) + it.holes }
    }

    private fun round10(v: Double): Double {
        val r = (v * 1e10).roundToLong() / 1e10
        return if (r == 0.0) 0.0 else r
    }

    // Flat polygons back to a GeoJSON geometry, or null when nothing is left.
    private fun toGeometry(polys: List<List<List<DoubleArray>>>, p: Flat): JsonObject? {
        if (polys.isEmpty()) return null
        val out = polys.map { rings ->
            rings.map { r ->
                val ring = r.map { c -> p.from(c).let { q -> doubleArrayOf(round10(q[0]), round10(q[1])) } }.toMutableList()
                ring += ring[0].copyOf()
                ring
            }
        }
        return if (out.size == 1) polygonJson(out[0]) else JsonObject().apply {
            addProperty("type", "MultiPolygon")
            add("coordinates", JsonArray().also { a -> out.forEach { a.add(ringsJson(it)) } })
        }
    }

    fun union(inputs: List<JsonElement?>): JsonObject? {
        val polys = ArrayList<List<List<DoubleArray>>>()
        for (i in inputs) polys += partsOf(i).polygons
        if (polys.isEmpty()) return null
        val p = Flat(middleOfBounds(boundsOfPolygons(polys)!!))
        val shapes = polys.map { rings -> shapeOf(rings.map { r -> r.map(p::to) }) }
        val isIn = { member: (Int) -> Boolean -> shapes.indices.any { member(it) } }
        return toGeometry(assemble(traceRegion(shapes, isIn)), p)
    }

    // A flat stadium: the points within r of the segment a-b, as a closed ring of half circles of [steps] each.
    private fun stadium(a: DoubleArray, b: DoubleArray, r: Double, steps: Int): List<DoubleArray> {
        val ang = atan2(b[1] - a[1], b[0] - a[0])
        val ring = ArrayList<DoubleArray>()
        fun arc(c: DoubleArray, from: Double) {
            for (i in 0..steps) { val t = from + PI * i / steps; ring += doubleArrayOf(c[0] + r * cos(t), c[1] + r * sin(t)) }
        }
        arc(b, ang - PI / 2)
        arc(a, ang + PI / 2)
        ring += ring[0].copyOf()
        return ring
    }

    private fun flatCircle(c: DoubleArray, r: Double, steps: Int): List<DoubleArray> {
        val ring = ArrayList<DoubleArray>()
        for (i in 0 until steps) { val t = 2 * PI * i / steps; ring += doubleArrayOf(c[0] + r * cos(t), c[1] + r * sin(t)) }
        ring += ring[0].copyOf()
        return ring
    }

    fun buffer(input: JsonElement?, metres: Double, stepsOption: Int = 8): JsonObject? {
        val r = if (metres.isNaN()) 0.0 else metres
        val steps = max(2, stepsOption) * 2
        val parts = partsOf(input)
        val b = bounds(input) ?: return null
        val p = Flat(middleOfBounds(b))
        val polys = parts.polygons.map { rings -> shapeOf(rings.map { ring -> ring.map(p::to) }) }
        if (r == 0.0) return if (polys.isNotEmpty()) union(listOf(input)) else null
        val reach = abs(r)
        val around = ArrayList<Shape>()
        for (pt in parts.points) around += shapeOf(listOf(flatCircle(p.to(pt), reach, steps * 2)))
        for (l in parts.lines) {
            val pts = l.map(p::to)
            if (pts.size == 1) around += shapeOf(listOf(flatCircle(pts[0], reach, steps * 2)))
            for (i in 1 until pts.size) if (pts[i][0] != pts[i - 1][0] || pts[i][1] != pts[i - 1][1]) around += shapeOf(listOf(stadium(pts[i - 1], pts[i], reach, steps)))
        }
        val edges = ArrayList<Shape>()
        for (s in polys) for (ring in s.rings) for (i in 1 until ring.size) {
            if (ring[i][0] != ring[i - 1][0] || ring[i][1] != ring[i - 1][1]) edges += shapeOf(listOf(stadium(ring[i - 1], ring[i], reach, steps)))
        }
        val shapes: List<Shape>
        val isIn: ((Int) -> Boolean) -> Boolean
        if (r > 0) {
            shapes = polys + around + edges
            isIn = { member -> shapes.indices.any { member(it) } }
        } else {
            // Shrinking: the areas less the band along their edges (points and lines have no inside to shrink).
            shapes = polys + edges
            val n = polys.size
            isIn = { member -> (0 until n).any { member(it) } && (n until shapes.size).none { member(it) } }
        }
        return toGeometry(assemble(traceRegion(shapes, isIn)), p)
    }

    // ---------------------------------------------------------------- simplify, self-intersection

    // Douglas-Peucker on flat points: the indexes kept.
    private fun dp(pts: List<DoubleArray>, tol: Double): BooleanArray {
        val keep = BooleanArray(pts.size)
        keep[0] = true; keep[pts.size - 1] = true
        val stack = ArrayDeque<IntArray>()
        stack.addLast(intArrayOf(0, pts.size - 1))
        while (stack.isNotEmpty()) {
            val s = stack.removeLast()
            val a = pts[s[0]]; val b = pts[s[1]]
            var far = -1; var farD = tol
            for (i in s[0] + 1 until s[1]) {
                val q = pts[i]; val dx = b[0] - a[0]; val dy = b[1] - a[1]; val l2 = dx * dx + dy * dy
                val t = if (l2 != 0.0) max(0.0, min(1.0, ((q[0] - a[0]) * dx + (q[1] - a[1]) * dy) / l2)) else 0.0
                val ex = a[0] + t * dx - q[0]; val ey = a[1] + t * dy - q[1]; val d = sqrt(ex * ex + ey * ey)
                if (d > farD) { farD = d; far = i }
            }
            if (far >= 0) { keep[far] = true; stack.addLast(intArrayOf(s[0], far)); stack.addLast(intArrayOf(far, s[1])) }
        }
        return keep
    }

    fun simplify(input: JsonElement?, metres: Double): JsonElement? {
        if (input == null) return null
        val tol = max(0.0, if (metres.isNaN()) 0.0 else metres)
        val b = bounds(input) ?: return input.deepCopy()
        val p = Flat(middleOfBounds(b))
        fun line(a: JsonArray): JsonArray {
            if (a.size() <= 2) return a.deepCopy()
            val l = a.map(::pos)
            val keep = dp(l.map(p::to), tol)
            return JsonArray().also { out -> a.forEachIndexed { i, c -> if (keep[i]) out.add(c.deepCopy()) } }
        }
        fun ring(a: JsonArray): JsonArray {
            if (a.size() <= 4) return a.deepCopy()
            // A closed ring is split at its farthest vertex from the first, so both halves have two fixed ends.
            val pts = a.map(::pos).map(p::to)
            var far = 1; var farD = -1.0
            for (i in 1 until pts.size - 1) {
                val d = (pts[i][0] - pts[0][0]) * (pts[i][0] - pts[0][0]) + (pts[i][1] - pts[0][1]) * (pts[i][1] - pts[0][1])
                if (d > farD) { farD = d; far = i }
            }
            val k1 = dp(pts.subList(0, far + 1), tol); val k2 = dp(pts.subList(far, pts.size), tol)
            val out = JsonArray()
            a.forEachIndexed { i, c -> if (if (i <= far) k1[i] else k2[i - far]) out.add(c.deepCopy()) }
            return if (out.size() >= 4) out else a.deepCopy()
        }
        fun geometry(g: JsonElement?): JsonElement? {
            if (g == null || !g.isJsonObject) return g?.deepCopy()
            val o = g.asJsonObject
            val c = o.get("coordinates")?.takeIf { it.isJsonArray }?.asJsonArray
            val type = o.get("type")?.asString
            fun of(coords: JsonArray) = JsonObject().apply { addProperty("type", type); add("coordinates", coords) }
            return when (type) {
                "LineString" -> of(line(c!!))
                "MultiLineString" -> of(JsonArray().also { a -> c!!.forEach { a.add(line(it.asJsonArray)) } })
                "Polygon" -> of(JsonArray().also { a -> c!!.forEach { a.add(ring(it.asJsonArray)) } })
                "MultiPolygon" -> of(JsonArray().also { a -> c!!.forEach { poly -> a.add(JsonArray().also { pa -> poly.asJsonArray.forEach { pa.add(ring(it.asJsonArray)) } }) } })
                "GeometryCollection" -> JsonObject().apply {
                    addProperty("type", type)
                    add("geometries", JsonArray().also { a -> o.getAsJsonArray("geometries").forEach { a.add(geometry(it)) } })
                }
                else -> o.deepCopy()
            }
        }
        fun any(v: JsonElement): JsonElement? {
            if (!v.isJsonObject) return v.deepCopy()
            val o = v.asJsonObject
            return when (o.get("type")?.asString) {
                "FeatureCollection" -> o.deepCopy().also { c -> c.add("features", JsonArray().also { a -> o.getAsJsonArray("features").forEach { a.add(any(it)) } }) }
                "Feature" -> o.deepCopy().also { c -> c.add("geometry", geometry(o.get("geometry")) ?: JsonNull.INSTANCE) }
                else -> geometry(o)
            }
        }
        return any(input)
    }

    // Whether two segments touch or cross.
    private fun segmentsMeet(a: DoubleArray, b: DoubleArray, c: DoubleArray, d: DoubleArray): Boolean {
        fun o(p: DoubleArray, q: DoubleArray, r: DoubleArray): Int {
            val v = (q[1] - p[1]) * (r[0] - q[0]) - (q[0] - p[0]) * (r[1] - q[1])
            return if (abs(v) < 1e-18) 0 else if (v > 0) 1 else 2
        }
        fun on(p: DoubleArray, q: DoubleArray, r: DoubleArray) =
            q[0] <= max(p[0], r[0]) && q[0] >= min(p[0], r[0]) && q[1] <= max(p[1], r[1]) && q[1] >= min(p[1], r[1])
        val o1 = o(a, b, c); val o2 = o(a, b, d); val o3 = o(c, d, a); val o4 = o(c, d, b)
        if (o1 != o2 && o3 != o4) return true
        return (o1 == 0 && on(a, c, b)) || (o2 == 0 && on(a, d, b)) || (o3 == 0 && on(c, a, d)) || (o4 == 0 && on(c, b, d))
    }

    private class Chain(val pts: List<DoubleArray>, val closed: Boolean)
    private class SEdge(val c: Int, val i: Int, val n: Int, val closed: Boolean, val a: DoubleArray, val b: DoubleArray) {
        val minx = min(a[0], b[0]); val maxx = max(a[0], b[0])
    }

    private fun check(chains: List<Chain>): Boolean {
        val edges = ArrayList<SEdge>()
        chains.forEachIndexed { ci, ch ->
            val pts = ch.pts; val n = pts.size - 1
            for (i in 0 until n) {
                if (pts[i][0] == pts[i + 1][0] && pts[i][1] == pts[i + 1][1]) continue
                edges += SEdge(ci, i, n, ch.closed, pts[i], pts[i + 1])
            }
        }
        edges.sortBy { it.minx }
        var active = ArrayList<SEdge>()
        for (e in edges) {
            active = active.filterTo(ArrayList()) { it.maxx >= e.minx }
            for (o in active) {
                if (o.c == e.c) {
                    val d = abs(o.i - e.i)
                    if (d == 1 || (e.closed && d == e.n - 1)) continue
                }
                if (segmentsMeet(e.a, e.b, o.a, o.b)) return true
            }
            active += e
        }
        return false
    }

    fun selfIntersects(input: JsonElement?): Boolean {
        val parts = partsOf(input)
        if (parts.lines.any { l -> check(listOf(Chain(l, l.size > 3 && l[0][0] == l[l.size - 1][0] && l[0][1] == l[l.size - 1][1]))) }) return true
        return parts.polygons.any { rings -> check(rings.map { Chain(it, true) }) }
    }

    /** Whether the open ring [ring] (an area being drawn, without its closing position) crosses itself. */
    fun ringCrosses(rings: List<List<DoubleArray>>): Boolean = check(rings.map { Chain(closedRing(it), true) })

    /** Whether the line [line] crosses or touches itself. */
    fun lineCrosses(line: List<DoubleArray>): Boolean = check(listOf(Chain(line, false)))

    // ---------------------------------------------------------------- JSON

    private fun position(c: DoubleArray) = JsonArray().apply { add(c[0]); add(c[1]) }
    private fun ringsJson(rings: List<List<DoubleArray>>) = JsonArray().also { a -> rings.forEach { r -> a.add(JsonArray().also { ra -> r.forEach { ra.add(position(it)) } }) } }
    fun polygonJson(rings: List<List<DoubleArray>>) = JsonObject().apply { addProperty("type", "Polygon"); add("coordinates", ringsJson(rings)) }
}
