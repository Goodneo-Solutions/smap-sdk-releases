package ca.superroute.smap

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Chooses the node the map reads from. The node list (`GET /v1/nodes`) is asked of [baseUrl] first, then of every
 * other known node in turn (the kept list, then [seeds]); the first answer wins and is kept for [listTtlMillis].
 * Each listed node is timed with `GET {node}/v1/ping` (204) and the fastest that answers within [pingTimeoutMillis]
 * comes first; that order is remembered for [ttlMillis]. When no node list can be read, the known nodes (kept list
 * and [seeds]) are measured instead, and [baseUrl] alone is used only when no node is known. A node that fails a
 * request is moved to the end with [demote].
 *
 * @param seeds node URLs known in advance, so a first start works while [baseUrl] is down
 * @param clock wall-clock milliseconds (for the remembered order's age)
 * @param monotonic monotonic milliseconds (for timing pings)
 */
class SMapNodePicker(
    baseUrl: String,
    private val http: SMapHttp,
    private val store: SMapStore,
    private val nearest: Boolean = true,
    private val clock: () -> Long = System::currentTimeMillis,
    private val monotonic: () -> Long = { System.nanoTime() / 1_000_000 },
    private val pingTimeoutMillis: Long = PING_TIMEOUT_MILLIS,
    private val listTimeoutMillis: Long = LIST_TIMEOUT_MILLIS,
    private val ttlMillis: Long = TTL_MILLIS,
    seeds: List<String> = emptyList(),
    private val listTtlMillis: Long = LIST_TTL_MILLIS,
) {
    val baseUrl: String = trimSlash(baseUrl)

    private val seeds: List<String> = seeds.map(::trimSlash).filter { it.isNotEmpty() }.distinct()
    private val key = "smap.nodes:" + this.baseUrl
    private val listKey = "smap.nodelist:" + this.baseUrl
    private val mutex = Mutex()

    init {
        // Identity headers go to node hosts only: these, and every node a list names (added as lists are read).
        SMapNodeHosts.add(listOf(this.baseUrl) + this.seeds)
    }

    @Volatile
    private var order: List<String>? = null

    /** The node tried first, once [nodes] has run; otherwise null. */
    val current: String? get() = order?.firstOrNull()

    /** The nodes in the order they are tried: nearest first. */
    suspend fun nodes(): List<String> {
        order?.let { return it }
        return mutex.withLock {
            order ?: pick().also { order = it }
        }
    }

    /** Moves [url] to the end of the order (after it failed a request) and remembers the new order. */
    @Synchronized
    fun demote(url: String) {
        val now = order ?: return
        if (now.size < 2 || url !in now) return
        val next = now.filter { it != url } + url
        order = next
        save(key, next)
    }

    /** Forgets the order, so the next call to [nodes] measures again. */
    @Synchronized
    fun reset() {
        order = null
        store.put(key, null)
    }

    private suspend fun pick(): List<String> {
        if (!nearest) return listOf(baseUrl)
        load(key, ttlMillis)?.let { return it }
        val kept = load(listKey, listTtlMillis).orEmpty()
        SMapNodeHosts.add(kept)
        val known = (kept + seeds).distinct().filter { it != baseUrl }
        val read = readList(listOf(baseUrl) + known)
        if (read != null) save(listKey, read)
        val urls = read ?: known
        if (urls.isEmpty()) return listOf(baseUrl) // nothing known: not remembered, the next start asks again
        val timed = coroutineScope {
            urls.map { url -> async { url to ping(url) } }.awaitAll()
        }
        val answered = timed.filter { it.second != null }.sortedBy { it.second!! }.map { it.first }
        val silent = timed.filter { it.second == null }.map { it.first }
        if (answered.isEmpty()) return listOf(baseUrl) + silent.filter { it != baseUrl } // not remembered
        val result = (answered + silent).toMutableList()
        if (baseUrl !in result) result.add(baseUrl)
        // Remembered for the hour only when a node list was read; an order guessed from known nodes is measured again
        // at the next start (which may have seeds, or find baseUrl back).
        if (read != null) save(key, result)
        return result
    }

    /** The node list from the first of [sources] that answers one; null when none does. */
    private suspend fun readList(sources: List<String>): List<String>? {
        for (source in sources) {
            val urls = try {
                val response = withTimeoutOrNull(listTimeoutMillis) { http.get("$source/v1/nodes", listTimeoutMillis) }
                if (response == null || !response.ok) null else parseNodes(response.body)
            } catch (e: Exception) {
                null
            }
            if (!urls.isNullOrEmpty()) {
                SMapNodeHosts.add(urls)
                return urls
            }
        }
        return null
    }

    /** Milliseconds the ping took, or null when it failed or took longer than the timeout. */
    private suspend fun ping(url: String): Long? {
        val start = monotonic()
        return try {
            val response = withTimeoutOrNull(pingTimeoutMillis) { http.get("$url/v1/ping", pingTimeoutMillis) }
            if (response != null && response.ok) monotonic() - start else null
        } catch (e: Exception) {
            null
        }
    }

    private fun load(key: String, ttl: Long): List<String>? = try {
        val text = store.get(key) ?: return null
        val obj = JsonParser.parseString(text).asJsonObject
        val at = obj.get("at").asLong
        val urls = obj.getAsJsonArray("urls").map { it.asString }
        if (urls.isNotEmpty() && clock() - at in 0 until ttl) urls else null
    } catch (e: Exception) {
        null
    }

    private fun save(key: String, urls: List<String>) {
        val obj = JsonObject()
        obj.add("urls", JsonArray().apply { urls.forEach { add(it) } })
        obj.addProperty("at", clock())
        try {
            store.put(key, obj.toString())
        } catch (e: Exception) {
            // storage unavailable: the order lives for this session only
        }
    }

    companion object {
        const val PING_TIMEOUT_MILLIS = 1500L
        const val LIST_TIMEOUT_MILLIS = 2000L
        const val TTL_MILLIS = 3600_000L
        const val LIST_TTL_MILLIS = 30L * 24 * 3600_000L

        internal fun trimSlash(url: String): String = url.trimEnd('/')

        /** The node URLs of a `/v1/nodes` answer, without trailing slashes. */
        internal fun parseNodes(body: String): List<String> {
            val nodes = JsonParser.parseString(body).asJsonObject.getAsJsonArray("nodes") ?: return emptyList()
            return nodes.mapNotNull { n ->
                val url = n.asJsonObject.get("url")
                if (url == null || url.isJsonNull) null else trimSlash(url.asString)
            }.filter { it.isNotEmpty() }
        }
    }
}
