package ca.superroute.smap

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.JsonPrimitive
import java.math.BigDecimal

/**
 * JSON helpers shared by the style, format and layer-description code: parsing, the canonical form every SDK compares
 * with (sorted keys, numbers as the shortest round-trip, written as JavaScript writes them), and the plain Java values
 * the rendering engine takes for a Style Spec value.
 */
object SMapJson {

    /** Parses [text]; throws [IllegalArgumentException] when it is not JSON. */
    fun parse(text: String): JsonElement = try {
        JsonParser.parseString(text)
    } catch (e: Exception) {
        throw IllegalArgumentException("sMap: not valid JSON: ${e.message}", e)
    }

    /** Parses [text] as a JSON object; throws [IllegalArgumentException] otherwise. */
    fun parseObject(text: String): JsonObject {
        val e = parse(text)
        if (!e.isJsonObject) throw IllegalArgumentException("sMap: a JSON object is expected")
        return e.asJsonObject
    }

    /**
     * The canonical serialisation: object keys sorted (by UTF-16 code units, as JavaScript sorts them), no white
     * space, numbers as the shortest text that reads back to the same double, in JavaScript's notation.
     */
    fun canonical(e: JsonElement?): String = StringBuilder().also { write(it, e, true) }.toString()

    /** `JSON.stringify` as JavaScript writes it: keys in their order, no white space, JavaScript number notation. */
    fun stringify(e: JsonElement?): String = StringBuilder().also { write(it, e, false) }.toString()

    private fun write(sb: StringBuilder, e: JsonElement?, sorted: Boolean) {
        when {
            e == null || e.isJsonNull -> sb.append("null")
            e.isJsonObject -> {
                sb.append('{')
                var first = true
                val keys = e.asJsonObject.keySet()
                for (key in if (sorted) keys.sorted() else keys) {
                    if (!first) sb.append(',')
                    first = false
                    string(sb, key)
                    sb.append(':')
                    write(sb, e.asJsonObject.get(key), sorted)
                }
                sb.append('}')
            }
            e.isJsonArray -> {
                sb.append('[')
                e.asJsonArray.forEachIndexed { i, v -> if (i > 0) sb.append(','); write(sb, v, sorted) }
                sb.append(']')
            }
            else -> {
                val p = e.asJsonPrimitive
                when {
                    p.isBoolean -> sb.append(p.asBoolean)
                    p.isNumber -> sb.append(number(p.asDouble))
                    else -> string(sb, p.asString)
                }
            }
        }
    }

    private fun string(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c)
            }
        }
        sb.append('"')
    }

    /**
     * A number as JavaScript's `Number.prototype.toString` writes it: the shortest round-trip digits, plain notation
     * from 1e-7 (exclusive) up to 1e21 (exclusive), exponent notation (`1e-7`, `1.5e+21`) outside.
     */
    fun number(value: Double): String {
        if (value.isNaN() || value.isInfinite()) return "null"
        if (value == 0.0) return "0"
        val bd = shortest(value)
        val negative = bd.signum() < 0
        val digits = bd.unscaledValue().abs().toString()
        val k = digits.length
        val n = k - bd.scale() // decimal point position: value = 0.digits × 10^n
        val sb = StringBuilder()
        if (negative) sb.append('-')
        when {
            n in k..21 -> sb.append(digits).append("0".repeat(n - k))
            n in 1..21 -> sb.append(digits, 0, n).append('.').append(digits, n, k)
            n in -5..0 -> sb.append("0.").append("0".repeat(-n)).append(digits)
            else -> {
                val e = n - 1
                sb.append(digits[0])
                if (k > 1) sb.append('.').append(digits, 1, k)
                sb.append('e').append(if (e >= 0) "+" else "-").append(kotlin.math.abs(e))
            }
        }
        return sb.toString()
    }

    /** The fewest significant digits that read back to [value] (the nearest such decimal), whatever the JDK. */
    private fun shortest(value: Double): BigDecimal {
        val exact = BigDecimal(value)
        for (p in 1..17) {
            val d = exact.round(java.math.MathContext(p, java.math.RoundingMode.HALF_EVEN))
            if (d.toDouble() == value) return d.stripTrailingZeros()
        }
        return exact.stripTrailingZeros()
    }

    /**
     * A Style Spec value as the plain Java values the rendering engine converts itself: numbers as [Double], arrays as
     * `Object[]` (expressions and literal arrays alike; the engine tells them apart), objects as [HashMap].
     */
    fun toEngine(e: JsonElement?): Any? = when {
        e == null || e.isJsonNull -> null
        e.isJsonArray -> e.asJsonArray.map { toEngine(it) }.toTypedArray()
        e.isJsonObject -> HashMap<String, Any?>().also { m -> e.asJsonObject.entrySet().forEach { (k, v) -> m[k] = toEngine(v) } }
        else -> {
            val p = e.asJsonPrimitive
            when {
                p.isBoolean -> p.asBoolean
                p.isNumber -> p.asDouble
                else -> p.asString
            }
        }
    }

    /** A plain Kotlin value (string, number, boolean, list, map, null, or a [JsonElement]) as JSON. */
    fun of(value: Any?): JsonElement = when (value) {
        null -> JsonNull.INSTANCE
        is JsonElement -> value
        is String -> JsonPrimitive(value)
        is Number -> JsonPrimitive(value)
        is Boolean -> JsonPrimitive(value)
        is Char -> JsonPrimitive(value.toString())
        is Map<*, *> -> JsonObject().also { o -> value.forEach { (k, v) -> o.add(k.toString(), of(v)) } }
        is Iterable<*> -> JsonArray().also { a -> value.forEach { a.add(of(it)) } }
        is Array<*> -> JsonArray().also { a -> value.forEach { a.add(of(it)) } }
        is FloatArray -> JsonArray().also { a -> value.forEach { a.add(it) } }
        is DoubleArray -> JsonArray().also { a -> value.forEach { a.add(it) } }
        is IntArray -> JsonArray().also { a -> value.forEach { a.add(it) } }
        else -> throw IllegalArgumentException("sMap: ${value.javaClass.name} is not a JSON value")
    }

    /** `{"a":1}`-style helper for building objects. */
    fun obj(vararg pairs: Pair<String, Any?>): JsonObject =
        JsonObject().also { o -> pairs.forEach { (k, v) -> if (v != null) o.add(k, of(v)) } }

    fun arr(vararg values: Any?): JsonArray = JsonArray().also { a -> values.forEach { a.add(of(it)) } }

    internal fun JsonObject.str(key: String): String? =
        get(key)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString

    internal fun JsonObject.num(key: String): Double? =
        get(key)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble

    internal fun JsonObject.bool(key: String): Boolean? =
        get(key)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean }?.asBoolean

    internal fun JsonObject.objOrNull(key: String): JsonObject? = get(key)?.takeIf { it.isJsonObject }?.asJsonObject

    internal fun JsonObject.arrOrNull(key: String): JsonArray? = get(key)?.takeIf { it.isJsonArray }?.asJsonArray
}
