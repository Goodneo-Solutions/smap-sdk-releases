package ca.superroute.smap

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.Point

/**
 * The engine expressions of a layer's style values (G20) and states (G21), as Style Spec JSON: a constant stays a
 * literal, a property is read with its default, a closure is worked out per feature on the device and read from the
 * hidden property `__smap_fn<n>` of the engine's copy of the data ([fns] in the order made). The looks of [states]
 * apply while the feature's state value is true; a state named later wins.
 */
internal class SMapStyleBuild(private val stateNames: List<String> = emptyList()) {
    /** The closures of this layer, `__smap_fn<index>` in the engine's data. */
    val fns = ArrayList<(Map<String, Any?>) -> Any?>()

    private fun fn(read: (Map<String, Any?>) -> Any?): JsonElement {
        fns += read
        return SMapJson.arr("get", SMapEngineData.FN + (fns.size - 1))
    }

    /** A colour per feature, else [base] (a literal or an expression, e.g. the simplestyle one). */
    fun color(v: SMapFeatureValue<String>?, base: JsonElement): JsonElement = when (v) {
        null -> base
        is SMapFeatureValue.Const -> JsonPrimitive(v.value)
        is SMapFeatureValue.Property -> SMapJson.arr("to-color", SMapJson.arr("get", v.name), v.default?.let(::JsonPrimitive) ?: base)
        is SMapFeatureValue.Of -> SMapJson.arr("to-color", fn { p -> v.read(p) }, base)
    }

    /** A number per feature, else [base]. */
    fun number(v: SMapFeatureValue<Number>?, base: JsonElement): JsonElement = when (v) {
        null -> base
        is SMapFeatureValue.Const -> JsonPrimitive(v.value)
        is SMapFeatureValue.Property -> {
            val d = v.default?.let { JsonPrimitive(it) } ?: base
            SMapJson.arr("to-number", SMapJson.arr("coalesce", SMapJson.arr("get", v.name), d), d)
        }
        is SMapFeatureValue.Of -> SMapJson.arr("to-number", SMapJson.arr("coalesce", fn { p -> v.read(p) }, base), base)
    }

    /**
     * Dashes `[dash, gap, …]` in line widths: a constant, or per feature (a feature without one is solid); null when
     * the line is solid.
     */
    fun dash(v: SMapFeatureValue<List<Float>>?, constant: List<Float>?): JsonElement? {
        val solid = SMapJson.arr("literal", SMapJson.arr(1, 0))
        return when (v) {
            null -> constant?.let { SMapJson.arr("literal", SMapJson.of(it)) }
            is SMapFeatureValue.Const -> SMapJson.arr("literal", SMapJson.of(v.value))
            is SMapFeatureValue.Property -> SMapJson.arr("array", "number", SMapJson.arr("coalesce", SMapJson.arr("get", v.name),
                v.default?.let { SMapJson.arr("literal", SMapJson.of(it)) } ?: solid))
            is SMapFeatureValue.Of -> SMapJson.arr("array", "number", SMapJson.arr("coalesce", fn { p -> v.read(p) }, solid))
        }
    }

    /**
     * The reader of a per-feature dash (a property or a closure), or null for a constant one. The native engine draws
     * no dash that differs per feature, so such a layer is drawn as one engine layer per pattern (see [SMapDashSplit]).
     */
    fun dashReader(v: SMapFeatureValue<List<Float>>?): ((Map<String, Any?>) -> List<Float>?)? = when (v) {
        null, is SMapFeatureValue.Const -> null
        is SMapFeatureValue.Property -> { p -> SMapDashSplit.floats(p[v.name]) ?: v.default }
        is SMapFeatureValue.Of -> { p -> v.read(p) }
    }

    /** A hidden property holding the place of each feature's dash in [patterns] (absent: solid). */
    fun dashIndex(reader: (Map<String, Any?>) -> List<Float>?, patterns: List<List<Float>>): JsonElement =
        fn { p -> reader(p)?.let { d -> patterns.indexOf(d).takeIf { it >= 0 } } }

    companion object {
        /** The engine's sort key of a label priority (G34): a higher priority is placed first (a lower key). */
        fun priorityKey(priority: JsonElement): JsonElement = SMapJson.arr("*", -1, priority)
    }

    /** A property ordering features: a higher value draws on top. */
    fun sortKey(property: String): JsonElement = SMapJson.arr("to-number", SMapJson.arr("coalesce", SMapJson.arr("get", property), 0), 0)

    /**
     * [base], or the look of each state (in [picks], the value each state's look gives, null = none) while the
     * feature has that state; a state named later wins.
     */
    fun stated(base: JsonElement, picks: List<Any?>): JsonElement {
        val cases = JsonArray().apply { add("case") }
        for (i in stateNames.indices.reversed()) {
            val v = picks.getOrNull(i) ?: continue
            cases.add(SMapJson.arr("boolean", SMapJson.arr("feature-state", stateNames[i]), false))
            cases.add(SMapJson.of(v))
        }
        if (cases.size() == 1) return base
        cases.add(base)
        return cases
    }
}

/**
 * The engine's copy of a drawn layer's data (G19–G23): every feature carries its key as the engine's feature id (so
 * states, hits and moves find it) and the value of each style closure as a hidden property.
 */
internal object SMapEngineData {
    const val HIDDEN = "__smap_"
    const val FN = "__smap_fn"

    /** A key as text: a whole number without its decimals (`7`, never `7.0`), as the Web SDK's String(value). */
    fun keyText(v: Any?): String? = when (v) {
        null -> null
        is JsonNull -> null
        is JsonPrimitive -> if (v.isNumber) keyText(v.asNumber) else v.asString
        is JsonElement -> v.toString()
        is Double -> if (v.isFinite() && v == Math.floor(v) && kotlin.math.abs(v) < 1e15) v.toLong().toString() else v.toString()
        is Float -> keyText(v.toDouble())
        is Number -> {
            val d = v.toDouble()
            if (d == Math.floor(d) && kotlin.math.abs(d) < 1e15) d.toLong().toString() else v.toString()
        }
        else -> v.toString()
    }

    /** A feature's key: the [idProperty] value, else its own id, else `#<index>`. */
    fun keyOf(f: Feature, index: Int, idProperty: String?): String {
        val p = idProperty?.let { name -> f.properties()?.get(name)?.takeIf { !it.isJsonNull }?.let(::keyText) }
        return p ?: f.id() ?: "#$index"
    }

    /** Key → place in the data (the first feature with a key wins). */
    fun keys(data: FeatureCollection, idProperty: String?): HashMap<String, Int> {
        val out = HashMap<String, Int>()
        data.features()?.forEachIndexed { i, f -> out.putIfAbsent(keyOf(f, i, idProperty), i) }
        return out
    }

    /** One feature as the engine gets it: its key as id, the closures' values as hidden properties. */
    fun engineFeature(f: Feature, key: String, fns: List<(Map<String, Any?>) -> Any?>, geometry: org.maplibre.geojson.Geometry? = null): Feature {
        val props = if (fns.isEmpty()) f.properties() else {
            val user = SMapGeoJson.propertiesOf(f)
            val copy = JsonObject()
            f.properties()?.entrySet()?.forEach { (k, v) -> copy.add(k, v) }
            fns.forEachIndexed { n, read ->
                val value = try { read(user) } catch (e: Exception) { null }
                if (value != null) copy.add(FN + n, SMapJson.of(value))
            }
            copy
        }
        return Feature.fromGeometry(geometry ?: f.geometry(), props, key)
    }

    /** The engine's copy of [data], leaving out the features whose keys are in [skip] (those drawn while moving). */
    fun build(data: FeatureCollection, idProperty: String?, fns: List<(Map<String, Any?>) -> Any?>, skip: Set<String> = emptySet()): FeatureCollection {
        val out = ArrayList<Feature>(data.features()?.size ?: 0)
        data.features()?.forEachIndexed { i, f ->
            val key = keyOf(f, i, idProperty)
            if (key !in skip) out += engineFeature(f, key, fns)
        }
        return FeatureCollection.fromFeatures(out)
    }

    /** A feature's properties without the SDK's hidden ones. */
    fun userProperties(f: Feature): Map<String, Any?> = SMapGeoJson.propertiesOf(f).filterKeys { !it.startsWith(HIDDEN) }

    /**
     * [properties] merged into a feature's own (a null value removes the property; [idProperty] is never changed),
     * as a new feature with the same geometry and id.
     */
    fun merged(f: Feature, properties: Map<String, Any?>, idProperty: String?): Feature {
        val p = f.properties()?.deepCopy() ?: JsonObject()
        for ((k, v) in properties) {
            if (k == idProperty) continue
            if (v == null) p.remove(k) else p.add(k, SMapJson.of(v))
        }
        return Feature.fromGeometry(f.geometry(), p, f.id())
    }

    /** A copy of [f] at [lngLat] (properties and id kept). */
    fun moved(f: Feature, lngLat: DoubleArray): Feature =
        Feature.fromGeometry(Point.fromLngLat(lngLat[0], lngLat[1]), f.properties(), f.id())
}

/**
 * Features on their way (G23): each moves in a straight line (longitude and latitude eased) from where it was when
 * the move was asked for; a feature stays in the set until it has been still for [lingerMillis], so a feed moving it
 * every second keeps it here.
 */
internal class SMapMoves(private val lingerMillis: Long = 1000) {
    class Move(val from: DoubleArray, val to: DoubleArray, val durationMillis: Long, val easing: ((Float) -> Float)?) {
        var start: Long? = null
    }

    class Entry(var at: DoubleArray) {
        var move: Move? = null
        var stillSince = 0L
    }

    /** Layer → key → entry, in the order the features started moving. */
    val layers = LinkedHashMap<String, LinkedHashMap<String, Entry>>()

    fun keys(layer: String): Set<String> = layers[layer]?.keys ?: emptySet()

    fun isMoving(layer: String, key: String): Boolean = layers[layer]?.containsKey(key) == true

    /**
     * Starts a move of [key] from [from] (where it is now) to [to]; [durationMillis] 0 puts it there at once.
     * @return true when the feature was not in the set before
     */
    fun start(layer: String, key: String, from: DoubleArray, to: DoubleArray, durationMillis: Long, easing: ((Float) -> Float)?, now: Long): Boolean {
        val keys = layers.getOrPut(layer) { LinkedHashMap() }
        val entry = keys[key]
        val fresh = entry == null
        val e = entry ?: Entry(from).also { keys[key] = it }
        if (durationMillis <= 0) {
            e.at = to.copyOf()
            e.move = null
            e.stillSince = now
        } else {
            e.move = Move(e.at.copyOf().takeIf { !fresh } ?: from.copyOf(), to.copyOf(), durationMillis, easing)
        }
        return fresh
    }

    /** Where a move is at [now]; true in the second value when it has arrived. */
    fun step(e: Entry, now: Long): Boolean {
        val m = e.move ?: return true
        val start = m.start ?: now.also { m.start = it }
        val t = ((now - start).toFloat() / m.durationMillis).coerceIn(0f, 1f)
        val k = (m.easing?.invoke(t) ?: t).toDouble()
        e.at = doubleArrayOf(m.from[0] + (m.to[0] - m.from[0]) * k, m.from[1] + (m.to[1] - m.from[1]) * k)
        if (t >= 1f) {
            e.at = m.to.copyOf()
            e.move = null
            e.stillSince = now
            return true
        }
        return false
    }

    /** The keys of [layer] still for [lingerMillis] at [now], taken out of the set. */
    fun settle(layer: String, now: Long): List<Pair<String, DoubleArray>> {
        val keys = layers[layer] ?: return emptyList()
        val out = ArrayList<Pair<String, DoubleArray>>()
        val it = keys.entries.iterator()
        while (it.hasNext()) {
            val (k, e) = it.next()
            if (e.move == null && now - e.stillSince >= lingerMillis) { out += k to e.at; it.remove() }
        }
        if (keys.isEmpty()) layers.remove(layer)
        return out
    }

    fun animating(): Boolean = layers.values.any { m -> m.values.any { it.move != null } }

    /** When the next feature leaves the set, or null when none is waiting. */
    fun nextSettle(): Long? = layers.values.flatMap { it.values }.filter { it.move == null }.minOfOrNull { it.stillSince + lingerMillis }

    fun remove(layer: String) { layers.remove(layer) }
}

/**
 * A dash that differs per feature (G20): the native line layer takes no data expression for its dashes, so the layer is
 * drawn as one engine layer for the solid features and one per distinct pattern, each with its constant dashes.
 */
internal object SMapDashSplit {
    /** A dash value read from a property: a list of numbers, else null. */
    fun floats(v: Any?): List<Float>? = (v as? List<*>)?.mapNotNull { (it as? Number)?.toFloat() }?.takeIf { it.isNotEmpty() }

    /** The distinct patterns of [data] in the order first met. */
    fun patterns(data: FeatureCollection, reader: (Map<String, Any?>) -> List<Float>?): List<List<Float>> {
        val out = LinkedHashSet<List<Float>>()
        data.features()?.forEach { f -> try { reader(SMapGeoJson.propertiesOf(f)) } catch (e: Exception) { null }?.let(out::add) }
        return out.toList()
    }

    /** The filter of one part: the solid features (null [index]) or those of pattern [index], read from [indexExpr]. */
    fun filter(indexExpr: JsonElement, index: Int?): JsonElement =
        if (index == null) SMapJson.arr("==", SMapJson.arr("typeof", indexExpr), "null")
        else SMapJson.arr("==", SMapJson.arr("to-number", SMapJson.arr("coalesce", indexExpr, -1)), index)
}
