package ca.superroute.smap

import com.google.gson.JsonParser
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Reading map tokens. A token looks like `sm1.<base64url JSON {"sub","exp"}>.<signature>`; the SDK reads `exp` only
 * and never checks the signature (the service does).
 */
object SMapTokens {
    /** A new token is asked for this many seconds before the current one expires. */
    const val REFRESH_BEFORE_SECONDS = 120L

    /** The shortest wait before a scheduled refresh. */
    const val MIN_REFRESH_DELAY_SECONDS = 5L

    /** Seconds since 1970 when [token] expires; 0 when it cannot be read. */
    fun expiry(token: String?): Long {
        if (token.isNullOrEmpty()) return 0
        val parts = token.split('.')
        if (parts.size < 2) return 0
        return try {
            val json = String(Base64Url.decode(parts[1]), Charsets.UTF_8)
            val obj = JsonParser.parseString(json).asJsonObject
            val exp = obj.get("exp")
            if (exp == null || !exp.isJsonPrimitive || !exp.asJsonPrimitive.isNumber) 0 else exp.asLong
        } catch (e: Exception) {
            0
        }
    }

    /**
     * True while [token] can still be sent: it exists and either has no readable expiry or expires more than
     * [REFRESH_BEFORE_SECONDS] from [nowMillis].
     */
    fun isFresh(token: String?, nowMillis: Long): Boolean {
        if (token.isNullOrEmpty()) return false
        val exp = expiry(token)
        return exp == 0L || exp - nowMillis / 1000 > REFRESH_BEFORE_SECONDS
    }

    /**
     * Milliseconds to wait before asking for a new token: [REFRESH_BEFORE_SECONDS] before `exp`, at least
     * [MIN_REFRESH_DELAY_SECONDS]; null when the token has no readable expiry (no refresh is scheduled).
     */
    fun refreshDelayMillis(token: String?, nowMillis: Long): Long? {
        val exp = expiry(token)
        if (exp == 0L) return null
        val seconds = maxOf(MIN_REFRESH_DELAY_SECONDS, exp - nowMillis / 1000 - REFRESH_BEFORE_SECONDS)
        return seconds * 1000
    }
}

/**
 * Holds the current token and asks [getToken] for a new one when needed; concurrent callers share one request.
 *
 * @param initial the token given in the options, if any
 * @param getToken called at start when no token is given and again before each token expires
 * @param clock wall-clock milliseconds
 */
class SMapTokenManager(
    initial: String?,
    private val getToken: (suspend () -> String)?,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    @Volatile
    var current: String? = initial
        private set

    private val mutex = Mutex()

    /** True when a token source exists (a fixed token or [getToken]). */
    val hasTokens: Boolean get() = current != null || getToken != null

    /** The token to send now: the current one while fresh, otherwise a new one from [getToken]. */
    suspend fun token(): String? {
        if (getToken == null || SMapTokens.isFresh(current, clock())) return current
        return mutex.withLock {
            if (SMapTokens.isFresh(current, clock())) current else fetch()
        }
    }

    /** Asks [getToken] for a new token now, whatever the current one's expiry. */
    suspend fun refresh(): String? {
        if (getToken == null) return current
        return mutex.withLock { fetch() }
    }

    /** Milliseconds until the next refresh should happen; null when none is due (no [getToken] or no expiry). */
    fun refreshDelayMillis(): Long? {
        if (getToken == null) return null
        return SMapTokens.refreshDelayMillis(current, clock())
    }

    private suspend fun fetch(): String {
        val source = getToken ?: throw SMapException("sMap: no getToken given")
        val token = try {
            source()
        } catch (e: Exception) {
            throw if (e is SMapException) e else SMapException("sMap: getToken failed: ${e.message}", cause = e)
        }
        if (token.isEmpty()) throw SMapException("sMap: getToken returned an empty token")
        current = token
        return token
    }
}

/** base64url decoding without padding, usable on every API level and in plain JVM tests. */
internal object Base64Url {
    private const val ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"

    fun decode(input: String): ByteArray {
        val s = input.trimEnd('=').replace('+', '-').replace('/', '_')
        val out = java.io.ByteArrayOutputStream(s.length * 3 / 4)
        var buffer = 0
        var bits = 0
        for (c in s) {
            val v = ALPHABET.indexOf(c)
            require(v >= 0) { "Invalid base64url character" }
            buffer = (buffer shl 6) or v
            bits += 6
            if (bits >= 8) {
                bits -= 8
                out.write((buffer shr bits) and 0xFF)
            }
        }
        return out.toByteArray()
    }
}
