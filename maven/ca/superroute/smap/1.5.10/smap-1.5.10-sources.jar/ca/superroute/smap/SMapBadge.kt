package ca.superroute.smap

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * The sMap badge shown on every map: the small icon and the name on a semi-transparent pill that reads on every
 * colour scheme. It sits in the bottom-right corner; the attribution button keeps its place in the bottom-left corner
 * and the rendering engine's own logo stays off. It is not a link and takes no touches.
 */
@SuppressLint("ViewConstructor")
internal class SMapBadge(context: Context) : LinearLayout(context) {

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        isClickable = false
        isFocusable = false
        contentDescription = NAME
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        minimumHeight = dp(HEIGHT_DP)
        setPadding(dp(3f), 0, dp(7f), 0)
        background = GradientDrawable().apply {
            cornerRadius = dp(HEIGHT_DP / 2).toFloat()
            setColor(BACKGROUND)
            setStroke(dp(0.5f).coerceAtLeast(1), OUTLINE)
        }
        addView(ImageView(context).apply {
            setImageResource(R.drawable.smap_badge_icon)
        }, LayoutParams(dp(ICON_DP), dp(ICON_DP)))
        addView(TextView(context).apply {
            text = NAME
            // Fixed in dp, like the icon: the badge keeps its size whatever the system font scale.
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 11f)
            setTextColor(TEXT)
            typeface = Typeface.DEFAULT_BOLD
            includeFontPadding = false
        }, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { marginStart = dp(4f) })
    }

    private fun dp(value: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, resources.displayMetrics).toInt()

    internal companion object {
        const val NAME = "sMap"
        const val HEIGHT_DP = 20f
        const val ICON_DP = 14f
        /** Distance from the map's bottom-right corner, as the attribution has from its corner. */
        const val MARGIN_DP = 4f
        val BACKGROUND = Color.argb(209, 255, 255, 255)
        val OUTLINE = Color.argb(31, 15, 23, 42)
        val TEXT = Color.rgb(30, 41, 59)
    }
}
