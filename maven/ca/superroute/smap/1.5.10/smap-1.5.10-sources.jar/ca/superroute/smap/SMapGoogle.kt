package ca.superroute.smap

import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.gson.JsonParser
import org.maplibre.android.maps.MapLibreMap
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/**
 * Google's base maps on one map (G10): the tiles read from Google with the app's session, the Google logo and the
 * copyright of the area in view (asked of Google after each camera stop), and onFail once when Google's first tiles
 * fail and none loads.
 */
internal class SMapGoogleState(private val map: SMap, private val g: SMapGoogleBase) {
    private val query = if (g.session != null) "session=" + enc(g.session) + "&key=" + enc(g.key!!) else ""
    val tiles: String = g.tiles ?: "https://tile.googleapis.com/v1/2dtiles/{z}/{x}/{y}?$query"
    private val viewport: String? = g.viewport ?: if (query.isNotEmpty()) "https://tile.googleapis.com/tile/v1/viewport?$query" else null
    private val main = Handler(Looper.getMainLooper())
    private val density = map.resources.displayMetrics.density
    private val corner = LinearLayout(map.context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private val text = TextView(map.context).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f)
        setTextColor(Color.rgb(17, 24, 39))
        text = "Google"
        val px = (5 * density).toInt(); setPadding(px, (1 * density).toInt(), px, (1 * density).toInt())
        background = GradientDrawable().apply { cornerRadius = 3 * density; setColor(Color.argb(191, 255, 255, 255)) }
    }
    private var seq = 0
    private var errors = 0
    private var loaded = 0
    private var failed = false
    private var stopped = false
    private val idle = MapLibreMap.OnCameraIdleListener { copyright() }
    private val watcher: (String, Int) -> Unit = { host, code ->
        if (host == "tile.googleapis.com" && !failed && !stopped) {
            if (code in 200..299) loaded++ else errors++
            if (errors >= 4 && loaded == 0) { failed = true; main.post { g.onFail?.invoke() } }
        }
    }

    fun start() {
        val logo = ImageView(map.context)
        corner.addView(logo, LinearLayout.LayoutParams((50 * density).toInt(), (18 * density).toInt()).apply { marginEnd = (6 * density).toInt() })
        corner.addView(text)
        map.googleCorner(corner)
        SMapLocalTiles.watch(watcher)
        IO.execute {
            val bitmap = try { URL(LOGO).openStream().use { BitmapFactory.decodeStream(it) } } catch (e: Exception) { null }
            if (bitmap != null) main.post { if (!stopped) logo.setImageBitmap(bitmap) }
        }
        map.ready { m -> if (!stopped) { m.engine?.addOnCameraIdleListener(idle); copyright() } }
    }

    fun stop() {
        stopped = true
        SMapLocalTiles.unwatch(watcher)
        map.engine?.removeOnCameraIdleListener(idle)
        map.removeControl(corner)
    }

    private fun copyright() {
        val base = viewport ?: return
        val engine = map.engine ?: return
        val b = engine.projection.visibleRegion.latLngBounds
        val url = base + (if ('?' in base) "&" else "?") + "zoom=" + Math.round(engine.cameraPosition.zoom + 1) +
            "&north=" + b.latitudeNorth + "&south=" + b.latitudeSouth + "&east=" + b.longitudeEast + "&west=" + b.longitudeWest
        val mine = ++seq
        IO.execute {
            val answer = try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 10_000; c.readTimeout = 10_000
                if (c.responseCode in 200..299) c.inputStream.bufferedReader().use { JsonParser.parseString(it.readText()).asJsonObject.get("copyright")?.asString } else null
            } catch (e: Exception) { null }
            main.post { if (mine == seq && !stopped) text.text = answer?.takeIf { it.isNotEmpty() } ?: "Google" }
        }
    }

    companion object {
        const val LOGO = "https://maps.gstatic.com/mapfiles/api-3/images/google_white5.png"
        private val IO = Executors.newSingleThreadExecutor()
        private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")
    }
}
