package ca.superroute.smap

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

/**
 * The app's identity as the map service checks it against a map key's allowlist, read from the system (never from
 * the caller's options): `X-SMap-App: android:<package name>` and `X-SMap-App-Cert: <SHA-256 of the signing
 * certificate, lower-case hex without separators>`.
 */
object SMapAppIdentity {
    const val APP_HEADER = "X-SMap-App"
    const val CERT_HEADER = "X-SMap-App-Cert"
    const val KEY_HEADER = "X-SMap-Key"

    @Volatile
    private var cached: Map<String, String>? = null

    /** The identity headers of the running app; read once, then kept. Empty when the system does not tell. */
    fun headers(context: Context): Map<String, String> {
        cached?.let { return it }
        val app = context.applicationContext
        val packageName = app.packageName
        val cert = try {
            signingCertificate(app.packageManager, packageName)?.let(::fingerprint)
        } catch (e: Exception) {
            null
        }
        return headers(packageName, cert).also { cached = it }
    }

    /** The headers for [packageName] and a certificate fingerprint (the certificate header only when known). */
    fun headers(packageName: String?, certFingerprint: String?): Map<String, String> {
        if (packageName.isNullOrEmpty()) return emptyMap()
        val h = linkedMapOf(APP_HEADER to appHeader(packageName))
        if (!certFingerprint.isNullOrEmpty()) h[CERT_HEADER] = certFingerprint
        return h
    }

    fun appHeader(packageName: String): String = "android:$packageName"

    /** SHA-256 of a certificate's encoded bytes, lower-case hex without separators. */
    fun fingerprint(certificate: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(certificate).joinToString("") { "%02x".format(it.toInt() and 0xff) }

    /** The encoded certificate the app is signed with now (the current signer, not past rotated ones). */
    @SuppressLint("PackageManagerGetSignatures")
    @Suppress("DEPRECATION")
    private fun signingCertificate(pm: PackageManager, packageName: String): ByteArray? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val info = pm.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo ?: return null
            // The signers of the APK contents: the current certificate (rotated-out ones are not included).
            return info.apkContentsSigners?.firstOrNull()?.toByteArray()
        }
        return pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES).signatures?.firstOrNull()?.toByteArray()
    }
}
