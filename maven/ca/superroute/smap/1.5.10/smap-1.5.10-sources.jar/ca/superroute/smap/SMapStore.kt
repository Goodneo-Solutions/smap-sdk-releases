package ca.superroute.smap

import android.content.Context

/** A tiny key-value store for what the SDK remembers between launches (the node order). */
interface SMapStore {
    fun get(key: String): String?
    fun put(key: String, value: String?)
}

/** Keeps values in memory only. */
class SMapMemoryStore : SMapStore {
    private val values = HashMap<String, String>()

    @Synchronized
    override fun get(key: String): String? = values[key]

    @Synchronized
    override fun put(key: String, value: String?) {
        if (value == null) values.remove(key) else values[key] = value
    }
}

/** Keeps values in the app's shared preferences (file `ca.superroute.smap`). */
class SMapPreferencesStore(context: Context) : SMapStore {
    private val prefs = context.applicationContext.getSharedPreferences("ca.superroute.smap", Context.MODE_PRIVATE)

    override fun get(key: String): String? = prefs.getString(key, null)

    override fun put(key: String, value: String?) {
        prefs.edit().apply { if (value == null) remove(key) else putString(key, value) }.apply()
    }
}
