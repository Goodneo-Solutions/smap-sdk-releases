package ca.superroute.smap

import android.view.MotionEvent
import kotlin.math.hypot

/**
 * Cooperative gestures (1.5.0, G36), without any view work: one finger leaves the map still (the screen around it
 * scrolls), two fingers move it. [touch] is told each touch and answers what the map does.
 */
internal class SMapCooperative(private val slopPx: Float) {
    /** What the map does after a touch: let its own scrolling run, take the touch from its parent, show the hint. */
    data class Decision(val mapScroll: Boolean, val claim: Boolean, val hint: Boolean)

    private var downX = 0f
    private var downY = 0f
    private var twoFingers = false
    private var hinted = false

    fun touch(action: Int, pointerCount: Int, x: Float, y: Float): Decision = when (action) {
        MotionEvent.ACTION_DOWN -> {
            downX = x; downY = y; twoFingers = false; hinted = false
            Decision(mapScroll = false, claim = false, hint = false)
        }
        MotionEvent.ACTION_POINTER_DOWN -> {
            if (pointerCount >= 2) twoFingers = true
            Decision(mapScroll = twoFingers, claim = twoFingers, hint = false)
        }
        MotionEvent.ACTION_MOVE -> {
            val far = hypot(x - downX, y - downY) > slopPx
            val hint = !twoFingers && far && !hinted
            if (hint) hinted = true
            Decision(mapScroll = twoFingers, claim = twoFingers, hint = hint)
        }
        // The screen around the map took the touch (it scrolls): one finger tried to move the map.
        MotionEvent.ACTION_CANCEL -> {
            val hint = !twoFingers && !hinted
            hinted = true
            Decision(mapScroll = twoFingers, claim = false, hint = hint)
        }
        else -> Decision(mapScroll = twoFingers, claim = false, hint = false)
    }
}
