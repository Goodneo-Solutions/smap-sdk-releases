package ca.superroute.smap

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/** One HTTP answer: the status and the body as text (empty for answers without one). */
data class SMapHttpResponse(val status: Int, val body: String = "") {
    val ok: Boolean get() = status in 200..299
}

/**
 * The small HTTP layer the SDK uses for its own calls (node list and pings). Replace it to route the calls
 * elsewhere or to test. A network failure throws.
 */
fun interface SMapHttp {
    suspend fun get(url: String, timeoutMillis: Long): SMapHttpResponse

    /**
     * Sends [body] (the converting endpoint, `SMap.convert`). The default throws; [SMapUrlConnectionHttp] sends it.
     *
     * @param headers request headers (`Content-Type`, `Authorization`)
     */
    suspend fun post(url: String, body: ByteArray, headers: Map<String, String>, timeoutMillis: Long): SMapHttpResponse =
        throw UnsupportedOperationException("sMap: this HTTP layer does not send requests with a body")
}

/**
 * The default [SMapHttp]: `HttpURLConnection` on the IO dispatcher, no caching.
 *
 * @param headers added to requests for node hosts only (the app identity and the map key)
 */
class SMapUrlConnectionHttp(private val headers: Map<String, String> = emptyMap()) : SMapHttp {
    override suspend fun get(url: String, timeoutMillis: Long): SMapHttpResponse = withContext(Dispatchers.IO) {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = timeoutMillis.toInt()
            connection.readTimeout = timeoutMillis.toInt()
            connection.useCaches = false
            connection.setRequestProperty("Cache-Control", "no-store")
            connection.setRequestProperty("User-Agent", "sMap-Android/${BuildConfig.SMAP_VERSION}")
            if (SMapNodeHosts.isNode(url)) headers.forEach { (name, value) -> connection.setRequestProperty(name, value) }
            val status = connection.responseCode
            val stream = if (status >= 400) connection.errorStream else connection.inputStream
            val body = stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            SMapHttpResponse(status, body)
        } finally {
            connection.disconnect()
        }
    }

    override suspend fun post(url: String, body: ByteArray, headers: Map<String, String>, timeoutMillis: Long): SMapHttpResponse =
        withContext(Dispatchers.IO) {
            val connection = URL(url).openConnection() as HttpURLConnection
            try {
                connection.connectTimeout = timeoutMillis.toInt()
                connection.readTimeout = timeoutMillis.toInt()
                connection.useCaches = false
                connection.requestMethod = "POST"
                connection.doOutput = true
                connection.setRequestProperty("User-Agent", "sMap-Android/${BuildConfig.SMAP_VERSION}")
                if (SMapNodeHosts.isNode(url)) this@SMapUrlConnectionHttp.headers.forEach { (name, value) -> connection.setRequestProperty(name, value) }
                headers.forEach { (name, value) -> connection.setRequestProperty(name, value) }
                connection.setFixedLengthStreamingMode(body.size)
                connection.outputStream.use { it.write(body) }
                val status = connection.responseCode
                val stream = if (status >= 400) connection.errorStream else connection.inputStream
                val text = stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                SMapHttpResponse(status, text)
            } finally {
                connection.disconnect()
            }
        }
}
