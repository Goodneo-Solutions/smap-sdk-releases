package ca.superroute.smap

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.JsonObject

/**
 * A route of a plan: the vehicle and its stops (job ids) in driving order. A route given with [reverse] is held in
 * driving order by the editor, as the plan calls answer it.
 */
data class SMapPlanRoute(val vehicleId: String, val stops: List<String>, val reverse: Boolean = false) {
    fun toJson(): JsonObject = JsonObject().apply {
        addProperty("vehicle_id", vehicleId)
        add("stops", JsonArray().also { a -> stops.forEach(a::add) })
    }

    companion object {
        fun fromJson(json: JsonObject): SMapPlanRoute = SMapPlanRoute(
            SMapPlanIds.of(json.get("vehicle_id")),
            json.get("stops")?.takeIf { it.isJsonArray }?.asJsonArray?.map { SMapPlanIds.of(it) } ?: emptyList(),
            json.get("reverse")?.let { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean && it.asBoolean } ?: false,
        )
    }
}

/**
 * A plan as the plan editor takes and gives it: vehicles and jobs as the Open Platform reads them (kept as JSON, so
 * every field the app sets travels unchanged), the routes, the jobs on no route ([unassigned], given by the editor)
 * and the context (`region`, `profile`, `departed_at`).
 */
data class SMapPlan(
    val vehicles: List<JsonObject>,
    val jobs: List<JsonObject>,
    val routes: List<SMapPlanRoute> = emptyList(),
    val unassigned: List<String> = emptyList(),
    val region: String? = null,
    val profile: String? = null,
    val departedAt: String? = null,
) {
    /** The plan as JSON: `{vehicles, jobs, routes, unassigned, region?, profile?, departed_at?}`. */
    fun toJson(): JsonObject = JsonObject().apply {
        add("vehicles", JsonArray().also { a -> vehicles.forEach { a.add(it.deepCopy()) } })
        add("jobs", JsonArray().also { a -> jobs.forEach { a.add(it.deepCopy()) } })
        add("routes", JsonArray().also { a -> routes.forEach { a.add(it.toJson()) } })
        add("unassigned", JsonArray().also { a -> unassigned.forEach(a::add) })
        region?.let { addProperty("region", it) }
        profile?.let { addProperty("profile", it) }
        departedAt?.let { addProperty("departed_at", it) }
    }

    companion object {
        /** Reads `{vehicles, jobs, routes?, region?, profile?, departed_at?}`. */
        fun fromJson(json: JsonObject): SMapPlan {
            fun objects(key: String): List<JsonObject> {
                val a = json.get(key)?.takeIf { it.isJsonArray }?.asJsonArray
                    ?: throw SMapPlanException("sMap plan editor: a plan has vehicles and jobs")
                return a.map { if (it.isJsonObject) it.asJsonObject.deepCopy() else throw SMapPlanException("sMap plan editor: $key are objects") }
            }
            fun text(key: String): String? = json.get(key)?.takeIf { it.isJsonPrimitive }?.asString?.takeIf { it.isNotEmpty() }
            return SMapPlan(
                vehicles = objects("vehicles"),
                jobs = objects("jobs"),
                routes = json.get("routes")?.takeIf { it.isJsonArray }?.asJsonArray
                    ?.filter { it.isJsonObject }?.map { SMapPlanRoute.fromJson(it.asJsonObject) } ?: emptyList(),
                region = text("region"),
                profile = text("profile"),
                departedAt = text("departed_at"),
            )
        }

        fun fromJson(text: String): SMapPlan = fromJson(SMapJson.parseObject(text))
    }
}

/** The plan's prices and judgement as an answer gave them: `routes` (per vehicle) and `summary`. */
data class SMapPlanResult(val routes: JsonArray, val summary: JsonObject?) {
    fun toJson(): JsonObject = JsonObject().apply {
        add("routes", routes.deepCopy())
        add("summary", summary?.deepCopy() ?: JsonNull.INSTANCE)
    }

    /** The priced route of [vehicleId], or null. */
    fun route(vehicleId: String): JsonObject? =
        routes.firstOrNull { it.isJsonObject && SMapPlanIds.of(it.asJsonObject.get("vehicle_id")) == vehicleId }?.asJsonObject

    internal fun copy(): SMapPlanResult = SMapPlanResult(routes.deepCopy(), summary?.deepCopy())
}

/** What an answered call gives: its kind, the plan and result now shown, and the call's own answer. */
data class SMapPlanEdit(val kind: String, val plan: SMapPlan?, val result: SMapPlanResult?, val answer: JsonElement?, val path: String? = null)

/** The routes a preview priced and their result. */
data class SMapPlanPreview(val routes: List<SMapPlanRoute>, val result: SMapPlanResult)

/** The last refused call as the editor keeps it. */
data class SMapPlanError(val kind: String, val status: Int, val code: String?, val message: String, val reason: String?)

/** The call answered last (not a recost) and its answer. */
data class SMapPlanLast(val kind: String, val answer: JsonElement?)

/**
 * The positions an insert answered for one job: [choices] are the answer's position objects (`vehicle_id`,
 * `position`, `added_distance_meters`, `added_duration_seconds`, `arrival`, `feasible`, `violations`), [chosen] the
 * index taken (0 when the service placed the job, else null until one is chosen).
 */
data class SMapPlanChoices(
    val job: String,
    val placed: Boolean,
    val reason: String?,
    val choices: List<JsonObject>,
    val chosen: Int?,
)

/** Everything a panel shows, in one object. */
data class SMapPlanState(
    val plan: SMapPlan?,
    val result: SMapPlanResult?,
    val busy: Boolean,
    val error: SMapPlanError?,
    val canUndo: Boolean,
    val canRedo: Boolean,
    val choices: List<SMapPlanChoices>?,
    val locked: List<String>,
    val last: SMapPlanLast?,
    val preview: SMapPlanPreview?,
    /** Where the last answered call was answered ([SMapPlanPath]); null before the first answer. */
    val path: String? = null,
)

/** An error answered by the Open Platform (status, code, reason, details) or raised on the way. */
class SMapPlanException(
    message: String,
    val status: Int = 0,
    val code: String? = null,
    val reason: String? = null,
    val details: JsonElement? = null,
    val path: String? = null,
    cause: Throwable? = null,
    /** Where a refusal was answered ([SMapPlanPath]); null when it was not an answer. */
    val via: String? = null,
) : Exception(message, cause)

/** Ids as the plan editor keeps them: strings (a number id is written as JavaScript writes it). */
internal object SMapPlanIds {
    fun of(e: JsonElement?): String = when {
        e == null || e.isJsonNull -> ""
        e.isJsonPrimitive && e.asJsonPrimitive.isNumber -> SMapJson.number(e.asDouble)
        e.isJsonPrimitive -> e.asString
        else -> e.toString()
    }

    fun ofJob(job: JsonObject): String = of(job.get("id"))
}

/**
 * The plan operations worked out on the device (MOBILE-SDK-SPEC "Plan editor"): every route kept for every vehicle,
 * the unassigned jobs, and the routes after a resequence, move, remove or drop.
 */
object SMapPlanOps {

    /** Routes as held: stops of a `reverse` route turned into driving order, the flag dropped. */
    fun routesOf(routes: List<SMapPlanRoute>): List<SMapPlanRoute> =
        routes.map { SMapPlanRoute(it.vehicleId, if (it.reverse) it.stops.reversed() else it.stops.toList()) }

    /** Every vehicle keeps a route to drop stops on: an empty one, last, where the plan gives none. */
    fun withAllVehicles(routes: List<SMapPlanRoute>, vehicleIds: List<String>): List<SMapPlanRoute> {
        val out = routes.toMutableList()
        vehicleIds.forEach { v -> if (out.none { it.vehicleId == v }) out.add(SMapPlanRoute(v, emptyList())) }
        return out
    }

    /** Every job on no route, in job order. */
    fun unassignedOf(jobIds: List<String>, routes: List<SMapPlanRoute>): List<String> {
        val on = routes.flatMapTo(HashSet()) { it.stops }
        return jobIds.filter { it !in on }
    }

    /** Where a stop is: (route index, vehicle, position from 1), or null. */
    fun findStop(routes: List<SMapPlanRoute>, id: String): Triple<Int, String, Int>? {
        routes.forEachIndexed { i, r ->
            val k = r.stops.indexOf(id)
            if (k >= 0) return Triple(i, r.vehicleId, k + 1)
        }
        return null
    }

    /** The routes after giving [vehicleId]'s route the stops in [stops] (every stop of the route once, no other). */
    fun applyResequence(routes: List<SMapPlanRoute>, vehicleId: String, stops: List<String>): List<SMapPlanRoute> {
        val r = routes.firstOrNull { it.vehicleId == vehicleId } ?: throw SMapPlanException("sMap plan editor: no route of vehicle $vehicleId")
        if (stops.size != r.stops.size || stops.sorted() != r.stops.sorted()) {
            throw SMapPlanException("sMap plan editor: a new order holds every stop of the route once, and no other")
        }
        return routes.map { if (it === r) SMapPlanRoute(vehicleId, stops.toList()) else it }
    }

    /** The routes after moving [stops] to [vehicleId]'s route at [position] (from 1, counted without them; null: last). */
    fun applyMove(routes: List<SMapPlanRoute>, stops: List<String>, vehicleId: String, position: Int?): List<SMapPlanRoute> {
        val out = routes.map { r -> SMapPlanRoute(r.vehicleId, r.stops.filter { it !in stops }) }.toMutableList()
        var i = out.indexOfFirst { it.vehicleId == vehicleId }
        if (i < 0) { out.add(SMapPlanRoute(vehicleId, emptyList())); i = out.size - 1 }
        val target = out[i].stops.toMutableList()
        val at = if (position == null) target.size else maxOf(0, minOf(target.size, position - 1))
        target.addAll(at, stops)
        out[i] = SMapPlanRoute(vehicleId, target)
        return out
    }

    /** The routes after taking [stops] off their routes (each must be on a route). */
    fun applyRemove(routes: List<SMapPlanRoute>, stops: List<String>): List<SMapPlanRoute> {
        stops.forEach { if (findStop(routes, it) == null) throw SMapPlanException("sMap plan editor: $it is on no route") }
        return routes.map { r -> SMapPlanRoute(r.vehicleId, r.stops.filter { it !in stops }) }
    }

    /** What a drop does: a new order of the stop's own route, or a move to another route (no position = last). */
    sealed class Drop {
        data class Resequence(val vehicleId: String, val stops: List<String>) : Drop()
        data class Move(val vehicleId: String, val position: Int?) : Drop()
    }

    /**
     * Where a stop dropped before the stop at [position] of [vehicleId]'s route (as drawn, the stop itself included;
     * past the last stop = after it) ends up; null when nothing changes.
     */
    fun dropEdit(routes: List<SMapPlanRoute>, stopId: String, vehicleId: String, position: Int): Drop? {
        val from = findStop(routes, stopId)
        val target = routes.firstOrNull { it.vehicleId == vehicleId }
        val length = target?.stops?.size ?: 0
        if (from != null && from.second == vehicleId && target != null) {
            val stops = target.stops.toMutableList()
            stops.removeAt(from.third - 1)
            var at = maxOf(1, minOf(position, length + 1))
            if (from.third < at) at -= 1
            stops.add(at - 1, stopId)
            if (stops == target.stops) return null
            return Drop.Resequence(vehicleId, stops)
        }
        val p = maxOf(1, position)
        return Drop.Move(vehicleId, if (p > length) null else p)
    }

    /** The routes a drop would make; null when it changes nothing. */
    fun dropRoutes(routes: List<SMapPlanRoute>, stopId: String, vehicleId: String, position: Int): List<SMapPlanRoute>? =
        when (val d = dropEdit(routes, stopId, vehicleId, position)) {
            null -> null
            is Drop.Resequence -> applyResequence(routes, d.vehicleId, d.stops)
            is Drop.Move -> applyMove(routes, listOf(stopId), d.vehicleId, d.position)
        }

    /** An encoded polyline (precision 5, as the plan calls answer legs) as `[lng, lat]` pairs. */
    fun decodePolyline(text: String, precision: Int = 5): List<DoubleArray> {
        val factor = Math.pow(10.0, precision.toDouble())
        val out = ArrayList<DoubleArray>()
        var index = 0
        var lat = 0
        var lng = 0
        while (index < text.length) {
            val values = IntArray(2)
            for (n in 0..1) {
                var shift = 0
                var result = 0
                var b: Int
                do {
                    b = if (index < text.length) text[index].code - 63 else 0
                    index++
                    result = result or ((b and 0x1f) shl shift)
                    shift += 5
                } while (b >= 0x20 && index <= text.length)
                values[n] = if (result and 1 != 0) (result shr 1).inv() else result shr 1
            }
            lat += values[0]
            lng += values[1]
            out.add(doubleArrayOf(lng / factor, lat / factor))
        }
        return out
    }

    /** `[lng, lat]` of a location given as `{lng, lat}` / `{lon, lat}` / `{longitude, latitude}` / `[lng, lat]`. */
    fun lngLat(v: JsonElement?): DoubleArray? {
        if (v == null || v.isJsonNull) return null
        return try {
            if (v.isJsonArray) {
                val a = v.asJsonArray
                if (a.size() >= 2) doubleArrayOf(a[0].asDouble, a[1].asDouble) else null
            } else if (v.isJsonObject) {
                val o = v.asJsonObject
                val lng = o.get("lng") ?: o.get("lon") ?: o.get("longitude")
                val lat = o.get("lat") ?: o.get("latitude")
                if (lng == null || lat == null || lng.isJsonNull || lat.isJsonNull) null else doubleArrayOf(lng.asDouble, lat.asDouble)
            } else null
        } catch (e: Exception) {
            null
        }
    }
}
