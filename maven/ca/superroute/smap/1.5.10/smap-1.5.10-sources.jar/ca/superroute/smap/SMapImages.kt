package ca.superroute.smap

import com.google.gson.JsonElement
import com.google.gson.JsonPrimitive

/**
 * The app's own images (G25) under their engine ids. An image of [SMap.addImage] is put on the map as
 * `smap-user:<id>`, so it never meets an image of the basemap's sprite of the same name (a sprite has an `arrow`, which
 * drew instead of the app's own); the app keeps naming it by its own id everywhere (`icon`, `iconProperty`,
 * [SMap.hasImage], [SMap.removeImage]). An icon naming no image of the app's still finds the sprite's.
 */
object SMapImages {
    /** What the SDK puts before an app image's id on the map (a raw style layer names the image so). */
    const val PREFIX = "smap-user:"

    /** The engine id of the app's image [id]. */
    fun engineId(id: String): String = PREFIX + id

    /** The app's id of an engine image id, or null for an image that is not the app's. */
    fun appId(engineId: String): String? = if (engineId.startsWith(PREFIX)) engineId.substring(PREFIX.length) else null

    /**
     * The `icon-image` value of icon points: the app's image of the name when [appIds] has it, else the name as it is
     * (a sprite image). [property] (a property naming each point's image) wins over [icon]. The engine's `coalesce`
     * does not pass over a missing image natively, so the app's ids are matched by name and the value is made again
     * when the app adds or removes an image.
     */
    internal fun iconImage(icon: String?, property: String?, appIds: Set<String>): JsonElement {
        if (property == null) {
            val name = icon ?: ""
            return JsonPrimitive(if (name in appIds) engineId(name) else name)
        }
        val name = SMapJson.arr("to-string", SMapJson.arr("get", property))
        if (appIds.isEmpty()) return name
        return SMapJson.arr("match", name, SMapJson.of(appIds.sorted()), SMapJson.arr("concat", PREFIX, name), name)
    }
}
