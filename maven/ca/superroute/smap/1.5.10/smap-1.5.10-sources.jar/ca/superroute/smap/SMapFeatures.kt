package ca.superroute.smap

import org.maplibre.android.geometry.LatLng

/**
 * A value that may differ per feature (MOBILE-SDK-SPEC "Per-feature values"): a constant, a function of the feature's
 * properties, or one of its properties with a default.
 */
sealed class SMapFeatureValue<out T> {
    data class Const<T>(val value: T) : SMapFeatureValue<T>()
    class Of<T>(val read: (Map<String, Any?>) -> T?) : SMapFeatureValue<T>()
    data class Property<T>(val name: String, val default: T? = null) : SMapFeatureValue<T>()

    companion object {
        fun <T> of(value: T): SMapFeatureValue<T> = Const(value)
        fun <T> property(name: String, default: T? = null): SMapFeatureValue<T> = Property(name, default)
        fun <T> computed(read: (Map<String, Any?>) -> T?): SMapFeatureValue<T> = Of(read)
    }
}

/** Reads a per-feature value: [fallback] when it is not given or gives nothing. */
@Suppress("UNCHECKED_CAST")
internal fun <T> SMapFeatureValue<T>?.read(properties: Map<String, Any?>, fallback: T): T = when (this) {
    null -> fallback
    is SMapFeatureValue.Const -> value
    is SMapFeatureValue.Of -> read(properties) ?: fallback
    is SMapFeatureValue.Property -> {
        val raw = properties[name]
        when {
            raw == null -> default ?: fallback
            fallback is Float && raw is Number -> raw.toFloat() as T
            fallback is Double && raw is Number -> raw.toDouble() as T
            fallback is Int && raw is Number -> raw.toInt() as T
            fallback is Boolean && raw is Boolean -> raw as T
            fallback is String -> raw.toString() as T
            else -> (raw as? T) ?: default ?: fallback
        }
    }
}

/** One feature as the callbacks see it: its key (idProperty value, feature id or `#<index>`), properties and position. */
data class SMapFeature(val key: String, val properties: Map<String, Any?>, val position: LatLng)

/** Where a dragged feature is now: its position and the point in the map view, in pixels. */
data class SMapDragEvent(val position: LatLng, val x: Float, val y: Float)

/** Dragging (G2): a long press starts it; the map does not pan meanwhile; at the release the layer holds the new position. */
data class SMapDragOptions(
    val draggable: SMapFeatureValue<Boolean>? = null,
    val onDragStart: ((SMapFeature, SMapDragEvent) -> Unit)? = null,
    val onDrag: ((SMapFeature, SMapDragEvent) -> Unit)? = null,
    val onDragEnd: ((SMapFeature, SMapDragEvent) -> Unit)? = null,
)

/** Where a tooltip sits beside its feature. */
enum class SMapTooltipDirection { TOP, BOTTOM, LEFT, RIGHT }

/**
 * The map's one tooltip (G5) while a finger rests on a feature: [text] of its properties (a template `{name}` or a
 * function), beside a point or marker, at the finger on lines and areas.
 */
data class SMapTooltip(
    val text: (Map<String, Any?>) -> String?,
    val direction: SMapTooltipDirection = SMapTooltipDirection.TOP,
    val offsetDp: Pair<Float, Float> = 0f to 0f,
) {
    companion object {
        /** A template: every `{name}` the feature's property of that name (empty when it has none). */
        fun template(template: String, direction: SMapTooltipDirection = SMapTooltipDirection.TOP): SMapTooltip {
            val parts = template.split(Regex("\\{([^{}]+)\\}"))
            val names = Regex("\\{([^{}]+)\\}").findAll(template).map { it.groupValues[1].trim() }.toList()
            return SMapTooltip({ p ->
                val sb = StringBuilder(parts[0])
                names.forEachIndexed { i, n -> sb.append(p[n]?.let { v -> if (v is Double && v % 1.0 == 0.0) v.toLong().toString() else v.toString() } ?: "").append(parts[i + 1]) }
                sb.toString()
            }, direction)
        }
    }
}
