package ca.superroute.smap

import com.google.gson.JsonObject
import java.text.NumberFormat
import java.util.Locale

/**
 * The plan editor panel's texts in 14 languages, read from `plan-texts.json` (shared/plan-texts.json of the smap-sdk
 * repository, generated from the Web SDK and copied verbatim; a unit test keeps the copy equal to the shared file).
 */
object SMapPlanTexts {
    /** The shipped file. */
    val JSON: String by lazy {
        val stream = SMapPlanTexts::class.java.getResourceAsStream("plan-texts.json")
            ?: throw IllegalStateException("sMap: plan-texts.json is missing from the library")
        stream.use { it.readBytes().toString(Charsets.UTF_8) }
    }

    private val doc: JsonObject by lazy { SMapJson.parseObject(JSON) }

    /** The 41 keys. */
    val keys: List<String> by lazy { doc.getAsJsonArray("keys").map { it.asString } }

    /** `en`, `zh-Hans`, `zh-Hant`, `de`, `es`, `fr`, `it`, `nl`, `pt` (European), `sr` (Latin), `hu`, `pl`, `sk`, `cs`. */
    val languages: List<String> by lazy { doc.getAsJsonArray("languages").map { it.asString } }

    private val fallback: String by lazy { doc.get("fallback")?.asString ?: "en" }

    private val table: Map<String, Map<String, String>> by lazy {
        doc.getAsJsonObject("texts").entrySet().associate { (lang, t) -> lang to t.asJsonObject.entrySet().associate { it.key to it.value.asString } }
    }

    /**
     * The panel's language for a BCP-47 tag: `zh-Hant` for `zh-Hant`, `zh-TW`, `zh-HK`, `zh-MO`; `zh-Hans` for any
     * other `zh`; else the tag's first part when it is one of the 14; else English.
     */
    fun language(tag: String?): String {
        val t = (tag ?: fallback).lowercase(Locale.ROOT).replace('_', '-')
        if (Regex("^zh-(hant|tw|hk|mo)").containsMatchIn(t)) return "zh-Hant"
        if (t.startsWith("zh")) return "zh-Hans"
        val base = t.split('-')[0]
        return languages.firstOrNull { it == base } ?: fallback
    }

    /** Every key's text in the language of [tag], with the app's own [labels] over them. */
    fun texts(tag: String?, labels: Map<String, String>? = null): Map<String, String> {
        val own = table.getValue(language(tag))
        val en = table.getValue(fallback)
        return keys.associateWith { k -> labels?.get(k)?.takeIf { it.isNotEmpty() } ?: own[k] ?: en.getValue(k) }
    }

    /** Fills `{name}` placeholders by name; unknown ones stay. */
    fun fill(template: String, values: Map<String, Any?>): String =
        Regex("""\{(\w+)\}""").replace(template) { m -> values[m.groupValues[1]]?.toString() ?: m.value }
}

/** Distances in km with one decimal, times as hours / minutes, numbers in the language's format. */
class SMapPlanFormat(language: String, private val texts: Map<String, String>) {
    // Portuguese is European Portuguese, as the texts are: any `pt` tag writes numbers as pt-PT (never Brazilian).
    private val one: NumberFormat = NumberFormat.getNumberInstance(numberLocale(language)).apply {
        minimumFractionDigits = 1
        maximumFractionDigits = 1
    }

    companion object {
        /** The locale numbers are written in: pt-PT for any `pt` tag, else the tag itself. */
        fun numberLocale(language: String): Locale =
            if (SMapPlanTexts.language(language) == "pt") Locale.forLanguageTag("pt-PT") else Locale.forLanguageTag(language)
    }

    fun distance(meters: Double?): String = SMapPlanTexts.fill(texts.getValue("km"), mapOf("d" to one.format((meters ?: 0.0) / 1000)))

    fun time(seconds: Double?): String {
        val min = Math.round((seconds ?: 0.0) / 60).toInt()
        val h = min / 60
        val m = min % 60
        return if (h > 0) SMapPlanTexts.fill(texts.getValue("hours"), mapOf("h" to h, "m" to (if (m < 10) "0" else "") + m))
        else SMapPlanTexts.fill(texts.getValue("minutes"), mapOf("m" to m))
    }

    /** The clock time `HH:MM` of an ISO time as the answer gives it (the plan's own time zone). */
    fun clock(iso: String?): String = SMapPlanTime.clock(iso)
}

/**
 * What the panel shows, worked out from the editor's state without any view (MOBILE-SDK-SPEC "Plan editor", Panel):
 * the bar, the error line, the refine note, the total, each route, the unassigned jobs and the insert positions.
 */
class SMapPlanPanelModel(
    val bar: Bar,
    val error: String?,
    val note: String?,
    val total: Total?,
    val routes: List<Route>,
    val unassigned: Unassigned?,
    val choices: List<ChoiceGroup>?,
    val closeChoices: String?,
) {
    data class Row(val label: String, val value: String)
    data class Bar(val undo: String, val redo: String, val refine: String, val canUndo: Boolean, val canRedo: Boolean, val canRefine: Boolean, val status: String, val close: String)
    data class Total(val title: String, val rows: List<Row>?, val pending: String?, val previewTitle: String?, val preview: List<Row>?)
    data class Stop(
        val id: String, val vehicleId: String, val position: Int, val seq: String, val arrival: String?, val arrivalLabel: String?,
        val marks: String?, val locked: Boolean, val lockText: String, val removeText: String,
    )
    data class Route(val vehicleId: String, val color: String, val rows: List<Row>?, val violations: List<String>, val stops: List<Stop>, val empty: String?)
    data class Job(val id: String, val placeText: String)
    data class Unassigned(val title: String, val jobs: List<Job>)
    data class Position(
        val index: Int, val where: String, val added: String, val arrival: String?, val violations: String?, val feasible: Boolean,
        val chosen: Boolean, val button: String,
    )
    data class ChoiceGroup(val job: String, val title: String, val notPlaced: String?, val positions: List<Position>)

    companion object {
        fun build(state: SMapPlanState, texts: Map<String, String>, format: SMapPlanFormat, vehicleIds: List<String>, colors: List<String> = SMapPlanDraw.COLORS): SMapPlanPanelModel {
            val t = texts
            fun num(o: JsonObject?, key: String): Double? = o?.get(key)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble
            fun totals(summary: JsonObject, stops: Int): List<Row> = buildList {
                add(Row(t.getValue("distance"), format.distance(num(summary, "distance_meters"))))
                add(Row(t.getValue("drivingTime"), format.time(num(summary, "duration_seconds"))))
                add(Row(t.getValue("stops"), stops.toString()))
                val violations = num(summary, "violations")?.takeIf { it != 0.0 } ?: num(summary, "violation_count")?.takeIf { it != 0.0 }
                if (violations != null) add(Row(t.getValue("violations"), violations.toLong().toString()))
                num(summary, "unreachable_legs")?.takeIf { it != 0.0 }?.let { add(Row(t.getValue("unreachable"), it.toLong().toString())) }
            }
            fun ruleText(v: JsonObject): String {
                val rule = v.get("rule")?.takeIf { it.isJsonPrimitive }?.asString
                return rule?.let { t["rule.$it"] } ?: v.get("message")?.takeIf { it.isJsonPrimitive }?.asString ?: rule ?: ""
            }
            fun objects(o: JsonObject?, key: String): List<JsonObject> =
                o?.get(key)?.takeIf { it.isJsonArray }?.asJsonArray?.filter { it.isJsonObject }?.map { it.asJsonObject } ?: emptyList()

            val bar = Bar(t.getValue("undo"), t.getValue("redo"), t.getValue("refine"), state.canUndo, state.canRedo, state.plan != null,
                if (state.busy) t.getValue("busy") else "", t.getValue("close"))
            val error = state.error?.let { e ->
                t.getValue("error") + (e.code?.let { " ($it" + (e.reason?.let { r -> ", $r" } ?: "") + ")" } ?: "")
            }
            val last = state.last
            val note = if (last != null && last.kind == "refine" && last.answer != null && last.answer.isJsonObject) {
                val a = last.answer.asJsonObject
                val changed = a.get("changed")?.let { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean && it.asBoolean } == true
                if (changed) SMapPlanTexts.fill(t.getValue("refined"), mapOf("n" to (num(a, "moved")?.toLong() ?: 0L))) else t.getValue("notRefined")
            } else null
            val plan = state.plan ?: return SMapPlanPanelModel(bar, error, note, null, emptyList(), null, null, null)

            val summary = state.result?.summary
            val previewSummary = state.preview?.result?.summary
            val total = Total(
                t.getValue("total"),
                summary?.let { totals(it, num(it, "tasks")?.toInt() ?: 0) },
                if (summary == null) t.getValue("pending") else null,
                previewSummary?.let { t.getValue("preview") },
                previewSummary?.let { totals(it, num(it, "tasks")?.toInt() ?: 0) },
            )
            val routes = plan.routes.map { r ->
                val p = state.result?.route(r.vehicleId)
                val rows = p?.let { totals(it, r.stops.size) }
                val violations = objects(p, "violations").map(::ruleText)
                val byId = objects(p, "stops").filter { it.get("type")?.takeIf { x -> x.isJsonPrimitive }?.asString == "job" }
                    .associateBy { SMapPlanIds.of(it.get("id")) }
                val stops = r.stops.mapIndexed { i, id ->
                    val st = byId[id]
                    val arrival = st?.get("arrival")?.takeIf { it.isJsonPrimitive }?.asString?.let(format::clock)?.takeIf { it.isNotEmpty() }
                    val marks = buildList {
                        if (st?.get("reachable")?.let { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean && !it.asBoolean } == true) add(t.getValue("rule.unreachable"))
                        objects(st, "violations").forEach { add(ruleText(it)) }
                    }
                    val locked = id in state.locked
                    Stop(id, r.vehicleId, i + 1, (i + 1).toString(), arrival, arrival?.let { SMapPlanTexts.fill(t.getValue("arrival"), mapOf("time" to it)) },
                        marks.takeIf { it.isNotEmpty() }?.joinToString(", "), locked, if (locked) t.getValue("unlock") else t.getValue("lock"), t.getValue("remove"))
                }
                Route(r.vehicleId, SMapPlanDraw.colorOf(vehicleIds, r.vehicleId, colors), rows, violations, stops, if (r.stops.isEmpty()) t.getValue("noStops") else null)
            }
            val unassigned = Unassigned("${t.getValue("unassigned")} (${plan.unassigned.size})", plan.unassigned.map { Job(it, t.getValue("place")) })
            val choices = state.choices?.takeIf { it.isNotEmpty() }?.map { item ->
                ChoiceGroup(
                    item.job,
                    SMapPlanTexts.fill(t.getValue("choicesFor"), mapOf("job" to item.job)),
                    if (!item.placed && item.choices.isEmpty()) t.getValue("notPlaced") else null,
                    item.choices.mapIndexed { i, c ->
                        val feasible = c.get("feasible")?.let { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean && it.asBoolean } == true
                        val violations = objects(c, "violations")
                        val chosen = item.chosen == i
                        Position(
                            i,
                            SMapPlanTexts.fill(t.getValue("choice"), mapOf("vehicle" to SMapPlanIds.of(c.get("vehicle_id")), "n" to num(c, "position")?.toLong())),
                            SMapPlanTexts.fill(t.getValue("added"), mapOf("distance" to format.distance(num(c, "added_distance_meters")), "time" to format.time(num(c, "added_duration_seconds")))),
                            c.get("arrival")?.takeIf { it.isJsonPrimitive }?.asString?.let { SMapPlanTexts.fill(t.getValue("arrival"), mapOf("time" to format.clock(it))) },
                            if (!feasible && violations.isNotEmpty()) violations.joinToString(", ", transform = ::ruleText) else null,
                            feasible,
                            chosen,
                            if (chosen) t.getValue("chosen") else t.getValue("choose"),
                        )
                    },
                )
            }
            return SMapPlanPanelModel(bar, error, note, total, routes, unassigned, choices, choices?.let { t.getValue("close") })
        }
    }
}
