package ca.superroute.smap

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.io.File
import java.io.InputStream

/**
 * An area of the map to keep on the device (sMap offline regions): a bounding box, a zoom range, a style and a label
 * language. One region holds one style in one language.
 *
 * @param id the app's own name for the region, unique on the device (letters, digits, `-`, `_`, `.`)
 * @param maxZoom null = the map's own maximum (the engine zooms in further on its own)
 * @param style a flavor id (`light`, …) or a saved custom style `custom:<id>`
 * @param language label language as a BCP-47 tag; the device language when null
 */
data class SMapOfflineRegion(
    val id: String,
    val west: Double,
    val south: Double,
    val east: Double,
    val north: Double,
    val minZoom: Int = 0,
    val maxZoom: Int? = null,
    val style: String = SMapFlavor.LIGHT.id,
    val language: String? = null,
) {
    init {
        require(SMapOfflineFiles.ID.matches(id)) { "sMap: a region id is 1–64 letters, digits, '-', '_' or '.'" }
        require(west < east && south < north) { "sMap: a region's west is below its east and its south below its north" }
        SMapStyleUrl.checkStyle(style)
    }

    /** True when the point lies inside the region's area. */
    fun contains(lat: Double, lng: Double): Boolean = lat in south..north && lng in west..east
}

/** What a region would be, as the map service answers before downloading (counts nothing). */
data class SMapOfflineEstimate(
    val tiles: Long,
    val bytes: Long,
    val maxBytes: Long,
    /** False when the region is larger than one region file may be; split it or lower its zoom. */
    val fits: Boolean,
    /** False when this app's key may not download offline regions (a token always may). */
    val allowed: Boolean,
)

/** Where a region stands on the device. */
enum class SMapOfflineState {
    /** Downloaded and usable until [SMapOfflineInfo.expiresAtMillis]. */
    READY,

    /** Past its 30 days: its map data was removed; [SMapOffline.refresh] downloads it again. */
    EXPIRED,
}

/** A region kept on the device. */
data class SMapOfflineInfo(
    val region: SMapOfflineRegion,
    val state: SMapOfflineState,
    /** The language the map service drew its labels in. */
    val language: String,
    val tiles: Long,
    /** Bytes the region takes on the device now. */
    val bytes: Long,
    /** When the map service answered the download (its clock). */
    val downloadedAtMillis: Long,
    val expiresAtMillis: Long,
) {
    val id: String get() = region.id
}

/**
 * The file layer of offline regions, free of Android so it runs in plain JVM tests: the query, the tar the map
 * service sends, the record kept beside each region and the rules on expiry and choice.
 */
object SMapOfflineFiles {
    internal val ID = Regex("^[A-Za-z0-9._-]{1,64}$")

    /** The map service writes this in the region's style; it becomes `file://` + the region's directory. */
    const val PLACEHOLDER = "{{REGION_DIR}}"
    const val DAY_MILLIS = 86_400_000L

    /** A region is refreshed on its own during its last days (when the app allows it). */
    const val REFRESH_BEFORE_MILLIS = 3 * DAY_MILLIS

    const val INFO_FILE = "region.json"
    const val STYLE_FILE = "style-device.json"

    /** The query of `/v1/offline/estimate` and `/v1/offline/region` for [region]. */
    fun query(region: SMapOfflineRegion, language: String): String {
        val q = StringBuilder("bbox=")
            .append(listOf(region.west, region.south, region.east, region.north).joinToString(",") { java.math.BigDecimal(it.toString()).stripTrailingZeros().toPlainString() })
            .append("&minzoom=").append(region.minZoom)
        region.maxZoom?.let { q.append("&maxzoom=").append(it) }
        q.append("&style=").append(SMapStyleUrl.encode(region.style))
        q.append("&lang=").append(SMapStyleUrl.encode(language))
        return q.toString()
    }

    /**
     * Unpacks an uncompressed tar into [dir]. Only plain files under [dir] are written; a name that leaves it is
     * refused.
     *
     * @return the names written
     */
    fun untar(input: InputStream, dir: File): List<String> {
        val root = dir.canonicalFile
        val names = ArrayList<String>()
        val header = ByteArray(512)
        while (true) {
            if (!readFully(input, header)) break
            if (header.all { it.toInt() == 0 }) break
            val name = String(header, 0, 100, Charsets.UTF_8).substringBefore('\u0000')
            val prefix = String(header, 345, 155, Charsets.UTF_8).substringBefore('\u0000')
            val full = if (prefix.isEmpty()) name else "$prefix/$name"
            val size = String(header, 124, 12, Charsets.US_ASCII).trim { it <= ' ' || it == '\u0000' }.toLong(8)
            val type = header[156].toInt().toChar()
            val padded = (size + 511) / 512 * 512
            if (type == '0' || type == '\u0000') {
                val target = File(root, full).canonicalFile
                if (!target.path.startsWith(root.path + File.separator)) throw SMapException("sMap: the region file names a path outside its directory: $full")
                target.parentFile?.mkdirs()
                target.outputStream().use { out -> copy(input, out, size) }
                skip(input, padded - size)
                names += full
            } else {
                skip(input, padded)
            }
        }
        return names
    }

    private fun readFully(input: InputStream, buf: ByteArray): Boolean {
        var at = 0
        while (at < buf.size) {
            val n = input.read(buf, at, buf.size - at)
            if (n < 0) {
                if (at == 0) return false
                throw SMapException("sMap: the region file ends early")
            }
            at += n
        }
        return true
    }

    private fun copy(input: InputStream, out: java.io.OutputStream, size: Long) {
        val buf = ByteArray(64 * 1024)
        var left = size
        while (left > 0) {
            val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (n < 0) throw SMapException("sMap: the region file ends early")
            out.write(buf, 0, n)
            left -= n
        }
    }

    private fun skip(input: InputStream, count: Long) {
        var left = count
        val buf = ByteArray(512)
        while (left > 0) {
            val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (n < 0) throw SMapException("sMap: the region file ends early")
            left -= n
        }
    }

    /** The region's style with its files under [dir] (`file://…`). */
    fun deviceStyle(style: String, dir: File): String = style.replace(PLACEHOLDER, "file://" + dir.absolutePath)

    /** The record kept beside a region. */
    fun infoJson(info: SMapOfflineInfo, etag: String): String {
        val r = info.region
        val o = JsonObject()
        o.addProperty("id", r.id)
        o.addProperty("west", r.west)
        o.addProperty("south", r.south)
        o.addProperty("east", r.east)
        o.addProperty("north", r.north)
        o.addProperty("minZoom", r.minZoom)
        r.maxZoom?.let { o.addProperty("maxZoom", it) }
        o.addProperty("style", r.style)
        r.language?.let { o.addProperty("language", it) }
        o.addProperty("servedLanguage", info.language)
        o.addProperty("tiles", info.tiles)
        o.addProperty("downloadedAt", info.downloadedAtMillis)
        o.addProperty("expiresAt", info.expiresAtMillis)
        o.addProperty("etag", etag)
        return o.toString()
    }

    /** A record read back; null when it is not one. [bytes] is measured by the caller. */
    fun readInfo(json: String, bytes: Long, nowMillis: Long): SMapOfflineInfo? = try {
        val o = JsonParser.parseString(json).asJsonObject
        val region = SMapOfflineRegion(
            id = o["id"].asString,
            west = o["west"].asDouble,
            south = o["south"].asDouble,
            east = o["east"].asDouble,
            north = o["north"].asDouble,
            minZoom = o["minZoom"].asInt,
            maxZoom = o["maxZoom"]?.asInt,
            style = o["style"].asString,
            language = o["language"]?.asString,
        )
        val expires = o["expiresAt"].asLong
        SMapOfflineInfo(
            region = region,
            state = if (nowMillis >= expires) SMapOfflineState.EXPIRED else SMapOfflineState.READY,
            language = o["servedLanguage"].asString,
            tiles = o["tiles"].asLong,
            bytes = bytes,
            downloadedAtMillis = o["downloadedAt"].asLong,
            expiresAtMillis = expires,
        )
    } catch (e: Exception) {
        null
    }

    /** When a region downloaded at [downloadedAtMillis] stops being shown ([validDays] from the region's manifest). */
    fun expiresAt(downloadedAtMillis: Long, validDays: Int): Long = downloadedAtMillis + validDays * DAY_MILLIS

    /** True during a region's last days, when it is refreshed on its own. */
    fun dueForRefresh(info: SMapOfflineInfo, nowMillis: Long): Boolean =
        info.state == SMapOfflineState.READY && info.expiresAtMillis - nowMillis <= REFRESH_BEFORE_MILLIS

    /**
     * The region to show for a view centred on [lat], [lng]: a ready one containing the centre, the smallest such area
     * first (the most detailed for that place); null when none contains it.
     */
    fun pick(regions: List<SMapOfflineInfo>, lat: Double, lng: Double): SMapOfflineInfo? =
        regions.filter { it.state == SMapOfflineState.READY && it.region.contains(lat, lng) }
            .minByOrNull { (it.region.east - it.region.west) * (it.region.north - it.region.south) }

    /** The manifest's `valid_days` (30 when absent). */
    fun validDays(manifest: String): Int = try {
        JsonParser.parseString(manifest).asJsonObject["valid_days"]?.asInt ?: 30
    } catch (e: Exception) {
        30
    }

    /** The manifest's tile count. */
    fun tiles(manifest: String): Long = try {
        JsonParser.parseString(manifest).asJsonObject["tiles"]?.asLong ?: 0
    } catch (e: Exception) {
        0
    }

    /** The manifest's language. */
    fun language(manifest: String, fallback: String): String = try {
        JsonParser.parseString(manifest).asJsonObject["lang"]?.asString ?: fallback
    } catch (e: Exception) {
        fallback
    }
}
