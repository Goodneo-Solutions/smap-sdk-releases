package ca.superroute.smap

import com.google.gson.JsonElement

/**
 * simplestyle (`marker-color`, `marker-size`, `stroke`, `stroke-width`, `stroke-opacity`, `fill`, `fill-opacity`):
 * the style values a layer uses when it gives no colour of its own, so files from geojson.io, GitHub or Google Earth
 * look as they do there; the same expressions as the JavaScript SDK. Each value falls back to the layer's own default.
 */
object SMapSimpleStyle {
    /** A colour read from property [name], else [fallback]. */
    fun color(name: String, fallback: String): JsonElement = SMapJson.arr("to-color", SMapJson.arr("get", name), fallback)

    /** A number read from property [name], else [fallback]. */
    fun number(name: String, fallback: Number): JsonElement =
        SMapJson.arr("to-number", SMapJson.arr("coalesce", SMapJson.arr("get", name), fallback), fallback)

    /** The circle radius for `marker-size`: small 4, large 9, else 6. */
    fun markerRadius(): JsonElement = SMapJson.arr("match", SMapJson.arr("get", "marker-size"), "small", 4, "large", 9, 6)

    /** An outline colour: `stroke`, else `fill`, else [fallback]. */
    fun outlineColor(fallback: String): JsonElement =
        SMapJson.arr("to-color", SMapJson.arr("get", "stroke"), SMapJson.arr("get", "fill"), fallback)
}
