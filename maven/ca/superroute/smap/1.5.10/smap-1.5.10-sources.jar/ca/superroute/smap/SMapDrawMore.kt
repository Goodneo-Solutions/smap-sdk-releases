package ca.superroute.smap

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import org.maplibre.geojson.Geometry
import org.maplibre.geojson.LineString
import org.maplibre.geojson.MultiLineString
import org.maplibre.geojson.MultiPoint
import org.maplibre.geojson.MultiPolygon
import org.maplibre.geojson.Point
import org.maplibre.geojson.Polygon
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** A shape's own look in the drawing tool (1.5.0, G28); what is not given keeps the tool's look. [dash] in line widths. */
data class SMapDrawStyle(
    val color: String? = null,
    val fill: String? = null,
    val fillOpacity: Float? = null,
    val width: Float? = null,
    val opacity: Float? = null,
    val dash: List<Float>? = null,
)

/** The figures of a shape (G28): [length] metres (a line's length, an area's perimeter), [area] m², [radius] metres of a circle. */
data class SMapDrawFigures(val length: Double, val area: Double, val radius: Double?, val feature: JsonObject)

/**
 * The shape being drawn or edited (1.5.0, G28): [mode] the shape drawn (`polygon`, `rectangle`, `circle`, `line`,
 * `point`, `hole`) or `edit`; [feature] the shape so far; [valid] false while the next vertex would make it cross itself.
 */
data class SMapDrawingEvent(
    val mode: String,
    val feature: JsonObject,
    val length: Double,
    val area: Double,
    val radius: Double?,
    val valid: Boolean,
)

/** The drawing tool's figures, texts, checks and snapping (G28), without any view work. */
internal object SMapDrawMath {
    /** The figures of a feature: a line's length, an area's perimeter over every ring and its area, a circle's radius. */
    fun figures(feature: JsonObject): SMapDrawFigures {
        val g = feature.getAsJsonObject("geometry")
        val props = feature.getAsJsonObject("properties")
        var length = 0.0
        val type = g?.get("type")?.asString
        if (g != null && type != "Point") {
            for (r in SMapDrawState.rings(g)) {
                val pts = if (r.closed && r.coords.isNotEmpty()) r.coords + listOf(r.coords[0]) else r.coords
                length += SMapGeo.length(pts)
            }
        }
        val area = if (g != null && (type == "Polygon" || type == "MultiPolygon")) SMapGeo.area(g) else 0.0
        val radius = if (props?.get("shape")?.asString == "circle") props.get("radius")?.asDouble else null
        return SMapDrawFigures(length, area, radius, feature)
    }

    private fun metres(v: Double, locale: Locale): String =
        if (v < 1000) String.format(locale, "%,d m", Math.round(v)) else String.format(locale, "%.2f km", v / 1000)

    private fun squareMetres(v: Double, locale: Locale): String =
        if (v < 100_000) String.format(locale, "%,d m²", Math.round(v)) else String.format(locale, "%.2f km²", v / 1_000_000)

    /** The measure text: a line `1.24 km`, an area `0.58 km² · 3.10 km`, a circle `r 350 m · 0.38 km²`. */
    fun text(f: SMapDrawFigures, locale: Locale = Locale.getDefault()): String = when {
        f.radius != null -> "r ${metres(f.radius, locale)} · ${squareMetres(f.area, locale)}"
        f.area > 0 -> "${squareMetres(f.area, locale)} · ${metres(f.length, locale)}"
        else -> metres(f.length, locale)
    }

    /** Whether an area of [rings] (open, the first the outer one) crosses itself; fewer than three positions never do. */
    fun areaCrosses(rings: List<List<DoubleArray>>): Boolean =
        rings.isNotEmpty() && rings[0].size >= 3 && SMapGeoOps.ringCrosses(rings.filter { it.size >= 3 })

    /** Whether a line crosses or touches itself. */
    fun lineCrosses(line: List<DoubleArray>): Boolean = line.size >= 3 && SMapGeoOps.lineCrosses(line)

    /** Whether a feature's geometry (a line or an area with its holes) crosses itself. */
    fun crosses(geometry: JsonObject): Boolean = when (geometry["type"]?.asString) {
        "LineString" -> lineCrosses(SMapDrawState.rings(geometry).firstOrNull()?.coords ?: emptyList())
        "Polygon" -> areaCrosses(SMapDrawState.rings(geometry).map { it.coords })
        "MultiPolygon" -> geometry.getAsJsonArray("coordinates").any { p ->
            areaCrosses(SMapDrawState.rings(JsonObject().apply { addProperty("type", "Polygon"); add("coordinates", p) }).map { it.coords })
        }
        else -> false
    }

    /**
     * Snapping to other layers (G28 `snapLayers`): the nearest vertex of [geometries] within [tolMetres] of [at], else
     * the nearest point of their lines' and outlines' edges within it; null when nothing is that close. Measured in a
     * flat projection around [at].
     */
    fun snap(at: DoubleArray, tolMetres: Double, geometries: List<Geometry>): DoubleArray? {
        val p = SMapGeoOps.Flat(at)
        var best: DoubleArray? = null
        var bestD = tolMetres
        val edges = ArrayList<List<Point>>()
        fun vertex(c: Point) {
            val q = p.to(doubleArrayOf(c.longitude(), c.latitude()))
            val d = hypot(q[0], q[1])
            if (d <= bestD) { bestD = d; best = doubleArrayOf(c.longitude(), c.latitude()) }
        }
        for (g in geometries) when (g) {
            is Point -> vertex(g)
            is MultiPoint -> g.coordinates().forEach(::vertex)
            is LineString -> { g.coordinates().forEach(::vertex); edges += g.coordinates() }
            is MultiLineString -> g.coordinates().forEach { l -> l.forEach(::vertex); edges += l }
            is Polygon -> g.coordinates().forEach { r -> r.forEach(::vertex); edges += r }
            is MultiPolygon -> g.coordinates().forEach { poly -> poly.forEach { r -> r.forEach(::vertex); edges += r } }
            else -> Unit
        }
        if (best != null) return best
        for (l in edges) {
            for (i in 1 until l.size) {
                val a = p.to(doubleArrayOf(l[i - 1].longitude(), l[i - 1].latitude()))
                val b = p.to(doubleArrayOf(l[i].longitude(), l[i].latitude()))
                val dx = b[0] - a[0]; val dy = b[1] - a[1]; val l2 = dx * dx + dy * dy
                val t = if (l2 > 0) max(0.0, min(1.0, -(a[0] * dx + a[1] * dy) / l2)) else 0.0
                val x = a[0] + t * dx; val y = a[1] + t * dy
                val d = hypot(x, y)
                if (d <= bestD) { bestD = d; best = p.from(doubleArrayOf(x, y)) }
            }
        }
        return best
    }

    /** A shape's properties replaced by [next], its own `shape`, `center` and `radius` kept (G28 setProperties). */
    fun replacedProperties(old: JsonObject?, next: JsonObject): JsonObject {
        val out = next.deepCopy()
        for (k in listOf("shape", "center", "radius")) old?.get(k)?.let { out.add(k, it.deepCopy()) } ?: out.remove(k)
        return out
    }

    /** The hidden render properties of a look (G28 `style`), as the tool's layers read them. */
    fun styleProperties(s: SMapDrawStyle?, dashIndex: Int?): JsonObject = JsonObject().apply {
        s ?: return@apply
        s.color?.let { addProperty("_color", it) }
        s.fill?.let { addProperty("_sfill", it) }
        s.fillOpacity?.let { addProperty("_fillOpacity", it) }
        s.width?.let { addProperty("_width", it) }
        s.opacity?.let { addProperty("_opacity", it) }
        dashIndex?.let { addProperty("_dash", it) }
    }

    fun positions(list: List<DoubleArray>): JsonArray = SMapDrawState.line(list)
}
