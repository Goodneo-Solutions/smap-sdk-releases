package ca.superroute.smap

import ca.superroute.smap.SMapJson.arrOrNull
import ca.superroute.smap.SMapJson.objOrNull
import ca.superroute.smap.SMapJson.str
import ca.superroute.smap.SMapJsNumber.encodeURIComponent
import ca.superroute.smap.SMapXml.elem
import ca.superroute.smap.SMapXml.elems
import ca.superroute.smap.SMapXml.trimmed
import com.google.gson.JsonElement
import com.google.gson.JsonObject

/**
 * Raster XYZ or TileJSON tiles.
 *
 * @param tiles tile URL templates (`{z}/{x}/{y}`); or
 * @param url a template (with `{z}`) or a TileJSON address
 * @param tileSize the tiles' size in pixels
 * @param attribution shown beside the map data credit
 * @param opacity 0..1
 */
data class SMapRasterOptions(
    val tiles: List<String>? = null,
    val url: String? = null,
    val tileSize: Int = 256,
    val attribution: String? = null,
    val opacity: Double? = null,
    val minzoom: Double? = null,
    val maxzoom: Double? = null,
    val slot: SMapSlot? = null,
    val before: String? = null,
    val zIndex: Int = 0,
)

/** An OGC WMS service, drawn as one GetMap image per tile (Web Mercator). [params] are added to every request. */
data class SMapWmsOptions(
    val url: String,
    val layers: String,
    val styles: String = "",
    val format: String = "image/png",
    val transparent: Boolean = true,
    val version: String = "1.3.0",
    val params: Map<String, String> = emptyMap(),
    val tileSize: Int = 256,
    val attribution: String? = null,
    val opacity: Double? = null,
    val minzoom: Double? = null,
    val maxzoom: Double? = null,
    val slot: SMapSlot? = null,
    val before: String? = null,
    val zIndex: Int = 0,
)

/**
 * An OGC WMTS service (Web Mercator matrix sets): [url] is a GetCapabilities address (or a service address it is
 * asked of) or a REST template (`{TileMatrix}`, `{TileRow}`, `{TileCol}`, `{Style}`, `{TileMatrixSet}`);
 * [capabilities] its text instead. [layer], [tileMatrixSet], [style], [format] choose from the capabilities (the
 * first layer, a Web Mercator set, the default style, a PNG format when not given); [encoding] `rest` or `kvp`.
 */
data class SMapWmtsOptions(
    val url: String? = null,
    val capabilities: String? = null,
    val layer: String? = null,
    val tileMatrixSet: String? = null,
    val style: String? = null,
    val format: String? = null,
    val encoding: String? = null,
    val matrixPrefix: String? = null,
    val tileSize: Int = 256,
    val attribution: String? = null,
    val opacity: Double? = null,
    val minzoom: Double? = null,
    val maxzoom: Double? = null,
    val slot: SMapSlot? = null,
    val before: String? = null,
    val zIndex: Int = 0,
)

/**
 * Vector tiles from any address: [tiles] templates, a TileJSON [url] (or a `.pmtiles` / `pmtiles://` archive), or a
 * [pmtiles] archive address, drawn by [layers] (Style Spec layers as JSON text, objects or maps; a layer naming no
 * source reads this one).
 */
data class SMapVectorTilesOptions(
    val tiles: List<String>? = null,
    val url: String? = null,
    val pmtiles: String? = null,
    val layers: List<Any> = emptyList(),
    val attribution: String? = null,
    val minzoom: Double? = null,
    val maxzoom: Double? = null,
    val promoteId: String? = null,
    val slot: SMapSlot? = null,
    val before: String? = null,
    val zIndex: Int = 0,
)

/**
 * An ArcGIS REST service: a MapServer / ImageServer tile service (raster) or a VectorTileServer (drawn by [layers],
 * else by the service's own root style). The service's copyright text is the attribution unless one is given.
 */
data class SMapArcGisOptions(
    val url: String,
    val layers: List<Any>? = null,
    val attribution: String? = null,
    val opacity: Double? = null,
    val minzoom: Double? = null,
    val maxzoom: Double? = null,
    val slot: SMapSlot? = null,
    val before: String? = null,
    val zIndex: Int = 0,
)

/** What an external-layer call adds: one source and its style layers. [ownsSource]: removing the layer removes the source. */
data class SMapExternalLayer(val sourceId: String, val source: JsonObject, val layers: List<JsonObject>, val ownsSource: Boolean)

/** Builds the sources and style layers of the external-layer calls, the same as the JavaScript SDK. Pure. */
object SMapExternalLayers {
    private val FORBIDDEN_HOSTS = Regex("(^|\\.)(google\\.[a-z.]+|googleapis\\.com|gstatic\\.com|ggpht\\.com|virtualearth\\.net|bing\\.com|bing\\.net)$", RegexOption.IGNORE_CASE)
    private val HOST = Regex("^[a-z][a-z0-9+.-]*://([^/?#:]+)", RegexOption.IGNORE_CASE)

    /** Google and Bing tiles are never used (their licences forbid it). */
    fun refuseForbidden(urls: List<String>) {
        for (u in urls) {
            val m = HOST.find(u.replace(Regex("^pmtiles://", RegexOption.IGNORE_CASE), "")) ?: continue
            if (FORBIDDEN_HOSTS.containsMatchIn(m.groupValues[1])) {
                throw IllegalArgumentException("sMap: Google and Bing tiles cannot be used (their licences do not allow it)")
            }
        }
    }

    /** Every address a source names (`url`, `tiles`, `data` when it is one, `urls`). */
    fun sourceUrls(source: JsonObject): List<String> {
        val out = ArrayList<String>()
        source.str("url")?.let { out += it }
        source.str("data")?.let { out += it }
        source.arrOrNull("tiles")?.forEach { if (it.isJsonPrimitive) out += it.asString }
        source.arrOrNull("urls")?.forEach { if (it.isJsonPrimitive) out += it.asString }
        return out
    }

    private fun JsonObject.opt(key: String, v: Any?) { if (v != null) add(key, SMapJson.of(v)) }

    private fun raster(id: String, source: JsonObject, opacity: Double?, minzoom: Double?, maxzoom: Double?): SMapExternalLayer {
        refuseForbidden(sourceUrls(source))
        val layer = JsonObject().apply {
            addProperty("id", id); addProperty("type", "raster"); addProperty("source", id)
            opt("minzoom", minzoom); opt("maxzoom", maxzoom)
            if (opacity != null) add("paint", SMapJson.obj("raster-opacity" to opacity))
        }
        return SMapExternalLayer(id, source, listOf(layer), ownsSource = true)
    }

    fun raster(id: String, o: SMapRasterOptions): SMapExternalLayer {
        val source = JsonObject().apply { addProperty("type", "raster"); addProperty("tileSize", o.tileSize) }
        when {
            !o.tiles.isNullOrEmpty() -> source.add("tiles", SMapJson.of(o.tiles))
            o.url != null && o.url.contains("{z}") -> source.add("tiles", SMapJson.arr(o.url))
            !o.url.isNullOrEmpty() -> source.addProperty("url", o.url)
            else -> throw IllegalArgumentException("sMap: addRasterLayer needs tiles or url")
        }
        source.opt("attribution", o.attribution); source.opt("minzoom", o.minzoom); source.opt("maxzoom", o.maxzoom)
        return raster(id, source, o.opacity, o.minzoom, o.maxzoom)
    }

    /** A WMS GetMap tile URL template (Web Mercator; the engine fills `{bbox-epsg-3857}`). */
    fun wmsTileUrl(o: SMapWmsOptions): String {
        if (o.url.isEmpty() || o.layers.isEmpty()) throw IllegalArgumentException("sMap: a WMS layer needs url and layers")
        val p = linkedMapOf(
            "SERVICE" to "WMS", "REQUEST" to "GetMap", "VERSION" to o.version, "LAYERS" to o.layers, "STYLES" to o.styles,
            "FORMAT" to o.format, "TRANSPARENT" to if (o.transparent) "TRUE" else "FALSE",
            "WIDTH" to o.tileSize.toString(), "HEIGHT" to o.tileSize.toString(),
        )
        p[if (o.version == "1.3.0") "CRS" else "SRS"] = "EPSG:3857"
        p.putAll(o.params)
        val sep = if ('?' !in o.url) "?" else if (o.url.endsWith("?") || o.url.endsWith("&")) "" else "&"
        return o.url + sep + p.entries.joinToString("&") { (k, v) -> k + "=" + encodeURIComponent(v) } + "&BBOX={bbox-epsg-3857}"
    }

    fun wms(id: String, o: SMapWmsOptions): SMapExternalLayer {
        val source = SMapJson.obj("type" to "raster", "tiles" to listOf(wmsTileUrl(o)), "tileSize" to o.tileSize)
        source.opt("attribution", o.attribution); source.opt("minzoom", o.minzoom); source.opt("maxzoom", o.maxzoom)
        return raster(id, source, o.opacity, o.minzoom, o.maxzoom)
    }

    /** True when [url] is a WMTS REST template rather than a capabilities or service address. */
    fun isWmtsTemplate(url: String): Boolean = Regex("\\{TileMatrix\\}|\\{TileRow\\}|\\{z\\}", RegexOption.IGNORE_CASE).containsMatchIn(url)

    /** The GetCapabilities address of a WMTS [url] (kept when it already is one). */
    fun wmtsCapabilitiesUrl(url: String): String =
        if (Regex("request=getcapabilities", RegexOption.IGNORE_CASE).containsMatchIn(url) || Regex("\\.xml(\\?|$)", RegexOption.IGNORE_CASE).containsMatchIn(url)) url
        else url + (if ('?' !in url) "?" else "&") + "SERVICE=WMTS&REQUEST=GetCapabilities"

    private fun ci(name: String) = Regex("\\{$name\\}", RegexOption.IGNORE_CASE)

    /** A WMTS layer from a REST template. */
    fun wmtsTemplate(id: String, o: SMapWmtsOptions): SMapExternalLayer {
        val tile = (o.url ?: "").replace(ci("TileMatrixSet"), Regex.escapeReplacement(o.tileMatrixSet ?: "GoogleMapsCompatible"))
            .replace(ci("TileMatrix"), Regex.escapeReplacement((o.matrixPrefix ?: "") + "{z}"))
            .replace(ci("TileRow"), "{y}").replace(ci("TileCol"), "{x}")
            .replace(ci("Style"), Regex.escapeReplacement(o.style ?: "default"))
        refuseForbidden(listOf(tile))
        val source = SMapJson.obj("type" to "raster", "tiles" to listOf(tile), "tileSize" to o.tileSize)
        source.opt("attribution", o.attribution); source.opt("minzoom", o.minzoom); source.opt("maxzoom", o.maxzoom)
        return raster(id, source, o.opacity, o.minzoom, o.maxzoom)
    }

    /** A WMTS layer from its capabilities' text; [o]'s `url` (without query) is used for a GetTile address not named. */
    fun wmtsFromCapabilities(id: String, xml: String, o: SMapWmtsOptions): SMapExternalLayer {
        val source = wmtsSource(xml, o.copy(url = o.url?.substringBefore('?')))
        source.opt("attribution", o.attribution); source.opt("minzoom", o.minzoom); source.opt("maxzoom", o.maxzoom)
        return raster(id, source, o.opacity, o.minzoom, o.maxzoom)
    }

    // ------------------------------------------------------------------ WMTS capabilities

    private const val WEB_MERCATOR_SCALE0 = 559082264.0287178
    private val MERCATOR_CRS = Regex("(3857|900913|3785|102100|102113|GoogleMapsCompatible)", RegexOption.IGNORE_CASE)

    private class Matrix(val id: String, val zoom: Double, val tileWidth: Int)
    private class MatrixSet(val id: String, val crs: String, val wellKnown: String, val matrices: List<Matrix>)
    private class WmtsLayer(val id: String, val styles: List<Pair<String, Boolean>>, val formats: List<String>,
                            val sets: List<String>, val resources: List<Pair<String?, String?>>, val bounds: List<Double>?)

    /**
     * A raster source for one WMTS layer from its capabilities (KVP or REST; Web Mercator matrix sets only), the same
     * as the JavaScript SDK's `wmtsSource`.
     */
    fun wmtsSource(xml: String, o: SMapWmtsOptions): JsonObject {
        val doc = SMapXml.parse(xml.removePrefix("﻿"))
        val caps = SMapXml.descendants(doc, "Capabilities").firstOrNull() ?: doc
        val contents = elem(caps, "Contents") ?: throw IllegalArgumentException("sMap: not WMTS capabilities")
        val sets = LinkedHashMap<String, MatrixSet>()
        for (s in elems(contents, "TileMatrixSet")) {
            val id = trimmed(elem(s, "Identifier"))
            val matrices = elems(s, "TileMatrix").map { m ->
                val scale = SMapJsNumber.parseFloat(trimmed(elem(m, "ScaleDenominator")))
                Matrix(trimmed(elem(m, "Identifier")), SMapFormats.jsRound(Math.log(WEB_MERCATOR_SCALE0 / scale) / Math.log(2.0)),
                    SMapJsNumber.parseInt(trimmed(elem(m, "TileWidth")))?.takeIf { it != 0 } ?: 256)
            }
            sets[id] = MatrixSet(id, trimmed(elem(s, "SupportedCRS")), trimmed(elem(s, "WellKnownScaleSet")), matrices)
        }
        val layers = elems(contents, "Layer").map { l ->
            val bbox = elem(l, "WGS84BoundingBox")
            fun corner(name: String) = bbox?.let { b -> trimmed(elem(b, name)).split(SMapXml.JS_SPACES).map { SMapJsNumber.number(it) } }
            val lower = corner("LowerCorner")
            val upper = corner("UpperCorner")
            WmtsLayer(
                trimmed(elem(l, "Identifier")),
                elems(l, "Style").map { trimmed(elem(it, "Identifier")) to (it.attrs["isDefault"] == "true") },
                elems(l, "Format").map { trimmed(it) },
                elems(l, "TileMatrixSetLink").map { trimmed(elem(it, "TileMatrixSet")) },
                elems(l, "ResourceURL").filter { (it.attrs["resourceType"] ?: "tile") == "tile" }.map { it.attrs["format"] to it.attrs["template"] },
                if (lower != null && upper != null && lower.size >= 2 && upper.size >= 2) listOf(lower[0], lower[1], upper[0], upper[1]) else null,
            )
        }
        var getTile: String? = null
        for (op in SMapXml.descendants(caps, "Operation")) {
            if (op.attrs["name"] != "GetTile") continue
            for (g in SMapXml.descendants(op, "Get")) {
                val enc = SMapXml.descendants(g, "Value").map { trimmed(it) }
                if (getTile == null && (enc.isEmpty() || "KVP" in enc)) getTile = SMapXml.attr(g, "href")
            }
        }
        val layer = (if (o.layer != null) layers.firstOrNull { it.id == o.layer } else layers.firstOrNull())
            ?: throw IllegalArgumentException("sMap: WMTS has no layer ${o.layer ?: ""}")
        val setId = o.tileMatrixSet ?: layer.sets.firstOrNull { id ->
            val s = sets[id]
            s != null && (MERCATOR_CRS.containsMatchIn(s.crs) || MERCATOR_CRS.containsMatchIn(s.wellKnown) || MERCATOR_CRS.containsMatchIn(id))
        }
        val set = sets[setId] ?: throw IllegalArgumentException("sMap: WMTS layer ${layer.id} has no Web Mercator matrix set")
        val ms = set.matrices.sortedBy { it.zoom }
        if (ms.isEmpty()) throw IllegalArgumentException("sMap: WMTS matrix set ${set.id} has no matrices")
        var prefix: String? = null
        for (m in ms) {
            val r = Regex("^(.*?)(\\d+)$").find(m.id)
            if (r == null || r.groupValues[2].toDouble() != m.zoom) throw IllegalArgumentException("sMap: WMTS matrix set ${set.id}: matrix ${m.id} is not named by its zoom")
            if (prefix == null) prefix = r.groupValues[1] else if (prefix != r.groupValues[1]) throw IllegalArgumentException("sMap: WMTS matrix set ${set.id} mixes matrix names")
        }
        val style = o.style ?: (layer.styles.firstOrNull { it.second } ?: layer.styles.firstOrNull())?.first ?: "default"
        val format = o.format ?: layer.formats.firstOrNull { it.contains("png", ignoreCase = true) } ?: layer.formats.firstOrNull() ?: "image/png"
        val rest = layer.resources.firstOrNull { o.format == null || it.first == o.format } ?: layer.resources.firstOrNull()
        val tile = if (rest != null && o.encoding != "kvp") {
            (rest.second ?: "").replace(ci("TileMatrixSet"), Regex.escapeReplacement(set.id))
                .replace(ci("TileMatrix"), Regex.escapeReplacement(prefix + "{z}"))
                .replace(ci("TileRow"), "{y}").replace(ci("TileCol"), "{x}").replace(ci("Style"), Regex.escapeReplacement(style))
        } else {
            var href = getTile ?: o.url ?: throw IllegalArgumentException("sMap: WMTS capabilities name no GetTile address")
            val sep = if ('?' !in href) "?" else if (href.endsWith("?") || href.endsWith("&")) "" else "&"
            if (sep == "?" && o.url != null && href == o.url) href = href.substringBefore('?')
            href + sep + "SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=" + encodeURIComponent(layer.id) + "&STYLE=" + encodeURIComponent(style) +
                "&FORMAT=" + encodeURIComponent(format) + "&TILEMATRIXSET=" + encodeURIComponent(set.id) + "&TILEMATRIX=" + encodeURIComponent(prefix!!) + "{z}&TILEROW={y}&TILECOL={x}"
        }
        val src = SMapJson.obj("type" to "raster", "tiles" to listOf(tile), "tileSize" to ms[0].tileWidth,
            "minzoom" to ms[0].zoom, "maxzoom" to ms[ms.size - 1].zoom)
        layer.bounds?.let { src.add("bounds", SMapJson.of(it)) }
        return src
    }

    // ------------------------------------------------------------------ vector tiles, ArcGIS

    fun vectorTiles(id: String, o: SMapVectorTilesOptions): SMapExternalLayer {
        val source = JsonObject().apply { addProperty("type", "vector") }
        val pm = Regex("^pmtiles://", RegexOption.IGNORE_CASE)
        val archive = o.pmtiles ?: o.url?.takeIf { pm.containsMatchIn(it) || Regex("\\.pmtiles(\\?|$)", RegexOption.IGNORE_CASE).containsMatchIn(it) }
        when {
            archive != null -> source.addProperty("url", if (pm.containsMatchIn(archive)) archive else "pmtiles://$archive")
            !o.tiles.isNullOrEmpty() -> source.add("tiles", SMapJson.of(o.tiles))
            !o.url.isNullOrEmpty() -> source.addProperty("url", o.url)
            else -> throw IllegalArgumentException("sMap: addVectorTiles needs tiles, url or pmtiles")
        }
        source.opt("attribution", o.attribution); source.opt("minzoom", o.minzoom); source.opt("maxzoom", o.maxzoom)
        source.opt("promoteId", o.promoteId)
        refuseForbidden(sourceUrls(source))
        val layers = o.layers.map { l ->
            val layer = SMapStyleSpec.layerObject(l).deepCopy()
            if (layer.get("source") == null || layer.get("source").isJsonNull) layer.addProperty("source", id)
            layer
        }
        return SMapExternalLayer(id, source, layers, ownsSource = false)
    }

    /** An ArcGIS address without its query and trailing slashes; throws unless it ends in a known service. */
    fun arcGisBase(url: String): String {
        val base = url.substringBefore('?').trimEnd('/')
        refuseForbidden(listOf(base))
        if (!isArcGisVector(base) && !Regex("/(MapServer|ImageServer)$", RegexOption.IGNORE_CASE).containsMatchIn(base)) {
            throw IllegalArgumentException("sMap: an ArcGIS address ends in /MapServer, /ImageServer or /VectorTileServer")
        }
        return base
    }

    fun isArcGisVector(base: String): Boolean = Regex("/VectorTileServer$", RegexOption.IGNORE_CASE).containsMatchIn(base)

    /** The address of the service's root style (`defaultStyles` of its description, else `resources/styles`). */
    fun arcGisStyleUrl(base: String, info: JsonObject): String = base + "/" + (info.str("defaultStyles") ?: "resources/styles") + "/root.json"

    /**
     * An ArcGIS layer from the service's description ([info], `?f=json`; `{}` when it could not be read) and, for a
     * VectorTileServer without [SMapArcGisOptions.layers], its root style's layers ([styleLayers]).
     */
    fun arcGis(id: String, o: SMapArcGisOptions, info: JsonObject, styleLayers: List<JsonElement>? = null): SMapExternalLayer {
        val base = arcGisBase(o.url)
        val attribution = o.attribution ?: info.str("copyrightText")?.takeIf { it.isNotEmpty() }
        if (!isArcGisVector(base)) {
            val rows = info.objOrNull("tileInfo")?.get("rows")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber && it.asDouble != 0.0 }?.asInt ?: 256
            return raster(id, SMapRasterOptions(tiles = listOf("$base/tile/{z}/{y}/{x}"), tileSize = rows, attribution = attribution,
                opacity = o.opacity, minzoom = o.minzoom, maxzoom = o.maxzoom))
        }
        val tiles = info.arrOrNull("tiles")?.takeIf { it.size() > 0 }?.map { t ->
            val s = t.asString
            if (Regex("^https?:").containsMatchIn(s)) s else "$base/$s"
        } ?: listOf("$base/tile/{z}/{y}/{x}.pbf")
        val layers = (o.layers ?: styleLayers ?: emptyList()).map { l ->
            val c = SMapStyleSpec.layerObject(if (l is JsonElement && l.isJsonObject) l.asJsonObject else l).deepCopy()
            if (c.get("source") != null && !c.get("source").isJsonNull) c.addProperty("source", id)
            c
        }
        return vectorTiles(id, SMapVectorTilesOptions(tiles = tiles, layers = layers, attribution = attribution, minzoom = o.minzoom, maxzoom = o.maxzoom))
    }
}
