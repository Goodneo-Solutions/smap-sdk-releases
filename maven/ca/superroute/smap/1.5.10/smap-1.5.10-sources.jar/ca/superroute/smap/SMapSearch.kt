package ca.superroute.smap

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.maplibre.android.geometry.LatLng

/**
 * One answer of a search tool's [SMapSearchOptions.search] (1.5.0, G35): [label] shown in the list, the map fits
 * [bounds] (any [SMap.fitBounds] input) or flies to [position]; [data] is the app's own.
 */
data class SMapSearchResult(
    val label: String,
    val position: LatLng? = null,
    val bounds: Any? = null,
    val data: Map<String, Any?> = emptyMap(),
)

/**
 * The search tool (1.5.0, G35): the app answers [search] (the SDK never calls a geocoder); [onPick] is told the
 * result chosen. [placeholder] null: *Search for an address* in the map's language.
 *
 * @param minChars letters before asking
 * @param maxResults results shown at most (null: all)
 * @param zoom the zoom a position is shown at (a fit zooms in to 17 at most)
 * @param debounceMillis after the last key before asking
 * @param durationMillis of the move to the pick
 */
data class SMapSearchOptions(
    val search: suspend (String) -> List<SMapSearchResult>,
    val onPick: ((SMapSearchResult) -> Unit)? = null,
    val placeholder: String? = null,
    val minChars: Int = 3,
    val maxResults: Int? = null,
    val zoom: Double = 16.0,
    val debounceMillis: Long = 250,
    val durationMillis: Long = 1200,
)

/** What the search tool does without a screen: when it asks, which answer it shows, where the map goes (G35). */
internal class SMapSearchController(
    private val scope: CoroutineScope,
    private val o: SMapSearchOptions,
    private val show: (List<SMapSearchResult>?) -> Unit,
    private val report: (Throwable) -> Unit,
) {
    private var job: Job? = null
    private var asked = 0

    /** The text changed: asks after the pause (null list: nothing to show). An older answer that comes late is dropped. */
    fun text(text: String) {
        job?.cancel()
        val question = ++asked
        val t = text.trim()
        if (t.length < o.minChars) { show(null); return }
        job = scope.launch {
            delay(o.debounceMillis)
            val answer = try {
                o.search(t)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                if (question == asked) { report(e); show(null) }
                return@launch
            }
            if (question != asked) return@launch
            show(o.maxResults?.let { answer.take(it) } ?: answer)
        }
    }

    /** Forgets the question in flight (the list was closed). */
    fun close() { job?.cancel(); asked++ }

    sealed class Move {
        data class Fit(val bounds: Any) : Move()
        data class Fly(val position: LatLng, val zoom: Double) : Move()
        object None : Move()
    }

    /** Where the map goes for [r]: its bounds fitted, else its position at [SMapSearchOptions.zoom], else nowhere. */
    fun move(r: SMapSearchResult): Move = when {
        r.bounds != null -> Move.Fit(r.bounds)
        r.position != null -> Move.Fly(r.position, o.zoom)
        else -> Move.None
    }

    companion object {
        /** The most a fit zooms in. */
        const val FIT_MAX_ZOOM = 17.0
    }
}

/** The search tool's view (G35): a search field and, under it, the results or the *No results* line. */
@SuppressLint("ViewConstructor")
internal class SMapSearchToolView(context: Context, private val map: SMap, private val o: SMapSearchOptions) : LinearLayout(context) {
    private val d = resources.displayMetrics.density
    private val field = EditText(context)
    private val list = LinearLayout(context)
    private val scroll = ScrollView(context)
    private var results: List<SMapSearchResult> = emptyList()
    private var picking = false
    val controller = SMapSearchController(map.scope, o, ::show) { map.reportError(it) }

    init {
        orientation = VERTICAL
        val card = GradientDrawable().apply { cornerRadius = 10 * d; setColor(Color.WHITE) }
        field.apply {
            hint = o.placeholder ?: SMapTexts.text(map.language, "searchPlaceholder")
            contentDescription = SMapTexts.text(map.language, "search")
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            background = card
            elevation = 2 * d
            setPadding((12 * d).toInt(), (10 * d).toInt(), (12 * d).toInt(), (10 * d).toInt())
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: Editable?) { if (!picking) controller.text(s?.toString() ?: "") }
            })
            setOnEditorActionListener { _, action, event ->
                val search = action == EditorInfo.IME_ACTION_SEARCH || (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
                if (search) results.firstOrNull()?.let(::pick)
                search
            }
        }
        addView(field, LayoutParams((280 * d).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT))
        list.orientation = VERTICAL
        scroll.addView(list)
        scroll.background = GradientDrawable().apply { cornerRadius = 10 * d; setColor(Color.WHITE) }
        scroll.elevation = 2 * d
        scroll.visibility = View.GONE
        addView(scroll, LayoutParams((280 * d).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = (4 * d).toInt() })
    }

    // Up to six rows in view; the list scrolls past them.
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val row = (40 * d).toInt()
        if (scroll.visibility == View.VISIBLE && scroll.measuredHeight > row * 6) {
            scroll.layoutParams = scroll.layoutParams.apply { height = row * 6 }
            super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        }
    }

    private fun row(text: String, enabled: Boolean, onTap: (() -> Unit)?): TextView = TextView(context).apply {
        this.text = text
        setSingleLine(true)
        ellipsize = TextUtils.TruncateAt.END
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        setTextColor(if (enabled) Color.rgb(31, 41, 55) else Color.rgb(107, 114, 128))
        gravity = Gravity.CENTER_VERTICAL
        minHeight = (40 * d).toInt()
        setPadding((12 * d).toInt(), 0, (12 * d).toInt(), 0)
        if (onTap != null) { isClickable = true; setOnClickListener { onTap() } }
    }

    private fun show(found: List<SMapSearchResult>?) {
        results = found ?: emptyList()
        list.removeAllViews()
        scroll.layoutParams = scroll.layoutParams.apply { height = ViewGroup.LayoutParams.WRAP_CONTENT }
        if (found == null) { scroll.visibility = View.GONE; return }
        if (found.isEmpty()) list.addView(row(SMapTexts.text(map.language, "noResults"), false, null))
        else found.forEach { r -> list.addView(row(r.label, true) { pick(r) }) }
        scroll.visibility = View.VISIBLE
    }

    private fun pick(r: SMapSearchResult) {
        controller.close()
        picking = true
        field.setText(r.label)
        field.setSelection(field.text.length)
        picking = false
        show(null)
        (context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)?.hideSoftInputFromWindow(field.windowToken, 0)
        field.clearFocus()
        when (val m = controller.move(r)) {
            is SMapSearchController.Move.Fit -> map.fitBounds(m.bounds, SMapFitOptions(maxZoom = SMapSearchController.FIT_MAX_ZOOM, durationMillis = o.durationMillis))
            // Flown to, never further out than the view is.
            is SMapSearchController.Move.Fly -> map.easeTo(SMapCameraOptions(center = m.position, zoom = maxOf(m.zoom, map.getZoom())), o.durationMillis)
            SMapSearchController.Move.None -> Unit
        }
        o.onPick?.invoke(r)
    }
}
