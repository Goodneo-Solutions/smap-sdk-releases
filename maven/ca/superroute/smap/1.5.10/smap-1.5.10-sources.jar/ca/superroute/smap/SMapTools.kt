package ca.superroute.smap

/**
 * Where a tool sits: a corner of the map, or [NONE] for a view that stays where the app put it.
 *
 * [TOOLBAR] is for the tools control only ([SMapToolsOptions.control], its default): the last button of the map's
 * toolbar, the corner of the first [SMapToolKind.ZOOM] tool, else of the first [SMapToolKind.COMPASS] tool, else the
 * top left. `addTool` refuses it.
 */
enum class SMapToolPosition { TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT, NONE, TOOLBAR }

/**
 * The tools the SDK makes.
 *
 * - [COMPASS]: the engine's compass, shown while the map is rotated; a tap turns north.
 * - [ZOOM]: + / − buttons.
 * - [SCALE]: a scale bar, metric, imperial in regions that use miles.
 * - [LOCATE]: centres the map on the device's position. It uses the position only while the app holds the location
 *   permission, never asks for it, and reports a missing permission to [SMapOptions.onError].
 */
enum class SMapToolKind(internal val label: String, internal val position: SMapToolPosition) {
    COMPASS("Compass", SMapToolPosition.TOP_LEFT),
    ZOOM("Zoom", SMapToolPosition.TOP_LEFT),
    SCALE("Scale", SMapToolPosition.BOTTOM_LEFT),
    LOCATE("Locate", SMapToolPosition.TOP_LEFT),
}

/** The tools control's texts (English by default). */
data class SMapToolsLabels(
    val button: String = "Map tools",
    val showAll: String = "Show all",
    val hideAll: String = "Hide all",
)

/**
 * Map tools at start.
 *
 * @param hidden ids of the tools hidden from the start
 * @param control where the tools control sits: [SMapToolPosition.TOOLBAR] (the default, the last button of the map's
 *   toolbar), a corner, or null to leave it out (switch tools from code then)
 * @param labels the tools control's texts
 * @param onChange called after every change of the tools' visibility; the SDK keeps no state itself
 */
data class SMapToolsOptions(
    val hidden: Set<String> = emptySet(),
    val control: SMapToolPosition? = SMapToolPosition.TOOLBAR,
    val labels: SMapToolsLabels = SMapToolsLabels(),
    val onChange: ((SMapToolsChange) -> Unit)? = null,
) {
    init {
        require(control != SMapToolPosition.NONE) { "sMap: the tools control sits in a corner" }
    }
}

/** A tool as [SMap.tools] lists it. */
data class SMapToolState(val id: String, val label: String, val visible: Boolean)

/** A change of the tools' visibility: the ids of the registered tools hidden now, and the tool switched (null: all). */
data class SMapToolsChange(val hidden: List<String>, val changed: String?)

/**
 * The tools of one map without any view: ids, labels, positions, what is hidden, and the change listeners. The map
 * keeps a view per tool beside it ([T]); every rule of the tools lives here so it can be tested without a screen.
 */
internal class SMapToolRegistry<T>(hidden: Set<String>) {

    /** A tool; [layers] are the layer ids of a data-layer tool (no view, no corner), null for any other tool. */
    class Entry<T>(
        val id: String,
        val label: String,
        val position: SMapToolPosition,
        val kind: SMapToolKind?,
        val payload: T,
        val layers: List<String>? = null,
    )

    private val entries = ArrayList<Entry<T>>()
    private val hiddenIds = LinkedHashSet(hidden)
    private val listeners = ArrayList<(SMapToolsChange) -> Unit>()

    val all: List<Entry<T>> get() = entries.toList()

    operator fun get(id: String): Entry<T>? = entries.firstOrNull { it.id == id }

    fun isVisible(id: String): Boolean = id !in hiddenIds

    fun states(): List<SMapToolState> = entries.map { SMapToolState(it.id, it.label, isVisible(it.id)) }

    /** The corner of the map's toolbar: the first zoom tool's, else the first compass tool's, else the top left. */
    fun toolbarCorner(): SMapToolPosition {
        val corners = setOf(SMapToolPosition.TOP_LEFT, SMapToolPosition.TOP_RIGHT, SMapToolPosition.BOTTOM_LEFT, SMapToolPosition.BOTTOM_RIGHT)
        return entries.firstOrNull { it.kind == SMapToolKind.ZOOM && it.position in corners }?.position
            ?: entries.firstOrNull { it.kind == SMapToolKind.COMPASS && it.position in corners }?.position
            ?: SMapToolPosition.TOP_LEFT
    }

    /** Is [layerId] named by a hidden data-layer tool? A layer added later under that id starts hidden. */
    fun hidesLayer(layerId: String): Boolean = entries.any { e -> e.layers?.contains(layerId) == true && !isVisible(e.id) }

    /** Adds an entry, replacing one with the same id (returned, so its view can be taken off the map). */
    fun add(entry: Entry<T>): Entry<T>? {
        checkId(entry.id)
        val old = remove(entry.id)
        entries.add(entry)
        return old
    }

    fun remove(id: String): Entry<T>? {
        val i = entries.indexOfFirst { it.id == id }
        return if (i < 0) null else entries.removeAt(i)
    }

    /** Switches one tool; the ids whose visibility changed (empty for an unknown id or no change). */
    fun setVisible(id: String, visible: Boolean): List<String> {
        if (this[id] == null || isVisible(id) == visible) return emptyList()
        if (visible) hiddenIds.remove(id) else hiddenIds.add(id)
        notify(id)
        return listOf(id)
    }

    /** Switches every tool; the ids whose visibility changed. */
    fun setAllVisible(visible: Boolean): List<String> {
        val changed = entries.filter { isVisible(it.id) != visible }.map { it.id }
        if (changed.isEmpty()) return changed
        changed.forEach { if (visible) hiddenIds.remove(it) else hiddenIds.add(it) }
        notify(null)
        return changed
    }

    fun addListener(listener: (SMapToolsChange) -> Unit) { listeners.add(listener) }
    fun removeListener(listener: (SMapToolsChange) -> Unit) { listeners.remove(listener) }

    private fun notify(changed: String?) {
        val event = SMapToolsChange(entries.filter { !isVisible(it.id) }.map { it.id }, changed)
        listeners.toList().forEach { it(event) }
    }

    companion object {
        private val ID = Regex("^[A-Za-z0-9._-]{1,64}$")

        fun checkId(id: String) {
            require(ID.matches(id)) { "sMap: a tool id is 1-64 letters, digits, \"-\", \"_\" or \".\"" }
        }

        /** The layer ids of a data-layer tool: one or more, none blank; a repeated id counts once. */
        fun checkLayers(layers: List<String>): List<String> {
            require(layers.isNotEmpty() && layers.none { it.isBlank() }) { "sMap: a data-layer tool names one or more layer ids" }
            return layers.distinct()
        }

        /** Refuses [SMapToolPosition.TOOLBAR] for a tool: it is the tools control's place only. */
        fun checkPosition(position: SMapToolPosition) {
            require(position != SMapToolPosition.TOOLBAR) { "sMap: the toolbar is the tools control's place, not a tool's" }
        }

        /** Imperial scale bars where the miles are the road unit. */
        fun usesMiles(country: String?): Boolean = country?.uppercase() in setOf("US", "GB", "LR", "MM")

        /**
         * The scale bar's length and text for [metersPerPixel] at most [maxPixels] wide: the largest round distance
         * (1, 2 or 5 × a power of ten; feet below a mile, then miles) that fits.
         */
        fun scaleBar(metersPerPixel: Double, maxPixels: Double, imperial: Boolean): Pair<Double, String> {
            if (!(metersPerPixel > 0) || !(maxPixels > 0)) return Pair(0.0, "")
            val maxMeters = metersPerPixel * maxPixels
            if (imperial) {
                val feet = maxMeters / 0.3048
                if (feet < 5280) {
                    val d = round(feet)
                    return Pair(d * 0.3048 / metersPerPixel, "${fmt(d)} ft")
                }
                val d = round(feet / 5280)
                return Pair(d * 1609.344 / metersPerPixel, "${fmt(d)} mi")
            }
            if (maxMeters < 1000) {
                val d = round(maxMeters)
                return Pair(d / metersPerPixel, "${fmt(d)} m")
            }
            val d = round(maxMeters / 1000)
            return Pair(d * 1000 / metersPerPixel, "${fmt(d)} km")
        }

        private fun round(value: Double): Double {
            if (value <= 0) return 0.0
            var p = 1.0
            while (p * 10 <= value) p *= 10
            while (p > value) p /= 10
            val d = value / p
            return p * when {
                d >= 5 -> 5
                d >= 2 -> 2
                else -> 1
            }
        }

        private fun fmt(d: Double): String = if (d >= 1 || d == 0.0) d.toLong().toString() else d.toBigDecimal().stripTrailingZeros().toPlainString()
    }
}
