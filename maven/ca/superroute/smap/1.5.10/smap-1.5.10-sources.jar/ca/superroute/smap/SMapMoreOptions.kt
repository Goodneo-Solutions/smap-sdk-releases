package ca.superroute.smap

import android.graphics.Typeface

/**
 * How [SMap.addImage] puts an image on the map (1.5.0, G25).
 *
 * @param pixelRatio image pixels per dp (default: the bitmap's own density, which a bitmap made in code has from the
 *   screen)
 * @param sdf the image is a signed distance field (alpha 0.75 is its edge), drawn in the points' `iconColor`
 */
data class SMapImageOptions(val pixelRatio: Float? = null, val sdf: Boolean = false)

/**
 * One character of a font drawn into an image of the app's (G25), the native stand-in for the Web SDK's pin glyphs:
 * on a round disc of [background] when given; [sdf] makes it colourable by `iconColor`.
 */
data class SMapGlyph(
    val text: String,
    val typeface: Typeface = Typeface.DEFAULT_BOLD,
    val sizeDp: Float = 24f,
    val color: String = "#000000",
    val background: String? = null,
    val sdf: Boolean = false,
)

/**
 * Circles of a radius in metres around points (1.5.0, G26), drawn true to the ground at every zoom with every option
 * of areas ([area]). [radius] metres per feature (default the feature's `radius` property); a feature without one
 * above 0 is not drawn. [steps] sides of each circle.
 */
data class SMapCircleOptions(
    val radius: SMapFeatureValue<Double> = SMapFeatureValue.property("radius"),
    val steps: Int = 64,
    val area: SMapPolygonOptions = SMapPolygonOptions(),
)

/**
 * Arrowheads along lines (1.5.0, G34): every [spacing] dp along each line, or with [share] (0–1, e.g. 0.15) at 15, 30,
 * … 90 % of each line's length at every zoom. [color] null draws them in the line's colour.
 */
data class SMapLineArrows(
    val spacing: Float = 80f,
    val share: Float? = null,
    val sizeDp: Float = 14f,
    val color: String? = null,
    val opacity: Float = 0.8f,
)
