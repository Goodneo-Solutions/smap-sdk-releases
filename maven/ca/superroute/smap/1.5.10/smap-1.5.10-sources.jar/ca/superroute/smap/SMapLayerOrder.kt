package ca.superroute.smap

/**
 * The draw order of the caller's layers: a higher zIndex draws on top, then the order added. Adding an id again
 * moves it to the top of its zIndex.
 *
 * A layer may name a [SMapSlot] (drawn under that slot's basemap layer) or a layer to draw under (`before`); a layer
 * with neither draws on top, as in 1.0.
 */
class SMapLayerOrder {
    private class Entry(val id: String, val zIndex: Int, val seq: Long, val slot: SMapSlot?, val before: String?)

    private val entries = LinkedHashMap<String, Entry>()
    private var seq = 0L

    /** Adds or re-adds [id]. */
    fun put(id: String, zIndex: Int, slot: SMapSlot? = null, before: String? = null) {
        entries.remove(id)
        entries[id] = Entry(id, zIndex, seq++, if (before != null) null else slot, before)
    }

    fun remove(id: String) {
        entries.remove(id)
    }

    operator fun contains(id: String): Boolean = id in entries

    fun slotOf(id: String): SMapSlot? = entries[id]?.slot
    fun beforeOf(id: String): String? = entries[id]?.before
    fun zIndexOf(id: String): Int = entries[id]?.zIndex ?: 0

    private fun rank(e: Entry): Int = if (e.before != null) -1 else (e.slot ?: SMapSlot.TOP).ordinal

    /**
     * Ids from the bottom to the top: slots bottom to top (a layer without a slot counts as top), then zIndex, then
     * the order added. Layers placed with `before` come first (their place is set by the layer they name).
     */
    fun ids(): List<String> =
        entries.values.sortedWith(compareBy<Entry>({ rank(it) }, { it.zIndex }, { it.seq })).map { it.id }

    /**
     * The engine layer to insert [id]'s layers below, so everything above it in the order stays above: the first
     * engine layer present of the next layer up. Null when [id] goes on top. (For layers without a slot or `before`.)
     *
     * @param firstEngineLayer the first engine layer of a caller layer that is on the map, or null
     */
    fun beforeId(id: String, firstEngineLayer: (String) -> String?): String? =
        insertBefore(id, { null }, firstEngineLayer)

    /**
     * The engine layer to insert [id]'s layers below. Layers that share an anchor (the same slot layer of the
     * basemap, the same `before` layer, or the top) form one group drawn in order just under it: [id] goes under the
     * next layer up of its group that is on the map, else under the anchor itself; null = on top.
     *
     * @param slotAnchor the basemap layer a slot is drawn under (null = top)
     * @param firstEngineLayer the first engine layer of a caller layer that is on the map, or null
     */
    fun insertBefore(id: String, slotAnchor: (SMapSlot) -> String?, firstEngineLayer: (String) -> String?): String? {
        val entry = entries[id] ?: return null
        fun anchor(e: Entry): String? {
            val before = e.before ?: return slotAnchor(e.slot ?: SMapSlot.TOP)
            // `before` names another caller layer (its first engine layer) or a basemap / engine layer id.
            return if (before in entries) firstEngineLayer(before) else before
        }
        val mine = anchor(entry)
        val ids = ids()
        val at = ids.indexOf(id)
        for (i in at + 1 until ids.size) {
            val other = entries[ids[i]] ?: continue
            if (other.id == entry.before || anchor(other) != mine) continue
            firstEngineLayer(other.id)?.let { return it }
        }
        return mine
    }

    /** The first engine layer of the bottom caller layer that is on the map (3D buildings go below it). */
    fun bottomEngineLayer(firstEngineLayer: (String) -> String?): String? {
        for (id in ids()) firstEngineLayer(id)?.let { return it }
        return null
    }
}
