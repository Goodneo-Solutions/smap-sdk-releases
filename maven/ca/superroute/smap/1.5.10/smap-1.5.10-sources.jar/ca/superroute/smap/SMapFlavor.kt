package ca.superroute.smap

/** The colour schemes the map service offers. */
enum class SMapFlavor(val id: String) {
    LIGHT("light"),
    WHITE("white"),
    GRAYSCALE("grayscale"),
    DARK("dark"),
    BLACK("black");

    /** True for the schemes drawn on a dark background. */
    val isDark: Boolean get() = this == DARK || this == BLACK

    companion object {
        /** The flavor with this id; [LIGHT] when the id is unknown. */
        fun fromId(id: String?): SMapFlavor = entries.firstOrNull { it.id == id } ?: LIGHT
    }
}
