package ca.superroute.smap

import android.graphics.Bitmap
import android.graphics.Canvas
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/**
 * The engine's HTTP client answering what the SDK makes itself (G14) and reporting what it fetched (G10):
 * - tiles drawn by the app at `https://smapcanvas.invalid/<key>/{z}/{x}/{y}` (drawn on the engine's network thread);
 * - every response's host and status to the watchers (the Google layer counts failed tiles).
 */
internal object SMapLocalTiles {
    const val HOST = "smapcanvas.invalid"

    class Drawer(val tileSize: Int, val ratio: Float, val draw: (Canvas, Int, Int, Int, Int) -> Unit)

    private val drawers = ConcurrentHashMap<String, Drawer>()
    private val watchers = CopyOnWriteArrayList<(String, Int) -> Unit>()
    private var seq = 0

    @Synchronized
    fun register(drawer: Drawer): String { val key = "c" + (++seq); drawers[key] = drawer; return key }
    fun unregister(key: String) { drawers.remove(key) }
    fun url(key: String) = "https://$HOST/$key/{z}/{x}/{y}"

    fun watch(w: (String, Int) -> Unit) { watchers += w }
    fun unwatch(w: (String, Int) -> Unit) { watchers -= w }

    /** One tile drawn as PNG bytes, or null when [path] names no drawer. */
    fun png(path: String): ByteArray? {
        val parts = path.trim('/').split('/')
        if (parts.size != 4) return null
        val d = drawers[parts[0]] ?: return null
        val z = parts[1].toIntOrNull() ?: return null
        val x = parts[2].toIntOrNull() ?: return null
        val y = parts[3].toIntOrNull() ?: return null
        val px = (d.tileSize * d.ratio).toInt()
        val bitmap = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.scale(d.ratio, d.ratio)
        d.draw(canvas, z, x, y, d.tileSize)
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        bitmap.recycle()
        return out.toByteArray()
    }

    val interceptor = Interceptor { chain ->
        val request = chain.request()
        if (request.url.host == HOST) {
            val bytes = try { png(request.url.encodedPath) } catch (e: Exception) { null }
            return@Interceptor Response.Builder().request(request).protocol(Protocol.HTTP_1_1)
                .code(if (bytes != null) 200 else 404).message(if (bytes != null) "OK" else "Not Found")
                .body((bytes ?: ByteArray(0)).toResponseBody("image/png".toMediaType())).build()
        }
        val response = try { chain.proceed(request) } catch (e: java.io.IOException) {
            watchers.forEach { it(request.url.host, 0) }
            throw e
        }
        if (watchers.isNotEmpty()) watchers.forEach { it(request.url.host, response.code) }
        response
    }
}
