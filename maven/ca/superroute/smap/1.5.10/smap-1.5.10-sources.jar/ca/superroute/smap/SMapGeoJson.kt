package ca.superroute.smap

import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.JsonObject
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.Geometry
import org.maplibre.geojson.GeometryCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.MultiLineString
import org.maplibre.geojson.MultiPoint
import org.maplibre.geojson.MultiPolygon
import org.maplibre.geojson.Point
import org.maplibre.geojson.Polygon

/** Conversions between the SDK's inputs and GeoJSON. */
object SMapGeoJson {
    private val gson = Gson()

    fun points(points: List<SMapPoint>): FeatureCollection =
        FeatureCollection.fromFeatures(points.map { p ->
            Feature.fromGeometry(Point.fromLngLat(p.lng, p.lat), properties(p.properties))
        })

    fun lines(lines: List<SMapLine>): FeatureCollection =
        FeatureCollection.fromFeatures(lines.map { l ->
            Feature.fromGeometry(
                LineString.fromLngLats(l.points.map { Point.fromLngLat(it.longitude, it.latitude) }),
                properties(l.properties),
            )
        })

    fun polygons(polygons: List<SMapPolygon>): FeatureCollection =
        FeatureCollection.fromFeatures(polygons.map { p ->
            val rings = p.rings.map { ring ->
                val pts = ring.map { Point.fromLngLat(it.longitude, it.latitude) }
                if (pts.isNotEmpty() && pts.first() != pts.last()) pts + pts.first() else pts
            }
            Feature.fromGeometry(Polygon.fromLngLats(rings), properties(p.properties))
        })

    /**
     * Any accepted input as a FeatureCollection: a FeatureCollection, a Feature, a GeoJSON string, or a list of
     * [SMapPoint], [SMapLine] or [SMapPolygon].
     */
    fun toFeatureCollection(data: Any?): FeatureCollection = when (data) {
        null -> FeatureCollection.fromFeatures(emptyList())
        is FeatureCollection -> data
        is Feature -> FeatureCollection.fromFeatures(listOf(data))
        is String -> fromJson(data)
        is List<*> -> when {
            data.isEmpty() -> FeatureCollection.fromFeatures(emptyList())
            data.all { it is SMapPoint } -> points(data.filterIsInstance<SMapPoint>())
            data.all { it is SMapLine } -> lines(data.filterIsInstance<SMapLine>())
            data.all { it is SMapPolygon } -> polygons(data.filterIsInstance<SMapPolygon>())
            data.all { it is Feature } -> FeatureCollection.fromFeatures(data.filterIsInstance<Feature>())
            else -> throw IllegalArgumentException("sMap: a list must hold only SMapPoint, SMapLine, SMapPolygon or Feature items")
        }
        else -> throw IllegalArgumentException("sMap: unsupported data type ${data.javaClass.name}")
    }

    private fun fromJson(json: String): FeatureCollection {
        val type = try {
            com.google.gson.JsonParser.parseString(json).asJsonObject.get("type")?.asString
        } catch (e: Exception) {
            throw IllegalArgumentException("sMap: the string is not GeoJSON", e)
        }
        return when (type) {
            "FeatureCollection" -> FeatureCollection.fromJson(json)
            "Feature" -> FeatureCollection.fromFeatures(listOf(Feature.fromJson(json)))
            else -> throw IllegalArgumentException("sMap: expected a GeoJSON Feature or FeatureCollection")
        }
    }

    /** Properties as a JSON object; values that are not JSON types are written through Gson. */
    fun properties(values: Map<String, Any?>): JsonObject {
        val obj = JsonObject()
        for ((k, v) in values) {
            obj.add(k, toJson(v))
        }
        return obj
    }

    private fun toJson(value: Any?): JsonElement = when (value) {
        null -> JsonNull.INSTANCE
        is JsonElement -> value
        else -> gson.toJsonTree(value)
    }

    /** A feature's properties as plain Kotlin values (numbers as Double, nested values as maps and lists). */
    fun propertiesOf(feature: Feature): Map<String, Any?> {
        val props = feature.properties() ?: return emptyMap()
        return props.entrySet().associate { (k, v) -> k to fromJson(v) }
    }

    private fun fromJson(e: JsonElement?): Any? = when {
        e == null || e.isJsonNull -> null
        e.isJsonPrimitive -> {
            val p = e.asJsonPrimitive
            when {
                p.isBoolean -> p.asBoolean
                p.isNumber -> p.asDouble
                else -> p.asString
            }
        }
        e.isJsonArray -> e.asJsonArray.map { fromJson(it) }
        else -> e.asJsonObject.entrySet().associate { (k, v) -> k to fromJson(v) }
    }

    /** `[west, south, east, north]` around every coordinate of [data], or null when it has none. */
    fun bounds(data: FeatureCollection): DoubleArray? {
        var west = Double.POSITIVE_INFINITY
        var south = Double.POSITIVE_INFINITY
        var east = Double.NEGATIVE_INFINITY
        var north = Double.NEGATIVE_INFINITY
        var any = false
        fun add(p: Point) {
            any = true
            west = minOf(west, p.longitude()); east = maxOf(east, p.longitude())
            south = minOf(south, p.latitude()); north = maxOf(north, p.latitude())
        }
        fun walk(g: Geometry?) {
            when (g) {
                is Point -> add(g)
                is MultiPoint -> g.coordinates().forEach(::add)
                is LineString -> g.coordinates().forEach(::add)
                is MultiLineString -> g.coordinates().forEach { it.forEach(::add) }
                is Polygon -> g.coordinates().forEach { it.forEach(::add) }
                is MultiPolygon -> g.coordinates().forEach { poly -> poly.forEach { it.forEach(::add) } }
                is GeometryCollection -> g.geometries().forEach(::walk)
                else -> Unit
            }
        }
        data.features()?.forEach { walk(it.geometry()) }
        return if (any) doubleArrayOf(west, south, east, north) else null
    }
}
