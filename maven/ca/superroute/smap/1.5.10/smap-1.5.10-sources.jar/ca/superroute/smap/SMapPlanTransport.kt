package ca.superroute.smap

import android.content.Context
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.util.Calendar
import java.util.TimeZone
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

// ------------------------------------------------------------------ credentials (Superroute OPEN-ROUTE-EDIT §2e)

/**
 * A plan editor token (`sr_pet_…`) and when it ends ([expiresAt], Unix seconds; 0 when it cannot be told).
 * [fastPathUrl] is the token answer's `fast_path.url` (OPEN-ROUTE-EDIT E19): while the latest token names one, the
 * editor sends its plan calls there; null sends them to the standard path.
 */
data class SMapPlanToken(val accessToken: String, val expiresAt: Long = expiry(accessToken), val fastPathUrl: String? = null) {
    companion object {
        private const val PREFIX = "sr_pet_"

        /** A bare token; its expiry read from its payload (`sr_pet_<base64url JSON>.<signature>`, or JWT-shaped). */
        fun of(token: String): SMapPlanToken = SMapPlanToken(token, expiry(token))

        /** The expiry (Unix seconds) of a plan editor token or a JWT-shaped token; 0 when unreadable. */
        fun expiry(token: String): Long = try {
            val payload = if (token.startsWith(PREFIX)) token.substring(PREFIX.length).split('.')[0] else token.split('.')[1]
            val exp = JsonParser.parseString(String(Base64Url.decode(payload), Charsets.UTF_8)).asJsonObject.get("exp")
            if (exp != null && exp.isJsonPrimitive && exp.asJsonPrimitive.isNumber) exp.asDouble.toLong() else 0
        } catch (e: Exception) {
            0
        }

        /**
         * What a token provider gave as JSON: the token string, or the token answer of `POST /v1/plan/token`
         * (`{access_token, token_type, expires_in, expires_at, scopes, origins}`, or that answer's `{data}` envelope).
         * Null when it holds no token.
         */
        fun fromJson(json: JsonElement?, nowMillis: Long = System.currentTimeMillis()): SMapPlanToken? {
            var t = json ?: return null
            if (t.isJsonObject && t.asJsonObject.get("data")?.isJsonObject == true && t.asJsonObject.get("access_token") == null) {
                t = t.asJsonObject.get("data")
            }
            if (t.isJsonPrimitive && t.asJsonPrimitive.isString && t.asString.isNotEmpty()) return of(t.asString)
            if (!t.isJsonObject) return null
            val o = t.asJsonObject
            val token = o.get("access_token")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString
            if (token.isNullOrEmpty()) return null
            var exp = o.get("expires_at")?.takeIf { it.isJsonPrimitive }?.asString?.let(SMapPlanTime::parseIso) ?: 0L
            val inSeconds = o.get("expires_in")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble
            if (exp == 0L && inSeconds != null) exp = nowMillis / 1000 + inSeconds.toLong()
            return SMapPlanToken(token, if (exp != 0L) exp else expiry(token), fastPathOf(o))
        }

        /** The `fast_path.url` of a token answer or a map key's configuration; null without one. */
        fun fastPathOf(o: JsonObject?): String? {
            val f = o?.get("fast_path")?.takeIf { it.isJsonObject }?.asJsonObject ?: return null
            val url = f.get("url")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString?.trimEnd('/')
            return url?.takeIf { it.isNotEmpty() }
        }

        /** [fromJson] of a JSON text (a token answer, or a quoted token). */
        fun fromJson(text: String, nowMillis: Long = System.currentTimeMillis()): SMapPlanToken? =
            fromJson(try { JsonParser.parseString(text) } catch (e: Exception) { null }, nowMillis)
    }
}

/**
 * How plan calls are authorised; both kinds are sent as `Authorization: Bearer …`.
 *
 * - [Token]: a plan editor token from a provider the app gives. The app's own server mints it with
 *   `POST /v1/plan/token` and its API token, never the device. The provider is called at first use, again 30 seconds
 *   before the token ends, and after a `401 SESSION_EXPIRED`; concurrent calls wait for one provider call.
 * - [Key]: a map key (`smk_…`) with *Allow plan editing* switched on; never renewed.
 */
sealed class SMapPlanCredentials {
    class Token(val provider: suspend () -> SMapPlanToken) : SMapPlanCredentials()
    class Key(val key: String) : SMapPlanCredentials() {
        init {
            require(key.isNotEmpty()) { "sMap plan editor: a map key is not empty" }
        }
    }

    companion object {
        /** A provider giving the bare token string. */
        fun token(provider: suspend () -> String): SMapPlanCredentials = Token { SMapPlanToken.of(provider()) }

        /** A provider giving the token answer of `POST /v1/plan/token` as JSON text, as the app's server passed it on. */
        fun tokenAnswer(provider: suspend () -> String): SMapPlanCredentials = Token {
            SMapPlanToken.fromJson(provider()) ?: throw SMapPlanException("sMap plan editor: the token provider gave no token")
        }

        fun key(key: String): SMapPlanCredentials = Key(key)
    }
}

/**
 * A native app's identity sent with every plan call: `X-SMap-App: android:<package>` and `X-SMap-App-Cert`. The
 * editor reads it from the system ([SMapAppIdentity]) when it is given a context; give it here only to override.
 */
data class SMapPlanApp(val id: String, val cert: String? = null) {
    fun headers(): Map<String, String> = buildMap {
        if (id.isNotEmpty()) put(SMapAppIdentity.APP_HEADER, id)
        if (!cert.isNullOrEmpty()) put(SMapAppIdentity.CERT_HEADER, cert)
    }

    companion object {
        /** The running app's identity, read from the system as for map requests. */
        fun of(context: Context): SMapPlanApp? {
            val h = SMapAppIdentity.headers(context)
            val id = h[SMapAppIdentity.APP_HEADER] ?: return null
            return SMapPlanApp(id, h[SMapAppIdentity.CERT_HEADER])
        }
    }
}

// ------------------------------------------------------------------ the HTTP layer

/** One plan request: method, full URL, headers, and the JSON body (null for none). */
data class SMapPlanHttpRequest(val method: String, val url: String, val headers: Map<String, String>, val body: String?)

/** One answer: status, headers (looked up without regard to case by [header]) and the body text. */
data class SMapPlanHttpResponse(val status: Int, val headers: Map<String, String> = emptyMap(), val body: String = "") {
    fun header(name: String): String? = headers.entries.firstOrNull { it.key.equals(name, ignoreCase = true) }?.value
}

/**
 * The HTTP layer of plan calls. A call must stop when its coroutine is cancelled (a newer edit supersedes it); a
 * network failure throws. [SMapPlanOkHttp] is the default; replace it to test or to route the calls elsewhere.
 */
fun interface SMapPlanHttp {
    suspend fun send(request: SMapPlanHttpRequest): SMapPlanHttpResponse
}

/**
 * The default [SMapPlanHttp]: OkHttp, its call cancelled when the coroutine waiting for it is. sMap gzips plan answers
 * when the request allows it; OkHttp asks for gzip and decompresses only when it adds `Accept-Encoding` itself, so
 * that header is never set here (an `Accept-Encoding` in [SMapPlanHttpRequest.headers] is dropped).
 */
class SMapPlanOkHttp(private val client: OkHttpClient = SHARED) : SMapPlanHttp {
    override suspend fun send(request: SMapPlanHttpRequest): SMapPlanHttpResponse = suspendCancellableCoroutine { cont ->
        val builder = Request.Builder().url(request.url)
        request.headers.forEach { (name, value) -> if (!name.equals("Accept-Encoding", ignoreCase = true)) builder.header(name, value) }
        builder.header("User-Agent", "sMap-Android/${BuildConfig.SMAP_VERSION}")
        val contentType = request.headers.entries.firstOrNull { it.key.equals("Content-Type", true) }?.value ?: "application/json"
        builder.method(request.method, request.body?.toByteArray(Charsets.UTF_8)?.toRequestBody(contentType.toMediaType()))
        val call = client.newCall(builder.build())
        cont.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(e)
            }

            override fun onResponse(call: Call, response: Response) {
                val answer = try {
                    response.use { r ->
                        SMapPlanHttpResponse(r.code, r.headers.toMultimap().mapValues { it.value.joinToString(", ") }, r.body?.string() ?: "")
                    }
                } catch (e: IOException) {
                    if (cont.isActive) cont.resumeWithException(e)
                    return
                }
                if (cont.isActive) cont.resume(answer)
            }
        })
    }

    companion object {
        private val SHARED: OkHttpClient by lazy { OkHttpClient() }
    }
}

// ------------------------------------------------------------------ the transport

/**
 * An answer of a plan call: status, the JSON body, its `data`, the `X-Plan-Matrix` header, and [path], where it was
 * answered ([SMapPlanPath.FAST] or [SMapPlanPath.STANDARD]).
 */
internal class SMapPlanAnswer(val status: Int, val body: JsonObject?, val data: JsonObject?, val matrix: String?, val path: String = SMapPlanPath.STANDARD)

/**
 * The answer of a quiet call (the drop points call): its status (0: no answer) and JSON body; [network] when the call
 * failed on the way. [ready] is the body's `ready` (or `data.ready`).
 */
internal class SMapPlanQuietAnswer(val status: Int, val json: JsonObject?, val network: Boolean) {
    val ready: Boolean
        get() {
            if (status !in 200..299) return false
            val d = json?.get("data")?.takeIf { it.isJsonObject }?.asJsonObject ?: json
            val r = d?.get("ready") ?: return false
            return r.isJsonPrimitive && r.asJsonPrimitive.isBoolean && r.asBoolean
        }
}

/** Where a plan call was answered: the fast path through sMap, or the Open Platform's standard path. */
object SMapPlanPath {
    const val FAST = "fast"
    const val STANDARD = "standard"
}

/**
 * The one place that knows where plan calls go and how they are authorised. A `401 SESSION_EXPIRED` with a token
 * provider asks for a new token and repeats the call once; every other refusal (`SESSION_REVOKED`, `TOKEN_INVALID`,
 * `403 NOT_AUTHORIZED` with its reason, any 401 on a map key) is raised with its code and reason.
 *
 * Fast path (OPEN-ROUTE-EDIT E19, §2f.5): when the credential names a fast-path address (the token answer's
 * `fast_path.url`, or a map key's configuration from `GET <smapUrl>/plan/v1/config`), each call goes to
 * `<url>/<same path>` with the same method, credential, headers and body. A `409 USE_STANDARD_PATH` (or
 * `X-Plan-Path: standard`), any 5xx, a network error or no answer within [fastPathTimeoutMillis] repeats the same call
 * once on the standard path; the next call tries the fast path again. 402, 429 and every other 4xx are final.
 */
internal class SMapPlanTransport(
    baseUrl: String,
    private val credentials: SMapPlanCredentials,
    private val app: Map<String, String>,
    private val http: SMapPlanHttp,
    private val clock: () -> Long,
    smapUrl: String? = null,
    private val fastPathOn: Boolean = true,
    private val fastPathTimeoutMillis: Long = FAST_PATH_TIMEOUT_MS,
    private val fastPathRefineTimeoutMillis: Long = FAST_PATH_REFINE_TIMEOUT_MS,
) {
    val base: String = baseUrl.trimEnd('/')
    val smap: String = (smapUrl ?: DEFAULT_SMAP_URL).trimEnd('/')
    val kind: String = if (credentials is SMapPlanCredentials.Key) "key" else "token"

    private val mutex = Mutex()
    private val configMutex = Mutex()
    @Volatile private var token: String? = null
    @Volatile private var exp: Long = 0
    @Volatile private var tokenFastPath: String? = null
    @Volatile private var keyFastPath: String? = null
    @Volatile private var keyConfigUntil: Long = 0

    private fun fresh(): Boolean {
        if (token == null) return false
        return exp == 0L || exp - clock() / 1000 > RENEW_BEFORE_SECONDS
    }

    private suspend fun bearer(): String = when (val c = credentials) {
        is SMapPlanCredentials.Key -> c.key
        is SMapPlanCredentials.Token -> {
            token?.takeIf { fresh() } ?: mutex.withLock {
                token?.takeIf { fresh() } ?: run {
                    val t = try {
                        c.provider()
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: SMapPlanException) {
                        throw e
                    } catch (e: Exception) {
                        throw SMapPlanException("sMap plan editor: the token provider failed: ${e.message}", cause = e)
                    }
                    if (t.accessToken.isEmpty()) throw SMapPlanException("sMap plan editor: the token provider gave no token")
                    token = t.accessToken
                    exp = t.expiresAt
                    tokenFastPath = t.fastPathUrl?.trimEnd('/')?.takeIf { it.isNotEmpty() }
                    t.accessToken
                }
            }
        }
    }

    /** After a 401 SESSION_EXPIRED: forget the token so the next call asks the provider again. True when a retry may help. */
    private fun renew(): Boolean {
        if (credentials !is SMapPlanCredentials.Token) return false
        token = null
        exp = 0
        return true
    }

    private fun headersWith(authorization: String, json: Boolean): LinkedHashMap<String, String> {
        val headers = LinkedHashMap<String, String>()
        headers["Accept"] = "application/json"
        headers.putAll(app)
        headers["Authorization"] = authorization
        if (json) headers["Content-Type"] = "application/json"
        return headers
    }

    /** A map key's configuration on sMap: `GET <smap>/plan/v1/config` → `{"fast_path": {"url"}}` or `{}`. */
    private suspend fun keyFastPath(authorization: String): String? {
        if (clock() < keyConfigUntil) return keyFastPath
        return configMutex.withLock {
            if (clock() < keyConfigUntil) return@withLock keyFastPath
            val r = exchange(SMapPlanHttpRequest("GET", "$smap/plan/v1/config", headersWith(authorization, false), null), true)
            val status = r.response?.status ?: 0
            keyFastPath = if (status in 200..299) SMapPlanToken.fastPathOf(parse(r.response!!.body)) else null
            // A refusal is an answer (no fast path for this key); a failure is asked again after a minute.
            keyConfigUntil = clock() + if (status in 200..499) KEY_CONFIG_TTL_MS else KEY_CONFIG_RETRY_MS
            keyFastPath
        }
    }

    private suspend fun fastPath(authorization: String): String? = when {
        !fastPathOn -> null
        credentials is SMapPlanCredentials.Key -> keyFastPath(authorization)
        else -> tokenFastPath
    }

    /** One exchange: the answer, or null when it failed on the way (a network error, or no answer in time when [limited]). */
    private class Exchange(val response: SMapPlanHttpResponse?, val failure: Exception?)

    /** The fast-path time limit of a call ([rest]: the path after `/v1/plan`): refine has its own, the rest share one. */
    private fun timeoutFor(rest: String): Long = if (rest == "/refine") fastPathRefineTimeoutMillis else fastPathTimeoutMillis

    private suspend fun exchange(request: SMapPlanHttpRequest, limited: Boolean, limit: Long = fastPathTimeoutMillis): Exchange {
        return try {
            if (!limited) {
                Exchange(http.send(request), null)
            } else {
                val r = withTimeoutOrNull(limit) { http.send(request) }
                if (r == null) Exchange(null, SMapPlanException("sMap plan editor: no answer from the fast path in time")) else Exchange(r, null)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: SMapPlanException) {
            if (!limited) throw e
            Exchange(null, e)
        } catch (e: Exception) {
            if (!limited) throw SMapPlanException(e.message ?: "sMap plan editor: the call failed", path = request.url, cause = e)
            Exchange(null, e)
        }
    }

    private fun parse(text: String): JsonObject? = try {
        if (text.isEmpty()) null else JsonParser.parseString(text).takeIf { it.isJsonObject }?.asJsonObject
    } catch (e: Exception) {
        null
    }

    /** Repeat on the standard path (§2f.5)? */
    private fun useStandard(r: Exchange): Boolean {
        val response = r.response ?: return true
        if (response.status >= 500) return true
        if (response.status != 409) return false
        val code = parse(response.body)?.get("error")?.takeIf { it.isJsonObject }?.asJsonObject?.text("code")
        return code == "USE_STANDARD_PATH" || response.header("X-Plan-Path")?.equals("standard", ignoreCase = true) == true
    }

    suspend fun send(method: String, path: String, body: JsonObject? = null, retried: Boolean = false): SMapPlanAnswer {
        val authorization = "Bearer " + bearer()
        val fast = fastPath(authorization)
        val text = body?.let { SMapJson.stringify(it) }
        val headers = headersWith(authorization, body != null)
        var via = SMapPlanPath.STANDARD
        var response: SMapPlanHttpResponse? = null
        if (fast != null && path.startsWith("$PLAN_PREFIX/")) {
            val rest = path.substring(PLAN_PREFIX.length)
            val r = exchange(SMapPlanHttpRequest(method, fast + rest, LinkedHashMap(headers), text), true, timeoutFor(rest))
            if (!useStandard(r)) {
                response = r.response
                via = SMapPlanPath.FAST
            }
        }
        if (response == null) {
            response = try {
                http.send(SMapPlanHttpRequest(method, base + path, LinkedHashMap(headers), text))
            } catch (e: CancellationException) {
                throw e
            } catch (e: SMapPlanException) {
                throw e
            } catch (e: Exception) {
                throw SMapPlanException(e.message ?: "sMap plan editor: the call failed", path = path, cause = e)
            }
        }
        val json = parse(response.body)
        if (response.status !in 200..299) {
            val err = json?.get("error")?.takeIf { it.isJsonObject }?.asJsonObject ?: JsonObject()
            val code = err.text("code")
            if (response.status == 401 && code == "SESSION_EXPIRED" && !retried && renew()) return send(method, path, body, true)
            throw SMapPlanException(
                err.text("message") ?: "HTTP ${response.status}",
                status = response.status,
                code = code,
                reason = err.text("reason") ?: json?.text("reason"),
                details = err.get("details")?.takeIf { !it.isJsonNull },
                path = path,
                via = via,
            )
        }
        return SMapPlanAnswer(response.status, json, json?.get("data")?.takeIf { it.isJsonObject }?.asJsonObject, response.header("X-Plan-Matrix"), via)
    }

    /**
     * One call to the standard path only, never the fast path (the drop points call, OPEN-ROUTE-EDIT E25/E26), given up
     * after [limitMillis]. It never throws but for cancellation: a refusal is its status, and no answer is status 0
     * ([SMapPlanQuietAnswer.network] true when the call failed on the way rather than ran out of time).
     */
    suspend fun sendQuiet(path: String, body: JsonObject, limitMillis: Long): SMapPlanQuietAnswer {
        return try {
            val authorization = "Bearer " + bearer()
            val request = SMapPlanHttpRequest("POST", base + path, headersWith(authorization, true), SMapJson.stringify(body))
            val r = withTimeoutOrNull(limitMillis) { http.send(request) } ?: return SMapPlanQuietAnswer(0, null, false)
            SMapPlanQuietAnswer(r.status, parse(r.body), false)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            SMapPlanQuietAnswer(0, null, true)
        }
    }

    private fun JsonObject.text(key: String): String? =
        get(key)?.takeIf { it.isJsonPrimitive }?.asString?.takeIf { it.isNotEmpty() }

    companion object {
        /** A token whose expiry can be read is renewed this many seconds before it ends. */
        const val RENEW_BEFORE_SECONDS = 30L

        /** The sMap service a map key's configuration is read from, unless the editor is told another. */
        const val DEFAULT_SMAP_URL = "https://tile.srsr.ca"

        /**
         * A fast-path call not answered within this long is repeated on the standard path (§2f.5): every call 2 s,
         * except refine (its search runs up to 2 s inside sRoad, and sMap's own refine budget is 4 s) 5 s.
         */
        const val FAST_PATH_TIMEOUT_MS = 2000L
        const val FAST_PATH_REFINE_TIMEOUT_MS = 5000L

        /** A map key's configuration is kept this long; one that could not be read is asked for again after a minute. */
        const val KEY_CONFIG_TTL_MS = 600_000L
        const val KEY_CONFIG_RETRY_MS = 60_000L

        private const val PLAN_PREFIX = "/v1/plan"
    }
}

/** ISO 8601 times without java.time (API 23). */
internal object SMapPlanTime {
    private val ISO = Regex("""^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?)?\s*(Z|[+-]\d{2}:?\d{2})?$""", RegexOption.IGNORE_CASE)

    /** Unix seconds of an ISO 8601 date-time (UTC when it names no offset); null when unreadable. */
    fun parseIso(text: String): Long? {
        val m = ISO.matchEntire(text.trim()) ?: return null
        val g = m.groupValues
        val c = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        c.clear()
        c.set(g[1].toInt(), g[2].toInt() - 1, g[3].toInt(), g[4].ifEmpty { "0" }.toInt(), g[5].ifEmpty { "0" }.toInt(), g[6].ifEmpty { "0" }.toInt())
        var seconds = c.timeInMillis / 1000
        val zone = g[8]
        if (zone.isNotEmpty() && !zone.equals("Z", true)) {
            val digits = zone.substring(1).replace(":", "")
            val offset = digits.substring(0, 2).toInt() * 3600 + digits.substring(2, 4).toInt() * 60
            seconds -= if (zone[0] == '+') offset else -offset
        }
        return seconds
    }

    /** The clock time `HH:MM` of an ISO time with offset, as the answer gives it (the plan's own time zone). */
    fun clock(iso: String?): String = Regex("""T(\d\d:\d\d)""").find(iso ?: "")?.groupValues?.get(1) ?: ""
}
