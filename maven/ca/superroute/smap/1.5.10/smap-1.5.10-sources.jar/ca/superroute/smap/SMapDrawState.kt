package ca.superroute.smap

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlin.math.cos
import kotlin.math.sin

/**
 * The shapes of a drawing tool and their edits (G3), without any view work: as the Web SDK's DrawTool. Shapes are
 * GeoJSON features with an id; rings are kept closed in the data and edited open.
 */
internal class SMapDrawState {
    val features = ArrayList<JsonObject>()
    private var seq = 0
    private val undoStack = ArrayDeque<String>()
    private val redoStack = ArrayDeque<String>()

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    fun own(f: JsonObject): JsonObject {
        val copy = f.deepCopy()
        if (!copy.has("id") || copy["id"].isJsonNull) copy.addProperty("id", "f" + (++seq))
        if (!copy.has("properties") || copy["properties"].isJsonNull) copy.add("properties", JsonObject())
        return copy
    }

    fun idOf(f: JsonObject): String = f["id"].asString
    fun find(id: String?): JsonObject? = features.firstOrNull { idOf(it) == id }

    fun set(list: List<JsonObject>) { features.clear(); list.forEach { features += own(it) }; undoStack.clear(); redoStack.clear() }

    fun record() {
        undoStack.addLast(snapshot())
        while (undoStack.size > 100) undoStack.removeFirst()
        redoStack.clear()
    }

    /** Takes back the last record (a gesture that changed nothing). */
    fun dropRecord() { if (undoStack.isNotEmpty()) undoStack.removeLast() }

    fun undo(): Boolean {
        val last = undoStack.removeLastOrNull() ?: return false
        redoStack.addLast(snapshot()); restore(last); return true
    }

    fun redo(): Boolean {
        val next = redoStack.removeLastOrNull() ?: return false
        undoStack.addLast(snapshot()); restore(next); return true
    }

    private fun snapshot(): String = JsonArray().also { a -> features.forEach { a.add(it.deepCopy()) } }.toString()
    private fun restore(s: String) { features.clear(); JsonParser.parseString(s).asJsonArray.forEach { features += it.asJsonObject } }

    fun add(f: JsonObject): JsonObject { record(); val o = own(f); features += o; return o }

    fun remove(id: String): JsonObject? {
        val f = find(id) ?: return null
        record(); features.remove(f); return f
    }

    fun collection(): JsonObject = JsonObject().apply {
        addProperty("type", "FeatureCollection")
        add("features", JsonArray().also { a -> features.forEach { a.add(it.deepCopy()) } })
    }

    // ---- rings

    /** One editable ring: [path] into the coordinates, open [coords], [closed] for an area. */
    class Ring(val path: List<Int>, val coords: MutableList<DoubleArray>, val closed: Boolean)

    companion object {
        private fun pos(e: JsonElement) = e.asJsonArray.let { doubleArrayOf(it[0].asDouble, it[1].asDouble) }
        private fun arr(c: DoubleArray) = JsonArray().apply { add(c[0]); add(c[1]) }
        private fun open(r: JsonArray): MutableList<DoubleArray> {
            val l = r.map(::pos).toMutableList()
            if (l.size > 1 && l.first()[0] == l.last()[0] && l.first()[1] == l.last()[1]) l.removeAt(l.size - 1)
            return l
        }
        fun closed(coords: List<DoubleArray>): JsonArray = JsonArray().also { a ->
            coords.forEach { a.add(arr(it)) }
            if (coords.isNotEmpty() && (coords.first()[0] != coords.last()[0] || coords.first()[1] != coords.last()[1])) a.add(arr(coords.first()))
        }
        fun line(coords: List<DoubleArray>): JsonArray = JsonArray().also { a -> coords.forEach { a.add(arr(it)) } }

        fun rings(geometry: JsonObject): List<Ring> {
            val c = geometry.getAsJsonArray("coordinates") ?: return emptyList()
            return when (geometry["type"]?.asString) {
                "LineString" -> listOf(Ring(emptyList(), c.map(::pos).toMutableList(), false))
                "Polygon" -> c.mapIndexed { i, r -> Ring(listOf(i), open(r.asJsonArray), true) }
                "MultiPolygon" -> c.flatMapIndexed { p, poly -> poly.asJsonArray.mapIndexed { i, r -> Ring(listOf(p, i), open(r.asJsonArray), true) } }
                else -> emptyList()
            }
        }

        fun setRing(geometry: JsonObject, ring: Ring, coords: List<DoubleArray>) {
            val c = geometry.getAsJsonArray("coordinates")
            when (geometry["type"]?.asString) {
                "LineString" -> geometry.add("coordinates", line(coords))
                "Polygon" -> c.set(ring.path[0], closed(coords))
                "MultiPolygon" -> c[ring.path[0]].asJsonArray.set(ring.path[1], closed(coords))
            }
        }

        fun move(geometry: JsonObject, dx: Double, dy: Double) {
            fun walk(e: JsonElement): JsonElement {
                val a = e.asJsonArray
                if (a.size() >= 2 && a[0].isJsonPrimitive) return JsonArray().apply { add(a[0].asDouble + dx); add(a[1].asDouble + dy) }
                return JsonArray().also { out -> a.forEach { out.add(walk(it)) } }
            }
            geometry.add("coordinates", walk(geometry["coordinates"]))
        }

        /** A circle of [radius] metres as 64 points (and the first again). */
        fun circleRing(center: DoubleArray, radius: Double): List<DoubleArray> {
            // The same Earth radius as SMapGeo.distance, so the radius handle measures what was drawn.
            val r = 6371008.8
            val lat = Math.toRadians(center[1])
            return (0..64).map { i ->
                val a = (i % 64) / 64.0 * 2 * Math.PI
                doubleArrayOf(center[0] + (radius * sin(a)) / (r * cos(lat)) * 180 / Math.PI, center[1] + (radius * cos(a)) / r * 180 / Math.PI)
            }
        }

        /** A rectangle kept a rectangle: the corner [index] at [to], its opposite corner where it was. */
        fun rectangleWithCorner(corners: List<DoubleArray>, index: Int, to: DoubleArray): List<DoubleArray> {
            val opp = corners[(index + 2) % 4]
            val rect = listOf(opp, doubleArrayOf(to[0], opp[1]), to, doubleArrayOf(opp[0], to[1]))
            val shift = (index + 2) % 4
            val ordered = arrayOfNulls<DoubleArray>(4)
            for (q in 0 until 4) ordered[(shift + q) % 4] = rect[q]
            return ordered.map { it!! }
        }

        fun polygon(ring: List<DoubleArray>, props: JsonObject = JsonObject()) = JsonObject().apply {
            addProperty("type", "Feature")
            add("properties", props)
            add("geometry", JsonObject().apply { addProperty("type", "Polygon"); add("coordinates", JsonArray().apply { add(closed(ring)) }) })
        }
    }
}
