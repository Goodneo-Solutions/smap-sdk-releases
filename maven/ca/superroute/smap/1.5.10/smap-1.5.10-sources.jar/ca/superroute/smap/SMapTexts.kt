package ca.superroute.smap

import com.google.gson.JsonObject
import com.google.gson.JsonParser

/**
 * The SDK's own texts in 14 languages (1.5.0): the unavailable notice, the search tool, the gesture hint. Read from
 * `sdk-texts.json` (the Web SDK's table, `forbidden` and `unsupported` worded for an app).
 */
object SMapTexts {
    private val table: JsonObject by lazy {
        val stream = SMapTexts::class.java.getResourceAsStream("sdk-texts.json")
            ?: throw IllegalStateException("sMap: sdk-texts.json is missing from the library")
        stream.reader(Charsets.UTF_8).use { JsonParser.parseReader(it).asJsonObject }
    }

    /** The table's language for a BCP-47 tag: one of the 14, English when none fits. */
    fun language(tag: String?): String {
        val t = (tag ?: "en").lowercase().replace('_', '-')
        if (Regex("^zh-(hant|tw|hk|mo)").containsMatchIn(t)) return "zh-Hant"
        if (t.startsWith("zh")) return "zh-Hans"
        val base = t.split('-')[0]
        return if (base != "note" && table.has(base)) base else "en"
    }

    /** The text [key] (`forbidden`, `unreachable`, `unsupported`, `searchPlaceholder`, `noResults`, `search`, `gestureMobile`). */
    fun text(tag: String?, key: String): String =
        table.getAsJsonObject(language(tag))?.get(key)?.asString ?: table.getAsJsonObject("en").get(key).asString
}

/** Why the map cannot be shown (1.5.0, G32). */
enum class SMapUnavailableReason(val webName: String) {
    /** The map service refuses this app (401 or 403 for the style or its tiles). */
    FORBIDDEN("forbidden"),
    /** No node of the map service answers, and no offline region can stand in. */
    UNREACHABLE("unreachable"),
    /** This device cannot run the map engine. */
    UNSUPPORTED("unsupported"),
}

/** When the map is unavailable (G32): the reason of a failure, once per map. */
internal object SMapUnavailable {
    /** A refusal of the map service: 401 and 403 from one of its nodes. */
    fun isRefusal(status: Int): Boolean = status == 401 || status == 403

    /** Whether [url] is the map service's (one of its node hosts), not someone else's tiles. */
    fun isService(url: String, nodeHosts: Collection<String>): Boolean {
        val host = try { java.net.URI(url).host?.lowercase() } catch (e: Exception) { null } ?: return false
        return nodeHosts.any { it.equals(host, ignoreCase = true) }
    }

    /** OpenGL ES 3.0, which the map engine needs (`reqGlEsVersion` of the device). */
    fun supports(glEsVersion: Int): Boolean = glEsVersion >= 0x30000
}
