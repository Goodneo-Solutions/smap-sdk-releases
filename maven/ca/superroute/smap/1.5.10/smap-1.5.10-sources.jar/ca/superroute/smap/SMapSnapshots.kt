package ca.superroute.smap

import android.graphics.Bitmap
import android.graphics.Canvas
import android.util.DisplayMetrics
import android.view.View
import com.google.gson.Gson
import java.util.TreeMap

/** Helpers of custom markers drawn by the map (`SMapCustomMarkerOptions.snapshot`). */
internal object SMapSnapshots {
    /** Properties the SDK adds to each feature (taken out again before the app sees a feature). */
    const val IMAGE = "__smap_image"
    const val KEY = "__smap_key"
    const val OPACITY = "__smap_opacity"
    const val ORDER = "__smap_order"
    private val added = setOf(IMAGE, KEY, OPACITY, ORDER)
    private val gson = Gson()

    fun stripped(props: Map<String, Any?>): Map<String, Any?> = props.filterKeys { it !in added }

    fun plain(f: SMapFeature): SMapFeature = SMapFeature(f.properties[KEY]?.toString() ?: f.key, stripped(f.properties), f.position)

    /** All properties in a stable order, or null when they cannot be written as JSON. */
    fun look(props: Map<String, Any?>): String? = runCatching { gson.toJson(TreeMap(props)) }.getOrNull()

    /**
     * The view drawn at the size it would have as a live marker: the size its layout parameters give, else the size
     * it wraps its content to. The bitmap carries the screen density, so the map draws it at the view's size.
     */
    fun draw(view: View, metrics: DisplayMetrics): Bitmap {
        val lp = view.layoutParams
        fun spec(size: Int?) = if (size != null && size > 0) View.MeasureSpec.makeMeasureSpec(size, View.MeasureSpec.EXACTLY)
        else View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        view.measure(spec(lp?.width), spec(lp?.height))
        val w = maxOf(1, view.measuredWidth)
        val h = maxOf(1, view.measuredHeight)
        view.layout(0, 0, w, h)
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bitmap.density = metrics.densityDpi
        view.draw(Canvas(bitmap))
        return bitmap
    }
}
