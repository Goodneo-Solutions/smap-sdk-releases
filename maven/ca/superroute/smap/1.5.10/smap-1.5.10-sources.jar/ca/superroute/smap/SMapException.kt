package ca.superroute.smap

/** An error raised by the SDK. [status] is the HTTP status when the error came from an answer, otherwise 0. */
class SMapException(
    message: String,
    val status: Int = 0,
    val url: String = "",
    cause: Throwable? = null,
) : Exception(message, cause)
