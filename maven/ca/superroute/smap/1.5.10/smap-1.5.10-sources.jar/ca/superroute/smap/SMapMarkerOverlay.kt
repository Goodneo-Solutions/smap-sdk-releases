package ca.superroute.smap

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.Point
import kotlin.math.abs

/**
 * The views over the map: custom markers (G1) — dragged after a long press (G2) — and the map's one tooltip (G5).
 * One layer of views per custom marker layer; only the items in view are attached.
 */
@SuppressLint("ViewConstructor")
internal class SMapMarkerOverlay(
    context: Context,
    private val mapView: MapView,
    /** The custom marker layers in draw order, bottom first. */
    private val order: () -> List<String>,
    /** A marker was dragged: the layer's data with the item's new position. */
    private val moved: (layerId: String, data: FeatureCollection) -> Unit,
    /** The map, told of long presses (the context menu) and of views made while their feature has a state. */
    private val host: SMap? = null,
) : FrameLayout(context) {

    class Layer(val id: String, var options: SMapCustomMarkerOptions, var data: FeatureCollection) {
        val set = SMapMarkerSet<View>(options.idProperty)
        var hidden = false
    }

    val layers = LinkedHashMap<String, Layer>()
    var map: MapLibreMap? = null
    private val density = resources.displayMetrics.density
    private val tooltip: TextView = TextView(context).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12f)
        setTextColor(Color.WHITE)
        val px = (8 * density).toInt(); val py = (4 * density).toInt()
        setPadding(px, py, px, py)
        background = GradientDrawable().apply { cornerRadius = 4 * density; setColor(Color.argb(235, 17, 24, 39)) }
        visibility = View.GONE
        translationZ = Float.MAX_VALUE / 2
    }

    init {
        clipChildren = true
        isClickable = false
        addView(tooltip, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    // The overlay never takes a touch itself: only its marker views do.
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent?): Boolean = false

    fun put(id: String, options: SMapCustomMarkerOptions, data: FeatureCollection) {
        remove(id)
        val layer = Layer(id, options, data)
        layers[id] = layer
        layer.set.update(data)
        layout()
    }

    fun setData(id: String, data: FeatureCollection) {
        val layer = layers[id] ?: return
        layer.data = data
        layer.set.update(data).forEach { gone -> gone.view?.let(::removeView) }
        layout()
    }

    fun setHidden(id: String, hidden: Boolean) { layers[id]?.hidden = hidden; layout() }

    fun remove(id: String) {
        val layer = layers.remove(id) ?: return
        layer.set.items.forEach { item -> item.view?.let(::removeView) }
    }

    /** The view of a marker made so far (null while it has none). */
    fun viewOf(id: String, key: String): View? = layers[id]?.set?.item(key)?.view

    /** The layer's data is now [data] (the map's own copy, shared so moves and updates reach both). */
    fun shareData(id: String, data: FeatureCollection) { layers[id]?.data = data }

    /**
     * One marker's feature changed (G23): [moved] only its position (laid out at the next layout), else its properties
     * too (its view is rendered again).
     */
    fun refresh(id: String, key: String, feature: Feature, moved: Boolean = false) {
        val item = layers[id]?.set?.item(key) ?: return
        item.feature = feature
        if (!moved) { item.stale = true; layout() }
    }

    /** The markers whose views cover a point of the map, top first: the top layer first, then a higher z first (G19). */
    fun hits(x: Float, y: Float): List<Pair<String, SMapMarkerSet.Item<View>>> {
        val out = ArrayList<Pair<String, SMapMarkerSet.Item<View>>>()
        for (id in order().asReversed()) {
            val layer = layers[id] ?: continue
            if (layer.hidden) continue
            layer.set.items.filter { item ->
                val v = item.view
                item.shown && v != null && v.visibility == View.VISIBLE && x >= v.x && x <= v.x + v.width && y >= v.y && y <= v.y + v.height
            }.sortedByDescending { it.view!!.translationZ }.forEach { out += id to it }
        }
        return out
    }

    /**
     * (1.5.5) The markers of the layers in [ids] whose views are within [tolerance] pixels of a point of the map, top
     * first (as [hits]), each with its distance from the view's frame (0 inside; rotation ignored).
     */
    fun near(x: Float, y: Float, tolerance: Float, ids: Set<String>): List<Triple<String, SMapMarkerSet.Item<View>, Float>> {
        val out = ArrayList<Triple<String, SMapMarkerSet.Item<View>, Float>>()
        for (id in order().asReversed()) {
            if (id !in ids) continue
            val layer = layers[id] ?: continue
            if (layer.hidden) continue
            layer.set.items.mapNotNull { item ->
                val v = item.view
                if (!item.shown || v == null || v.visibility != View.VISIBLE) return@mapNotNull null
                val d = SMapTapMath.toBox(v.x, v.y, v.width.toFloat(), v.height.toFloat(), x, y)
                if (d <= tolerance) item to d else null
            }.sortedByDescending { it.first.view!!.translationZ }.forEach { (item, d) -> out += Triple(id, item, d) }
        }
        return out
    }

    fun marker(id: String, key: String): View? {
        val layer = layers[id] ?: return null
        val item = layer.set.item(key) ?: return null
        return item.view ?: render(layer, item)
    }

    private fun render(layer: Layer, item: SMapMarkerSet.Item<View>): View {
        val props = SMapGeoJson.propertiesOf(item.feature)
        val old = item.view
        val view = layer.options.render(props)
        if (old != null && old !== view) {
            removeView(old)
            item.shown = false
        }
        item.view = view
        item.stale = false
        view.alpha = layer.options.opacity.read(props, 1f)
        view.tag = item.key
        bind(layer, item, view)
        if (view.parent == null) {
            // The size the app gave the view's layout parameters, else its content's (a snapshot marker is sized the same way).
            val lp = view.layoutParams
            addView(view, LayoutParams(lp?.width?.takeIf { it > 0 } ?: ViewGroup.LayoutParams.WRAP_CONTENT, lp?.height?.takeIf { it > 0 } ?: ViewGroup.LayoutParams.WRAP_CONTENT))
            view.visibility = View.INVISIBLE
        }
        host?.markerRendered(layer.id, item.key, view)
        return view
    }

    /** Places every marker in view; the ones out of view leave the screen (and are kept). */
    fun layout() {
        val map = map ?: return
        val w = width.takeIf { it > 0 } ?: mapView.width
        val h = height.takeIf { it > 0 } ?: mapView.height
        val zoom = map.cameraPosition.zoom
        val bearing = map.cameraPosition.bearing.toFloat()
        val projection = map.projection
        val ids = order()
        var rank = 0
        for (id in ids) {
            val layer = layers[id] ?: continue
            rank += 1
            val o = layer.options
            val inRange = !layer.hidden && (o.minZoom == null || zoom >= o.minZoom) && (o.maxZoom == null || zoom < o.maxZoom)
            val offX = o.offsetDp.first * density
            val offY = o.offsetDp.second * density
            for (item in layer.set.items) {
                val p = if (inRange) projection.toScreenLocation(LatLng(item.lat, item.lng)) else null
                if (p == null || !SMapMarkerSet.inView(p.x, p.y, w, h, MARGIN_DP * density)) {
                    if (item.shown) { item.view?.visibility = View.GONE; item.shown = false }
                    continue
                }
                val view = if (item.view == null || item.stale) render(layer, item) else item.view!!
                if (view.width == 0) {
                    view.measure(MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
                }
                val vw = if (view.width > 0) view.width else view.measuredWidth
                val vh = if (view.height > 0) view.height else view.measuredHeight
                view.translationX = p.x - o.anchor.x * vw + offX
                view.translationY = p.y - o.anchor.y * vh + offY
                val props = SMapGeoJson.propertiesOf(item.feature)
                // A heading turns the view about its anchor (G24).
                o.rotation?.read(props, Float.NaN)?.takeIf { !it.isNaN() }?.let { heading ->
                    view.pivotX = o.anchor.x * vw
                    view.pivotY = o.anchor.y * vh
                    view.rotation = viewRotation(heading, bearing, o.rotationAlignment)
                }
                val z = o.zIndex.read(props, 0).coerceIn(-99_999, 99_998)
                view.translationZ = if (item.dragAt != null) Z_TOP else rank * 100_000f + z
                if (!item.shown) { view.visibility = View.VISIBLE; item.shown = true }
            }
        }
    }

    // ---- touch: a tap, or a long press that drags or shows the tooltip; until then the map gets the touch

    @SuppressLint("ClickableViewAccessibility")
    private fun bind(layer: Layer, item: SMapMarkerSet.Item<View>, view: View) {
        val slop = ViewConfiguration.get(context).scaledTouchSlop
        val handler = Handler(Looper.getMainLooper())
        var downX = 0f; var downY = 0f
        var pressed = false; var moved = false; var dragging = false; var tipping = false
        var grabX = 0f; var grabY = 0f
        fun toMap(e: MotionEvent): MotionEvent = MotionEvent.obtain(e).apply { offsetLocation(view.left + view.translationX, view.top + view.translationY) }
        fun feature() = SMapFeature(item.key, SMapGeoJson.propertiesOf(item.feature), LatLng(item.lat, item.lng))
        val longPress = Runnable {
            if (!pressed || moved) return@Runnable
            val o = layer.options
            val props = SMapGeoJson.propertiesOf(item.feature)
            val cancel = MotionEvent.obtain(0, 0, MotionEvent.ACTION_CANCEL, 0f, 0f, 0)
            mapView.dispatchTouchEvent(cancel); cancel.recycle()
            if (o.drag.draggable.read(props, false)) {
                dragging = true
                view.scaleX = LIFT; view.scaleY = LIFT
                hideTooltip()
                val p = map!!.projection.toScreenLocation(LatLng(item.lat, item.lng))
                grabX = view.left + view.translationX + downX - p.x
                grabY = view.top + view.translationY + downY - p.y
                o.drag.onDragStart?.invoke(feature(), SMapDragEvent(LatLng(item.lat, item.lng), p.x, p.y))
            } else {
                // A long press that does not drag is the context menu (G19); the tooltip still shows meanwhile.
                host?.contextMenuAt(android.graphics.PointF(view.x + downX, view.y + downY), null)
                if (o.tooltip != null) {
                    tipping = true
                    showTooltip(o.tooltip, props, view)
                }
            }
        }
        view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    pressed = true; moved = false; dragging = false; tipping = false
                    downX = e.x; downY = e.y
                    handler.postDelayed(longPress, LONG_PRESS_MS)
                    toMap(e).also { mapView.dispatchTouchEvent(it); it.recycle() }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (dragging) {
                        val x = view.left + view.translationX + e.x - grabX
                        val y = view.top + view.translationY + e.y - grabY
                        val ll = map!!.projection.fromScreenLocation(android.graphics.PointF(x, y))
                        item.dragAt = doubleArrayOf(ll.longitude, ll.latitude)
                        layout()
                        layer.options.drag.onDrag?.invoke(feature(), SMapDragEvent(ll, x, y))
                    } else if (!tipping) {
                        if (abs(e.x - downX) > slop || abs(e.y - downY) > slop) { moved = true; handler.removeCallbacks(longPress) }
                        toMap(e).also { mapView.dispatchTouchEvent(it); it.recycle() }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress)
                    val was = pressed
                    pressed = false
                    when {
                        dragging -> {
                            view.scaleX = 1f; view.scaleY = 1f
                            val at = item.dragAt
                            item.dragAt = null
                            if (at != null) {
                                val next = moveFeature(layer.data, item.index, at)
                                layer.data = next
                                item.feature = next.features()!![item.index]
                                moved(layer.id, next)
                                val p = map!!.projection.toScreenLocation(LatLng(at[1], at[0]))
                                layer.options.drag.onDragEnd?.invoke(feature(), SMapDragEvent(LatLng(at[1], at[0]), p.x, p.y))
                            }
                            layout()
                        }
                        tipping -> hideTooltip()
                        else -> {
                            toMap(e).also { mapView.dispatchTouchEvent(it); it.recycle() }
                            // (1.5.5) The map answers a custom marker layer's tap with every point and marker
                            // near it (nearest first, piled ones to choose from); view clusters answer themselves.
                            if (was && !moved && e.actionMasked == MotionEvent.ACTION_UP &&
                                host?.markerTapped(layer.id, view.x + e.x, view.y + e.y) != true) layer.options.onTap?.invoke(feature())
                        }
                    }
                    dragging = false; tipping = false
                }
                else -> if (!dragging && !tipping) toMap(e).also { mapView.dispatchTouchEvent(it); it.recycle() }
            }
            true
        }
    }

    // ---- the tooltip

    fun showTooltip(t: SMapTooltip, properties: Map<String, Any?>, anchor: View) {
        val text = t.text(properties)?.takeIf { it.isNotEmpty() } ?: return hideTooltip()
        place(t, text, anchor.left + anchor.translationX, anchor.top + anchor.translationY, anchor.width.toFloat(), anchor.height.toFloat())
    }

    /** At a point of the map (a drawn point: [size] its size; a line or area: 0, beside the finger). */
    fun showTooltip(t: SMapTooltip, properties: Map<String, Any?>, x: Float, y: Float, size: Float) {
        val text = t.text(properties)?.takeIf { it.isNotEmpty() } ?: return hideTooltip()
        val gap = if (size > 0) size else 24 * density
        place(t, text, x - gap / 2, y - gap / 2, gap, gap)
    }

    private fun place(t: SMapTooltip, text: String, left: Float, top: Float, w: Float, h: Float) {
        tooltip.text = text
        tooltip.visibility = View.VISIBLE
        tooltip.measure(MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        val tw = tooltip.measuredWidth.toFloat(); val th = tooltip.measuredHeight.toFloat()
        val gap = 6 * density
        val (x, y) = when (t.direction) {
            SMapTooltipDirection.TOP -> (left + w / 2 - tw / 2) to (top - th - gap)
            SMapTooltipDirection.BOTTOM -> (left + w / 2 - tw / 2) to (top + h + gap)
            SMapTooltipDirection.LEFT -> (left - tw - gap) to (top + h / 2 - th / 2)
            SMapTooltipDirection.RIGHT -> (left + w + gap) to (top + h / 2 - th / 2)
        }
        tooltip.translationX = x + t.offsetDp.first * density
        tooltip.translationY = y + t.offsetDp.second * density
        tooltip.bringToFront()
    }

    fun hideTooltip() { tooltip.visibility = View.GONE }

    companion object {
        const val MARGIN_DP = 64f
        const val LONG_PRESS_MS = 500L
        const val LIFT = 1.1f
        private const val Z_TOP = 1e9f

        /**
         * The view rotation of a heading (G24): from north, turning with the map ([SMapRotationAlignment.MAP]: the
         * heading less the map's bearing), or from the top of the screen.
         */
        fun viewRotation(heading: Float, bearing: Float, alignment: SMapRotationAlignment): Float =
            if (alignment == SMapRotationAlignment.MAP) heading - bearing else heading

        /** A copy of the data with one feature's point moved (the caller's objects are not changed). */
        fun moveFeature(data: FeatureCollection, index: Int, lngLat: DoubleArray): FeatureCollection {
            val features = ArrayList(data.features() ?: emptyList())
            val f = features[index]
            features[index] = Feature.fromGeometry(Point.fromLngLat(lngLat[0], lngLat[1]), f.properties()?.deepCopy(), f.id())
            return FeatureCollection.fromFeatures(features)
        }
    }
}
