package ca.superroute.smap

/**
 * A small XML reader for KML, GPX and WMTS capabilities, the same as the JavaScript SDK's (so every SDK reads the same
 * files the same way, malformed ones included): elements with their name, local name (prefix dropped), attributes and
 * children (elements and text). Comments, processing instructions and DOCTYPE are skipped; no entity is ever loaded.
 */
internal object SMapXml {
    class El(val name: String, val attrs: Map<String, String>) {
        val local: String = name.substringAfterLast(':')
        val children = ArrayList<Any>() // El or String
    }

    private val ENTITIES = mapOf("lt" to "<", "gt" to ">", "amp" to "&", "quot" to "\"", "apos" to "'")
    private val ENTITY = Regex("&(#x[0-9a-fA-F]+|#[0-9]+|[a-zA-Z]+);")

    fun decodeEntities(s: String): String {
        if (s.indexOf('&') < 0) return s
        return ENTITY.replace(s) { m ->
            val e = m.groupValues[1]
            if (e[0] == '#') {
                val cp = if (e.length > 1 && (e[1] == 'x' || e[1] == 'X')) e.substring(2).toIntOrNull(16) else e.substring(1).toIntOrNull()
                if (cp != null && cp in 0..0x10FFFF) String(Character.toChars(cp)) else m.value
            } else ENTITIES[e] ?: m.value
        }
    }

    private val ATTR = Regex("([^\\s=]+)\\s*=\\s*(\"([^\"]*)\"|'([^']*)')")
    private val TAG_NAME = Regex("^([^\\s/>]+)")
    private val SELF_CLOSE = Regex("/\\s*$")

    fun parse(text: String): El {
        val s = text
        val doc = El("#document", emptyMap())
        val stack = ArrayList<El>().apply { add(doc) }
        fun top() = stack[stack.size - 1]
        var i = 0
        val n = s.length
        while (i < n) {
            val lt = s.indexOf('<', i)
            if (lt < 0) { top().children += decodeEntities(s.substring(i)); break }
            if (lt > i) top().children += decodeEntities(s.substring(i, lt))
            if (s.startsWith("<!--", lt)) { val end = s.indexOf("-->", lt + 4); i = if (end < 0) n else end + 3; continue }
            if (s.startsWith("<![CDATA[", lt)) {
                val end = s.indexOf("]]>", lt + 9)
                top().children += s.substring(lt + 9, if (end < 0) n else end)
                i = if (end < 0) n else end + 3
                continue
            }
            if (lt + 1 < n && s[lt + 1] == '?') { val end = s.indexOf("?>", lt + 2); i = if (end < 0) n else end + 2; continue }
            if (lt + 1 < n && s[lt + 1] == '!') {
                var depth = 0
                var j = lt + 2
                while (j < n) {
                    val c = s[j]
                    if (c == '[') depth++ else if (c == ']') depth-- else if (c == '>' && depth <= 0) break
                    j++
                }
                i = j + 1
                continue
            }
            if (lt + 1 < n && s[lt + 1] == '/') {
                val end = s.indexOf('>', lt)
                val closing = s.substring(lt + 2, if (end < 0) n else end).trim()
                for (k in stack.size - 1 downTo 1) {
                    if (stack[k].name == closing) { while (stack.size > k) stack.removeAt(stack.size - 1); break }
                }
                i = if (end < 0) n else end + 1
                continue
            }
            var q: Char? = null
            var p = lt + 1
            while (p < n) {
                val c = s[p]
                if (q != null) { if (c == q) q = null } else if (c == '"' || c == '\'') q = c else if (c == '>') break
                p++
            }
            var body = s.substring(lt + 1, minOf(p, n))
            val selfClose = SELF_CLOSE.containsMatchIn(body)
            if (selfClose) body = SELF_CLOSE.replace(body, "")
            val m = TAG_NAME.find(body)
            if (m == null) { i = p + 1; continue }
            val attrs = LinkedHashMap<String, String>()
            val rest = body.substring(m.groupValues[1].length)
            for (a in ATTR.findAll(rest)) {
                attrs[a.groupValues[1]] = decodeEntities(if (a.groups[3] != null) a.groupValues[3] else a.groupValues[4])
            }
            val el = El(m.groupValues[1], attrs)
            top().children += el
            if (!selfClose) stack += el
            i = p + 1
        }
        return doc
    }

    fun elems(el: El?, local: String? = null): List<El> =
        el?.children?.filterIsInstance<El>()?.filter { local == null || it.local == local } ?: emptyList()

    fun elem(el: El?, local: String): El? = elems(el, local).firstOrNull()

    fun textOf(el: El?): String {
        if (el == null) return ""
        val sb = StringBuilder()
        for (c in el.children) if (c is String) sb.append(c) else sb.append(textOf(c as El))
        return sb.toString()
    }

    /** The text of [el], trimmed as JavaScript's `trim` does. */
    fun trimmed(el: El?): String = jsTrim(textOf(el))

    fun descendants(el: El?, local: String, out: MutableList<El> = ArrayList()): MutableList<El> {
        for (c in elems(el)) {
            if (c.local == local) out += c
            descendants(c, local, out)
        }
        return out
    }

    fun attr(el: El?, local: String): String? {
        el ?: return null
        for ((k, v) in el.attrs) if (k == local || k.substringAfterLast(':') == local) return v
        return null
    }

    /** JavaScript's white space for `trim` and `\s`. */
    fun isJsSpace(c: Char): Boolean = c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\u000B' || c == '\u000C' ||
        c == '\u00A0' || c == '\uFEFF' || c == '\u1680' || c in '\u2000'..'\u200A' || c == '\u2028' || c == '\u2029' ||
        c == '\u202F' || c == '\u205F' || c == '\u3000'

    fun jsTrim(s: String): String = s.trim { isJsSpace(it) }

    /** JavaScript's `/\s+/`. */
    val JS_SPACES = Regex("[\\s\\u00A0\\uFEFF\\u1680\\u2000-\\u200A\\u2028\\u2029\\u202F\\u205F\\u3000]+")
}

/** JavaScript's number conversions, so text is read into the same numbers as the JavaScript SDK reads it. */
internal object SMapJsNumber {
    private val DECIMAL = Regex("^[+-]?(\\d+\\.?\\d*|\\.\\d+)([eE][+-]?\\d+)?$")
    private val PREFIX = Regex("^[+-]?(Infinity|(\\d+\\.?\\d*|\\.\\d+)([eE][+-]?\\d+)?)")

    /** `Number(s)`. */
    fun number(s: String): Double {
        val t = SMapXml.jsTrim(s)
        if (t.isEmpty()) return 0.0
        if (DECIMAL.matches(t)) return t.toDouble()
        when (t) {
            "Infinity", "+Infinity" -> return Double.POSITIVE_INFINITY
            "-Infinity" -> return Double.NEGATIVE_INFINITY
        }
        val radix = when {
            t.startsWith("0x") || t.startsWith("0X") -> 16
            t.startsWith("0o") || t.startsWith("0O") -> 8
            t.startsWith("0b") || t.startsWith("0B") -> 2
            else -> return Double.NaN
        }
        return t.substring(2).takeIf { it.isNotEmpty() }?.toBigIntegerOrNull(radix)?.toDouble() ?: Double.NaN
    }

    /** `parseFloat(s)`. */
    fun parseFloat(s: String?): Double {
        if (s == null) return Double.NaN
        val t = s.trimStart { SMapXml.isJsSpace(it) }
        val m = PREFIX.find(t) ?: return Double.NaN
        val v = m.value
        return when {
            v.endsWith("Infinity") -> if (v.startsWith("-")) Double.NEGATIVE_INFINITY else Double.POSITIVE_INFINITY
            else -> v.toDouble()
        }
    }

    /** `parseInt(s, 10)`, or null for NaN. */
    fun parseInt(s: String?): Int? {
        val t = s?.trimStart { SMapXml.isJsSpace(it) } ?: return null
        return Regex("^[+-]?\\d+").find(t)?.value?.toIntOrNull()
    }

    fun finite(v: Double) = !v.isNaN() && !v.isInfinite()

    /** `String(n)` of a number. */
    fun string(v: Double): String = if (v.isNaN()) "NaN" else if (v.isInfinite()) (if (v > 0) "Infinity" else "-Infinity") else SMapJson.number(v)

    /** `encodeURIComponent(s)`. */
    fun encodeURIComponent(s: String): String {
        val sb = StringBuilder()
        for (b in s.toByteArray(Charsets.UTF_8)) {
            val c = b.toInt() and 0xff
            val ch = c.toChar()
            if (c < 0x80 && (ch.isLetterOrDigit() || ch in "-_.!~*'()")) sb.append(ch)
            else sb.append('%').append(String.format("%02X", c))
        }
        return sb.toString()
    }
}
