package ca.superroute.smap

import ca.superroute.smap.SMapJson.bool
import ca.superroute.smap.SMapJson.num
import ca.superroute.smap.SMapJson.objOrNull
import ca.superroute.smap.SMapJson.str
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive

/**
 * How one basemap class is changed (every field optional).
 *
 * @param visible shows or hides the class
 * @param color fill, line or background colour; the text colour for labels; never casings
 * @param casing the colour of road casings
 * @param halo the text halo colour of labels
 * @param opacity 0..1
 * @param width a line width factor, 0.25..4 (lines and casings)
 */
data class SMapBasemapOverride(
    val visible: Boolean? = null,
    val color: String? = null,
    val casing: String? = null,
    val halo: String? = null,
    val opacity: Double? = null,
    val width: Double? = null,
)

/** One basemap layer property the runtime sets; a null [value] puts the style's own value back. */
data class SMapPropertyChange(val layer: String, val paint: Boolean, val name: String, val value: JsonElement?)

/**
 * The basemap classes (`water`, `roads.major`, `labels.places`, …) of the shared class table and the one function
 * that applies class overrides to a style ([apply]); the same rules as the map service and every other SDK.
 */
object SMapBasemap {
    /** The fields an override may carry. */
    val FIELDS = listOf("visible", "color", "casing", "halo", "opacity", "width")

    /** The class table as shipped (`basemap-classes.json`, copied verbatim from the shared folder). */
    val TABLE_JSON: String by lazy {
        val stream = SMapBasemap::class.java.getResourceAsStream("basemap-classes.json")
            ?: throw IllegalStateException("sMap: basemap-classes.json is missing from the library")
        stream.use { it.readBytes().toString(Charsets.UTF_8) }
    }

    private class Table(val classes: List<Pair<String, List<Pair<String, String>>>>, val paint: Map<String, Map<String, String>>)

    private val table: Table by lazy {
        val v = SMapJson.parseObject(TABLE_JSON)
        val classes = v.getAsJsonObject("classes").entrySet().map { (name, layers) ->
            name to layers.asJsonArray.map { l -> l.asJsonObject.str("layer").orEmpty() to l.asJsonObject.str("role").orEmpty() }
        }
        val paint = v.getAsJsonObject("paint").entrySet().associate { (role, keys) ->
            role to keys.asJsonObject.entrySet().associate { (f, k) -> f to k.asString }
        }
        Table(classes, paint)
    }

    /** Every class name of the table, in its order. */
    val classes: List<String> get() = table.classes.map { it.first }

    /** The layers of a class as (layer id, role). Empty for an unknown class. */
    fun layersOf(name: String): List<Pair<String, String>> = table.classes.firstOrNull { it.first == name }?.second.orEmpty()

    /** Every basemap layer id the table names. */
    val layerIds: Set<String> by lazy { table.classes.flatMap { c -> c.second.map { it.first } }.toSet() }

    /** The layer ids of every label-role layer. */
    val labelLayerIds: Set<String> by lazy {
        table.classes.flatMap { c -> c.second.filter { it.second == "label" }.map { it.first } }.toSet()
    }

    private fun parent(name: String): String? = name.substringBefore('.', "").ifEmpty { null }

    /** True for a class of the table or a parent key (`roads`, `labels`). */
    fun isClass(name: String): Boolean = table.classes.any { (c, _) -> c == name || parent(c) == name }

    /** Overrides as the contract's JSON object (fields left null are not written). */
    fun toJson(overrides: Map<String, SMapBasemapOverride>): JsonObject = JsonObject().also { o ->
        for ((name, v) in overrides) {
            o.add(name, SMapJson.obj(
                "visible" to v.visible, "color" to v.color, "casing" to v.casing,
                "halo" to v.halo, "opacity" to v.opacity, "width" to v.width,
            ))
        }
    }

    /**
     * The contract's JSON object as overrides.
     *
     * @throws IllegalArgumentException naming every unknown class, unknown field and unusable value
     */
    fun fromJson(json: JsonObject): Map<String, SMapBasemapOverride> {
        refuse(json)
        return json.entrySet().associate { (name, v) ->
            val o = v.asJsonObject
            name to SMapBasemapOverride(o.bool("visible"), o.str("color"), o.str("casing"), o.str("halo"), o.num("opacity"), o.num("width"))
        }
    }

    /** Throws [IllegalArgumentException] naming what [check] finds. */
    fun refuse(overrides: JsonObject) {
        val problems = check(overrides)
        if (problems.isNotEmpty()) throw IllegalArgumentException("sMap: " + problems.joinToString("; "))
    }

    /** What is wrong in [overrides], named (`unknown class "x"`, `water: unknown field "y"`, bad values). */
    fun check(overrides: JsonElement?): List<String> {
        val problems = ArrayList<String>()
        if (overrides == null || overrides.isJsonNull) return problems
        if (!overrides.isJsonObject) return listOf("basemap overrides must be an object")
        for ((name, o) in overrides.asJsonObject.entrySet()) {
            if (!isClass(name)) { problems += "unknown basemap class \"$name\""; continue }
            if (!o.isJsonObject) { problems += "basemap class \"$name\" needs an object"; continue }
            for ((field, value) in o.asJsonObject.entrySet()) {
                if (field !in FIELDS) problems += "unknown field \"$field\" on basemap class \"$name\""
                else if (!valid(field, value)) problems += "\"$name.$field\" " + when (field) {
                    "visible" -> "must be true or false"
                    "opacity" -> "must be between 0 and 1"
                    "width" -> "must be between 0.25 and 4"
                    else -> "must be a colour"
                }
            }
        }
        return problems
    }

    private fun valid(field: String, value: JsonElement): Boolean {
        val p = value.takeIf { it.isJsonPrimitive }?.asJsonPrimitive ?: return false
        return when (field) {
            "visible" -> p.isBoolean
            "color", "casing", "halo" -> p.isString && p.asString.isNotEmpty()
            "opacity" -> p.isNumber && p.asDouble in 0.0..1.0
            "width" -> p.isNumber && p.asDouble in 0.25..4.0
            else -> false
        }
    }

    /** JavaScript's `Math.round(n * 10000) / 10000`. */
    internal fun round4(n: Double): Double = Math.floor(n * 10000 + 0.5) / 10000

    /**
     * A line width scaled by [factor] (contract §11, the same output as the JavaScript SDK): a number becomes
     * round(n × f, 4 decimals); a top-level `interpolate` / `step` / legacy `{stops}` keeps its structure with each
     * output scaled the same way (the input is not checked); any other value becomes `["*", f, value]`; no width
     * counts as 1.
     */
    fun scaleWidth(original: JsonElement?, factor: Double): JsonElement {
        val w = if (original == null || original.isJsonNull) JsonPrimitive(1) else original
        if (w.isJsonPrimitive && w.asJsonPrimitive.isNumber) return JsonPrimitive(round4(w.asDouble * factor))
        if (w.isJsonObject && w.asJsonObject.get("stops")?.isJsonArray == true) {
            val out = w.asJsonObject.deepCopy()
            for (stop in out.getAsJsonArray("stops")) {
                if (stop.isJsonArray && stop.asJsonArray.size() == 2) stop.asJsonArray.set(1, scaleWidth(stop.asJsonArray[1], factor))
            }
            return out
        }
        if (w.isJsonArray && w.asJsonArray.size() > 0) {
            val a = w.asJsonArray
            val head = a[0].takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString
            val first = when (head) { "interpolate" -> 4; "step" -> 2; else -> -1 }
            if (first >= 0) {
                val out = JsonArray()
                for (i in 0 until a.size()) out.add(if (i >= first && (i - first) % 2 == 0) scaleWidth(a[i], factor) else a[i].deepCopy())
                return out
            }
        }
        return JsonArray().apply { add("*"); add(JsonPrimitive(factor)); add(w.deepCopy()) }
    }

    /**
     * Contract §1: the style (a Style Spec v8 object) with [overrides] applied — parent keys first, then their classes
     * (a class's own value wins). A copy is returned; [style] is not changed. Unknown classes, fields and unusable
     * values are skipped here (use [check] / [refuse] to name them); layers the style does not have are skipped.
     */
    fun apply(style: JsonObject, overrides: JsonObject?): JsonObject {
        val out = style.deepCopy()
        if (overrides == null) return out
        val layers = out.get("layers")?.takeIf { it.isJsonArray }?.asJsonArray ?: return out
        val byId = HashMap<String, JsonObject>()
        for (l in layers) if (l.isJsonObject) l.asJsonObject.str("id")?.let { byId[it] = l.asJsonObject }
        for ((name, classLayers) in table.classes) {
            val merged = LinkedHashMap<String, JsonElement>()
            for (key in listOfNotNull(parent(name), name)) {
                val o = overrides.objOrNull(key) ?: continue
                for ((field, value) in o.entrySet()) if (field in FIELDS && valid(field, value)) merged[field] = value
            }
            if (merged.isEmpty()) continue
            for ((layerId, role) in classLayers) {
                val layer = byId[layerId] ?: continue
                val keys = table.paint[role] ?: continue
                merged["visible"]?.let { v ->
                    val layout = layer.objOrNull("layout") ?: JsonObject().also { layer.add("layout", it) }
                    layout.addProperty("visibility", if (v.asBoolean) "visible" else "none")
                }
                for (field in listOf("color", "casing", "halo", "opacity")) {
                    val value = merged[field] ?: continue
                    val key = keys[field] ?: continue
                    paintOf(layer).add(key, value.deepCopy())
                }
                val width = merged["width"]
                val widthKey = keys["width"]
                if (width != null && widthKey != null) {
                    val paint = paintOf(layer)
                    paint.add(widthKey, scaleWidth(paint.get(widthKey), width.asDouble))
                }
            }
        }
        return out
    }

    private fun paintOf(layer: JsonObject): JsonObject =
        layer.objOrNull("paint") ?: JsonObject().also { layer.add("paint", it) }

    /**
     * The property changes that turn the basemap layers of style [from] into those of style [to] (both the same
     * style with different overrides): every paint and layout value that differs, a value [to] does not have as null.
     * Only layers of the class table are compared.
     */
    fun changes(from: JsonObject, to: JsonObject): List<SMapPropertyChange> {
        val a = layerMap(from)
        val out = ArrayList<SMapPropertyChange>()
        for ((id, target) in layerMap(to)) {
            if (id !in layerIds) continue
            val source = a[id] ?: continue
            for (paint in listOf(false, true)) {
                val key = if (paint) "paint" else "layout"
                val x = source.objOrNull(key) ?: JsonObject()
                val y = target.objOrNull(key) ?: JsonObject()
                for (name in (x.keySet() + y.keySet()).sorted()) {
                    val before = x.get(name)
                    val after = y.get(name)
                    if (before != after) out += SMapPropertyChange(id, paint, name, after)
                }
            }
        }
        return out
    }

    private fun layerMap(style: JsonObject): LinkedHashMap<String, JsonObject> {
        val m = LinkedHashMap<String, JsonObject>()
        style.get("layers")?.takeIf { it.isJsonArray }?.asJsonArray?.forEach { l ->
            if (l.isJsonObject) l.asJsonObject.str("id")?.let { m[it] = l.asJsonObject }
        }
        return m
    }
}
