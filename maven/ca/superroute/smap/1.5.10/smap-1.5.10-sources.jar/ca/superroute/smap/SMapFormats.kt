package ca.superroute.smap

import ca.superroute.smap.SMapJson.arrOrNull
import ca.superroute.smap.SMapJson.objOrNull
import ca.superroute.smap.SMapJson.str
import ca.superroute.smap.SMapJsNumber.finite
import ca.superroute.smap.SMapXml.El
import ca.superroute.smap.SMapXml.elem
import ca.superroute.smap.SMapXml.elems
import ca.superroute.smap.SMapXml.trimmed
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive
import org.maplibre.geojson.FeatureCollection
import java.io.ByteArrayInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipInputStream

/**
 * Reads map data files into GeoJSON FeatureCollections on the device, with the same answers as every other SDK and
 * the map service's converting endpoint: KML, KMZ, GPX, encoded polylines (precision 5 and 6), WKT, WKB, CSV with
 * latitude / longitude columns, TopoJSON and GeoJSON. Writes GeoJSON and KML.
 */
object SMapFormats {
    /** Every format name [read] takes. */
    val FORMATS = listOf("kml", "kmz", "gpx", "polyline", "polyline6", "wkt", "wkb", "csv", "topojson", "geojson")

    private val GEOMETRY_TYPES = setOf("Point", "MultiPoint", "LineString", "MultiLineString", "Polygon", "MultiPolygon", "GeometryCollection")

    /**
     * Reads [input] as a FeatureCollection (JSON).
     *
     * @param format one of [FORMATS]; when null, from [fileName]'s extension, else guessed from the content
     *   (encoded polylines are never guessed)
     * @param lat the latitude column of a CSV file (guessed from common headings when null)
     * @param lng the longitude column of a CSV file (guessed when null)
     * @throws IllegalArgumentException when the input cannot be read in that format
     */
    fun readJson(input: ByteArray, format: String? = null, lat: String? = null, lng: String? = null, fileName: String? = null): JsonObject =
        readAny(input, null, format, lat, lng, fileName)

    /** [readJson] for text input (WKB as hexadecimal text). */
    fun readJson(input: String, format: String? = null, lat: String? = null, lng: String? = null, fileName: String? = null): JsonObject =
        readAny(null, input, format, lat, lng, fileName)

    /** [readJson] for parsed GeoJSON or TopoJSON. */
    fun readJson(input: JsonObject, format: String? = null): JsonObject {
        val f = format?.lowercase() ?: if (input.str("type") == "Topology") "topojson" else "geojson"
        return when (f) {
            "topojson" -> readTopojson(input)
            "geojson" -> readGeojson(input)
            else -> throw IllegalArgumentException("sMap: $f needs text or bytes")
        }
    }

    /** [readJson] as the engine's FeatureCollection. */
    fun read(input: ByteArray, format: String? = null, lat: String? = null, lng: String? = null, fileName: String? = null): FeatureCollection =
        FeatureCollection.fromJson(readJson(input, format, lat, lng, fileName).toString())

    /** [read] for text input. */
    fun read(input: String, format: String? = null, lat: String? = null, lng: String? = null, fileName: String? = null): FeatureCollection =
        FeatureCollection.fromJson(readJson(input, format, lat, lng, fileName).toString())

    private fun readAny(bytes: ByteArray?, string: String?, format: String?, lat: String?, lng: String?, fileName: String?): JsonObject {
        val f = format?.lowercase() ?: formatOfName(fileName) ?: sniff(bytes, string)
            ?: throw IllegalArgumentException("sMap: the file format could not be recognised; name the format")
        if (f !in FORMATS) throw IllegalArgumentException("sMap: unknown format \"$f\"")
        fun text(): String = string ?: utf8(bytes!!)
        fun json(): JsonObject {
            val e = SMapJson.parse(stripBom(text()))
            if (!e.isJsonObject) throw IllegalArgumentException("sMap: not GeoJSON")
            return e.asJsonObject
        }
        return when (f) {
            "kml" -> readKml(text())
            "kmz" -> readKmz(bytes ?: throw IllegalArgumentException("sMap: kmz needs bytes"))
            "gpx" -> readGpx(text())
            "polyline" -> readPolyline(text(), 5)
            "polyline6" -> readPolyline(text(), 6)
            "wkt" -> readWkt(text())
            "wkb" -> when {
                string != null -> readWkbHex(string)
                hexText(bytes!!) -> readWkbHex(SMapXml.jsTrim(utf8(bytes)))
                else -> readWkb(listOf(bytes))
            }
            "csv" -> readCsv(text(), lat, lng)
            "topojson" -> readTopojson(json())
            else -> readGeojson(json())
        }
    }

    private val HEX_TEXT = Regex("^[\\s0-9a-fA-Fx\\\\]+$")
    private fun hexText(b: ByteArray): Boolean =
        b.isNotEmpty() && b[0].toInt() != 0 && b[0].toInt() != 1 && HEX_TEXT.matches(SMapXml.jsTrim(utf8(b)))

    private fun utf8(b: ByteArray): String = String(b, Charsets.UTF_8)
    private fun stripBom(s: String): String = if (s.isNotEmpty() && s[0] == '﻿') s.substring(1) else s

    private val EXTENSIONS = mapOf(
        "kml" to "kml", "kmz" to "kmz", "gpx" to "gpx", "wkt" to "wkt", "wkb" to "wkb", "csv" to "csv", "tsv" to "csv",
        "topojson" to "topojson", "geojson" to "geojson", "polyline" to "polyline", "polyline6" to "polyline6",
    )

    /** The format of a file name's extension, or null. */
    fun formatOfName(name: String?): String? {
        val m = Regex("\\.([A-Za-z0-9]+)$").find(name ?: return null) ?: return null
        return EXTENSIONS[m.groupValues[1].lowercase()]
    }

    /** Guesses the format from the content: zip → kmz, XML root kml / gpx, JSON Topology / GeoJSON, WKT, hex WKB, CSV. */
    fun guess(input: ByteArray): String? = sniff(input, null)

    /** [guess] for text. */
    fun guess(input: String): String? = sniff(null, input)

    private val WKT_START = Regex("^(SRID=\\d+;)?\\s*(POINT|LINESTRING|POLYGON|MULTIPOINT|MULTILINESTRING|MULTIPOLYGON|GEOMETRYCOLLECTION)\\b", RegexOption.IGNORE_CASE)
    private val WKB_HEX = Regex("^(\\\\x)?0[01][0-9a-fA-F]{8}")

    private fun sniff(bytes: ByteArray?, string: String?): String? {
        if (bytes != null && bytes.size >= 2 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte()) return "kmz"
        if (bytes != null && bytes.isNotEmpty() && (bytes[0].toInt() == 0 || bytes[0].toInt() == 1) && bytes.size >= 21) return "wkb"
        val s = SMapXml.jsTrim(stripBom(string ?: utf8(bytes!!)))
        if (s.startsWith("<")) {
            if (Regex("<kml[\\s>]", RegexOption.IGNORE_CASE).containsMatchIn(s)) return "kml"
            if (Regex("<gpx[\\s>]", RegexOption.IGNORE_CASE).containsMatchIn(s)) return "gpx"
            return null
        }
        if (s.startsWith("{")) return if (Regex("\"type\"\\s*:\\s*\"Topology\"").containsMatchIn(s)) "topojson" else "geojson"
        if (WKT_START.containsMatchIn(s)) return "wkt"
        if (WKB_HEX.containsMatchIn(s) && HEX_TEXT.matches(s)) return "wkb"
        val first = s.split(Regex("\\r?\\n"))[0].lowercase()
        if (Regex("[,;\\t|]").containsMatchIn(first)) {
            val cells = first.split(Regex("[,;\\t|]")).map { c -> SMapXml.jsTrim(c).replace(Regex("^\"|\"$"), "").replace(Regex("\\s+"), "_") }
            if ((LAT_HEADINGS + LNG_HEADINGS).any { it in cells }) return "csv"
        }
        return null
    }

    // ------------------------------------------------------------------ GeoJSON helpers

    fun collection(features: List<JsonObject>): JsonObject = JsonObject().apply {
        addProperty("type", "FeatureCollection")
        add("features", JsonArray().also { a -> features.forEach(a::add) })
    }

    /** `{type, id?, properties, geometry}`. */
    fun feature(properties: JsonObject?, geometry: JsonElement?, id: JsonElement? = null): JsonObject = JsonObject().apply {
        addProperty("type", "Feature")
        if (id != null && !id.isJsonNull) add("id", id)
        add("properties", properties ?: JsonObject())
        add("geometry", geometry?.takeIf { !it.isJsonNull } ?: JsonNull.INSTANCE)
    }

    fun geometry(type: String, coordinates: JsonElement): JsonObject = JsonObject().apply {
        addProperty("type", type)
        add("coordinates", coordinates)
    }

    private fun pos(vararg v: Double): JsonArray = JsonArray().also { a -> v.forEach { a.add(it) } }

    private fun arr(items: List<JsonElement>): JsonArray = JsonArray().also { a -> items.forEach(a::add) }

    /** Any GeoJSON object (FeatureCollection, Feature or geometry) as a FeatureCollection of `{type, id?, properties, geometry}` features. */
    fun readGeojson(data: JsonObject?): JsonObject {
        if (data == null) return collection(emptyList())
        fun norm(f: JsonObject) = feature(f.objOrNull("properties"), f.get("geometry"), f.get("id"))
        return when (val type = data.str("type")) {
            "FeatureCollection" -> collection(data.arrOrNull("features")?.filter { it.isJsonObject }?.map { norm(it.asJsonObject) } ?: emptyList())
            "Feature" -> collection(listOf(norm(data)))
            in GEOMETRY_TYPES -> collection(listOf(feature(JsonObject(), data)))
            else -> throw IllegalArgumentException("sMap: not GeoJSON" + (type?.let { " ($it)" } ?: ""))
        }
    }

    /**
     * Splits features into points, lines and areas, as [SMap.addData] draws them: multi-geometries go with their
     * single kind, a GeometryCollection's members each go to theirs (with the feature's properties and id), features
     * without a geometry are left out.
     */
    fun split(collection: JsonObject): Triple<JsonObject, JsonObject, JsonObject> {
        val points = ArrayList<JsonObject>()
        val lines = ArrayList<JsonObject>()
        val areas = ArrayList<JsonObject>()
        fun place(f: JsonObject, g: JsonElement?) {
            if (g == null || !g.isJsonObject) return
            val geom = g.asJsonObject
            val type = geom.str("type")
            if (type == "GeometryCollection") { geom.arrOrNull("geometries")?.forEach { place(f, it) }; return }
            val part = JsonObject().apply {
                addProperty("type", "Feature")
                add("properties", f.objOrNull("properties") ?: JsonObject())
                add("geometry", geom)
                f.get("id")?.let { add("id", it) }
            }
            when (type) {
                "Point", "MultiPoint" -> points += part
                "LineString", "MultiLineString" -> lines += part
                "Polygon", "MultiPolygon" -> areas += part
            }
        }
        collection.arrOrNull("features")?.forEach { if (it.isJsonObject) place(it.asJsonObject, it.asJsonObject.get("geometry")) }
        return Triple(collection(points), collection(lines), collection(areas))
    }

    // ------------------------------------------------------------------ KML

    /** KML `aabbggrr` as (`#rrggbb`, opacity rounded to 2 decimals). */
    fun kmlColor(v: String?): Pair<String, Double>? {
        val c = SMapXml.jsTrim(v ?: "").removePrefix("#")
        if (!Regex("^[0-9a-fA-F]{8}$").matches(c)) return null
        val l = c.lowercase()
        return "#" + l.substring(6, 8) + l.substring(4, 6) + l.substring(2, 4) to Math.round(l.substring(0, 2).toInt(16) / 255.0 * 100) / 100.0
    }

    private fun kmlCoords(text: String): List<JsonArray> {
        val out = ArrayList<JsonArray>()
        // Tuples are separated by white space that is not next to a comma ("-79.38, 43.65" is one tuple).
        val joined = SMapXml.jsTrim(Regex("[\\s\\u00A0\\uFEFF\\u1680\\u2000-\\u200A\\u2028\\u2029\\u202F\\u205F\\u3000]*,[\\s\\u00A0\\uFEFF\\u1680\\u2000-\\u200A\\u2028\\u2029\\u202F\\u205F\\u3000]*").replace(text, ","))
        for (tuple in joined.split(SMapXml.JS_SPACES)) {
            if (tuple.isEmpty()) continue
            val p = tuple.split(',').map { SMapJsNumber.number(it) }
            if (p.size < 2 || !finite(p[0]) || !finite(p[1])) continue
            out += if (p.size >= 3 && finite(p[2])) pos(p[0], p[1], p[2]) else pos(p[0], p[1])
        }
        return out
    }

    private val GEOMETRY_ELEMENTS = setOf("Point", "LineString", "LinearRing", "Polygon", "MultiGeometry", "Track", "MultiTrack")

    private fun kmlGeometry(el: El): JsonObject? {
        when (el.local) {
            "Point" -> return kmlCoords(trimmed(elem(el, "coordinates"))).firstOrNull()?.let { geometry("Point", it) }
            "LineString", "LinearRing" -> {
                val l = kmlCoords(trimmed(elem(el, "coordinates")))
                return if (l.isNotEmpty()) geometry("LineString", arr(l)) else null
            }
            "Polygon" -> {
                val rings = ArrayList<JsonArray>()
                fun ring(b: El) {
                    val r = elem(b, "LinearRing")
                    val cs = if (r != null) kmlCoords(trimmed(elem(r, "coordinates"))) else emptyList()
                    if (cs.isNotEmpty()) rings += arr(cs)
                }
                elems(el, "outerBoundaryIs").forEach(::ring)
                if (rings.isEmpty()) return null
                elems(el, "innerBoundaryIs").forEach(::ring)
                return geometry("Polygon", arr(rings))
            }
            "Track" -> {
                val t = elems(el, "coord").map { x ->
                    val p = trimmed(x).split(SMapXml.JS_SPACES).map { SMapJsNumber.number(it) }
                    p
                }.filter { p -> p.size >= 2 && finite(p[0]) && finite(p[1]) }
                    .map { p -> if (p.size >= 3 && finite(p[2])) pos(p[0], p[1], p[2]) else pos(p[0], p[1]) }
                return if (t.isNotEmpty()) geometry("LineString", arr(t)) else null
            }
            "MultiTrack" -> {
                val lines = elems(el, "Track").mapNotNull { kmlGeometry(it) }.map { it.get("coordinates") }
                return if (lines.isNotEmpty()) geometry("MultiLineString", arr(lines)) else null
            }
            "MultiGeometry" -> return combine(elems(el).filter { it.local in GEOMETRY_ELEMENTS }.mapNotNull { kmlGeometry(it) })
        }
        return null
    }

    /** One part is itself; parts all Point / LineString / Polygon → Multi*; anything else a GeometryCollection. */
    private fun combine(parts: List<JsonObject>): JsonObject? {
        if (parts.isEmpty()) return null
        if (parts.size == 1) return parts[0]
        val t = parts[0].str("type")
        if (parts.all { it.str("type") == t } && (t == "Point" || t == "LineString" || t == "Polygon")) {
            return geometry("Multi$t", arr(parts.map { it.get("coordinates") }))
        }
        return JsonObject().apply { addProperty("type", "GeometryCollection"); add("geometries", arr(parts)) }
    }

    private fun kmlStyleProps(style: El?): LinkedHashMap<String, JsonElement> {
        val props = LinkedHashMap<String, JsonElement>()
        style ?: return props
        val icon = elem(style, "IconStyle")
        val line = elem(style, "LineStyle")
        val poly = elem(style, "PolyStyle")
        if (icon != null) kmlColor(trimmed(elem(icon, "color")))?.let { props["marker-color"] = JsonPrimitive(it.first) }
        if (line != null) {
            kmlColor(trimmed(elem(line, "color")))?.let { props["stroke"] = JsonPrimitive(it.first); props["stroke-opacity"] = JsonPrimitive(it.second) }
            val w = SMapJsNumber.parseFloat(trimmed(elem(line, "width")))
            if (finite(w)) props["stroke-width"] = JsonPrimitive(w)
        }
        if (poly != null) {
            kmlColor(trimmed(elem(poly, "color")))?.let { props["fill"] = JsonPrimitive(it.first); props["fill-opacity"] = JsonPrimitive(it.second) }
            if (trimmed(elem(poly, "fill")) == "0") props["fill-opacity"] = JsonPrimitive(0)
            if (trimmed(elem(poly, "outline")) == "0") props["stroke-opacity"] = JsonPrimitive(0)
        }
        return props
    }

    private fun readKml(text: String): JsonObject {
        val doc = SMapXml.parse(stripBom(text))
        val styles = HashMap<String, El>()
        val maps = HashMap<String, String>()
        SMapXml.descendants(doc, "Style").forEach { s -> s.attrs["id"]?.takeIf { it.isNotEmpty() }?.let { styles[it] = s } }
        SMapXml.descendants(doc, "StyleMap").forEach { s ->
            val id = s.attrs["id"]?.takeIf { it.isNotEmpty() } ?: return@forEach
            elems(s, "Pair").forEach { p -> if (trimmed(elem(p, "key")) == "normal") maps[id] = trimmed(elem(p, "styleUrl")) }
        }
        fun resolve(url: String, depth: Int): El? {
            val id = url.replace(Regex("^[^#]*#"), "")
            styles[id]?.let { return it }
            val m = maps[id]
            if (m != null && depth < 4) return resolve(m, depth + 1)
            return null
        }
        val features = SMapXml.descendants(doc, "Placemark").map { pm ->
            val props = JsonObject()
            elem(pm, "name")?.let { props.addProperty("name", trimmed(it)) }
            elem(pm, "description")?.let { props.addProperty("description", trimmed(it)) }
            elem(pm, "ExtendedData")?.let { ext ->
                elems(ext, "Data").forEach { d -> d.attrs["name"]?.let { props.addProperty(it, trimmed(elem(d, "value"))) } }
                elems(ext, "SchemaData").forEach { sd -> elems(sd, "SimpleData").forEach { d -> d.attrs["name"]?.let { props.addProperty(it, trimmed(d)) } } }
            }
            val style = LinkedHashMap<String, JsonElement>()
            elem(pm, "styleUrl")?.let { style.putAll(kmlStyleProps(resolve(trimmed(it), 0))) }
            elem(pm, "Style")?.let { style.putAll(kmlStyleProps(it)) }
            for (k in listOf("marker-color", "stroke", "stroke-opacity", "stroke-width", "fill", "fill-opacity")) style[k]?.let { props.add(k, it) }
            val geoms = elems(pm).filter { it.local in GEOMETRY_ELEMENTS }.mapNotNull { kmlGeometry(it) }
            feature(props, combine(geoms))
        }
        return collection(features)
    }

    private fun readKmz(bytes: ByteArray): JsonObject {
        val files = ArrayList<Pair<String, ByteArray>>()
        var entries = 0
        try {
            ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    entries++
                    if (!e.isDirectory && e.name.lowercase().endsWith(".kml")) files += e.name to z.readBytes()
                }
            }
        } catch (e: Exception) {
            throw IllegalArgumentException("sMap: not a ZIP archive", e)
        }
        if (entries == 0) throw IllegalArgumentException("sMap: not a ZIP archive")
        if (files.isEmpty()) throw IllegalArgumentException("sMap: the KMZ file holds no KML document")
        val main = files.firstOrNull { Regex("(^|/)doc\\.kml$", RegexOption.IGNORE_CASE).containsMatchIn(it.first) }
            ?: files.firstOrNull { '/' !in it.first } ?: files[0]
        return readKml(utf8(main.second))
    }

    // ------------------------------------------------------------------ GPX

    private val GPX_SKIP = setOf("ele", "extensions", "link", "rtept", "trkseg", "trkpt")

    private fun gpxProps(el: El): JsonObject {
        val props = JsonObject()
        for (c in elems(el)) {
            if (c.local in GPX_SKIP || elems(c).isNotEmpty()) continue
            props.addProperty(c.local, trimmed(c))
        }
        return props
    }

    private fun gpxPoint(pt: El): JsonArray? {
        val lon = SMapJsNumber.parseFloat(pt.attrs["lon"])
        val lat = SMapJsNumber.parseFloat(pt.attrs["lat"])
        if (!finite(lon) || !finite(lat)) return null
        val eleEl = elem(pt, "ele")
        val ele = SMapJsNumber.parseFloat(trimmed(eleEl))
        return if (finite(ele) && eleEl != null) pos(lon, lat, ele) else pos(lon, lat)
    }

    private fun readGpx(text: String): JsonObject {
        val doc = SMapXml.parse(stripBom(text))
        val gpx = SMapXml.descendants(doc, "gpx").firstOrNull() ?: throw IllegalArgumentException("sMap: not a GPX document")
        val features = ArrayList<JsonObject>()
        for (el in elems(gpx)) {
            when (el.local) {
                "wpt" -> gpxPoint(el)?.let { features += feature(gpxProps(el), geometry("Point", it)) }
                "rte" -> {
                    val r = elems(el, "rtept").mapNotNull { gpxPoint(it) }
                    if (r.isNotEmpty()) features += feature(gpxProps(el), geometry("LineString", arr(r)))
                }
                "trk" -> {
                    val segs = elems(el, "trkseg").map { s -> elems(s, "trkpt").mapNotNull { gpxPoint(it) } }.filter { it.isNotEmpty() }
                    if (segs.size == 1) features += feature(gpxProps(el), geometry("LineString", arr(segs[0])))
                    else if (segs.size > 1) features += feature(gpxProps(el), geometry("MultiLineString", arr(segs.map { arr(it) })))
                }
            }
        }
        return collection(features)
    }

    // ------------------------------------------------------------------ polylines

    /** Decodes an encoded polyline (precision 5: Google, OSRM; 6: Valhalla) into `[lng, lat]` pairs. */
    fun decodePolyline(encoded: String, precision: Int = 5): List<DoubleArray> {
        val factor = Math.pow(10.0, precision.toDouble())
        val str = SMapXml.jsTrim(encoded)
        var i = 0
        var lat = 0.0
        var lng = 0.0
        val out = ArrayList<DoubleArray>()
        fun next(): Double {
            var result = 0.0
            var shift = 1.0
            var b: Int
            do {
                if (i >= str.length) throw IllegalArgumentException("sMap: the polyline ends early")
                b = str[i++].code - 63
                if (b < 0 || b > 63) throw IllegalArgumentException("sMap: not an encoded polyline")
                result += (b and 0x1f) * shift
                shift *= 32
            } while (b >= 0x20)
            return if (result % 2 != 0.0) -(result + 1) / 2 else result / 2
        }
        while (i < str.length) {
            lat += next()
            lng += next()
            out += doubleArrayOf(lng / factor, lat / factor)
        }
        return out
    }

    /** Encodes `[lng, lat]` pairs as a polyline. */
    fun encodePolyline(coords: List<DoubleArray>, precision: Int = 5): String {
        val factor = Math.pow(10.0, precision.toDouble())
        val sb = StringBuilder()
        var plat = 0.0
        var plng = 0.0
        fun enc(v: Double) {
            var n = if (v < 0) -2 * v - 1 else 2 * v
            while (n >= 32) { sb.append(((32 + (n % 32).toInt()) + 63).toChar()); n = Math.floor(n / 32) }
            sb.append((n.toInt() + 63).toChar())
        }
        for (c in coords) {
            val lat = jsRound(c[1] * factor)
            val lng = jsRound(c[0] * factor)
            enc(lat - plat); enc(lng - plng)
            plat = lat; plng = lng
        }
        return sb.toString()
    }

    /** JavaScript's `Math.round`: halves go up. */
    internal fun jsRound(v: Double): Double = Math.floor(v + 0.5)

    private fun readPolyline(text: String, precision: Int): JsonObject {
        val c = decodePolyline(text, precision)
        return collection(if (c.isNotEmpty()) listOf(feature(JsonObject(), geometry("LineString", arr(c.map { pos(it[0], it[1]) })))) else emptyList())
    }

    // ------------------------------------------------------------------ WKT

    private fun readWkt(text: String): JsonObject {
        val s = text
        var i = 0
        val features = ArrayList<JsonObject>()
        fun isWs(c: Char) = SMapXml.isJsSpace(c)
        fun ws() { while (i < s.length && (isWs(s[i]) || s[i] == ',' || s[i] == ';')) i++ }
        fun spaces() { while (i < s.length && isWs(s[i])) i++ }
        fun word(): String { spaces(); val st = i; while (i < s.length && (s[i] in 'A'..'Z' || s[i] in 'a'..'z')) i++; return s.substring(st, i).uppercase() }
        fun expect(c: Char) { spaces(); if (i >= s.length || s[i] != c) throw IllegalArgumentException("sMap: WKT: \"$c\" expected at $i"); i++ }
        fun peek(): Char? { spaces(); return s.getOrNull(i) }
        var dz = false
        var dm = false
        val num = Regex("[-+]?(\\d+\\.?\\d*|\\.\\d+)([eE][-+]?\\d+)?")
        fun point(): JsonArray {
            val nums = ArrayList<Double>()
            while (true) {
                spaces()
                val m = num.matchAt(s, i) ?: break
                nums += m.value.toDouble(); i += m.value.length
            }
            if (nums.size < 2) throw IllegalArgumentException("sMap: WKT: a position needs two numbers at $i")
            val hasZ = dz || (!dm && nums.size >= 3)
            return if (hasZ && nums.size >= 3) pos(nums[0], nums[1], nums[2]) else pos(nums[0], nums[1])
        }
        fun list(item: () -> JsonElement?): List<JsonElement?> {
            expect('(')
            val out = arrayListOf(item())
            while (peek() == ',') { i++; out += item() }
            expect(')')
            return out
        }
        fun empty(): Boolean { val save = i; if (word() == "EMPTY") return true; i = save; return false }
        fun nn(l: List<JsonElement?>) = arr(l.map { it ?: JsonNull.INSTANCE })
        fun geometry(): JsonObject? {
            spaces()
            Regex("SRID=\\d+;", RegexOption.IGNORE_CASE).matchAt(s, i)?.let { i += it.value.length }
            val type = word()
            if (type.isEmpty()) throw IllegalArgumentException("sMap: WKT: a geometry type expected at $i")
            // The flag may be glued to the type: POINTZ, LINESTRINGM, POLYGONZM are POINT Z, LINESTRING M, POLYGON ZM.
            var name = type
            var flag: String?
            val glued = GLUED.matchEntire(type)
            if (glued != null) {
                name = glued.groupValues[1]; flag = glued.groupValues[2]
            } else {
                val save = i
                flag = word()
                if (flag != "Z" && flag != "M" && flag != "ZM") { i = save; flag = null }
            }
            dz = flag == "Z" || flag == "ZM"
            dm = flag == "M" || flag == "ZM"
            if (empty()) return null
            val ring = { nn(list { point() }) }
            return when (name) {
                "POINT" -> geometry("Point", list { point() }[0]!!)
                "LINESTRING" -> geometry("LineString", nn(list { point() }))
                "POLYGON" -> geometry("Polygon", nn(list(ring)))
                "MULTIPOINT" -> geometry("MultiPoint", nn(list { if (peek() == '(') list { point() }[0] else point() }))
                "MULTILINESTRING" -> geometry("MultiLineString", nn(list(ring)))
                "MULTIPOLYGON" -> geometry("MultiPolygon", nn(list { nn(list(ring)) }))
                "GEOMETRYCOLLECTION" -> {
                    val oz = dz
                    val om = dm
                    val g = list { val x = geometry(); dz = oz; dm = om; x }.filterNotNull()
                    JsonObject().apply { addProperty("type", "GeometryCollection"); add("geometries", arr(g)) }
                }
                else -> throw IllegalArgumentException("sMap: WKT: unknown geometry type $name")
            }
        }
        ws()
        while (i < s.length) { features += feature(JsonObject(), geometry()); ws() }
        return collection(features)
    }

    private val GLUED = Regex("^(POINT|LINESTRING|POLYGON|MULTIPOINT|MULTILINESTRING|MULTIPOLYGON|GEOMETRYCOLLECTION)(ZM|Z|M)$")

    // ------------------------------------------------------------------ WKB

    private fun readWkbGeometry(b: ByteBuffer): JsonObject? {
        b.order(if (b.get().toInt() == 1) ByteOrder.LITTLE_ENDIAN else ByteOrder.BIG_ENDIAN)
        val raw = b.int.toLong() and 0xffffffffL
        var z = raw and 0x80000000L != 0L
        var m = raw and 0x40000000L != 0L
        if (raw and 0x20000000L != 0L) b.int
        var type = (raw and 0x0fffffffL).toInt()
        if (type >= 1000) {
            val k = type / 1000
            z = z || k == 1 || k == 3
            m = m || k == 2 || k == 3
            type %= 1000
        }
        fun read(): DoubleArray {
            val x = b.double
            val y = b.double
            val zz = if (z) b.double else null
            if (m) b.double
            return if (zz != null) doubleArrayOf(x, y, zz) else doubleArrayOf(x, y)
        }
        fun j(c: DoubleArray) = pos(*c)
        fun seq(): List<JsonArray> = List(b.int) { j(read()) }
        fun parts(): List<JsonObject?> = List(b.int) { readWkbGeometry(b) }
        val g: JsonObject? = when (type) {
            1 -> { val c = read(); if (c.all { it.isNaN() }) null else geometry("Point", j(c)) }
            2 -> geometry("LineString", arr(seq()))
            3 -> { val n = b.int; geometry("Polygon", arr(List(n) { arr(seq()) })) }
            4 -> geometry("MultiPoint", arr(parts().filterNotNull().map { it.get("coordinates") }))
            5 -> geometry("MultiLineString", arr(parts().filterNotNull().map { it.get("coordinates") }))
            6 -> geometry("MultiPolygon", arr(parts().filterNotNull().map { it.get("coordinates") }))
            7 -> JsonObject().apply { addProperty("type", "GeometryCollection"); add("geometries", arr(parts().filterNotNull())) }
            else -> throw IllegalArgumentException("sMap: WKB: unknown geometry type $type")
        }
        if (g != null && g.str("type") == "GeometryCollection") return if (g.getAsJsonArray("geometries").size() == 0) null else g
        if (g != null && g.str("type") != "Point" && g.getAsJsonArray("coordinates").size() == 0) return null
        return g
    }

    private fun readWkb(chunks: List<ByteArray>): JsonObject {
        val features = ArrayList<JsonObject>()
        try {
            for (c in chunks) {
                val b = ByteBuffer.wrap(c)
                while (b.position() < c.size) features += feature(JsonObject(), readWkbGeometry(b))
            }
        } catch (e: IllegalArgumentException) {
            throw e
        } catch (e: Exception) {
            throw IllegalArgumentException("sMap: not valid WKB", e)
        }
        return collection(features)
    }

    private fun readWkbHex(text: String): JsonObject {
        val chunks = ArrayList<ByteArray>()
        for (part in text.split(SMapXml.JS_SPACES)) {
            val h = part.replace(Regex("^\\\\x", RegexOption.IGNORE_CASE), "")
            if (h.isEmpty()) continue
            if (!Regex("^[0-9a-fA-F]+$").matches(h) || h.length % 2 != 0) throw IllegalArgumentException("sMap: WKB text must be hexadecimal")
            chunks += ByteArray(h.length / 2) { k -> h.substring(k * 2, k * 2 + 2).toInt(16).toByte() }
        }
        return readWkb(chunks)
    }

    // ------------------------------------------------------------------ CSV

    private val LAT_HEADINGS = listOf("lat", "latitude", "y", "lat_dd", "latitude_dd", "ycoord", "y_coord", "point_y", "纬度")
    private val LNG_HEADINGS = listOf("lng", "lon", "long", "longitude", "x", "lng_dd", "lon_dd", "longitude_dd", "xcoord", "x_coord", "point_x", "经度")

    private val DECIMAL_COMMA = Regex("^[-+]?\\d*,\\d+([eE][-+]?\\d+)?$")
    private val CSV_NUMBER = Regex("^[-+]?(\\d+\\.?\\d*|\\.\\d+)([eE][-+]?\\d+)?$")

    internal fun csvRows(s: String, delim: Char): List<List<String>> {
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val field = StringBuilder()
        var q = false
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (q) {
                if (c == '"') { if (s.getOrNull(i + 1) == '"') { field.append('"'); i++ } else q = false } else field.append(c)
            } else if (c == '"' && field.isEmpty()) q = true
            else if (c == delim) { row += field.toString(); field.setLength(0) }
            else if (c == '\n' || c == '\r') {
                if (c == '\r' && s.getOrNull(i + 1) == '\n') i++
                row += field.toString(); field.setLength(0); rows += row; row = ArrayList()
            } else field.append(c)
            i++
        }
        if (field.isNotEmpty() || row.isNotEmpty()) { row += field.toString(); rows += row }
        return rows.filter { r -> !(r.size == 1 && SMapXml.jsTrim(r[0]).isEmpty()) }
    }

    private fun readCsv(input: String, lat: String?, lng: String?): JsonObject {
        val text = stripBom(input)
        val firstLine = text.split(Regex("\\r?\\n"))[0]
        val delim = listOf(',', ';', '\t', '|').maxBy { d -> firstLine.split(d).size }
        val rows = csvRows(text, delim)
        if (rows.isEmpty()) return collection(emptyList())
        val head = rows[0].map { SMapXml.jsTrim(it) }
        val norm = head.map { it.lowercase().replace(SMapXml.JS_SPACES, "_") }
        fun find(given: String?, candidates: List<String>, what: String): Int {
            if (given != null) {
                var at = head.indexOf(given)
                if (at < 0) at = norm.indexOf(given.lowercase())
                if (at < 0) throw IllegalArgumentException("sMap: CSV has no column \"$given\"")
                return at
            }
            for (c in candidates) { val k = norm.indexOf(c); if (k >= 0) return k }
            throw IllegalArgumentException("sMap: CSV: no $what column found; name it with the $what option")
        }
        val la = find(lat, LAT_HEADINGS, "lat")
        val ln = find(lng, LNG_HEADINGS, "lng")
        // A coordinate is a whole number text (never a prefix of one); with ';' or tab delimiters a decimal comma counts.
        val decimalComma = delim == ';' || delim == '\t'
        fun coord(cell: String?): Double {
            var v = SMapXml.jsTrim(cell ?: "")
            if (decimalComma && DECIMAL_COMMA.matches(v)) v = v.replaceFirst(',', '.')
            return if (CSV_NUMBER.matches(v)) v.toDouble() else Double.NaN
        }
        val features = ArrayList<JsonObject>()
        for (r in 1 until rows.size) {
            val row = rows[r].map { SMapXml.jsTrim(it) }
            val y = coord(row.getOrNull(la))
            val x = coord(row.getOrNull(ln))
            if (!finite(y) || !finite(x) || Math.abs(y) > 90 || Math.abs(x) > 180) continue
            val props = JsonObject()
            for (c in head.indices) if (c != la && c != ln) props.addProperty(head[c], row.getOrNull(c) ?: "")
            features += feature(props, geometry("Point", pos(x, y)))
        }
        return collection(features)
    }

    // ------------------------------------------------------------------ TopoJSON

    private fun readTopojson(topo: JsonObject): JsonObject {
        if (topo.str("type") != "Topology") throw IllegalArgumentException("sMap: not a TopoJSON topology")
        val tr = topo.objOrNull("transform")
        val kx = tr?.getAsJsonArray("scale")?.get(0)?.asDouble ?: 1.0
        val ky = tr?.getAsJsonArray("scale")?.get(1)?.asDouble ?: 1.0
        val dx = tr?.getAsJsonArray("translate")?.get(0)?.asDouble ?: 0.0
        val dy = tr?.getAsJsonArray("translate")?.get(1)?.asDouble ?: 0.0
        val arcs: List<List<JsonArray>> = topo.arrOrNull("arcs")?.map { arc ->
            var x = 0.0
            var y = 0.0
            arc.asJsonArray.map { pe ->
                val p = pe.asJsonArray
                if (tr != null) {
                    x += p[0].asDouble; y += p[1].asDouble
                    val q = pos(x * kx + dx, y * ky + dy)
                    for (k in 2 until p.size()) q.add(p[k].deepCopy())
                    q
                } else p.deepCopy()
            }
        } ?: emptyList()
        fun arcOf(i: Int): List<JsonArray> = if (i < 0) arcs[i.inv()].asReversed() else arcs[i]
        fun line(ids: JsonArray): JsonArray {
            val out = ArrayList<JsonArray>()
            for (id in ids) { val a = arcOf(id.asInt); out += if (out.isNotEmpty()) a.drop(1) else a }
            return arr(out.map { it.deepCopy() })
        }
        fun pt(p: JsonArray): JsonArray {
            if (tr == null) return p.deepCopy()
            val q = pos(p[0].asDouble * kx + dx, p[1].asDouble * ky + dy)
            for (k in 2 until p.size()) q.add(p[k].deepCopy())
            return q
        }
        fun geom(o: JsonObject): JsonObject? {
            val a = o.get("arcs")
            val c = o.get("coordinates")
            return when (o.str("type")) {
                "Point" -> geometry("Point", pt(c.asJsonArray))
                "MultiPoint" -> geometry("MultiPoint", arr(c.asJsonArray.map { pt(it.asJsonArray) }))
                "LineString" -> geometry("LineString", line(a.asJsonArray))
                "MultiLineString" -> geometry("MultiLineString", arr(a.asJsonArray.map { line(it.asJsonArray) }))
                "Polygon" -> geometry("Polygon", arr(a.asJsonArray.map { line(it.asJsonArray) }))
                "MultiPolygon" -> geometry("MultiPolygon", arr(a.asJsonArray.map { p -> arr(p.asJsonArray.map { line(it.asJsonArray) }) }))
                "GeometryCollection" -> JsonObject().apply {
                    addProperty("type", "GeometryCollection")
                    add("geometries", arr(o.arrOrNull("geometries")?.mapNotNull { geom(it.asJsonObject) } ?: emptyList()))
                }
                else -> null
            }
        }
        val features = ArrayList<JsonObject>()
        topo.objOrNull("objects")?.entrySet()?.forEach { (_, oe) ->
            val o = oe.asJsonObject
            val list = if (o.str("type") == "GeometryCollection") o.arrOrNull("geometries")?.map { it.asJsonObject } ?: emptyList() else listOf(o)
            for (g in list) features += feature(g.objOrNull("properties")?.deepCopy() ?: JsonObject(), geom(g), g.get("id"))
        }
        return collection(features)
    }

    // ------------------------------------------------------------------ KML out

    private fun xmlEscape(v: String): String = buildString {
        for (c in v) append(when (c) { '&' -> "&amp;"; '<' -> "&lt;"; '>' -> "&gt;"; '"' -> "&quot;"; '\'' -> "&apos;"; else -> c.toString() })
    }

    /** `String(v)` of a JSON value. */
    private fun jsString(v: JsonElement): String = when {
        v.isJsonNull -> "null"
        v.isJsonPrimitive && v.asJsonPrimitive.isString -> v.asString
        v.isJsonPrimitive && v.asJsonPrimitive.isNumber -> SMapJsNumber.string(v.asDouble)
        v.isJsonPrimitive -> v.asBoolean.toString()
        v.isJsonArray -> v.asJsonArray.joinToString(",") { if (it.isJsonNull) "" else jsString(it) }
        else -> "[object Object]"
    }

    /** `Number(v)` of a JSON value. */
    private fun jsNumber(v: JsonElement?): Double = when {
        v == null -> Double.NaN
        v.isJsonNull -> 0.0
        v.isJsonPrimitive && v.asJsonPrimitive.isNumber -> v.asDouble
        v.isJsonPrimitive && v.asJsonPrimitive.isBoolean -> if (v.asBoolean) 1.0 else 0.0
        v.isJsonPrimitive -> SMapJsNumber.number(v.asString)
        else -> Double.NaN
    }

    private fun truthy(v: JsonElement?): Boolean = when {
        v == null || v.isJsonNull -> false
        v.isJsonPrimitive && v.asJsonPrimitive.isBoolean -> v.asBoolean
        v.isJsonPrimitive && v.asJsonPrimitive.isNumber -> v.asDouble != 0.0 && !v.asDouble.isNaN()
        v.isJsonPrimitive -> v.asString.isNotEmpty()
        else -> true
    }

    /** `#rgb` / `#rrggbb` + opacity as KML `aabbggrr`; anything else null. */
    private fun toKmlColor(color: JsonElement?, opacity: JsonElement?): String? {
        val text = if (color == null || color.isJsonNull) "" else jsString(color)
        val m = Regex("^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$").find(SMapXml.jsTrim(text)) ?: return null
        val g = m.groupValues[1]
        val h = if (g.length == 3) g.map { "$it$it" }.joinToString("") else g
        val o = if (opacity == null || opacity.isJsonNull || (opacity.isJsonPrimitive && opacity.asJsonPrimitive.isString && opacity.asString.isEmpty())) 1.0 else jsNumber(opacity)
        val a = jsRound(maxOf(0.0, minOf(1.0, o)) * 255).toInt()
        val aa = (if (a < 16) "0" else "") + Integer.toHexString(a)
        return (aa + h.substring(4, 6) + h.substring(2, 4) + h.substring(0, 2)).lowercase()
    }

    private val SIMPLESTYLE = setOf("marker-color", "marker-size", "marker-symbol", "stroke", "stroke-width", "stroke-opacity", "fill", "fill-opacity", "title", "description")

    private fun coordText(c: List<JsonElement>): String = c.joinToString(" ") { p ->
        p.asJsonArray.take(3).joinToString(",") { if (it.isJsonNull) "" else jsString(it) }
    }

    private fun kmlGeom(g: JsonElement?): String {
        if (g == null || !g.isJsonObject) return ""
        val o = g.asJsonObject
        val c = o.get("coordinates")
        fun list() = c.asJsonArray.toList()
        return when (o.str("type")) {
            "Point" -> "<Point><coordinates>" + coordText(listOf(c)) + "</coordinates></Point>"
            "LineString" -> "<LineString><coordinates>" + coordText(list()) + "</coordinates></LineString>"
            "Polygon" -> "<Polygon>" + list().mapIndexed { i, r ->
                val tag = if (i == 0) "outerBoundaryIs" else "innerBoundaryIs"
                "<$tag><LinearRing><coordinates>" + coordText(r.asJsonArray.toList()) + "</coordinates></LinearRing></$tag>"
            }.joinToString("") + "</Polygon>"
            "MultiPoint" -> "<MultiGeometry>" + list().joinToString("") { kmlGeom(geometry("Point", it)) } + "</MultiGeometry>"
            "MultiLineString" -> "<MultiGeometry>" + list().joinToString("") { kmlGeom(geometry("LineString", it)) } + "</MultiGeometry>"
            "MultiPolygon" -> "<MultiGeometry>" + list().joinToString("") { kmlGeom(geometry("Polygon", it)) } + "</MultiGeometry>"
            "GeometryCollection" -> "<MultiGeometry>" + (o.arrOrNull("geometries")?.joinToString("") { kmlGeom(it) } ?: "") + "</MultiGeometry>"
            else -> ""
        }
    }

    /**
     * A FeatureCollection (or any GeoJSON) as a KML 2.2 document: one Placemark per feature (name from `name` or
     * `title`, `description`, simplestyle properties as an inline Style, every other property as ExtendedData).
     */
    fun toKml(data: JsonObject, name: String? = null): String {
        val features = readGeojson(data).getAsJsonArray("features")
        val out = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document>")
        if (!name.isNullOrEmpty()) out.append("<name>").append(xmlEscape(name)).append("</name>")
        out.append('\n')
        for (fe in features) {
            val f = fe.asJsonObject
            val p = f.objOrNull("properties") ?: JsonObject()
            fun has(k: String) = p.has(k)
            fun present(k: String) = p.has(k) && !p.get(k).isJsonNull
            val nameValue = if (present("name")) p.get("name") else p.get("title")
            val s = StringBuilder("<Placemark>")
            if (nameValue != null && !nameValue.isJsonNull) s.append("<name>").append(xmlEscape(jsString(nameValue))).append("</name>")
            if (present("description")) s.append("<description>").append(xmlEscape(jsString(p.get("description")))).append("</description>")
            val style = StringBuilder()
            toKmlColor(p.get("marker-color"), null)?.let { style.append("<IconStyle><color>").append(it).append("</color></IconStyle>") }
            val strokeColor = if (truthy(p.get("stroke"))) p.get("stroke") else if (has("stroke-opacity") || has("stroke-width")) JsonPrimitive("#555555") else null
            val line = toKmlColor(strokeColor, p.get("stroke-opacity"))
            if (line != null || has("stroke-width")) {
                style.append("<LineStyle>")
                if (line != null) style.append("<color>").append(line).append("</color>")
                if (has("stroke-width")) style.append("<width>").append(SMapJsNumber.string(jsNumber(p.get("stroke-width")))).append("</width>")
                style.append("</LineStyle>")
            }
            val fillColor = if (truthy(p.get("fill"))) p.get("fill") else if (has("fill-opacity")) JsonPrimitive("#555555") else null
            toKmlColor(fillColor, p.get("fill-opacity"))?.let { style.append("<PolyStyle><color>").append(it).append("</color></PolyStyle>") }
            if (style.isNotEmpty()) s.append("<Style>").append(style).append("</Style>")
            val extra = p.keySet().filter { k -> k != "name" && k !in SIMPLESTYLE && present(k) }.toMutableList()
            if (present("name") && present("title")) extra += "title"
            if (extra.isNotEmpty()) {
                s.append("<ExtendedData>")
                for (k in extra) {
                    val v = p.get(k)
                    val text = if (v.isJsonObject || v.isJsonArray) SMapJson.stringify(v) else jsString(v)
                    s.append("<Data name=\"").append(xmlEscape(k)).append("\"><value>").append(xmlEscape(text)).append("</value></Data>")
                }
                s.append("</ExtendedData>")
            }
            out.append(s).append(kmlGeom(f.get("geometry"))).append("</Placemark>\n")
        }
        return out.append("</Document></kml>\n").toString()
    }

    /** The engine's FeatureCollection as KML. */
    fun toKml(data: FeatureCollection, name: String? = null): String = toKml(SMapJson.parseObject(data.toJson()), name)

    /** A FeatureCollection as GeoJSON text (normalised features, keys in order, JavaScript number notation). */
    fun toGeoJsonText(data: JsonObject): String = SMapJson.stringify(readGeojson(data))
}
