package ca.superroute.smap

import android.graphics.Bitmap
import android.view.View
import java.io.ByteArrayOutputStream

/** The picture's format (G29). */
enum class SMapExportFormat { PNG, JPEG }

/** An app view drawn into the exported picture (G29): where it is over the map, or in [corner] of the picture. */
data class SMapExportView(val view: View, val corner: SMapToolPosition? = null)

/**
 * Options of [SMap.export] (1.5.0, G29, M82).
 *
 * @param quality 0–1, JPEG
 * @param pixelRatio pixels of the picture per dp (default the screen's)
 * @param background behind the map (`#rrggbb`; JPEG white by default)
 * @param include app views drawn into the picture (a legend)
 */
data class SMapExportOptions(
    val format: SMapExportFormat = SMapExportFormat.PNG,
    val quality: Float = 0.92f,
    val pixelRatio: Float? = null,
    val background: String? = null,
    val include: List<SMapExportView> = emptyList(),
)

/** The parts of an export that need no screen (G29). */
internal object SMapExportMath {
    /** The margin of a view placed in a corner, in dp. */
    const val CORNER_MARGIN_DP = 10f

    /** Picture pixels per view pixel. */
    fun scale(pixelRatio: Float?, density: Float): Float = (pixelRatio ?: density) / density

    /** The picture's size for a view of [width] × [height] pixels. */
    fun size(width: Int, height: Int, scale: Float): Pair<Int, Int> = Math.max(1, Math.round(width * scale)) to Math.max(1, Math.round(height * scale))

    /** Where a view of [w] × [h] picture pixels sits in [corner] of a picture of [width] × [height], [margin] pixels in. */
    fun corner(corner: SMapToolPosition, width: Int, height: Int, w: Int, h: Int, margin: Int): Pair<Int, Int> = when (corner) {
        SMapToolPosition.TOP_LEFT, SMapToolPosition.NONE, SMapToolPosition.TOOLBAR -> margin to margin
        SMapToolPosition.TOP_RIGHT -> (width - w - margin) to margin
        SMapToolPosition.BOTTOM_LEFT -> margin to (height - h - margin)
        SMapToolPosition.BOTTOM_RIGHT -> (width - w - margin) to (height - h - margin)
    }

    /** The background a format needs: JPEG has no transparency, so white unless one is given. */
    fun background(format: SMapExportFormat, background: String?): String? = background ?: if (format == SMapExportFormat.JPEG) "#ffffff" else null

    /** PNG or JPEG data of [bitmap]. */
    fun encode(bitmap: Bitmap, format: SMapExportFormat, quality: Float): ByteArray = ByteArrayOutputStream().use { out ->
        bitmap.compress(if (format == SMapExportFormat.JPEG) Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG, Math.round(quality.coerceIn(0f, 1f) * 100), out)
        out.toByteArray()
    }
}
