package ca.superroute.smap

import android.annotation.SuppressLint
import android.content.Context
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup

/**
 * The layer switcher (G8): a 36 dp round button with the layers icon; a tap opens a panel with one radio row per
 * base map and one check row per overlay.
 */
@SuppressLint("ViewConstructor")
internal class SMapLayersToolView(
    context: Context,
    private val tool: SMapLayersTool,
    position: SMapToolPosition,
    label: String,
    private val applyBase: (SMapLayersBase) -> Unit,
    private val applyOverlay: (SMapLayersOverlay, Boolean) -> Unit,
) : LinearLayout(context) {
    private val panel = LinearLayout(context)
    private var current: String? = tool.value ?: tool.base.firstOrNull()?.id
    private val shown = LinkedHashMap<String, Boolean>().apply { tool.overlays.forEach { put(it.id, it.visible) } }

    init {
        orientation = HORIZONTAL
        clipChildren = false
        val button = SMapToolStyle.roundButton(context)
        button.contentDescription = label
        button.addView(ImageView(context).apply { setImageResource(R.drawable.smap_layers_icon) },
            FrameLayout.LayoutParams(SMapToolStyle.dp(context, 20f), SMapToolStyle.dp(context, 20f), Gravity.CENTER))
        button.setOnClickListener { open(panel.visibility != View.VISIBLE) }
        panel.apply {
            orientation = VERTICAL
            background = SMapToolStyle.card(context, 8f)
            elevation = SMapToolStyle.dp(context, 4f).toFloat()
            val pad = SMapToolStyle.dp(context, 8f)
            setPadding(pad, pad, pad, pad)
            minimumWidth = SMapToolStyle.dp(context, 160f)
            visibility = View.GONE
        }
        val group = RadioGroup(context)
        tool.base.forEachIndexed { i, b ->
            group.addView(RadioButton(context).apply {
                id = View.generateViewId()
                text = b.label
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(SMapToolStyle.TEXT)
                isChecked = b.id == current
                setOnCheckedChangeListener { _, on -> if (on && current != b.id) { current = b.id; applyBase(b); report() } }
            })
        }
        if (tool.base.isNotEmpty()) panel.addView(group)
        tool.overlays.forEach { ov ->
            panel.addView(CheckBox(context).apply {
                text = ov.label
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(SMapToolStyle.TEXT)
                isChecked = shown[ov.id] == true
                setOnCheckedChangeListener { _, on -> shown[ov.id] = on; applyOverlay(ov, on); report() }
            })
        }
        val size = SMapToolStyle.dp(context, SMapToolStyle.BUTTON_DP)
        val gap = SMapToolStyle.dp(context, 6f)
        val right = position == SMapToolPosition.TOP_RIGHT || position == SMapToolPosition.BOTTOM_RIGHT
        gravity = if (position == SMapToolPosition.BOTTOM_LEFT || position == SMapToolPosition.BOTTOM_RIGHT) Gravity.BOTTOM else Gravity.TOP
        val panelParams = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        if (right) { addView(panel, panelParams.apply { marginEnd = gap }); addView(button, LayoutParams(size, size)) }
        else { addView(button, LayoutParams(size, size)); addView(panel, panelParams.apply { marginStart = gap }) }
    }

    /** The starting state: the chosen base and every overlay as given. */
    fun start() {
        tool.base.firstOrNull { it.id == current }?.let { if (it.imagery != null) applyBase(it) }
        tool.overlays.forEach { if (!it.visible) applyOverlay(it, false) }
    }

    fun open(on: Boolean) { panel.visibility = if (on) View.VISIBLE else View.GONE }

    private fun report() = tool.onChange?.invoke(current, shown.filterValues { it }.keys.toList())
}
