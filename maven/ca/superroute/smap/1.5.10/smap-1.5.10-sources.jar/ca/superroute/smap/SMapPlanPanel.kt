package ca.superroute.smap

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * The plan editor's ready-made panel, built from the platform's own controls (buttons, text views and lists with
 * Android drag and drop): undo / redo / refine and the busy status, the error line, the refine note, the totals (with
 * the preview's while a stop is dragged on the map), every route with its stops (Lock / Unlock, Remove; long-press a
 * stop and drop it before another stop or on a route to move it, on the unassigned jobs to take it off), the
 * unassigned jobs (Place) and the positions an insert answered (Choose). Texts in 14 languages
 * ([SMapPlanTexts]); the app's own [labels] replace any key.
 *
 * Made by [SMap.planEditor] as the map tool `plan-editor`, or by the app for a place of its own.
 */
@SuppressLint("ViewConstructor")
class SMapPlanPanel(
    context: Context,
    private val editor: SMapPlanEditor,
    language: String? = null,
    private val labels: Map<String, String>? = null,
    private val colors: List<String> = SMapPlanDraw.COLORS,
) : FrameLayout(context) {

    private var languageTag: String = language ?: java.util.Locale.getDefault().toLanguageTag()
    var texts: Map<String, String> = SMapPlanTexts.texts(languageTag, labels)
        private set
    private var format = SMapPlanFormat(SMapPlanTexts.language(languageTag), texts)
    private val content = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    private val scroll = object : ScrollView(context) {
        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val max = dp(MAX_HEIGHT_DP)
            val spec = MeasureSpec.getSize(heightMeasureSpec).let { h ->
                MeasureSpec.makeMeasureSpec(if (h > 0) minOf(h, max) else max, MeasureSpec.AT_MOST)
            }
            super.onMeasure(widthMeasureSpec, spec)
        }
    }
    private var destroyed = false

    /** The model last drawn (for tests and apps reading what is shown). */
    var model: SMapPlanPanelModel? = null
        private set

    private val listener: (SMapPlanEvent) -> Unit = { e ->
        when (e) {
            is SMapPlanEvent.Change, is SMapPlanEvent.Busy, is SMapPlanEvent.Preview -> render()
            SMapPlanEvent.Destroy -> destroy()
            else -> Unit
        }
    }

    init {
        background = SMapToolStyle.card(context, 8f)
        elevation = dp(4f).toFloat()
        val pad = dp(10f)
        content.setPadding(pad, pad, pad, pad)
        scroll.addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(scroll, LayoutParams(dp(WIDTH_DP), ViewGroup.LayoutParams.WRAP_CONTENT))
        editor.addListener(listener)
        render()
    }

    /** Switches the panel's language (a BCP-47 tag). */
    fun setLanguage(language: String) {
        languageTag = language
        texts = SMapPlanTexts.texts(languageTag, labels)
        format = SMapPlanFormat(SMapPlanTexts.language(languageTag), texts)
        render()
    }

    /** Takes the panel off the editor and out of its parent. */
    fun destroy() {
        if (destroyed) return
        destroyed = true
        editor.removeListener(listener)
        (parent as? ViewGroup)?.removeView(this)
    }

    fun render() {
        if (destroyed) return
        val m = SMapPlanPanelModel.build(editor.state(), texts, format, editor.vehicleIds(), colors)
        model = m
        content.removeAllViews()
        contentDescription = texts.getValue("editor")

        // Undo, Redo, Refine and the busy status.
        val bar = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(button(m.bar.undo, m.bar.canUndo) { editor.perform { undo() } })
        bar.addView(button(m.bar.redo, m.bar.canRedo) { editor.perform { redo() } })
        bar.addView(button(m.bar.refine, m.bar.canRefine) { editor.perform { refine() } })
        bar.addView(text(m.bar.status, 12f).apply {
            if (Build.VERSION.SDK_INT >= 28) accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(4f) })
        content.addView(bar)

        m.error?.let { line ->
            val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(text(line, 13f, ERROR), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(button(m.bar.close, true) { editor.clearError() })
            row.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_ASSERTIVE
            content.addView(row)
        }
        m.note?.let { content.addView(text(it, 13f)) }

        m.total?.let { total ->
            content.addView(heading(total.title))
            total.rows?.let { rows(it) }
            total.pending?.let { content.addView(text(it, 13f, MUTED)) }
            if (total.previewTitle != null && total.preview != null) {
                content.addView(heading(total.previewTitle, 13f))
                rows(total.preview)
            }
        }

        for (r in m.routes) {
            val section = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
            val head = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(View(context).apply {
                background = GradientDrawable().apply { cornerRadius = dp(3f).toFloat(); setColor(Color.parseColor(r.color)) }
            }, LinearLayout.LayoutParams(dp(12f), dp(12f)).apply { marginEnd = dp(6f) })
            head.addView(heading(r.vehicleId))
            section.addView(head)
            r.rows?.let { rows(it, section) }
            r.violations.forEach { section.addView(text("• $it", 12f, ERROR)) }
            val list = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; minimumHeight = dp(28f) }
            r.empty?.let { list.addView(text(it, 13f, MUTED)) }
            for (s in r.stops) list.addView(stopRow(s))
            drop(list) { id -> editor.perform { dropStop(id, r.vehicleId, r.stops.size + 1) } }
            section.addView(list)
            content.addView(section, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8f) })
        }

        m.unassigned?.let { u ->
            val section = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; minimumHeight = dp(28f) }
            section.addView(heading(u.title))
            for (j in u.jobs) {
                val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                row.addView(text(j.id, 13f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(button(j.placeText, true) { editor.perform { insert(j.id) } })
                draggable(row, j.id)
                section.addView(row)
            }
            // A stop dropped here is taken off its route.
            drop(section) { id -> if (id !in u.jobs.map { it.id }) editor.perform { remove(listOf(id)) } }
            content.addView(section, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8f) })
        }

        m.choices?.let { groups ->
            for (g in groups) {
                content.addView(heading(g.title))
                g.notPlaced?.let { content.addView(text(it, 13f, MUTED)) }
                for (p in g.positions) {
                    val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    val info = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
                    info.addView(text(p.where, 13f, if (p.feasible) TEXT else MUTED))
                    info.addView(text(p.added, 12f, MUTED))
                    p.arrival?.let { info.addView(text(it, 12f, MUTED)) }
                    p.violations?.let { info.addView(text(it, 12f, ERROR)) }
                    row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                    row.addView(button(p.button, !p.chosen) { editor.perform { choose(g.job, p.index) } })
                    content.addView(row)
                }
            }
            m.closeChoices?.let { close -> content.addView(button(close, true) { editor.clearChoices() }) }
        }
    }

    private fun stopRow(s: SMapPlanPanelModel.Stop): View {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(36f)
            if (s.locked) background = GradientDrawable().apply { cornerRadius = dp(4f).toFloat(); setColor(Color.argb(20, 17, 24, 39)) }
        }
        row.addView(text(s.seq, 12f, MUTED).apply { typeface = Typeface.DEFAULT_BOLD; minWidth = dp(20f) })
        row.addView(text(s.id, 13f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        s.arrival?.let { row.addView(text(it, 12f, MUTED).apply { contentDescription = s.arrivalLabel; tooltip(s.arrivalLabel) }) }
        s.marks?.let { row.addView(text(" $it", 12f, ERROR).apply { maxLines = 1 }) }
        row.addView(button(s.lockText, true) { if (s.locked) editor.unlock(listOf(s.id)) else editor.lock(listOf(s.id)) })
        row.addView(button(s.removeText, true) { editor.perform { remove(listOf(s.id)) } })
        draggable(row, s.id)
        drop(row) { id -> editor.perform { dropStop(id, s.vehicleId, s.position) } }
        return row
    }

    private fun rows(rows: List<SMapPlanPanelModel.Row>, into: LinearLayout = content) {
        for (r in rows) {
            val line = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            line.addView(text(r.label, 12f, MUTED), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            line.addView(text(r.value, 12f))
            into.addView(line)
        }
    }

    private fun text(value: String, sp: Float, color: Int = TEXT): TextView = TextView(context).apply {
        text = value
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
    }

    private fun heading(value: String, sp: Float = 14f): TextView = text(value, sp).apply {
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(4f), 0, dp(2f))
        if (Build.VERSION.SDK_INT >= 28) isAccessibilityHeading = true
    }

    private fun button(label: String, enabled: Boolean, onClick: () -> Unit): Button = Button(context).apply {
        text = label
        isAllCaps = false
        isEnabled = enabled
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        minWidth = 0
        minimumWidth = 0
        minHeight = dp(32f)
        minimumHeight = dp(32f)
        setPadding(dp(8f), 0, dp(8f), 0)
        setOnClickListener { onClick() }
    }

    private fun TextView.tooltip(value: String?) {
        if (Build.VERSION.SDK_INT >= 26 && value != null) tooltipText = value
    }

    // A row is dragged with a long press (the platform's drag and drop), carrying the stop's id.
    @Suppress("DEPRECATION")
    private fun draggable(view: View, id: String) {
        view.setOnLongClickListener { v ->
            val data = ClipData.newPlainText("stop", id)
            val shadow = View.DragShadowBuilder(v)
            if (Build.VERSION.SDK_INT >= 24) v.startDragAndDrop(data, shadow, DraggedStop(id), 0) else v.startDrag(data, shadow, DraggedStop(id), 0)
            true
        }
    }

    private class DraggedStop(val id: String)

    private fun drop(view: View, onDrop: (String) -> Unit) {
        view.setOnDragListener { v, e ->
            val dragged = e.localState as? DraggedStop
            when (e.action) {
                DragEvent.ACTION_DRAG_STARTED -> dragged != null
                DragEvent.ACTION_DRAG_ENTERED -> { v.alpha = 0.6f; true }
                DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> { v.alpha = 1f; true }
                DragEvent.ACTION_DROP -> {
                    v.alpha = 1f
                    dragged?.let { onDrop(it.id) }
                    dragged != null
                }
                else -> true
            }
        }
    }

    private fun dp(value: Float): Int = SMapToolStyle.dp(context, value)

    private companion object {
        const val WIDTH_DP = 300f
        const val MAX_HEIGHT_DP = 440f
        val TEXT = SMapToolStyle.TEXT
        val MUTED = Color.rgb(100, 116, 139)
        val ERROR = Color.rgb(185, 28, 28)
    }
}
