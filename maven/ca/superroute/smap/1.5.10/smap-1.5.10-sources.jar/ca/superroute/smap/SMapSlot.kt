package ca.superroute.smap

/**
 * Where a layer is drawn relative to the basemap. A layer given no slot (and no `before`) draws on top, in the order
 * added, as in 1.0.
 */
enum class SMapSlot(val id: String) {
    /** Over land and water, under everything else. */
    BOTTOM("bottom"),

    /** Under the roads. */
    ROADS("roads"),

    /** Under the labels. */
    LABELS("labels"),

    /** On top of the basemap. */
    TOP("top");

    companion object {
        /** The slot named [id] (`bottom`, `roads`, `labels`, `top`). */
        fun fromId(id: String): SMapSlot = entries.firstOrNull { it.id == id }
            ?: throw IllegalArgumentException("sMap: unknown slot \"$id\" (bottom, roads, labels or top)")
    }
}

/** Finds the basemap layer each slot draws under, from the style's layer list and the class table. */
object SMapSlots {
    /**
     * The basemap layer each slot's layers are inserted below, for a style whose layers are [layerIds] in drawing
     * order (null = on top). The same rule as every SDK, found from the classes, never from a position:
     * `labels` the first label layer (classes `labels.*` and `pois`); `roads` the first road layer (`roads.*`, `rail`),
     * else `labels`; `bottom` the layer after the last land, landcover or water layer, else `roads`, never above
     * `roads`; `top` null.
     */
    fun anchors(layerIds: List<String>): Map<SMapSlot, String?> {
        val classOf = HashMap<String, String>()
        for (cls in SMapBasemap.classes) for ((layer, _) in SMapBasemap.layersOf(cls)) classOf[layer] = cls
        fun first(test: (String) -> Boolean): Int = layerIds.indexOfFirst { id -> classOf[id]?.let(test) == true }
        val labels = first { it.startsWith("labels.") || it == "pois" }
        var roads = first { it.startsWith("roads.") || it == "rail" }
        if (roads < 0 || (labels >= 0 && roads > labels)) roads = labels
        val lastGround = layerIds.indexOfLast { classOf[it] == "land" || classOf[it] == "landcover" || classOf[it] == "water" }
        var bottom = if (lastGround >= 0 && lastGround + 1 < layerIds.size) lastGround + 1 else roads
        if (roads >= 0 && (bottom < 0 || bottom > roads)) bottom = roads
        fun id(i: Int) = if (i >= 0) layerIds[i] else null
        return mapOf(SMapSlot.BOTTOM to id(bottom), SMapSlot.ROADS to id(roads), SMapSlot.LABELS to id(labels), SMapSlot.TOP to null)
    }
}
