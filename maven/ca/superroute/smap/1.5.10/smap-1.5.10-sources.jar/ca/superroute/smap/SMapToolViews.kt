package ca.superroute.smap

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Sizes and colours shared by the tool views (MOBILE-SDK-SPEC "Map tools"). */
internal object SMapToolStyle {
    const val BUTTON_DP = 36f
    const val GAP_DP = 8f
    const val EDGE_DP = 10f
    /** Room left under the bottom-left tools for the engine's attribution button, under the bottom-right ones for the badge. */
    const val ABOVE_ATTRIBUTION_DP = 36f
    const val ABOVE_BADGE_DP = 32f
    val BLUE = Color.rgb(37, 99, 235)
    val TEXT = Color.rgb(30, 41, 59)
    val OUTLINE = Color.argb(38, 15, 23, 42)

    fun dp(context: Context, value: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, context.resources.displayMetrics).toInt()

    fun card(context: Context, radiusDp: Float): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(context, radiusDp).toFloat()
        setColor(Color.WHITE)
        setStroke(dp(context, 0.5f).coerceAtLeast(1), OUTLINE)
    }

    fun roundButton(context: Context): FrameLayout = FrameLayout(context).apply {
        background = card(context, BUTTON_DP / 2)
        elevation = dp(context, 2f).toFloat()
        isClickable = true
        isFocusable = true
    }
}

/**
 * The four corner stacks the tools are laid in, over the map. Made with the first tool, so a map without tools has
 * none of them.
 */
internal class SMapToolCorners(private val host: FrameLayout) {

    private val stacks = HashMap<SMapToolPosition, LinearLayout>()

    /** Whether a point of the map view is on one of the corners' tools or controls. */
    fun contains(x: Float, y: Float): Boolean = stacks.values.any { stack ->
        stack.visibility == View.VISIBLE && (0 until stack.childCount).any { i ->
            val c = stack.getChildAt(i)
            c.visibility == View.VISIBLE && x >= stack.left + c.left && x <= stack.left + c.right && y >= stack.top + c.top && y <= stack.top + c.bottom
        }
    }

    fun stack(position: SMapToolPosition): LinearLayout {
        require(position != SMapToolPosition.NONE)
        return stacks.getOrPut(position) {
            val context = host.context
            val edge = SMapToolStyle.dp(context, SMapToolStyle.EDGE_DP)
            val end = position == SMapToolPosition.TOP_RIGHT || position == SMapToolPosition.BOTTOM_RIGHT
            val bottom = position == SMapToolPosition.BOTTOM_LEFT || position == SMapToolPosition.BOTTOM_RIGHT
            val stack = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = if (end) Gravity.END else Gravity.START
                clipChildren = false
                clipToPadding = false
            }
            val params = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                (if (bottom) Gravity.BOTTOM else Gravity.TOP) or (if (end) Gravity.END else Gravity.START)).apply {
                marginStart = edge
                marginEnd = edge
                topMargin = edge
                bottomMargin = when (position) {
                    SMapToolPosition.BOTTOM_LEFT -> SMapToolStyle.dp(context, SMapToolStyle.ABOVE_ATTRIBUTION_DP)
                    SMapToolPosition.BOTTOM_RIGHT -> SMapToolStyle.dp(context, SMapToolStyle.ABOVE_BADGE_DP)
                    else -> edge
                }
            }
            host.addView(stack, params)
            stack
        }
    }

    /** Adds [view] to its corner: under the tools already there (above them at the bottom), with a gap between. */
    fun add(position: SMapToolPosition, view: View, last: Boolean = false) {
        val stack = stack(position)
        val end = position == SMapToolPosition.TOP_RIGHT || position == SMapToolPosition.BOTTOM_RIGHT
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = if (end) Gravity.END else Gravity.START
            val gap = SMapToolStyle.dp(host.context, SMapToolStyle.GAP_DP) / 2
            topMargin = gap
            bottomMargin = gap
        }
        val bottom = position == SMapToolPosition.BOTTOM_LEFT || position == SMapToolPosition.BOTTOM_RIGHT
        // At the bottom the stack grows upwards: a later tool goes above the earlier ones. `last` puts the view at the
        // end of the stack (lowest in it): the tools control's place.
        if (bottom && !last) stack.addView(view, 0, params) else stack.addView(view, params)
    }

    /** Is [view] the last child of [position]'s stack? */
    fun isLast(position: SMapToolPosition, view: View): Boolean {
        val stack = stacks[position] ?: return false
        return view.parent === stack && stack.getChildAt(stack.childCount - 1) === view
    }

    /** Draws [position]'s stack above the map's other corners and the app's views on the map (raised while [raised]). */
    fun raise(position: SMapToolPosition, raised: Boolean) {
        val stack = stacks[position] ?: return
        stack.bringToFront()
        stack.translationZ = if (raised) SMapToolStyle.dp(host.context, RAISED_DP).toFloat() else 0f
        host.invalidate()
    }

    fun remove(view: View) {
        (view.parent as? ViewGroup)?.removeView(view)
    }

    private companion object {
        /** How far an open tools control's corner is lifted above everything else on the map. */
        const val RAISED_DP = 24f
    }
}

/**
 * The tools control: a round button with the sliders icon that opens a panel beside it, one toggle row per tool
 * (filled blue = shown) and Show all / Hide all. Never a tool and never hidden.
 */
@SuppressLint("ViewConstructor")
internal class SMapToolsControl(
    context: Context,
    position: SMapToolPosition,
    private val labels: SMapToolsLabels,
    private val onToggle: (String) -> Unit,
    private val onAll: (Boolean) -> Unit,
    private val onOpen: (Boolean) -> Unit = {},
) : LinearLayout(context) {

    /** The corner the control is laid out for (the panel opens towards the map's middle from there). */
    var position: SMapToolPosition = position
        private set

    private val button = SMapToolStyle.roundButton(context)
    private val panel = LinearLayout(context)
    private val rows = LinearLayout(context)
    private var drawn: List<Pair<String, String>>? = null

    val isOpen: Boolean get() = panel.visibility == View.VISIBLE

    init {
        orientation = HORIZONTAL
        clipChildren = false
        val size = SMapToolStyle.dp(context, SMapToolStyle.BUTTON_DP)
        button.contentDescription = labels.button
        button.addView(ImageView(context).apply { setImageResource(R.drawable.smap_tools_icon) },
            FrameLayout.LayoutParams(SMapToolStyle.dp(context, 20f), SMapToolStyle.dp(context, 20f), Gravity.CENTER))
        button.setOnClickListener { open(!isOpen) }
        panel.apply {
            orientation = VERTICAL
            background = SMapToolStyle.card(context, 8f)
            elevation = SMapToolStyle.dp(context, 4f).toFloat()
            val pad = SMapToolStyle.dp(context, 8f)
            setPadding(pad, pad, pad, pad)
            minimumWidth = SMapToolStyle.dp(context, 170f)
            visibility = View.GONE
            contentDescription = labels.button
        }
        rows.orientation = VERTICAL
        panel.addView(rows, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val all = LinearLayout(context).apply { orientation = HORIZONTAL }
        all.addView(row(labels.showAll, centered = true).apply { setOnClickListener { onAll(true) } },
            LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = SMapToolStyle.dp(context, 2f) })
        all.addView(row(labels.hideAll, centered = true).apply { setOnClickListener { onAll(false) } },
            LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = SMapToolStyle.dp(context, 2f) })
        panel.addView(all, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = SMapToolStyle.dp(context, 6f)
        })
        layOut(position)
    }

    /** Lays the button and the panel out for [corner]: the panel beside the button, towards the map's middle. */
    fun layOut(corner: SMapToolPosition) {
        position = corner
        removeAllViews()
        val size = SMapToolStyle.dp(context, SMapToolStyle.BUTTON_DP)
        val gap = SMapToolStyle.dp(context, 6f)
        val buttonParams = LayoutParams(size, size)
        val panelParams = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val right = corner == SMapToolPosition.TOP_RIGHT || corner == SMapToolPosition.BOTTOM_RIGHT
        val bottom = corner == SMapToolPosition.BOTTOM_LEFT || corner == SMapToolPosition.BOTTOM_RIGHT
        // From a bottom corner the panel grows upwards (aligned with the button's bottom), from a top one downwards.
        gravity = if (bottom) Gravity.BOTTOM else Gravity.TOP
        if (right) {
            addView(panel, panelParams.apply { marginEnd = gap })
            addView(button, buttonParams)
        } else {
            addView(button, buttonParams)
            addView(panel, panelParams.apply { marginStart = gap })
        }
    }

    fun open(on: Boolean) {
        val was = isOpen
        panel.visibility = if (on) View.VISIBLE else View.GONE
        if (was != on) onOpen(on)
    }

    /** Shows [tools] (id, label, visible); rows are made again only when the tools or their labels changed. */
    fun render(tools: List<SMapToolState>) {
        visibility = if (tools.isEmpty()) View.GONE else View.VISIBLE
        val signature = tools.map { it.id to it.label }
        if (signature != drawn) {
            drawn = signature
            rows.removeAllViews()
            tools.forEach { tool ->
                rows.addView(row(tool.label, centered = false).apply {
                    tag = tool.id
                    setOnClickListener { onToggle(tool.id) }
                }, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = SMapToolStyle.dp(context, 4f)
                })
            }
        }
        tools.forEachIndexed { i, tool -> pressed(rows.getChildAt(i) as TextView, tool.visible) }
    }

    private fun row(text: String, centered: Boolean): TextView = TextView(context).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setTextColor(SMapToolStyle.TEXT)
        minHeight = SMapToolStyle.dp(context, 32f)
        gravity = Gravity.CENTER_VERTICAL or (if (centered) Gravity.CENTER_HORIZONTAL else Gravity.START)
        val h = SMapToolStyle.dp(context, 10f)
        setPadding(h, 0, h, 0)
        background = SMapToolStyle.card(context, 6f)
        isClickable = true
        isFocusable = true
    }

    private fun pressed(row: TextView, on: Boolean) {
        row.isSelected = on
        row.setTextColor(if (on) Color.WHITE else SMapToolStyle.TEXT)
        row.background = SMapToolStyle.card(context, 6f).apply { if (on) { setColor(SMapToolStyle.BLUE); setStroke(0, 0) } }
        row.stateDescription(on)
    }

    private fun TextView.stateDescription(on: Boolean) {
        if (android.os.Build.VERSION.SDK_INT >= 30) stateDescription = if (on) "On" else "Off"
    }
}

/** + / − buttons stacked in one card. */
@SuppressLint("ViewConstructor")
internal class SMapZoomTool(context: Context, label: String, onZoom: (Int) -> Unit) : LinearLayout(context) {
    init {
        orientation = VERTICAL
        background = SMapToolStyle.card(context, 8f)
        elevation = SMapToolStyle.dp(context, 2f).toFloat()
        contentDescription = label
        val size = SMapToolStyle.dp(context, SMapToolStyle.BUTTON_DP)
        listOf("+" to 1, "−" to -1).forEach { (text, step) ->
            addView(TextView(context).apply {
                this.text = text
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20f)
                setTextColor(SMapToolStyle.TEXT)
                typeface = Typeface.DEFAULT_BOLD
                contentDescription = if (step > 0) "Zoom in" else "Zoom out"
                isClickable = true
                isFocusable = true
                setOnClickListener { onZoom(step) }
            }, LayoutParams(size, size))
        }
    }
}

/** A button that centres the map on the device's position. */
@SuppressLint("ViewConstructor")
internal class SMapLocateTool(context: Context, label: String, onLocate: () -> Unit) : FrameLayout(context) {
    init {
        val size = SMapToolStyle.dp(context, SMapToolStyle.BUTTON_DP)
        val button = SMapToolStyle.roundButton(context).apply {
            contentDescription = label
            setOnClickListener { onLocate() }
            addView(ImageView(context).apply { setImageResource(R.drawable.smap_locate_icon) },
                LayoutParams(SMapToolStyle.dp(context, 20f), SMapToolStyle.dp(context, 20f), Gravity.CENTER))
        }
        addView(button, LayoutParams(size, size))
    }
}

/** A north arrow turned with the map; a tap turns north. Shown by the map only while it is rotated. */
@SuppressLint("ViewConstructor")
internal class SMapCompassTool(context: Context, label: String, onNorth: () -> Unit) : FrameLayout(context) {
    private val needle = object : View(context) {
        private val north = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(220, 38, 38) }
        private val south = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(148, 163, 184) }
        override fun onDraw(canvas: Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            val r = width / 2f
            val w = r * 0.32f
            canvas.drawPath(Path().apply { moveTo(cx, cy - r); lineTo(cx + w, cy); lineTo(cx - w, cy); close() }, north)
            canvas.drawPath(Path().apply { moveTo(cx, cy + r); lineTo(cx + w, cy); lineTo(cx - w, cy); close() }, south)
        }
    }

    init {
        val size = SMapToolStyle.dp(context, SMapToolStyle.BUTTON_DP)
        val button = SMapToolStyle.roundButton(context).apply {
            contentDescription = label
            setOnClickListener { onNorth() }
            addView(needle, LayoutParams(SMapToolStyle.dp(context, 20f), SMapToolStyle.dp(context, 20f), Gravity.CENTER))
        }
        addView(button, LayoutParams(size, size))
    }

    fun setBearing(bearing: Double) {
        needle.rotation = (-bearing).toFloat()
    }
}

/** A scale bar: a line with end ticks and its distance, at most 100 dp wide. */
@SuppressLint("ViewConstructor")
internal class SMapScaleTool(context: Context, label: String, private val imperial: Boolean) : View(context) {
    private val density = context.resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = SMapToolStyle.TEXT; strokeWidth = 1.5f * density; style = Paint.Style.STROKE }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(204, 255, 255, 255); strokeWidth = 4f * density; style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = SMapToolStyle.TEXT; textSize = 11f * density; typeface = Typeface.DEFAULT_BOLD }
    private val textHalo = Paint(text).apply { color = Color.argb(204, 255, 255, 255); style = Paint.Style.STROKE; strokeWidth = 3f * density }
    private var barDp = 0.0
    private var caption = ""

    init {
        contentDescription = label
    }

    /** [metersPerDp]: the map's metres per density-independent pixel at the view's centre. */
    fun update(metersPerDp: Double) {
        if (metersPerDp <= 0 || metersPerDp.isNaN()) return
        val (dp, label) = SMapToolRegistry.scaleBar(metersPerDp, MAX_DP, imperial)
        if (dp == barDp && label == caption) return
        barDp = dp
        caption = label
        contentDescription = label
        requestLayout()
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(((MAX_DP + 8) * density).toInt(), (24 * density).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        if (barDp <= 0) return
        val x0 = 2 * density
        val x1 = x0 + (barDp * density).toFloat()
        val y = height - 3 * density
        val tick = 5 * density
        val path = Path().apply { moveTo(x0, y - tick); lineTo(x0, y); lineTo(x1, y); lineTo(x1, y - tick) }
        canvas.drawPath(path, halo)
        canvas.drawPath(path, line)
        canvas.drawText(caption, x0 + 2 * density, y - 5 * density, textHalo)
        canvas.drawText(caption, x0 + 2 * density, y - 5 * density, text)
    }

    private companion object {
        const val MAX_DP = 100.0
    }
}
