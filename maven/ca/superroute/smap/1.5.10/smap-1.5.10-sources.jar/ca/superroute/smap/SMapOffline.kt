package ca.superroute.smap

import android.content.Context
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.coroutines.coroutineContext

/**
 * Offline regions: areas of the map downloaded as one file each and shown without a network.
 *
 * A download resumes where it stopped when it is called again for the same region (after a lost connection, or after
 * the app was closed). Run it from the app's own background work when it should outlive the screen. A region is shown
 * for 30 days from its download; after that its map data is removed until it is refreshed, and during its last
 * 3 days a map refreshes it on its own while online ([SMapOptions.offlineAutoRefresh]).
 *
 * Only a map token, or a map key whose *Allow offline regions* switch is on, may download. Each download is billed
 * as the region's tiles; showing a region offline costs nothing.
 *
 * Uses the same [SMapOptions] as a map (base URL, nodes, token or key); the layers and camera options are not read.
 */
class SMapOffline(context: Context, private val options: SMapOptions = SMapOptions()) {
    private val app = context.applicationContext

    /** Where regions are kept: `<files>/smap-offline/<region id>/`. */
    val directory: File = File(app.filesDir, "smap-offline")

    private val identity: Map<String, String> = LinkedHashMap(SMapAppIdentity.headers(app)).apply {
        options.apiKey?.takeIf { it.isNotEmpty() }?.let { put(SMapAppIdentity.KEY_HEADER, it) }
    }
    private val tokens = SMapTokenManager(options.token, options.getToken)
    private val nodes = SMapNodePicker(
        options.baseUrl,
        options.http ?: SMapUrlConnectionHttp(identity),
        options.store ?: SMapPreferencesStore(app),
        options.nearest,
        seeds = options.nodes,
    )

    private fun languageOf(region: SMapOfflineRegion): String =
        region.language ?: options.language ?: Locale.getDefault().toLanguageTag()

    /** The size of [region] and whether this app may download it. Counts nothing. */
    suspend fun estimate(region: SMapOfflineRegion): SMapOfflineEstimate {
        val query = SMapOfflineFiles.query(region, languageOf(region))
        val body = withNodes { node -> request("$node/v1/offline/estimate?$query", emptyMap()) { c -> c.inputStream.use { it.readBytes() } } }
        val o = JsonParser.parseString(String(body, Charsets.UTF_8)).asJsonObject
        return SMapOfflineEstimate(
            tiles = o["tiles"].asLong,
            bytes = o["bytes"].asLong,
            maxBytes = o["max_bytes"].asLong,
            fits = o["fits"].asBoolean,
            allowed = o["allowed"].asBoolean,
        )
    }

    /**
     * Downloads [region] (or continues an interrupted download of it) and keeps it on the device, replacing an
     * earlier copy of the same id only once the new one is complete.
     *
     * @param onProgress bytes received so far and the file's size, called on a background thread
     * @throws SMapException with the map service's status: 403 when this app may not download, 413 when the region is
     *   larger than one region file may be (split it or lower its zoom), 422 for a region the service refuses
     */
    suspend fun download(region: SMapOfflineRegion, onProgress: ((Long, Long) -> Unit)? = null): SMapOfflineInfo =
        lockFor(region.id).withLock {
            withContext(Dispatchers.IO) {
                directory.mkdirs()
                val language = languageOf(region)
                val query = SMapOfflineFiles.query(region, language)
                val part = File(directory, "${region.id}.part")
                val meta = File(directory, "${region.id}.part.json")
                val started = withNodes { node -> fetch("$node/v1/offline/region?$query", query, part, meta, onProgress) }
                install(region, language, part, started)
                meta.delete()
                part.delete()
                read(region.id) ?: throw SMapException("sMap: the region could not be kept")
            }
        }

    /** Downloads the region [id] again (its area, zooms, style and language as kept). */
    suspend fun refresh(id: String, onProgress: ((Long, Long) -> Unit)? = null): SMapOfflineInfo {
        val info = get(id) ?: throw SMapException("sMap: no offline region \"$id\"")
        return download(info.region, onProgress)
    }

    /** Every region on the device; a region past its 30 days has its map data removed here. */
    suspend fun list(): List<SMapOfflineInfo> = withContext(Dispatchers.IO) {
        (directory.listFiles() ?: emptyArray())
            .filter { it.isDirectory && SMapOfflineFiles.ID.matches(it.name) }
            .mapNotNull { read(it.name) }
            .sortedBy { it.id }
    }

    /** The region [id], or null. */
    suspend fun get(id: String): SMapOfflineInfo? = withContext(Dispatchers.IO) { read(id) }

    /** Removes the region [id] and any download of it in progress. */
    suspend fun remove(id: String) = lockFor(id).withLock {
        withContext(Dispatchers.IO) {
            File(directory, id).deleteRecursively()
            File(directory, "$id.part").delete()
            File(directory, "$id.part.json").delete()
        }
    }

    /** Bytes every region and unfinished download take on the device. */
    suspend fun usage(): Long = withContext(Dispatchers.IO) { size(directory) }

    /** Refreshes the regions in their last 3 days; failures are left for the next time. */
    suspend fun refreshDue(): List<SMapOfflineInfo> {
        val now = System.currentTimeMillis()
        return list().filter { SMapOfflineFiles.dueForRefresh(it, now) }.mapNotNull {
            try {
                download(it.region)
            } catch (e: Exception) {
                null
            }
        }
    }

    /** The device style of a ready region, for the map. */
    internal fun styleFile(id: String): File? {
        val info = read(id) ?: return null
        if (info.state != SMapOfflineState.READY) return null
        return File(File(directory, id), SMapOfflineFiles.STYLE_FILE).takeIf { it.isFile }
    }

    /** Every ready region (no network, for the map). */
    internal fun ready(): List<SMapOfflineInfo> =
        (directory.listFiles() ?: emptyArray()).filter { it.isDirectory && SMapOfflineFiles.ID.matches(it.name) }
            .mapNotNull { read(it.name) }.filter { it.state == SMapOfflineState.READY }

    // ------------------------------------------------------------------ files

    private fun read(id: String): SMapOfflineInfo? {
        val dir = File(directory, id)
        val file = File(dir, SMapOfflineFiles.INFO_FILE)
        if (!file.isFile) return null
        val now = System.currentTimeMillis()
        val info = SMapOfflineFiles.readInfo(file.readText(), size(dir), now) ?: return null
        if (info.state == SMapOfflineState.EXPIRED && (dir.listFiles()?.size ?: 0) > 1) {
            // Past its days: the map data goes, the definition stays for a refresh.
            dir.listFiles()?.filter { it.name != SMapOfflineFiles.INFO_FILE }?.forEach { it.deleteRecursively() }
            return info.copy(bytes = size(dir))
        }
        return info
    }

    private fun install(region: SMapOfflineRegion, language: String, part: File, started: Started) {
        val target = File(directory, region.id)
        val fresh = File(directory, "${region.id}.new")
        fresh.deleteRecursively()
        fresh.mkdirs()
        val names = part.inputStream().buffered().use { SMapOfflineFiles.untar(it, fresh) }
        for (needed in listOf("manifest.json", "style.json", "region.pmtiles")) {
            if (needed !in names) throw SMapException("sMap: the region file has no $needed")
        }
        val manifest = File(fresh, "manifest.json").readText()
        File(fresh, SMapOfflineFiles.STYLE_FILE).writeText(SMapOfflineFiles.deviceStyle(File(fresh, "style.json").readText(), target))
        val downloadedAt = started.date ?: System.currentTimeMillis()
        val info = SMapOfflineInfo(
            region = region,
            state = SMapOfflineState.READY,
            language = SMapOfflineFiles.language(manifest, language),
            tiles = SMapOfflineFiles.tiles(manifest),
            bytes = 0,
            downloadedAtMillis = downloadedAt,
            expiresAtMillis = SMapOfflineFiles.expiresAt(downloadedAt, SMapOfflineFiles.validDays(manifest)),
        )
        File(fresh, SMapOfflineFiles.INFO_FILE).writeText(SMapOfflineFiles.infoJson(info, started.etag))
        val old = File(directory, "${region.id}.old")
        old.deleteRecursively()
        if (target.exists() && !target.renameTo(old)) throw SMapException("sMap: the earlier copy of the region could not be replaced")
        if (!fresh.renameTo(target)) {
            old.renameTo(target)
            throw SMapException("sMap: the region could not be kept")
        }
        old.deleteRecursively()
    }

    private fun size(file: File): Long =
        if (file.isFile) file.length() else (file.listFiles() ?: emptyArray()).sumOf { size(it) }

    // ------------------------------------------------------------------ HTTP

    private class Started(val etag: String, val date: Long?)

    /** Downloads into [part], continuing it when [meta] says it is the same region and version. */
    private suspend fun fetch(url: String, query: String, part: File, meta: File, onProgress: ((Long, Long) -> Unit)?): Started {
        val before = readMeta(meta)?.takeIf { it["query"]?.asString == query && part.isFile }
        val have = if (before != null) part.length() else 0L
        val headers = HashMap<String, String>()
        if (before != null && have > 0) {
            headers["Range"] = "bytes=$have-"
            headers["If-Range"] = before["etag"].asString
        }
        return request(url, headers) { c ->
            val resumed = c.responseCode == 206
            val etag = c.getHeaderField("ETag") ?: throw SMapException("sMap: the region answer has no ETag", url = url)
            val total: Long
            val date: Long?
            if (resumed) {
                total = c.getHeaderField("Content-Range")?.substringAfterLast('/')?.toLongOrNull()
                    ?: throw SMapException("sMap: the region answer has no size", url = url)
                date = before!!["date"]?.takeIf { !it.isJsonNull }?.asLong
            } else {
                total = c.getHeaderField("Content-Length")?.toLongOrNull() ?: throw SMapException("sMap: the region answer has no size", url = url)
                date = c.getHeaderFieldDate("Date", 0L).takeIf { it > 0 }
                part.delete()
                writeMeta(meta, query, etag, date, total)
            }
            var done = if (resumed) have else 0L
            onProgress?.invoke(done, total)
            FileOutputStream(part, resumed).use { out ->
                c.inputStream.use { input ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        onProgress?.invoke(done, total)
                    }
                }
            }
            if (part.length() != total) throw IOException("sMap: the region download stopped at ${part.length()} of $total bytes")
            Started(etag, date)
        }
    }

    private fun readMeta(meta: File): JsonObject? = try {
        if (meta.isFile) JsonParser.parseString(meta.readText()).asJsonObject else null
    } catch (e: Exception) {
        null
    }

    private fun writeMeta(meta: File, query: String, etag: String, date: Long?, total: Long) {
        val o = JsonObject()
        o.addProperty("query", query)
        o.addProperty("etag", etag)
        date?.let { o.addProperty("date", it) }
        o.addProperty("total", total)
        meta.writeText(o.toString())
    }

    /** One request to a node with the token, key and app identity; [read] handles a 2xx answer. */
    private suspend fun <T> request(url: String, extra: Map<String, String>, read: suspend (HttpURLConnection) -> T): T {
        val token = tokens.token()
        return withContext(Dispatchers.IO) {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 15_000
                c.readTimeout = 60_000
                c.useCaches = false
                c.setRequestProperty("User-Agent", "sMap-Android/${BuildConfig.SMAP_VERSION}")
                identity.forEach { (k, v) -> c.setRequestProperty(k, v) }
                token?.let { c.setRequestProperty("Authorization", "Bearer $it") }
                extra.forEach { (k, v) -> c.setRequestProperty(k, v) }
                val status = c.responseCode
                if (status !in 200..299) {
                    val text = (c.errorStream ?: null)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                    val message = try {
                        JsonParser.parseString(text).asJsonObject["message"]?.asString
                    } catch (e: Exception) {
                        null
                    } ?: text.ifBlank { "HTTP $status" }
                    throw SMapException("sMap: $message", status = status, url = url)
                }
                read(c)
            } finally {
                c.disconnect()
            }
        }
    }

    /** Tries each node in turn; an answer that refuses the request (4xx) is final, a failure moves to the next node. */
    private suspend fun <T> withNodes(call: suspend (String) -> T): T {
        var last: Exception? = null
        for (node in nodes.nodes()) {
            try {
                return call(node)
            } catch (e: SMapException) {
                if (e.status in 400..499) throw e
                last = e
                nodes.demote(node)
            } catch (e: IOException) {
                last = e
                nodes.demote(node)
            }
        }
        throw (last as? SMapException) ?: SMapException("sMap: no map node answered: ${last?.message}", cause = last)
    }

    private companion object {
        val locks = HashMap<String, Mutex>()

        @Synchronized
        fun lockFor(id: String): Mutex = locks.getOrPut(id) { Mutex() }
    }
}
