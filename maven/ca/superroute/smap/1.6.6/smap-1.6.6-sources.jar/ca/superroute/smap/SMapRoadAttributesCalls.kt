package ca.superroute.smap

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser

/**
 * The road attributes calls of the Flutter and React Native SDKs (MOBILE-SDK-SPEC "Road attributes"): the view's
 * option, its calls by name with JSON arguments and its events, one reading for both. Their wrapper draws the button
 * and panel itself, so the native view never draws one.
 *
 * Events go to `emit`: `roadAttributesAvailable` `{available}` once sMap answered, `roadAttributesChange`
 * `{groups, detail, open}` after every change and `roadAttributesInfo` `{reduced, speedUnit}` when what the map learnt
 * from its tiles changes (the panel's reduced-detail note and the routing speed legend's unit).
 */
object SMapRoadAttributesCalls {
    val METHODS = setOf("setRoadAttributes", "roadAttributes")

    fun handles(method: String) = method in METHODS

    /**
     * The view's `roadAttributes` option as the wrapper sends it (absent / true: on; false: off; an object `{groups,
     * detail}`), always without the native button.
     */
    fun options(value: JsonElement?): SMapRoadAttributesOptions {
        if (value != null && value.isJsonPrimitive && value.asJsonPrimitive.isBoolean && !value.asBoolean) return SMapRoadAttributesOptions.OFF
        val o = value?.takeIf { it.isJsonObject }?.asJsonObject
        return SMapRoadAttributesOptions(
            groups = o?.get("groups")?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { if (it.isJsonPrimitive) it.asString else null },
            detail = SMapRoadAttributes.detail(o?.get("detail")?.takeIf { it.isJsonPrimitive }?.asString),
            control = false,
        )
    }

    /** [options] from the option's JSON text (null / empty: on). */
    fun options(json: String?): SMapRoadAttributesOptions =
        options(json?.takeIf { it.isNotBlank() }?.let { try { JsonParser.parseString(it) } catch (e: Exception) { null } })

    /** Sends [map]'s availability and every change to [emit]. */
    fun listen(map: SMap, emit: (String, JsonObject) -> Unit) {
        map.onRoadAttributesAvailable { ok -> emit("roadAttributesAvailable", JsonObject().apply { addProperty("available", ok) }) }
        map.onRoadAttributesChange { e -> emit("roadAttributesChange", change(e)) }
        map.onRoadAttributesInfo { i -> emit("roadAttributesInfo", info(i)) }
    }

    fun info(i: SMapRoadAttributesInfo): JsonObject = JsonObject().apply {
        addProperty("reduced", i.reduced)
        addProperty("speedUnit", i.speedUnit)
    }

    fun change(e: SMapRoadAttributesChange): JsonObject = JsonObject().apply {
        add("groups", JsonArray().also { a -> e.groups.forEach { a.add(it) } })
        addProperty("detail", e.detail)
        addProperty("open", e.open)
    }

    fun stateJson(s: SMapRoadAttributesState?): String {
        if (s == null) return "null"
        return JsonObject().apply {
            if (s.available == null) add("available", com.google.gson.JsonNull.INSTANCE) else addProperty("available", s.available)
            add("groups", JsonArray().also { a -> s.groups.forEach { a.add(it) } })
            addProperty("detail", s.detail)
            addProperty("open", s.open)
            addProperty("reduced", s.reduced)
        }.toString()
    }

    /** One call; [args] the call's JSON array as text (`setRoadAttributes`: `[groups | null, detail | null, open | null]`). */
    fun call(map: SMap, method: String, args: String): String? {
        if (!handles(method)) return null
        val a = JsonParser.parseString(args.ifEmpty { "[]" }).takeIf { it.isJsonArray }?.asJsonArray ?: JsonArray()
        fun at(i: Int): JsonElement? = if (i < a.size() && !a[i].isJsonNull) a[i] else null
        return when (method) {
            "setRoadAttributes" -> {
                map.setRoadAttributes(
                    groups = at(0)?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { if (it.isJsonPrimitive) it.asString else null },
                    detail = at(1)?.asString,
                    open = at(2)?.asBoolean,
                )
                "null"
            }
            "roadAttributes" -> stateJson(map.roadAttributes())
            else -> null
        }
    }
}
