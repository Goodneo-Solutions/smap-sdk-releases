package ca.superroute.smap

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.JsonPrimitive

/**
 * How the road attributes layer starts (MOBILE-SDK-SPEC "Road attributes"; Superroute MAP-SDK-DESIGN M86–M100).
 *
 * @param groups the categories shown first (null: General); unknown ones are dropped
 * @param detail `standard`, or `full`: every road at every zoom (the tile URLs carry `?detail=full`)
 * @param position the corner of its button
 * @param control false: no button (change the layer with [SMap.setRoadAttributes])
 * @param enabled false ([OFF]): no button, no layer, no request
 */
data class SMapRoadAttributesOptions(
    val groups: List<String>? = null,
    val detail: String = SMapRoadAttributes.STANDARD,
    val position: SMapToolPosition = SMapToolPosition.TOP_RIGHT,
    val control: Boolean = true,
    val enabled: Boolean = true,
) {
    companion object {
        /** The map without the road attributes layer (the Web SDK's `roadAttributes: false`). */
        val OFF = SMapRoadAttributesOptions(enabled = false)
    }
}

/** The road attributes layer now: [available] is null until sMap answered, then whether it serves the layer here. */
data class SMapRoadAttributesState(
    val available: Boolean?,
    val groups: List<String>,
    val detail: String,
    val open: Boolean,
    /** A forced tile came at reduced detail (`X-Road-Attributes-Detail: reduced`). */
    val reduced: Boolean,
)

/** Told after every change of the road attributes layer (the SDK stores nothing). */
data class SMapRoadAttributesChange(val groups: List<String>, val detail: String, val open: Boolean)

/**
 * What the map learnt from the tiles it drew, for wrappers that draw the panel themselves (Flutter, React Native):
 * whether a forced tile came at reduced detail and the routing speed legend's unit (`km/h` or `mph`, by the country of
 * the roads in view, M100). Not a change of the layer.
 */
data class SMapRoadAttributesInfo(val reduced: Boolean, val speedUnit: String)

/**
 * The road attributes layer's rules that need no map: everything comes from the SDK's copy of
 * shared/road-attributes.json (`road-attributes.json`, written by tools/road-attributes.mjs), the only place tile
 * property names, categories, presets, colours, images, layers and texts are written.
 */
object SMapRoadAttributes {
    const val STANDARD = "standard"
    const val FULL = "full"
    const val LAYER_PREFIX = "smap-ra-"

    /** The contract as the SDK carries it. */
    val spec: JsonObject by lazy {
        val stream = SMapRoadAttributes::class.java.getResourceAsStream("road-attributes.json")
            ?: throw IllegalStateException("sMap: road-attributes.json is missing from the library")
        stream.reader(Charsets.UTF_8).use { JsonParser.parseReader(it).asJsonObject }
    }

    val toolId: String get() = spec["toolId"].asString
    val attributesSource: String get() = spec.getAsJsonObject("sources")["attributes"].asString
    val speedsSource: String get() = spec.getAsJsonObject("sources")["speeds"].asString
    val reducedHeader: String get() = spec.getAsJsonObject("services")["reducedHeader"].asString
    val reducedValue: String get() = spec.getAsJsonObject("services")["reducedValue"].asString
    private val groupList: JsonArray get() = spec.getAsJsonArray("groups")

    /** The ten categories in the panel's order. */
    fun groupKeys(): List<String> = groupList.map { it.asJsonObject["key"].asString }

    /** The categories of [list] that exist, once each, in the panel's order. */
    fun groups(list: List<String>?): List<String> {
        val want = (list ?: emptyList()).toSet()
        return groupKeys().filter { it in want }
    }

    fun defaultGroups(): List<String> = spec.getAsJsonArray("defaultGroups").map { it.asString }

    /** The presets in order: key → its categories. */
    fun presets(): List<Pair<String, List<String>>> =
        spec.getAsJsonArray("presets").map { p -> p.asJsonObject["key"].asString to p.asJsonObject.getAsJsonArray("groups").map { it.asString } }

    /** The start: null when the layer is off, else (groups, detail). */
    fun start(options: SMapRoadAttributesOptions?): Pair<List<String>, String>? {
        if (options == null || !options.enabled) return null
        return (options.groups?.let { groups(it) } ?: defaultGroups()) to detail(options.detail)
    }

    fun detail(value: String?): String = if (value == FULL) FULL else STANDARD

    /** The preset whose categories are exactly [groups], or null. */
    fun presetOf(groups: List<String>): String? {
        val key = groups(groups)
        return presets().firstOrNull { it.second == key }?.first
    }

    /** Whether [groups] need the road speeds tile set. */
    fun needsSpeeds(groups: List<String>): Boolean {
        val on = groups.toSet()
        return groupList.any { g -> g.asJsonObject["key"].asString in on && g.asJsonObject["source"]?.asString == "speeds" }
    }

    /** The spec's language for a BCP-47 tag: one of the 14, English when none fits. */
    fun language(tag: String?): String {
        val t = (tag ?: "en").lowercase().replace('_', '-')
        if (Regex("^zh-(hant|tw|hk|mo)").containsMatchIn(t)) return "zh-Hant"
        if (t.startsWith("zh")) return "zh-Hans"
        val base = t.split('-')[0]
        return if (spec.getAsJsonObject("texts").has(base)) base else "en"
    }

    fun texts(tag: String?): JsonObject = spec.getAsJsonObject("texts").getAsJsonObject(language(tag))
    fun text(tag: String?, key: String): String = texts(tag)[key]?.asString ?: spec.getAsJsonObject("texts").getAsJsonObject("en")[key].asString

    /** The layers in drawing order: `@text:<key>` replaced by the language's text, `text-font` by [font] when given. */
    fun layers(tag: String?, font: JsonArray? = null): List<JsonObject> {
        val tx = texts(tag)
        fun walk(e: JsonElement): JsonElement = when {
            e.isJsonPrimitive && e.asJsonPrimitive.isString && e.asString.startsWith("@text:") ->
                JsonPrimitive(tx[e.asString.substring(6)]?.asString ?: "")
            e.isJsonArray -> JsonArray().also { out -> e.asJsonArray.forEach { out.add(walk(it)) } }
            e.isJsonObject -> JsonObject().also { out -> e.asJsonObject.entrySet().forEach { (k, v) -> out.add(k, walk(v)) } }
            else -> e
        }
        return spec.getAsJsonArray("layers").map { l ->
            val out = walk(l).asJsonObject
            val layout = out.getAsJsonObject("layout")
            if (font != null && font.size() > 0 && layout != null && layout.has("text-font")) layout.add("text-font", font.deepCopy())
            out
        }
    }

    /**
     * layer id → shown, for the categories [groups]. [labelsSeen]: the tiles have shown a `road_attribute_labels`
     * point (sPath RA8), so the labels drawn along the lines in its place (`labels.fallback`) are hidden.
     */
    fun visibility(groups: List<String>, labelsSeen: Boolean = false): Map<String, Boolean> {
        val on = groups.toSet()
        val hidden = if (labelsSeen) labelFallback().toSet() else emptySet()
        val out = LinkedHashMap<String, Boolean>()
        groupList.forEach { g -> val o = g.asJsonObject; o.getAsJsonArray("layers").forEach { out[it.asString] = o["key"].asString in on && it.asString !in hidden } }
        return out
    }

    /** The layers drawn along the lines while the server has not shown `road_attribute_labels`. */
    fun labelFallback(): List<String> = spec.getAsJsonObject("labels").getAsJsonArray("fallback").map { it.asString }

    /** The tile layer of the labels (`road_attribute_labels`). */
    val labelsSourceLayer: String get() = spec.getAsJsonObject("labels")["sourceLayer"].asString

    /** The layers drawn from `road_attribute_labels` (their features tell the SDK that the server writes it). */
    fun labelLayers(): List<String> {
        val layer = spec.getAsJsonObject("labels")["sourceLayer"].asString
        return spec.getAsJsonArray("layers").map { it.asJsonObject }.filter { it["source-layer"]?.asString == layer }.map { it["id"].asString }
    }

    /** The country most of these features' properties carry (`props.country`), or null when none has one. */
    fun countryOf(properties: List<JsonObject?>): String? {
        val key = spec.getAsJsonObject("props")["country"].asString
        val n = HashMap<String, Int>()
        var best: String? = null
        for (p in properties) {
            val c = p?.get(key)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString?.takeIf { it.isNotEmpty() } ?: continue
            n[c] = (n[c] ?: 0) + 1
            if (best == null || n[c]!! > n[best]!!) best = c
        }
        return best
    }

    /** The routing speed legend's unit by the road's country, as its signs show speeds (M100): `mph` or `km/h`. */
    fun speedUnit(country: String?): String =
        if (spec.getAsJsonObject("units").getAsJsonArray("mph").any { it.asString == country?.uppercase() }) "mph" else "km/h"

    /** The routing speed legend in a unit: its title's text key and the bins (lower bound in that unit, colour). */
    fun legend(unit: String): Pair<String, List<Pair<Int, String>>> {
        val bins = spec.getAsJsonArray(if (unit == "mph") "speedBinsMph" else "speedBins").map { it.asJsonArray[0].asInt to it.asJsonArray[1].asString }
        return (if (unit == "mph") "speedLegendMph" else "speedLegend") to bins
    }

    /** The chips' texts of the bins: `a–b`, the last `a+`. */
    fun chips(bins: List<Pair<Int, String>>): List<String> =
        bins.mapIndexed { i, b -> if (i + 1 < bins.size) "${b.first}–${bins[i + 1].first}" else "${b.first}+" }

    /** The TileJSON address of a set (`attributes` | `speeds`), with the token and key as the style URL carries them. */
    fun tileJsonUrl(node: String, set: String, token: String? = null, apiKey: String? = null): String {
        val path = spec.getAsJsonObject("services")[if (set == "speeds") "speeds" else "attributes"].asString
        val q = ArrayList<String>()
        if (!token.isNullOrEmpty()) q += "token=" + SMapStyleUrl.encode(token)
        if (!apiKey.isNullOrEmpty()) q += "key=" + SMapStyleUrl.encode(apiKey)
        return node.trimEnd('/') + path + (if (q.isEmpty()) "" else "?" + q.joinToString("&"))
    }

    /** The tile URLs of a TileJSON answer, null without the service; `detail=full` added while [detail] is full. */
    fun tiles(tilejson: JsonObject?, detail: String = STANDARD): List<String>? {
        if (tilejson == null) return null
        if (tilejson["available"]?.let { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean && !it.asBoolean } == true) return null
        val list = tilejson.getAsJsonArray("tiles")?.mapNotNull { if (it.isJsonPrimitive) it.asString else null } ?: return null
        if (list.isEmpty()) return null
        val q = spec.getAsJsonObject("services")["detailQuery"].asString
        return list.map { u -> if (detail != FULL || Regex("[?&]detail=full\\b").containsMatchIn(u)) u else u + (if ('?' in u) "&" else "?") + q }
    }

    /** The TileJSON answer as JSON, or null for anything else (a refusal's body, text that is not JSON). */
    fun parseTileJson(status: Int, body: String): JsonObject? {
        if (status !in 200..299) return null
        return try { JsonParser.parseString(body).takeIf { it.isJsonObject }?.asJsonObject } catch (e: Exception) { null }
    }

    /**
     * The layer a road attributes layer goes under: the next road attributes layer already in [styleIds] after it in
     * the spec's order, else the first layer that is neither the basemap's nor a road attributes layer (the caller's
     * first); null = on top.
     */
    fun beforeId(layerId: String, styleIds: List<String>, basemapIds: Set<String>): String? {
        val order = spec.getAsJsonArray("layers").map { it.asJsonObject["id"].asString }
        val present = styleIds.toSet()
        val at = order.indexOf(layerId)
        for (i in at + 1 until order.size) if (order[i] in present) return order[i]
        return styleIds.firstOrNull { it !in basemapIds && !it.startsWith(LAYER_PREFIX) }
    }

    /** The images by id: logical width, height and shapes (shared/road-attributes.json `images`). */
    fun imageIds(): List<String> = spec.getAsJsonObject("images").keySet().toList()

    /** Draws image [id] at [scale] device pixels per logical pixel. */
    fun image(id: String, scale: Float): Bitmap {
        val o = spec.getAsJsonObject("images").getAsJsonObject(id)
        val w = Math.ceil(o["width"].asDouble * scale).toInt()
        val h = Math.ceil(o["height"].asDouble * scale).toInt()
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bitmap)
        c.scale(scale, scale)
        o.getAsJsonArray("shapes").forEach { s ->
            val sh = s.asJsonObject
            val path = Path()
            when (sh["type"].asString) {
                "circle" -> path.addCircle(sh["cx"].asFloat, sh["cy"].asFloat, sh["r"].asFloat, Path.Direction.CW)
                "rect" -> path.addRect(sh["x"].asFloat, sh["y"].asFloat, sh["x"].asFloat + sh["w"].asFloat, sh["y"].asFloat + sh["h"].asFloat, Path.Direction.CW)
                else -> {
                    sh.getAsJsonArray("points").forEachIndexed { i, p ->
                        val x = p.asJsonArray[0].asFloat
                        val y = p.asJsonArray[1].asFloat
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    if (sh["type"].asString == "polygon") path.close()
                }
            }
            val line = sh["type"].asString == "line"
            sh["stroke"]?.asString?.let { color ->
                c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    this.color = Color.parseColor(color)
                    strokeWidth = sh["strokeWidth"]?.asFloat ?: 1f
                    strokeCap = if (line) Paint.Cap.ROUND else Paint.Cap.BUTT
                    strokeJoin = Paint.Join.ROUND
                })
            }
            if (!line) sh["fill"]?.asString?.let { color ->
                c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; this.color = Color.parseColor(color) })
            }
        }
        return bitmap
    }
}
