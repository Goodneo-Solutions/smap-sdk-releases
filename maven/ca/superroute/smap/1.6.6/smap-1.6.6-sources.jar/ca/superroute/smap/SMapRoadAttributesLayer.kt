package ca.superroute.smap

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.launch
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.Property

/**
 * The road attributes layer of one map (MOBILE-SDK-SPEC "Road attributes"): the TileJSON asked for once, the
 * sources and layers drawn above the basemap and under the caller's layers, the button and panel as the tool
 * `road-attributes`, and the change listeners. Its layers and sources are the SDK's own: never among the caller's
 * layers, sources or the layer description.
 */
internal class SMapRoadAttributesLayer(private val map: SMap, options: SMapRoadAttributesOptions?) {
    private val start = SMapRoadAttributes.start(options)
    val enabled: Boolean get() = start != null
    private val position = options?.position ?: SMapToolPosition.TOP_RIGHT
    private val wantsControl = options?.control != false

    var groups: List<String> = start?.first ?: emptyList()
        private set
    var detail: String = start?.second ?: SMapRoadAttributes.STANDARD
        private set
    var open = false
        private set
    var available: Boolean? = null
        private set
    var reduced = false
        private set
    private var tiles: List<String>? = null
    private var speedTiles: List<String>? = null
    private var speedAsked = false
    private var shownDetail: String? = null
    private var control: SMapRoadAttributesControl? = null
    private val listeners = ArrayList<(SMapRoadAttributesChange) -> Unit>()
    private val infoListeners = ArrayList<(SMapRoadAttributesInfo) -> Unit>()
    /** The tiles have shown a road_attribute_labels point (sPath RA8): the labels along the lines are hidden. */
    var labelsSeen = false
        private set
    /** The country of the roads in view (the routing speed legend's unit, M100), once seen. */
    var country: String? = null
        private set
    val speedUnit: String get() = SMapRoadAttributes.speedUnit(country)
    fun info() = SMapRoadAttributesInfo(reduced && detail == SMapRoadAttributes.FULL, speedUnit)
    fun addInfoListener(l: (SMapRoadAttributesInfo) -> Unit) { infoListeners += l }
    private fun infoChanged(before: SMapRoadAttributesInfo) { val now = info(); if (now != before) infoListeners.toList().forEach { it(now) } }
    private val handler = Handler(Looper.getMainLooper())
    private val headerListener: (String, String) -> Unit = { url, value -> if (value.equals(SMapRoadAttributes.reducedValue, true)) handler.post { reducedSeen(url) } }

    /** Called with the availability once sMap answered (the Flutter and React Native views tell their wrapper). */
    var onAvailable: ((Boolean) -> Unit)? = null

    fun state(): SMapRoadAttributesState? = if (!enabled) null else SMapRoadAttributesState(available, groups, detail, open, reduced)

    fun addListener(l: (SMapRoadAttributesChange) -> Unit) { listeners += l }
    fun removeListener(l: (SMapRoadAttributesChange) -> Unit) { listeners -= l }

    /** Asks for the TileJSON once the map has its node; without the service there is no button, no layer and no error. */
    fun begin() {
        if (!enabled || available != null) return
        map.scope.launch {
            val t = fetch("attributes")
            available = t != null
            tiles = t
            if (t != null) {
                SMapEngineHttp.headerListeners += headerListener
                if (wantsControl) {
                    val c = SMapRoadAttributesControl(map.context, position, this@SMapRoadAttributesLayer) { map.language }
                    control = c
                    map.addTool(SMapRoadAttributes.toolId, c, SMapRoadAttributes.text(map.language, "button"), position)
                    c.render()
                }
                map.currentStyle()?.let { apply(it) }
                if (SMapRoadAttributes.needsSpeeds(groups)) speeds()
            }
            onAvailable?.invoke(t != null)
        }
    }

    private suspend fun fetch(set: String): List<String>? = try {
        val url = SMapRoadAttributes.tileJsonUrl(map.nodeUrl(), set, map.currentToken(), map.mapKey())
        val res = map.indoorHttp.get(url, map.indoorHeaders(), FETCH_TIMEOUT_MILLIS)
        SMapRoadAttributes.tiles(SMapRoadAttributes.parseTileJson(res.status, res.body))
    } catch (e: Exception) {
        null
    }

    private fun speeds() {
        if (speedTiles != null) { map.currentStyle()?.let { apply(it) }; return }
        if (speedAsked) return
        speedAsked = true
        map.scope.launch {
            speedTiles = fetch("speeds")
            speedAsked = speedTiles != null
            map.currentStyle()?.let { apply(it) }
        }
    }

    /** Puts the sources and layers on [style] as the state says (after a style load, a change of detail or categories). */
    fun apply(style: SMapEngineStyle) {
        val t = tiles ?: return
        val srcA = SMapRoadAttributes.attributesSource
        val srcS = SMapRoadAttributes.speedsSource
        try {
            if (style.getSource(srcA) != null && shownDetail != detail) {
                for (l in SMapRoadAttributes.layers(null)) if (l["source"]?.asString == srcA) style.removeLayer(l["id"].asString)
                style.removeSource(srcA)
            }
            if (style.getSource(srcA) == null) {
                reduced = false
                style.addSource(SMapStyleBridge.source(srcA, sourceJson(SMapRoadAttributes.tiles(tilesJson(t), detail)!!)))
                shownDetail = detail
            }
            speedTiles?.let { s -> if (style.getSource(srcS) == null) style.addSource(SMapStyleBridge.source(srcS, sourceJson(s))) }
            val scale = map.resources.displayMetrics.density
            for (id in SMapRoadAttributes.imageIds()) {
                if (style.getImage(id) == null) {
                    val b = SMapRoadAttributes.image(id, scale).apply { density = map.resources.displayMetrics.densityDpi }
                    style.addImage(id, b)
                }
            }
            val vis = SMapRoadAttributes.visibility(groups, labelsSeen)
            val basemap = map.basemapLayerIds()
            for (l in SMapRoadAttributes.layers(map.language, map.basemapFont())) {
                val id = l["id"].asString
                if (style.getSource(l["source"].asString) == null) continue
                if (style.getLayer(id) == null) {
                    val layer = SMapStyleBridge.layer(l, hidden = false)
                    val before = SMapRoadAttributes.beforeId(id, style.layerIds, basemap)
                    if (before != null) style.addLayerBelow(layer, before) else style.addLayer(layer)
                }
                style.getLayer(id)?.setProperties(PropertyFactory.visibility(if (vis[id] == true) Property.VISIBLE else Property.NONE))
            }
        } catch (e: Exception) {
            map.reportError(e)
        }
        control?.render()
    }

    private fun tilesJson(t: List<String>) = JsonObject().apply { add("tiles", JsonArray().also { a -> t.forEach { a.add(it) } }) }

    private fun sourceJson(t: List<String>) = JsonObject().apply {
        addProperty("type", "vector")
        add("tiles", JsonArray().also { a -> t.forEach { a.add(it) } })
        addProperty("minzoom", 0)
        addProperty("maxzoom", 16)
    }

    /** Changes the state; keys left null keep their value. Tells the listeners when something changed. */
    fun set(groups: List<String>?, detail: String?, open: Boolean?) {
        if (!enabled) return
        val before = Triple(this.groups, this.detail, this.open)
        val infoBefore = info()
        groups?.let { this.groups = SMapRoadAttributes.groups(it) }
        detail?.let { this.detail = SMapRoadAttributes.detail(it) }
        open?.let { this.open = it && control != null }
        if (Triple(this.groups, this.detail, this.open) == before) return
        if (available == true && SMapRoadAttributes.needsSpeeds(this.groups)) speeds()
        map.currentStyle()?.let { apply(it) }
        look()
        control?.render()
        val e = SMapRoadAttributesChange(this.groups, this.detail, this.open)
        listeners.toList().forEach { it(e) }
        infoChanged(infoBefore)
    }

    /**
     * What the drawn tiles tell, looked at when the map comes to rest: a road_attribute_labels point (the labels along
     * the lines are then hidden; sPath RA8) and, while the routing speed is on, the country of the roads in view (the
     * legend's unit, M100). Nothing is asked of the engine once there is nothing to learn.
     */
    fun look() {
        if (!enabled || available != true) return
        val vis = SMapRoadAttributes.visibility(groups)
        val labels = SMapRoadAttributes.labelLayers().filter { vis[it] == true }
        if (!labelsSeen && labels.isNotEmpty() && labelsInTiles(labels)) {
            labelsSeen = true
            map.currentStyle()?.let { apply(it) }
        }
        val speed = "smap-ra-speed"
        if ("routing_speeds" !in groups || vis[speed] != true) return
        val c = SMapRoadAttributes.countryOf(map.engineFeatures(viewBox(), listOf(speed)).map { it.properties() }) ?: return
        if (c == country) return
        val before = info()
        country = c
        control?.render()
        infoChanged(before)
    }

    /**
     * Does a loaded tile hold a road_attribute_labels feature? Asked of the source where the engine can (MapLibre:
     * whatever was drawn or hidden by collision), else of the drawn label layers.
     */
    private fun labelsInTiles(layers: List<String>): Boolean {
        val src = map.currentStyle()?.getSource(SMapRoadAttributes.attributesSource)
        val vector = src as? org.maplibre.android.style.sources.VectorSource
        if (vector != null && try { vector.querySourceFeatures(arrayOf(SMapRoadAttributes.labelsSourceLayer), null).isNotEmpty() } catch (e: Exception) { false }) return true
        return map.engineFeatures(viewBox(), layers).isNotEmpty()
    }

    private fun viewBox() = android.graphics.RectF(0f, 0f, map.width.toFloat(), map.height.toFloat())

    fun close() { if (open) set(null, null, false) }

    private fun reducedSeen(url: String) {
        if (reduced || detail != SMapRoadAttributes.FULL) return
        if (!url.contains(SMapRoadAttributes.spec.getAsJsonObject("services")["attributes"].asString + "/")) return
        val before = info()
        reduced = true
        control?.render()
        infoChanged(before)
    }

    fun destroy() { SMapEngineHttp.headerListeners -= headerListener }

    private companion object {
        const val FETCH_TIMEOUT_MILLIS = 10_000L
    }
}

/**
 * The road attributes tool: a round button with the road icon that opens a panel beside it (towards the map's middle):
 * the title, the presets (the one matching the shown categories filled blue), one row per category with its
 * swatch, the routing speed legend while it is on, the full-detail switch and the reduced-detail note.
 */
@SuppressLint("ViewConstructor")
internal class SMapRoadAttributesControl(
    context: Context,
    private val corner: SMapToolPosition,
    private val layer: SMapRoadAttributesLayer,
    private val languageOf: () -> String?,
) : LinearLayout(context) {
    private val button = SMapToolStyle.roundButton(context)
    private val scroll = ScrollView(context)
    private val panel = LinearLayout(context)
    private fun dp(v: Float) = SMapToolStyle.dp(context, v)

    init {
        orientation = HORIZONTAL
        clipChildren = false
        button.addView(RoadIcon(context), FrameLayout.LayoutParams(dp(20f), dp(20f), Gravity.CENTER))
        button.setOnClickListener { layer.set(null, null, !layer.open) }
        panel.orientation = VERTICAL
        val pad = dp(10f)
        panel.setPadding(pad, dp(8f), pad, dp(8f))
        scroll.background = SMapToolStyle.card(context, 8f)
        scroll.elevation = dp(4f).toFloat()
        scroll.addView(panel, ViewGroup.LayoutParams(dp(250f), ViewGroup.LayoutParams.WRAP_CONTENT))
        scroll.visibility = View.GONE
        val right = corner == SMapToolPosition.TOP_RIGHT || corner == SMapToolPosition.BOTTOM_RIGHT
        val bottom = corner == SMapToolPosition.BOTTOM_LEFT || corner == SMapToolPosition.BOTTOM_RIGHT
        gravity = if (bottom) Gravity.BOTTOM else Gravity.TOP
        val size = dp(SMapToolStyle.BUTTON_DP)
        val panelParams = LayoutParams(dp(250f), ViewGroup.LayoutParams.WRAP_CONTENT)
        if (right) { addView(scroll, panelParams.apply { marginEnd = dp(6f) }); addView(button, LayoutParams(size, size)) }
        else { addView(button, LayoutParams(size, size)); addView(scroll, panelParams.apply { marginStart = dp(6f) }) }
    }

    /** Draws the panel again from the layer's state, in the map's language. */
    fun render() {
        val lang = languageOf()
        button.contentDescription = SMapRoadAttributes.text(lang, "button")
        scroll.visibility = if (layer.open) View.VISIBLE else View.GONE
        panel.removeAllViews()
        val t = { k: String -> SMapRoadAttributes.text(lang, k) }
        panel.addView(text(t("button"), 13f, bold = true), LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(4f) })
        val presets = LinearLayout(context).apply { orientation = HORIZONTAL }
        val current = SMapRoadAttributes.presetOf(layer.groups)
        SMapRoadAttributes.presets().forEach { (key, groups) ->
            val on = current == key
            presets.addView(text(t("preset" + key.replaceFirstChar { it.uppercase() }), 12f).apply {
                tag = "preset:$key"
                setPadding(dp(8f), dp(3f), dp(8f), dp(3f))
                setTextColor(if (on) Color.WHITE else SMapToolStyle.TEXT)
                background = SMapToolStyle.card(context, 5f).apply { if (on) { setColor(SMapToolStyle.BLUE); setStroke(0, 0) } }
                isSelected = on
                isClickable = true
                setOnClickListener { layer.set(groups, null, null) }
            }, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(4f) })
        }
        panel.addView(HorizontalScrollView(context).apply { isHorizontalScrollBarEnabled = false; addView(presets) },
            LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(4f) })
        SMapRoadAttributes.spec.getAsJsonArray("groups").forEach { ge ->
            val g = ge.asJsonObject
            val key = g["key"].asString
            val on = key in layer.groups
            val row = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; tag = "group:$key" }
            val box = CheckBox(context).apply {
                isChecked = on
                contentDescription = t(key)
                setOnCheckedChangeListener { _, checked -> layer.set(layer.groups.filter { it != key } + (if (checked) listOf(key) else emptyList()), null, null) }
            }
            row.addView(box, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(Swatch(context, g["swatch"].asString, Color.parseColor(g["color"].asString)), LayoutParams(dp(28f), dp(14f)).apply { marginEnd = dp(7f) })
            row.addView(text(t(key), 12f).apply { setOnClickListener { box.toggle() } }, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            panel.addView(row)
            // In the unit of the roads in view's signs (M100).
            if (key == "routing_speeds" && on) SMapRoadAttributes.legend(layer.speedUnit).let { (title, bins) -> panel.addView(legend(t(title), bins).apply { tag = "legend:" + layer.speedUnit }) }
        }
        val full = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; tag = "detail" }
        val fb = CheckBox(context).apply {
            isChecked = layer.detail == SMapRoadAttributes.FULL
            contentDescription = t("detailFull")
            setOnCheckedChangeListener { _, checked -> layer.set(null, if (checked) SMapRoadAttributes.FULL else SMapRoadAttributes.STANDARD, null) }
        }
        full.addView(fb)
        full.addView(text(t("detailFull"), 12f).apply { setOnClickListener { fb.toggle() } }, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        panel.addView(full, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4f) })
        if (layer.reduced && layer.detail == SMapRoadAttributes.FULL) {
            panel.addView(text(t("reduced"), 12f).apply { setTextColor(Color.rgb(194, 65, 12)) })
        }
    }

    private fun legend(title: String, bins: List<Pair<Int, String>>): View {
        val box = LinearLayout(context).apply { orientation = VERTICAL; setPadding(dp(30f), 0, 0, dp(2f)) }
        box.addView(text(title, 11f).apply { setTextColor(Color.rgb(71, 85, 105)) })
        val labels = SMapRoadAttributes.chips(bins)
        var line = LinearLayout(context).apply { orientation = HORIZONTAL }
        for (i in bins.indices) {
            val label = labels[i]
            val chip = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            chip.addView(View(context).apply { setBackgroundColor(Color.parseColor(bins[i].second)) }, LayoutParams(dp(10f), dp(4f)).apply { marginEnd = dp(3f) })
            chip.addView(text(label, 11f))
            line.addView(chip, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(8f) })
            if (i % 4 == 3) { box.addView(line); line = LinearLayout(context).apply { orientation = HORIZONTAL } }
        }
        if (line.childCount > 0) box.addView(line)
        return box
    }

    private fun text(s: String, sp: Float, bold: Boolean = false) = TextView(context).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(SMapToolStyle.TEXT)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    /** The road icon: two edges and a dashed middle line. */
    private class RoadIcon(context: Context) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = SMapToolStyle.TEXT; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        override fun onDraw(canvas: Canvas) {
            val k = width / 24f
            p.strokeWidth = 2 * k
            canvas.drawLine(8 * k, 3 * k, 5 * k, 21 * k, p)
            canvas.drawLine(16 * k, 3 * k, 19 * k, 21 * k, p)
            canvas.drawLine(12 * k, 4 * k, 12 * k, 7 * k, p)
            canvas.drawLine(12 * k, 11 * k, 12 * k, 14 * k, p)
            canvas.drawLine(12 * k, 18 * k, 12 * k, 20 * k, p)
        }
    }

    /** A category's swatch as the Web SDK's panel draws it. */
    private class Swatch(context: Context, private val kind: String, private val color: Int) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val d = resources.displayMetrics.density
            val cy = h / 2
            p.color = color
            p.pathEffect = null
            when (kind) {
                "marker", "sign" -> {
                    val r = 6 * d
                    if (kind == "marker") { p.style = Paint.Style.FILL; canvas.drawCircle(w / 2, cy, r, p); p.color = Color.WHITE; canvas.drawRect(w / 2 - 4 * d, cy - d, w / 2 + 4 * d, cy + d, p) }
                    else { p.style = Paint.Style.FILL; p.color = Color.WHITE; canvas.drawCircle(w / 2, cy, r, p); p.color = color; p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * d; canvas.drawCircle(w / 2, cy, r - 1.25f * d, p) }
                }
                "ramp" -> {
                    val bins = SMapRoadAttributes.spec.getAsJsonArray("speedBins")
                    val step = w / bins.size()
                    p.style = Paint.Style.FILL
                    bins.forEachIndexed { i, b -> p.color = Color.parseColor(b.asJsonArray[1].asString); canvas.drawRect(i * step, cy - 2 * d, (i + 1) * step, cy + 2 * d, p) }
                }
                "arrow" -> {
                    p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d
                    canvas.drawLine(0f, cy, w, cy, p)
                    p.style = Paint.Style.FILL
                    canvas.drawPath(Path().apply { moveTo(w - 15 * d, cy - 5 * d); lineTo(w - 6 * d, cy); lineTo(w - 15 * d, cy + 5 * d); close() }, p)
                }
                else -> {
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = (if (kind == "label") 8 else 4) * d
                    if (kind == "dash") p.pathEffect = DashPathEffect(floatArrayOf(6 * d, 4 * d), 0f)
                    canvas.drawLine(0f, cy, w, cy, p)
                }
            }
        }
    }
}
