package ca.superroute.smap

import org.maplibre.android.geometry.LatLng

/**
 * How a map starts.
 *
 * @param baseUrl the map service
 * @param nodes node URLs known in advance; the node list is asked of them when [baseUrl] does not answer, so a first
 *   start works while [baseUrl] is down
 * @param token a map token; or
 * @param getToken called at start when no token is given and again 120 s before each token expires
 * @param style the colour scheme
 * @param language label language as a BCP-47 tag (`en`, `fr`, `zh-Hans`, …); the device language when null
 * @param nearest read from the nearest node (asked of [baseUrl], remembered for an hour)
 * @param center initial centre
 * @param zoom initial zoom
 * @param bearing initial bearing in degrees
 * @param pitch initial tilt in degrees
 * @param onError told about errors that happen in the background (a failed token refresh, a style that could not load)
 * @param http replaces the HTTP layer of the SDK's own calls (node list and pings)
 * @param store replaces where the node order is remembered (shared preferences by default)
 * @param apiKey a map key (`smk_…`) whose allowlist names this app (package name and signing certificate); safe to
 *   ship inside the app. With a token too, both are sent and the token is checked first.
 * @param styleName a style by name, used instead of [style] when given: a flavor id (`light`, …) or a saved custom
 *   style `custom:<id>`
 * @param basemap basemap class overrides applied from the first style on (see [SMap.setBasemap])
 * @param offlineRegion show this downloaded offline region ([SMapOffline]) from the start, without the network
 * @param offlineFallback when the map service cannot be reached, show a downloaded region containing the view's centre
 * @param offlineAutoRefresh while online, download again on their own the regions in their last 3 days (billed as a
 *   download)
 * @param tools map tools at start: the ids hidden, where the tools control sits, its texts and a change listener
 *   (see [SMap.addTool])
 */
data class SMapOptions(
    val baseUrl: String = DEFAULT_BASE_URL,
    val nodes: List<String> = emptyList(),
    val token: String? = null,
    val getToken: (suspend () -> String)? = null,
    val style: SMapFlavor = SMapFlavor.LIGHT,
    val language: String? = null,
    val nearest: Boolean = true,
    val center: LatLng? = null,
    val zoom: Double? = null,
    val bearing: Double? = null,
    val pitch: Double? = null,
    val onError: ((Throwable) -> Unit)? = null,
    /** Called once for each feature asked for that this map's engine cannot draw (e.g. "terrain": hillshading only). */
    val onUnsupported: ((String) -> Unit)? = null,
    val http: SMapHttp? = null,
    val store: SMapStore? = null,
    val apiKey: String? = null,
    val styleName: String? = null,
    val basemap: Map<String, SMapBasemapOverride> = emptyMap(),
    val offlineRegion: String? = null,
    val offlineFallback: Boolean = true,
    val offlineAutoRefresh: Boolean = true,
    val tools: SMapToolsOptions = SMapToolsOptions(),
    /**
     * (1.5.0, G36) For a map in a screen that scrolls: one finger scrolls the screen, two move the map, with a hint in
     * the map's language when one finger tries to.
     */
    val cooperativeGestures: Boolean = false,
    /** (1.5.0, G32) false: no notice over the map when it cannot be shown (the UNAVAILABLE event still comes). */
    val unavailableNotice: Boolean = true,
) {
    companion object {
        const val DEFAULT_BASE_URL = "https://tile.srsr.ca"
    }
}

/** A point to draw: position plus any properties (used by labels, taps and data-driven styling). */
data class SMapPoint(
    val lat: Double,
    val lng: Double,
    val properties: Map<String, Any?> = emptyMap(),
)

/** A line through [points]. */
data class SMapLine(
    val points: List<LatLng>,
    val properties: Map<String, Any?> = emptyMap(),
)

/** An area: the first ring is the outline, any further rings are holes. */
data class SMapPolygon(
    val rings: List<List<LatLng>>,
    val properties: Map<String, Any?> = emptyMap(),
)

/** A number, or the name of a feature property holding the number. */
sealed class SMapValue {
    data class Fixed(val value: Double) : SMapValue()
    data class Property(val name: String) : SMapValue()

    companion object {
        fun of(value: Number): SMapValue = Fixed(value.toDouble())
        fun property(name: String): SMapValue = Property(name)
    }
}

/** Draws polygons in 3D: [height] and [base] in metres. */
data class SMapExtrude(
    val height: SMapValue = SMapValue.Fixed(20.0),
    val base: SMapValue = SMapValue.Fixed(0.0),
)

/** Clustering of a point layer. */
data class SMapCluster(
    val radius: Int = 50,
    val maxZoom: Int = 14,
    /**
     * Clusters drawn as views (G6): the bold count on a white disc inside a ring of the points' colours, each colour's
     * share of the cluster's points (the property [SMapClusterRing.property], read from at most [SMapClusterRing.limit]).
     */
    val ring: SMapClusterRing? = null,
    /** Clusters drawn as the app's own views (G6); takes precedence over [ring]. */
    val render: ((SMapClusterInfo) -> android.view.View)? = null,
    /** A tap on a cluster zooms in to where it splits (default true). */
    val zoomOnTap: Boolean = true,
    val onTap: ((SMapClusterInfo) -> Unit)? = null,
)

data class SMapClusterRing(val property: String, val limit: Long = 500, val color: String? = null)

/**
 * How points are drawn.
 *
 * @param cluster groups nearby points into circles sized by their count; a tap zooms in to split them
 * @param icon the name of an image registered with [SMap.addImage]; drawn instead of a circle
 * @param color null draws each feature's simplestyle `marker-color` (`marker-size` sets the radius), else `#2563eb`
 * @param label the property whose value is written under each point
 * @param slot where the layer draws relative to the basemap; null = on top, in the order added
 * @param before an engine or caller layer id to draw under, instead of a slot
 */
data class SMapPointOptions(
    val cluster: SMapCluster? = null,
    val color: String? = null,
    val radius: Float = 6f,
    val strokeColor: String = "#ffffff",
    val icon: String? = null,
    val iconSize: Float = 1f,
    val label: String? = null,
    val minZoom: Float? = null,
    val maxZoom: Float? = null,
    val zIndex: Int = 0,
    val slot: SMapSlot? = null,
    val before: String? = null,
    /** The map's tooltip while a finger rests on a point (G5). */
    val tooltip: SMapTooltip? = null,
    /** Dragging points after a long press (G2). */
    val drag: SMapDragOptions = SMapDragOptions(),
    /** A property naming each point's own image of [SMap.addImage]; wins over [icon]. Such icons all show, however close. */
    val iconProperty: String? = null,
    /** Which part of the icon sits on the point. */
    val iconAnchor: SMapAnchor = SMapAnchor.BOTTOM,
    /** Moves each icon from its anchor, in density-independent pixels. */
    val iconOffsetDp: Pair<Float, Float> = 0f to 0f,
    /** A property holding each point's icon opacity (0…1, default 1). */
    val iconOpacityProperty: String? = null,
    /** A property ordering the points: a higher value draws on top. */
    val sortProperty: String? = null,
    /** The feature's key for states, moves and the calls by key (G19–G23): this property's value, else the feature's id, else `#<index>`. */
    val idProperty: String? = null,
    /** A hovering pointer (mouse, trackpad, stylus) came onto a feature of the layer, or left them (null); never fired by touch (G19). */
    val onHover: ((SMapFeature?, SMapLayerEvent) -> Unit)? = null,
    /** A double tap on a feature; the map does not zoom (G19). */
    val onDoubleClick: ((SMapFeature, SMapLayerEvent) -> Unit)? = null,
    /** A long press on a feature that does not start a drag (G19). */
    val onContextMenu: ((SMapFeature, SMapLayerEvent) -> Unit)? = null,
    /** The feature under a hovering pointer has the state `hover`, so [states] draws it (G21). */
    val hoverState: Boolean = false,
    /** The circle's colour per feature (G20); wins over [color]. */
    val colorValue: SMapFeatureValue<String>? = null,
    /** The circle's radius per feature (G20); wins over [radius]. */
    val radiusValue: SMapFeatureValue<Float>? = null,
    /** The stroke's colour per feature (G20); wins over [strokeColor]. */
    val strokeColorValue: SMapFeatureValue<String>? = null,
    /** The stroke's width per feature (G20; default 1.5). */
    val strokeWidth: SMapFeatureValue<Float>? = null,
    /** The opacity of the circle and its stroke, or of the icon, per feature (G20; default 1). */
    val opacity: SMapFeatureValue<Float>? = null,
    /** Looks per state over the layer's values, e.g. `mapOf("hover" to SMapPointLook(radius = 9f))`; a state named later wins (G21). */
    val states: Map<String, SMapPointLook> = emptyMap(),
    /** The heading of each icon in degrees clockwise (icon and iconProperty points; G24). */
    val rotation: SMapFeatureValue<Float>? = null,
    /** How [rotation] is counted: from north, turning with the map (default), or from the top of the screen. */
    val rotationAlignment: SMapRotationAlignment = SMapRotationAlignment.MAP,
    /** (1.5.0, G25) The colour of an SDF image ([SMapImageOptions.sdf]), per feature; looks per state may give their own. */
    val iconColor: SMapFeatureValue<String>? = null,
    /** (G34) Labels drawn even where they overlap (true), or never over another (false); null: optional, as before. */
    val allowOverlap: Boolean? = null,
    /** (G34) A higher priority is placed first and wins a collision, e.g. `SMapFeatureValue.property("rank")`. */
    val priority: SMapFeatureValue<Float>? = null,
    /** (G34) Label size in pixels, per feature too (default 12). */
    val labelSize: SMapFeatureValue<Float>? = null,
)

/**
 * How lines are drawn. [dash] alternates dash and gap lengths in line widths.
 *
 * @param color null draws each feature's simplestyle `stroke`, `stroke-width` and `stroke-opacity` (falling back to
 *   `#2563eb`, [width] and [opacity])
 */
data class SMapLineOptions(
    val color: String? = null,
    val width: Float = 4f,
    val dash: List<Float>? = null,
    val opacity: Float = 1f,
    val minZoom: Float? = null,
    val maxZoom: Float? = null,
    val zIndex: Int = 0,
    val slot: SMapSlot? = null,
    val before: String? = null,
    /** A property written along each line as a permanent label (G5), every [labelSpacing] pixels. */
    val label: String? = null,
    val labelSpacing: Float = 250f,
    val labelColor: String = "#1f2937",
    /** The map's tooltip while a finger rests on a line (G5). */
    val tooltip: SMapTooltip? = null,
    /** The feature's key for states, moves and the calls by key (G19–G23): this property's value, else the feature's id, else `#<index>`. */
    val idProperty: String? = null,
    /** A hovering pointer (mouse, trackpad, stylus) came onto a feature of the layer, or left them (null); never fired by touch (G19). */
    val onHover: ((SMapFeature?, SMapLayerEvent) -> Unit)? = null,
    /** A double tap on a feature; the map does not zoom (G19). */
    val onDoubleClick: ((SMapFeature, SMapLayerEvent) -> Unit)? = null,
    /** A long press on a feature that does not start a drag (G19). */
    val onContextMenu: ((SMapFeature, SMapLayerEvent) -> Unit)? = null,
    /** The feature under a hovering pointer has the state `hover`, so [states] draws it (G21). */
    val hoverState: Boolean = false,
    /** The colour per feature (G20); wins over [color]. */
    val colorValue: SMapFeatureValue<String>? = null,
    /** The width per feature (G20); wins over [width]. */
    val widthValue: SMapFeatureValue<Float>? = null,
    /** The opacity per feature (G20); wins over [opacity]. */
    val opacityValue: SMapFeatureValue<Float>? = null,
    /** Dashes per feature (G20), in line widths; a feature without one is solid. Wins over [dash]. */
    val dashValue: SMapFeatureValue<List<Float>>? = null,
    /** A property ordering the lines: a higher value draws on top (G20). */
    val sortProperty: String? = null,
    /** Looks per state over the layer's values; a state named later wins (G21). */
    val states: Map<String, SMapLineLook> = emptyMap(),
    /** (1.5.0, G34) Arrowheads along each line in its direction, every so many dp or every share of the line. */
    val arrows: SMapLineArrows? = null,
    /** (G34) Labels drawn even where they overlap (true), or never over another (false). */
    val allowOverlap: Boolean? = null,
    /** (G34) A higher priority is placed first. */
    val priority: SMapFeatureValue<Float>? = null,
    /** (G34) Label size in pixels, per feature too (default 12). */
    val labelSize: SMapFeatureValue<Float>? = null,
)

/**
 * How areas are drawn; with [extrude] they are drawn in 3D and the outline is left out.
 *
 * @param fill null draws each feature's simplestyle `fill`, `fill-opacity`, `stroke` and `stroke-width` (falling
 *   back to `#2563eb`, [opacity] and [outlineWidth])
 */
data class SMapPolygonOptions(
    val fill: String? = null,
    val opacity: Float = 0.35f,
    val outline: String? = null,
    val outlineWidth: Float = 1.5f,
    val extrude: SMapExtrude? = null,
    val minZoom: Float? = null,
    val maxZoom: Float? = null,
    val zIndex: Int = 0,
    val slot: SMapSlot? = null,
    val before: String? = null,
    /** The map's tooltip while a finger rests on an area (G5). */
    val tooltip: SMapTooltip? = null,
    /** The feature's key for states, moves and the calls by key (G19–G23): this property's value, else the feature's id, else `#<index>`. */
    val idProperty: String? = null,
    /** A hovering pointer (mouse, trackpad, stylus) came onto a feature of the layer, or left them (null); never fired by touch (G19). */
    val onHover: ((SMapFeature?, SMapLayerEvent) -> Unit)? = null,
    /** A double tap on a feature; the map does not zoom (G19). */
    val onDoubleClick: ((SMapFeature, SMapLayerEvent) -> Unit)? = null,
    /** A long press on a feature that does not start a drag (G19). */
    val onContextMenu: ((SMapFeature, SMapLayerEvent) -> Unit)? = null,
    /** The feature under a hovering pointer has the state `hover`, so [states] draws it (G21). */
    val hoverState: Boolean = false,
    /** The fill per feature (G20; of an extruded area too); wins over [fill]. */
    val fillValue: SMapFeatureValue<String>? = null,
    /** The fill's opacity per feature (G20); wins over [opacity]. */
    val opacityValue: SMapFeatureValue<Float>? = null,
    /** The outline's colour per feature (G20); wins over [outline]. */
    val outlineValue: SMapFeatureValue<String>? = null,
    /** The outline's width per feature (G20); wins over [outlineWidth]. */
    val outlineWidthValue: SMapFeatureValue<Float>? = null,
    /** Dashes of the outline in its widths, e.g. `SMapFeatureValue.of(listOf(2f, 2f))`, or per feature (G20). */
    val outlineDash: SMapFeatureValue<List<Float>>? = null,
    /** A property ordering the areas: a higher value draws on top (G20). */
    val sortProperty: String? = null,
    /** Looks per state over the layer's values; a state named later wins (G21). */
    val states: Map<String, SMapPolygonLook> = emptyMap(),
)

/**
 * A heat map of points (G7).
 *
 * @param weight per point (default 1); @param colors low to high (the first at no density is made transparent), or
 *   null for the Web SDK's six-stop ramp
 */
data class SMapHeatmapOptions(
    val weight: SMapValue? = null,
    val radius: Float = 20f,
    val intensity: Float = 1f,
    val opacity: Float = 0.8f,
    val colors: List<String>? = null,
    val minZoom: Float? = null,
    val maxZoom: Float? = null,
    val zIndex: Int = 0,
    val slot: SMapSlot? = null,
    val before: String? = null,
    /** (1.5.0, G33) Pixels each point's heat fades over past [radius] (the spot reaches radius + blur). */
    val blur: Float? = null,
    /** (G33) Heat that shows at all is at least this opaque (0–1), faded in below a density of 0.05. */
    val minOpacity: Float? = null,
)

/** A cluster as its view and its tap see it (G6). */
class SMapClusterInfo internal constructor(
    val id: Int,
    val count: Int,
    val properties: Map<String, Any?>,
    val position: org.maplibre.android.geometry.LatLng,
    private val leavesOf: (Long) -> List<org.maplibre.geojson.Feature>,
) {
    /** The points inside the cluster (at most [limit]). */
    fun leaves(limit: Long = Long.MAX_VALUE): List<org.maplibre.geojson.Feature> = leavesOf(limit)
}

/** Where a Style Spec layer is drawn: under [before] (an engine or caller layer id), else in [slot]; neither = on top. */
data class SMapStyleLayerOptions(
    val before: String? = null,
    val slot: SMapSlot? = null,
    val zIndex: Int = 0,
)

/**
 * How [SMap.addData] reads and draws a file.
 *
 * @param format one of [SMapFormats.FORMATS]; guessed from [fileName] and the content when null
 * @param lat / [lng] the coordinate columns of a CSV file (guessed when null)
 * @param points / [lines] / [polygons] how each part is drawn (no colour = simplestyle)
 */
data class SMapDataOptions(
    val format: String? = null,
    val lat: String? = null,
    val lng: String? = null,
    val fileName: String? = null,
    val points: SMapPointOptions = SMapPointOptions(),
    val lines: SMapLineOptions = SMapLineOptions(),
    val polygons: SMapPolygonOptions = SMapPolygonOptions(),
)

/** The default colour of points, lines and areas. */
const val DEFAULT_COLOR = "#2563eb"

/**
 * Imagery in place of the street map (G8): raster tiles over the basemap's land, water and roads and under its labels,
 * which stay with [labels] (a hybrid map). Google and Bing tiles are refused (only [SMap.setGoogleBase] reads Google).
 */
data class SMapBaseImagery(
    val tiles: List<String>,
    val tileSize: Int = 256,
    val minZoom: Float? = null,
    val maxZoom: Float? = null,
    val attribution: String? = null,
    val tms: Boolean = false,
    val labels: Boolean = false,
)

/**
 * Relief (G11): elevation tiles ([encoding] "terrarium" or "mapbox") with hillshading under the roads. The relief
 * itself is drawn where the engine can (on this engine: hillshading only, reported to onUnsupported as "terrain").
 */
data class SMapTerrain(
    val tiles: List<String>,
    val encoding: String = "terrarium",
    val tileSize: Int = 256,
    val maxZoom: Float = 15f,
    val attribution: String? = null,
    val exaggeration: Float = 1f,
    val hillshade: Boolean = true,
    val hillshadeExaggeration: Float = 0.35f,
    val shadowColor: String? = null,
    val highlightColor: String? = null,
)

/**
 * Google's base maps (G10), read straight from Google with a Map Tiles API [session] the app's server made with its
 * own Google [key] (or the [tiles] template and the [viewport] address, both carrying session and key).
 */
data class SMapGoogleBase(
    val session: String? = null,
    val key: String? = null,
    val tiles: String? = null,
    val viewport: String? = null,
    val maxZoom: Float = 22f,
    val labels: Boolean = false,
    val onFail: (() -> Unit)? = null,
)

/**
 * One base map of the layer switcher (G8): a style (a flavor id or `custom:<id>`), imagery, or (1.5.0, G37) Google's
 * map, shown through [SMap.setGoogleBase] when chosen and taken off when another base is.
 */
data class SMapLayersBase(
    val id: String,
    val label: String,
    val style: String? = null,
    val imagery: SMapBaseImagery? = null,
    val google: SMapGoogleBase? = null,
)
/** One overlay of the layer switcher: the caller layers it shows or hides. */
data class SMapLayersOverlay(val id: String, val label: String, val layers: List<String>, val visible: Boolean = true)

/** The layer switcher tool (G8): base maps one at a time, overlays each on or off, each change reported. */
data class SMapLayersTool(
    val base: List<SMapLayersBase> = emptyList(),
    val overlays: List<SMapLayersOverlay> = emptyList(),
    val value: String? = null,
    val onChange: ((base: String?, overlays: List<String>) -> Unit)? = null,
)
