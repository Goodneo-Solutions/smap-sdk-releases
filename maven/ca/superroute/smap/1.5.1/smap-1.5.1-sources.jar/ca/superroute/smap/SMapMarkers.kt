package ca.superroute.smap

import android.view.View
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.Point

/** Which point of a marker's view is at its position. */
enum class SMapAnchor(val x: Float, val y: Float) {
    CENTER(0.5f, 0.5f), TOP(0.5f, 0f), BOTTOM(0.5f, 1f), LEFT(0f, 0.5f), RIGHT(1f, 0.5f),
    TOP_LEFT(0f, 0f), TOP_RIGHT(1f, 0f), BOTTOM_LEFT(0f, 1f), BOTTOM_RIGHT(1f, 1f),
}

/**
 * Custom markers (G1): the app's own view at each point, laid out over the map while in view.
 *
 * @param render the view of one feature (called when it first comes into view and again when its properties change);
 *   it must not have a parent
 * @param offsetDp added to the place, in density-independent pixels
 * @param idProperty the property naming each feature (getMarker and keeping views across setData); else the feature's
 *   id, else `#<index>`
 */
data class SMapCustomMarkerOptions(
    val render: (Map<String, Any?>) -> View,
    val anchor: SMapAnchor = SMapAnchor.CENTER,
    val offsetDp: Pair<Float, Float> = 0f to 0f,
    val opacity: SMapFeatureValue<Float>? = null,
    val zIndex: SMapFeatureValue<Int>? = null,
    val idProperty: String? = null,
    val minZoom: Double? = null,
    val maxZoom: Double? = null,
    val onTap: ((SMapFeature) -> Unit)? = null,
    val tooltip: SMapTooltip? = null,
    val drag: SMapDragOptions = SMapDragOptions(),
    /**
     * Draw each view once into an image and let the map draw the images, as it draws points: tens of thousands pan
     * smoothly, but a view is a still picture (no animation, no controls, no content that changes by itself). Taps,
     * tooltips, dragging, opacity and zIndex work as for live views; getMarker answers null. Features that look the
     * same share one image.
     */
    val snapshot: Boolean = false,
    /** What makes two features look the same (same key, one image); else all their properties. */
    val snapshotKey: ((Map<String, Any?>) -> String)? = null,
    /** A hovering pointer came onto a marker of the layer, or left them (null); never fired by touch (G19). */
    val onHover: ((SMapFeature?, SMapLayerEvent) -> Unit)? = null,
    /** A double tap on a marker; the map does not zoom (G19). */
    val onDoubleClick: ((SMapFeature, SMapLayerEvent) -> Unit)? = null,
    /** A long press on a marker that does not start a drag (G19). */
    val onContextMenu: ((SMapFeature, SMapLayerEvent) -> Unit)? = null,
    /** The marker under a hovering pointer has the state `hover` (G21). */
    val hoverState: Boolean = false,
    /**
     * Called after a marker's state changed (setFeatureState, hoverState) and when its view is made while it has a
     * state, with its key, its state and its view (null while it has none), so the app restyles the view (G21).
     */
    val onStateChange: ((key: String, state: Map<String, Any?>, view: View?) -> Unit)? = null,
    /** The view's heading in degrees clockwise, turned about its anchor (G24). */
    val rotation: SMapFeatureValue<Float>? = null,
    /** How [rotation] is counted: from north, turning with the map (default), or from the top of the screen. */
    val rotationAlignment: SMapRotationAlignment = SMapRotationAlignment.MAP,
)

/** The engine's name of an anchor (`top-left`, …). */
internal val SMapAnchor.engineName: String get() = name.lowercase().replace('_', '-')

/**
 * What a custom marker layer holds, without any view work: one item per point feature by key, kept across new data
 * (moved, or marked to render again when its properties changed), and which items are in view.
 */
internal class SMapMarkerSet<V>(val idProperty: String?) {
    class Item<V>(val key: String, var index: Int, var feature: Feature) {
        var view: V? = null
        var shown = false
        var stale = true
        var dragAt: DoubleArray? = null
        val lng: Double get() = dragAt?.get(0) ?: (feature.geometry() as Point).longitude()
        val lat: Double get() = dragAt?.get(1) ?: (feature.geometry() as Point).latitude()
    }

    val items = ArrayList<Item<V>>()
    private val byKey = HashMap<String, Item<V>>()

    fun item(key: String): Item<V>? = byKey[key]

    fun keyOf(f: Feature, i: Int): String = SMapEngineData.keyOf(f, i, idProperty)

    /** New data: returns the items no longer there (their views are the caller's to take away). */
    fun update(data: FeatureCollection): List<Item<V>> {
        val old = HashMap(byKey)
        items.clear()
        byKey.clear()
        data.features()?.forEachIndexed { i, f ->
            if (f.geometry() !is Point) return@forEachIndexed
            val key = keyOf(f, i)
            val item = old.remove(key)?.also {
                if (signature(it.feature) != signature(f)) it.stale = true
                it.feature = f
                it.index = i
            } ?: Item<V>(key, i, f)
            items += item
            byKey[key] = item
        }
        return old.values.toList()
    }

    companion object {
        private val POSITION_KEYS = setOf("lng", "lat", "lon", "longitude", "latitude", "coordinates")

        /** A feature's properties without its position: a marker that only moved is not rendered again. */
        fun signature(f: Feature): String {
            val p = f.properties() ?: return "{}"
            val copy = com.google.gson.JsonObject()
            p.entrySet().forEach { (k, v) -> if (k !in POSITION_KEYS) copy.add(k, v) }
            return copy.toString()
        }

        /** Whether a projected point is laid out: within [margin] pixels of a view of [w] × [h]. */
        fun inView(x: Float, y: Float, w: Int, h: Int, margin: Float): Boolean =
            !x.isNaN() && !y.isNaN() && x >= -margin && y >= -margin && x <= w + margin && y <= h + margin
    }
}
